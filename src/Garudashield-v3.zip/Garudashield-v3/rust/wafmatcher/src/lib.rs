//! wafmatcher — a C-ABI WAF rule matcher used by GarudaShield v3 via cgo FFI.
//!
//! Rules are compiled once with `waf_create` (case-insensitive regexes, exactly
//! mirroring the Go engine's `(?i)` patterns) and scored per request with
//! `waf_score`. This lets the hot WAF path run in Rust while the Go engine
//! remains the source of truth and fallback.

use std::ffi::CStr;
use std::os::raw::{c_char, c_int, c_void};

use regex::Regex;

struct Matcher {
    rules: Vec<(Regex, i32)>,
}

/// Compile `n` rules. `patterns` is an array of NUL-terminated C strings;
/// `scores` is a parallel array of i32. Invalid patterns are skipped. Returns
/// an opaque handle (NULL on bad input).
#[no_mangle]
pub extern "C" fn waf_create(
    patterns: *const *const c_char,
    scores: *const c_int,
    n: c_int,
) -> *mut c_void {
    if patterns.is_null() || scores.is_null() || n <= 0 {
        return std::ptr::null_mut();
    }
    let count = n as usize;
    let mut rules: Vec<(Regex, i32)> = Vec::with_capacity(count);
    unsafe {
        for i in 0..count {
            let p = *patterns.add(i);
            if p.is_null() {
                continue;
            }
            let pat = CStr::from_ptr(p).to_string_lossy().into_owned();
            match Regex::new(&pat) {
                Ok(re) => {
                    let sc = *scores.add(i);
                    rules.push((re, sc));
                }
                Err(_) => continue,
            }
        }
    }
    let m = Matcher { rules };
    Box::into_raw(Box::new(m)) as *mut c_void
}

/// Return the cumulative score of all rules matching `input` (NULL-safe).
#[no_mangle]
pub extern "C" fn waf_score(matcher: *mut c_void, input: *const c_char) -> c_int {
    if matcher.is_null() || input.is_null() {
        return -1;
    }
    let m = unsafe { &*(matcher as *const Matcher) };
    let cstr = unsafe { CStr::from_ptr(input) };
    let text = match cstr.to_str() {
        Ok(t) => t,
        Err(_) => return -1,
    };
    let mut total: i32 = 0;
    for (re, sc) in &m.rules {
        if re.is_match(text) {
            total += *sc;
        }
    }
    total
}

/// Free a matcher handle created by `waf_create`.
#[no_mangle]
pub extern "C" fn waf_destroy(matcher: *mut c_void) {
    if matcher.is_null() {
        return;
    }
    unsafe {
        let _ = Box::from_raw(matcher as *mut Matcher);
    }
}

/// Return the number of rules actually compiled into the matcher. The engine
/// compares this against the number of rules it sent: a mismatch means Rust
/// silently skipped invalid patterns (fail-loud, not fail-silent).
#[no_mangle]
pub extern "C" fn waf_count(matcher: *mut c_void) -> c_int {
    if matcher.is_null() {
        return -1;
    }
    let m = unsafe { &*(matcher as *const Matcher) };
    m.rules.len() as c_int
}
