# AGENTS.md — GarudaShield v3

Panduan wajib baca bagi agent coding (Claude Code, Hermes, dsb.) yang bekerja di
repo ini. Tujuannya: agent langsung paham konteks, arsitektur, dan konvensi tanpa
harus menjelajah ulang.

## Apa ini

GarudaShield v3 = rewrite **polyglot** dari GarudaShield v2 (Node.js murni) menjadi
sistem proteksi DDoS multi-layer. Repo v2 ada di `../garudashield` (REFERENSI
PARITAS, jangan diubah dari sini). v3 mengejar **100% paritas fitur v2** lalu
konsolidasi seluruh frontend v2 ke satu app Next.js.

- **Stack**: Go 1.24+ (`net/http`, tanpa framework berat) = engine/edge proxy +
  kontrol plane; Rust cdylib (`rust/wafmatcher`) = WAF matcher via FFI (fallback
  pure-Go); Next.js 14 + React 18 + TypeScript + Tailwind + **Motion** (motion/react
  v13) = satu app web (landing/status/features/docs/chat/dashboard); Redis 7 (opsional)
  = state store L2 dengan fallback lokal otomatis.
- **Modul utama**: `cmd/garudashield` (boot + reverse proxy + `/health`,`/stats`),
  `internal/` (shield orchestrator, defense/* = layer4/layer7/waf/fingerprint/
  challenge/anomaly/reputation/analyzer, access, admin, cluster, statestore, geo,
  storage, ratelimit, token, status, config, alerts, reqview).

## Prinsip desain (TERKUNCI — jangan langgar)

1. **Paritas v2 + fail-closed.** Urutan pipeline, threshold (skor ≥60 block /
   20–59 challenge), budget evaluasi 50 ms (di v3 `budgetMs ≤ 0` = fail-closed
   instan). Quirk v2 yang **disengaja dipertahankan**: L7 banyak pelanggaran = hard
   block walau skor <50; WAF skor kumulatif ≥50 block; challenge hash JS int32
   wraparound; token `gs_ok` `<expiry>.<hmac>` terikat IP; reputation key
   `subnet:`/`reason:`.
2. **Hybrid state L1/L2.** In-process memory di hot path; Redis persistent source of
   truth + koordinasi lintas node. Redis mati → otomatis lokal (mode v2).
3. **Rust di belakang interface.** `Matcher` dengan fallback Go; FFI aktif hanya
   bila DLL ada (`WAFMATCHER_DLL` / candidate path, no cgo).
4. **Self-resilient security.** trust-proxy IP hardening, admin API auth
   (X-GS-Key / Bearer, timing-safe), attack-suite release gate.

## Konvensi & perintah

- **Build/test engine**: `go build ./...`, `go vet ./...`,
  `go test ./internal/... ./cmd/... -count=1` (semua harus hijau sebelum commit).
- **Dashboard**: `cd dashboard && npm install && npm run build` (Node 20+).
  `npm run dev` untuk dev (port 3000). `motion` sudah di package.json.
- **Run lokal**: `.\run.ps1` (Win) / `./run.sh` (WSL/Linux) / `make dev` /
  `docker compose up --build`. Jalankan engine (:8080) + web (:3000).
- **Rust WAF**: `cargo check` di `rust/wafmatcher` (opsional, hanya untuk cdylib).
- **CI**: `.github/workflows/ci.yml` — go 1.24, cargo check, tsc, `go test`,
  cron harian.
- **Commit**: identitas lokal `hkurdev <ah.kurniawan27@gmail.com>`. Tulis ke
  `log.md` (lihat format sectionnya) SETIAP selesai chunk pekerjaan.
- **Bahasa**: komentar kode & log.md campur ID/EN (gaya penulis asli). UI text
  Indonesia.

## Web / BFF

- Satu app Next.js di `dashboard/`. BFF di `dashboard/app/api/gs/[...path]/route.ts`
  menyuntikkan admin key server-side dan meneruskan `/api/gs/<x>` ke engine
  `/api/<x>` (SSE & strip hop-by-hop headers). Dashboard memanggil lewat helper
  `gsGet`/`gsPost` (`dashboard/lib/api.ts`).
- **JANGAN** hardcode admin key di client. **JANGAN** buat endpoint baru di engine
  tanpa menambahkannya ke `internal/admin/admin.go` (dan update docs/CUTOVER.md).
- Path admin identik v2: `/api/stats`, `/api/blocklist`, `/api/whitelist`,
  `/api/top`, `/api/logs`, `/api/reputation`, `/api/mode`, `/api/geo` (baru),
  `/api/status` (publik), `/api/whoami` (publik, baru).

## GeoIP (fitur terbaru — Fase 9)

- `internal/geo` = resolver MMDB offline (country + ASN), nil-safe. Aktif bila
  `geo.enabled=true` di config + DB ada.
- Unduh DB: `tools/fetch-geodb.ps1` → `data/GeoIP/{geoip-country,geoip-asn}.mmdb`
  (script men-renama dari GeoLite2-* upstream ke `geoip-*` agar cocok default config).
- Endpoint: `GET /api/geo` (auth, agregasi top-talkers) & `GET /api/whoami` (publik).
- Dashboard GeoMap (`dashboard/app/dash/page.tsx`) konsumsi `/api/gs/geo`.
- Test: `TestLookupRealMMDB` jalan bila DB ada (skip otomatis bila tidak); CI
  sekarang men-download DB sebelum `go test`. whoami/geo sudah di dok CUTOVER.md.

## Status (per 2026-10-08)

- Engine v3: paritas v2 praktis lengkap (Fase 0–7 + P0–P4). Semua gate hijau.
- Web: konsolidasi selesai (Fase 8 B0–B5), 18 rute build hijau, pakai Motion.
- **Redesign UI (Batch 19–21)**: palet slate/blue/teal/orange + Geist Sans ramp 60/25/5,
  `globals.css` token `--gs-*`, font Geist di `layout.tsx`, kartu pricing reworked,
  favicon `app/icon.svg`. Validasi: tsc, `next build`, audit kontras 12 job
  (a11y 0), sweep CDP konsol/network, matriks integrasi API (semua 200), SSE
  `/stats/stream` live via BFF, login E2E OK. Stack lokal `run.ps1` + origin
  `:3001` untuk screenshot.
- **Ekspos fitur penuh (Batch 22, 2026-10-08)**: seluruh admin API diekspos dari
  dashboard — whitelist detailed, reputation reset, WAF module toggle + custom
  rules (POST/DELETE), rate-limit policy editor, backup/restore, emergency mode,
  alerts log & test, Logs pause/play. BFF dukung `DELETE` (`gsDelete`); Icons +
  `pause`/`play`; `IconName` di-import eksplisit di `page.tsx`. Tsc 0 error
  (setelah regresi transient dari edit one-liner PowerShell difix — JANGAN edit
  `page.tsx` via `node -e`/PowerShell one-liner, pakai tool edit presisi),
  `next build` hijau, audit 12 job 0 contrast/overflow, E2E 15 tab 0 error,
  integrasi BFF live semua 200. Admin token kini `gcgB2SFxzEzWIyPk-xmQqKWSw_iJdu3HbB1nsxn4314`
  (`garudashield.local.json` -> `admin.secret`; `.env.local` `GS_API_KEY` sama).
- **GeoIP konsisten + aktif (Batch 23, 2026-10-08)**: `tools/fetch-geodb.ps1` kini
  men-renama output ke `geoip-*.mmdb` (sebelumnya `GeoLite2-*` tidak pernah cocok
  dengan default config); `geo_test.go` mengikuti nama `geoip-*`; CI men-download
  DB sebelum `go test` sehingga `TestLookupRealMMDB` benar-benar tidak lagi skip.
  `garudashield.local.json` kini `geo.enabled=true`; `/api/geo` live `available:true`
  via BFF (`countries:[]` karena seluruh traffic lokal 127.0.0.1 = degradasi
  graceful). Deck ulang stack local live: engine :8080 + web :3000 + origin :3001.
- **Design polish light corporate (Batch 24, 2026-10-08)**: palet "LIGHT CORPORATE
  CYBER DEFENSE" — bg `#F5F7FA` + kartu putih + navy `#0A192F` + gold `#D4AF37`;
  crimson `#DC3545` khusus threat, green `#20C997` status; proporsi ±60% putih/abu,
  25–30% navy, 8–10% gold. Font Geist → **Plus Jakarta Sans** (400–800, Google Fonts
  di `layout.tsx`). Aturan a11y: gold murni hanya untuk fill/logo/CTA di atas navy;
  teks gold di atas putih pakai warn-ink `#8A6D1F`; focus-visible navy; teks hijau
  `#0B7A57`; sidebar navy pakai warna opaque (bukan rgba-white) karena auditor CDP
  melempar alpha<0.9 ke parent → ratio 1. Validasi: tsc + `next build` hijau, audit
  12 job 0 contrast/0 overflow, 15 tab 0 error,   integ BFF 0 gagal.
- **Portal pelanggan: config proteksi per-domain + background interaktif + deploy
  produksi (Batch 44, 2026-10-11)**: pelanggan mengatur proteksi domain-nya
  sendiri dari portal (subset knob admin), ditegakkan **di edge, fail-closed**
  (policy kosong tidak melemahkan proteksi global). Engine:
  `internal/policy/{policy.go,store.go}` (model + validasi + store Postgres
  `domain_policies`, PK domain, FK tenant ON DELETE CASCADE),
  `internal/shield/domains.go` (registry runtime per-domain; `Apply` = copy global
  lalu overlay policy; `StartPolicyWatcher` rekonsiliasi peer dari Postgres tiap
  ~poll, tanpa bus khusus), hot path `evaluate/shield/geo_policy` pakai runtime
  `rt` per-domain, migrasi di `internal/db/db.go`, API di
  `internal/admin/policy.go` (tenant `/api/v1/policies` &
  `/api/v1/assets/{id}/policy` GET/POST/DELETE; operator `/api/admin/policy`
  GET/POST/DELETE), wiring di `cmd/garudashield/main.go`. Scope per-domain:
  Mode/BudgetMs/VerifyOnFirstVisit/Layer7/WAF(+customRules)/RateLimit/Geo;
  blocklist/whitelist/L4/flood/fingerprint/challenge/anomaly/reputation tetap
  GLOBAL. Web: `app/portal/PolicyEditor.tsx` (di-wire ke `portal/page.tsx`,
  tombol "Atur proteksi") + `components/MouseGlow.tsx` (latar interaktif, mati saat
  reduced-motion/pointer kasar, dipasang di `app/layout.tsx`). Deploy kode saja ke
  `/opt/garudashield` dua node (backup `/root/backup-pre-policy-20261011/`) +
  `build engine web` + `up -d`; migrasi tabel otomatis. Verifikasi: kedua node
  `nodes=2`/`onlineNodes=2`; E2E API produksi (asset + `POST policy emergency` ->
  edge `Host:` => **403 `Blocked: emergency-mode`** -> DELETE revert); publik
  `/logo.jpg`+`/api/gs/status`+`/api/status` 200, `/portal` 403 (gate PoW).
  Validasi lokal: `go build/vet/test` hijau, tsc 0, `next build` 19/19, E2E
  portal browser CDP (login -> Atur proteksi -> set emergency -> Simpan -> 200,
  `CONSOLE_PROBLEMS []`). **Catatan**: cookie sesi engine `Secure` -> E2E curl di
  `http://engine:8080` wajib kirim `Cookie: gs_session=<v>` dari header
  `Set-Cookie` (jar `-c/-b` diabaikan di http); `next build` saat dev server hidup
  merusak `.next`; verdict `block` (emergency) dievaluasi SEBELUM gate akses. JANGAN edit
  `page.tsx` via `node -e`/PowerShell one-liner — backtick/`${}` merusak file.
- **Ringkasan L3 fix + landing anchor (Batch 25, 2026-10-08)**: bug terpotong pada Panel
  "Traffic & risiko" (Overview L3) — grid inner lama `grid-cols-2 ... sm:grid-cols-4`
  memaksa 4 kolom saat panel menyempit (1024–1279) di kolom kiri `1.35fr` → sel 72–94px,
  label/value wrap. Ubah menjadi `grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4
  lg:grid-cols-2 xl:grid-cols-4` (1024–1279 → 2 kolom, ≥1280 → 4, 640–1023 full-width → 4,
  mobile → 2). Landing diperkaya: capability band (L4+L7/50 ms/Fail-closed/Go+Rust) dari
  kartu putih flat → tile navy gradient + value gold `#D4AF37` + `text-slate-300`; NETWORK
  CTA putih → panel navy gradient, heading putih, tombol utama gold `bg-[#D4AF37] text-navy`
  (hover `#C9A227`) + tombol sekunder outline putih. **Ilmu baru**: `gs-gradient` hanya set
  background-image (computed bg transparent) → auditor CDP walk-up ke body putih = false
  fail; selalu sertakan `bg-[#0A192F]` (opaque) pada elemen ber-gs-gradient berisi teks
  terang. Validasi: tsc 0 error, `next build` hijau, audit 12 job 0 contrast/0 overflow,
  15 tab 0 error, integ 0 gagal, l3scan 1024–1180 cols=2 (sel 168–213px) 0 terpotong.
  Breadcrumb topbar juga dirapikan (`truncate min-w-0 max-w-[220px]` — tanpa min-w-0
  flex tidak shrink jadi teks terpotong tanpa ellipsis). Ilmu tambahan: `go` tidak di
  PATH saat `go run` dari PowerShell — engine di-restart via `bin\gs.exe -config
  garudashield.local.json` langsung.
- **Produksi 2 node + edge di depan engine (Batch 36–37, 2026-10-11)**: node-1
  `172.236.152.58` (edge) + node-2 `172.104.37.113` (peer), Docker Compose di
  `/opt/garudashield`. Caddy node-1 **mem-front engine** untuk semua GET/HEAD
  halaman (WAF+L7) lalu engine site-proxy ke `web:3000`; `POST/PUT/...`
  dan `/api/*` (BFF/login) langsung ke web (engine edge membaca body). Verifikasi
  browser JS di entry pertama (`access.enabled+protectAll`, cookie `gs_access`
  HMAC terikat IP `ok:<ip>`, TTL 8 jam), redirect `301 /status` untuk UA probe
  monitor, `mem_limit` engine 1g/web 2g, `handle_errors` → static maintenance page.
  **Pelajaran**: domain yang dilayani Caddy → web LANGSUNG saat flood = Next.js
  OOM → Electron DNS docker timeout → 502; shield harus selalu di jalur.
  **15 Tbps tak mungkin di 2 VPS** — volumetric butuh scrub upstream/anycast.
- **Verifikasi browser JS ganti captcha (Batch 38, 2026-10-11)**: entry gate kini
  halaman self-contained (HTML/CSS/JS inline) yang menyelesaikan SHA-256
  proof-of-work (`crypto.subtle`, diff 4 = 16 bit) + kirim fingerprint ringan
  (`fp.wd` = navigator.webdriver) ke `POST /_captcha/verify` (JSON). Server
  (`internal/access.IssueChallenge`/`VerifyChallenge`, id stateless `1*rand*
  c|ip|unix|diff*sig`) menolak: HMAC rusak, IP beda, kedaluwarsa >5 mnt, PoW
  salah, `Sec-Fetch-Site` kosong (klien HTTP mentah), atau `fp.wd=true`. Cookie
  akses kini **IP-bound** (`hasValidAccess` cek payload `ok:<ip>`). GenerateCaptcha/
  VerifyCaptcha SVG lama tetap ada (paritas v2 + test). `Caddyfile.node1`
  TIDAK berubah (`@captcha` sudah sebelum `@write`).
- **Logo produksi + fix Docker web (Batch 39, 2026-10-11)**: `dashboard/Dockerfile`
  stage `run` dulu TIDAK meng-copy `/app/public` → `/logo.jpg` 404 &
  `/_next/image` 400 di container (logo produksi kosong, hanya tampil di dev).
  Ditambah `COPY --from=build /app/public ./public`. `dashboard/public/logo.jpg`
  diganti (Pinterest, 487x513, 37 kB). Node-1 `access.exemptPaths` +`/logo.jpg`
  (aset brand publik). Live: `/logo.jpg` 200, `/_next/image` 200, gate `/` tetap
  403. Catatan: ganti config node-1 = `docker compose ... restart engine`
  (bind-mount berubah tidak memicu recreate).
- **Respons DDoS cepat + static-under-flood (Batch 40, 2026-10-11)**: flood-mode
  kini **murni RPS** (tanpa baseline/`AttackActive`) dan mengonsumsi
  `shield.floodRpsThreshold`/`floodMinMs` (fallback v2 3000/15000) → spike
  memicu mode banjir <=2s (1 tick statsLoop); saat ON per-IP rate diturunkan ke
  1/5. `main.go`: verdict `challenge` dgn host/path ter-gate → diserahkan ke gate
  (halaman PoW **statis**, nol origin; cookie `gs_access` dihormati → tidak loop),
  JSON 429 hanya utk klien API non-gated. Config kedua node:
  `floodRpsThreshold:400`, `floodMinMs:10000`, `budgetMs:5->25`, rate/l4
  diperketat. Benchmark kontrol: **block 0.31s**, **flood-mode 1.65s** (<3s).
  Benchmark pakai container python di network `garudashield_edge` + 16 IP
  spoofed `X-Forwarded-For`, target path pemicu-WAF (tak menyentuh Next.js).
  Kedua node `onlineNodes=2` sehat.
- **node-2 jadi edge AKTIF (Batch 41, 2026-10-11)**: node-2 kini menjalankan
  `caddy`(80/443)+`web`(dashboard)+`engine`+`postgres`+`upstream` via override
  baru `docker-compose.edge2.yml` di atas `docker-compose.peer.yml`. Config
  node-2 ditambah `sites` (`gg.garudashield.my.id -> web:3000`) + `access` gate
  (protectAll, exempt `/logo.jpg` dll) mirror node-1. Caddyfile live node-1
  disalin apa adanya ke node-2. Verifikasi lokal: `/`->403 PoW, `/logo.jpg`->200,
  `/_captcha/verify` ada, BFF `/api/gs/stats` 200, cluster `onlineNodes=2`.
  **Sisa**: tambah A-record KEDUA `gg.garudashield.my.id A 172.104.37.113` di
  Clouden.id (DNS round-robin); setelah itu Caddy node-2 ambil cert otomatis.
  Catatan: IP uji kena `reputation-block` (auto-block) — bersihkan via
  `POST /api/unblock` + `POST /api/reputation/reset` (secret = GS_ADMIN_SECRET).
  Gate cookie `gs_access` pakai `GS_ACCESS_SECRET` sama + IP-bound → mulus lintas
  node.
- **Round-robin + TLS dua node via shared-Redis ACME (Batch 42, 2026-10-11)**:
  `gg` kini 2 A-record (`172.236.152.58` + `172.104.37.113`, SOA `2026101121`)
  — authoritative + fresh resolver return 2 IP; cache publik expiry ≤1 jam.
  Caddy pakai image custom `garudashield-caddy-shared` (Dockerfile di
  `/opt/garudashield/caddy-shared/`; `golang:1.24-alpine` + xcaddy v2.8.4 +
  `github.com/pberkel/caddy-storage-redis@v1.5.0` — WAJIB v1.5.0 utk Caddy
  ≤2.10.x, butuh Go ≥1.24). Global `persist_config off` (**bukan `false`**)
  + `storage redis` (node-1 `redis:6379`, node-2 `172.236.152.58:6379`;
  password `REDIS_PASSWORD` dari `.env`). Deploy: tambahkan
  `docker-compose.shared.yml` di command `up -d caddy`. Hasil: kedua node serve
  **sertifikat LE identik** (serial `0562760982F6953F3BE9D84E43D6720050ED`,
  NotAfter 2027-09-01); renewal otomatis cukup di satu node, redis mempropagasi.
  Verifikasi ulang (ganti config node-1 = `docker compose ... restart engine`):
  /logo.jpg 200, gate 403, BFF 200 di KEDUA node; browser CDP gate→PoW→landing
  200; cluster `onlineNodes=2` sehat. **Temuan**: egress ISP bisa rotasi (CGNAT)
  — cookie `gs_access` IP-bound ketat → sesi bisa kena re-verify bila IP berubah
  tengah jalan; testing dari IP "kotor" pakai whitelist sementara
  (`POST /api/whitelist` → E2E → `POST /api/unwhitelist`). BFF POST via curl
  Windows wajib `--data-binary @file`.
- **Polish UX + hardening (Batch 43, 2026-10-11)**: `components/AnimatedNumber.tsx`
  (count-up rAF, reduced-motion) + dipasang di topbar/Overview/Charts/Traffic;
  transisi tab `AnimatePresence mode="wait"` + scroll-to-top; chip LIVE/OFFLINE
  di topbar; Escape + scroll-lock utk nav mobile; `next.config.mjs` header
  global (`X-Content-Type-Options`, `Referrer-Policy`,
  `Permissions-Policy: camera=(), microphone=(), geolocation=()`, COOP
  same-origin — TANPA CSP karena memblokir Google Fonts); login rate-limit
  in-memory 10/mnt/IP → 429. Caddyfile prod KEDUA node +
  `Permissions-Policy`/`COOP`/`X-DNS-Prefetch-Control` (deploy: validate +
  restart caddy; repo `Caddyfile` dev tidak diubah). **Fix**: `internal/harden/
  harden.go` CSP global `style-src 'self'` memblokir Google Fonts di SEMUA
  halaman → tambah `https://fonts.googleapis.com` (style-src) &
  `https://fonts.gstatic.com` (font-src); engine rebuild dua node. Validasi:
  tsc 0, `next build` exit 0, rate-limit 10×401→429×2, E2E CDP
  `CONSOLE_PROBLEMS=[]`, cluster 2/2. Temuan: curl/CLI selalu 403
  `Blocked: blocked-ua` (sengaja); `too many failed attempts` di BFF = engine
  auth throttle (5 gagal/IP/300 s) — sembuh 5 mnt/restart; operasi state per-IP
  wajib ke DUA node (`curl --resolve ...:<ip>`).
- **Honeypot + hardening agresif + observabilitas + landing static (Batch 45,
  2026-10-11)**: paket baru `internal/defense/honeypot` (guard path probe/exploit
  `/.env`,`/.git`,`/wp-login`,`/phpmyadmin`,... substring case-insensitive,
  `DefaultPatterns`, default TTL 1 jam/skor 100) → config `defense.honeypot
  {enabled,paths,blockTTLMs,score}` (default aktif); dipanggil di
  `internal/shield/evaluate.go` langkah **3.5** (sebelum flood fast-path) →
  `BlockIP(ip,ttl,"honeypot:<pat>")` fail-closed 403 `Blocked: honeypot` (field
  `Shield.Honey`). Metrik baru: `garudashield_honeypot_hits_total{pattern}` +
  `garudashield_flood_mode` (gauge di-set di `runFloodCheck`). `POST
  /api/v1/account/logout-all` (`internal/auth/account.go`, bump
  `session_version`). Portal `PolicyEditor.tsx` + preset cepat
  (Normal/Agresif/Lockdown/Darurat). `next.config.mjs` static cache
  (`/_next/static/*` immutable, `/logo.jpg` 1 hari). Prod kedua node: config
  diperketat (`budgetMs 15`, `floodRpsThreshold 250`, `floodMinMs 8000`,
  `perIPRPS 40`/`perIPBurst 100`/`perPathRPS 100`/`connLimitPerIP 20`/
  `connRateLimit 10`, L4 `maxHalfOpenPerIP 6`/`maxConnPerSecPerIP 20`) + honeypot
  TTL 2 jam; backup `/root/backup-pre-b45-config-<ts>.json`. Verifikasi: `go
  build/vet/test` hijau, tsc 0, `next build` 19/19 static; kedua node engine
  rebuild+`up -d`, `/.env` → 403 `Blocked: honeypot` + blocklist lintas node,
  `/metrics` `honeypot_hits_total`/`flood_mode` ada, cluster `onlineNodes=2`,
  publik `/logo.jpg`+`/api/status`+`/api/gs/status` 200 & `/` 403 (gate), header
  cache terpasang, `GET /api/v1/account/logout-all` 405 (rute ada).
- **Fix false-positive reputasi subnet + reset L2 (Batch 46, 2026-10-11)**: bug —
  `Reputation.ShouldBlock`/`ShouldChallenge` memakai `GetScore` blended
  (max own,/24,/16) → penyerang membanjiri satu /24 membuat IP bersih tetangga
  ikut ter-block (`Blocked: reputation-block`); `evaluate.go` langkah 16 juga
  memakai blended; `ShouldBlock` baca `cfg.BlockThreshold` tanpa lock; `ResetAll`
  tak purge L2 `rep:`. Fix: `Reputation` tambah `OwnScore`/`SubnetScore`/
  `subnetBlockMin()`; `ShouldBlock` = own≥thr ATAU (`SubnetScores` DAN
  own≥`subnetBlockMin` DAN blended≥thr); `ShouldChallenge` = own≥thr ATAU
  (`SubnetScores` DAN own>0 DAN blended≥thr); pakai `GetThreshold()`;
  `evaluate.go` pakai `OwnScore`; `ResetAll` purge L2 via `l2.ForEach`+`Delete`.
  Config baru `reputation.subnetBlockMinScore` (default 40). Test:
  `reputation_test.go` (`TestCleanNeighbourNotBlockedBySubnet`,
  `TestCorroboratedNeighbourStillBlocked`) + `shield_test.go`
  (`TestSubnetPoisonDoesNotBlockCleanNeighbour`, `TestResetAllClearsL2Reputation`).
  Verifikasi LIVE 2 node (XFF trusted 172.18.x): poison `198.51.100.10-15` via
  honeypot → IP bersih `198.51.100.200` dapat halaman PoW (BUKAN reputation-block)
  di KEDUA node; `POST /api/reputation/reset` hapus Redis `gs:rep:<ip>`; cluster
  2/2. Engine rebuild+recreate saja (config prod tak berubah, default 40 berlaku).
  Catatan: rate-limit tetap per-IP (NAT/CGNAT besar masih bisa kena → longgarkan
  `perIPRPS`/whitelist); file root repo bernama secret admin lokal dihapus.
- **Fix false-positive conn-limit: konkurensi, bukan kumulatif (Batch 47,
  2026-10-12)**: `internal/ratelimit/ratelimit.go` `checkConnLimit` dulu menghitung
  request **kumulatif** di window geser 30 s (`conn:<ip>` TTL di-refresh tiap
  request) → dengan `connLimitPerIP=20` (Batch 45), **page load browser biasa
  (>20 request aset) langsung `Blocked: conn-limit`** (repro request ke-21), dan
  langkah 11 `Rep.Adjust(ip,15,"rate-limit")` menaikkan reputasi pengguna nyata.
  Fix: `ConnOpen`/`ConnClose` (`inflight:<ip>` `Incr(+1/-1, TTL 60000)`; Close
  `Delete` saat `<=0`) dipanggil di handler edge `cmd/garudashield/main.go`
  (`ConnOpen(ip)` setelah `clientIP`, `defer ConnClose(ip)`) → `checkConnLimit`
  baca in-flight dan tolak hanya bila `> ConnLimitPerIP`. Limiter per-domain
  (`rt.ownRate`) tak di-Open/Close → conn-limit nonaktif utk domain ber-policy
  (degradasi aman, dijaga perIPRPS/WAF/L7). Test `TestConnLimitIsConcurrentNotCumulative`.
  Deploy kode saja 2 node (`ratelimit.go`, `main.go`) + engine rebuild; verifikasi
  60 request berurutan satu IP = 0 `conn-limit`, `connDropped=0`, cluster 2/2.
  Config prod tak berubah (`connLimitPerIP=20` kini = maks 20 request konkuren).
- **Fix false-block manusia: reputation-block tak lagi "blocklisted" (Batch 48,
  2026-10-12)**: IP pengguna nyata masuk `/login` langsung `403 Blocked:
  blocklisted` karena langkah 8 `evaluate.go` memanggil `BlockIP(ip,300000,
  "reputation-block")` untuk skor reputasi ≥80 → entri durable `block:` → semua
  request berikutnya = `blocklisted` (5 mnt, + `BlockIP` naikkan +50 rep =
  umpan balik). Fix: langkah 8 **tak lagi** menulis blocklist — cukup
  `autoBlock`/`verdict` reason `reputation-block` (soft, self-healing); langkah 3
  memunculkan `be.Reason` tersimpan (fallback `blocklisted`), `evaluateFlood`
  disamakan; `Shield.ClearSoftState(ip)` baru (hapus autoBlock/verdicts +
  `Rep.Reset`, TIDAK menyentuh blocklist/whitelist). Edge `cmd/garudashield/
  main.go` `ActionBlock`: bila `isSoftBlockReason(d.Reason)` & bukan flood →
  cookie `gs_access` valid = lolos, host/path ter-gate = sajikan halaman PoW,
  selain itu 403; flood mode & reason keras (honeypot/blocklist operator/geo/
  emergency/WAF-L7) tetap 403. `POST /_captcha/verify` sukses → `ClearSoftState`.
  Test: `TestReputationBlockIsSoftNotBlocklist`, `TestClearSoftStateResetsEnforcement`,
  `TestEdgeSoftReputationBlockRoutesToGate`, `TestEdgeHardBlockStaysBlocked`,
  `TestIsSoftBlockReason`; `TestFloodFastPath` disesuaikan. build/vet/test hijau.
- **Rotasi admin secret (Batch 49, 2026-10-12)**: `GS_ADMIN_SECRET` (engine) +
  `GS_API_KEY` (web BFF) di `.env` KEDUA node dirotasi ke secret acak 64-hex baru
  (backup `/root/backup-pre-rotate-<ts>/.env`); `up -d engine web` (node-1
  prod+edge+shared, node-2 peer+edge2). Engine baca `GS_ADMIN_SECRET` via
  `applyEnvOverrides` (env > `admin.secret` JSON). Verifikasi: key baru 200, lama
  403 (KEDUA node), BFF `/api/gs/stats` 200, cluster 2/2. Dev default lokal
  (COMMITTED) dirotasi juga di `run.ps1`/`run.sh` +
  `garudashield.local.json`/`dashboard/.env.local` (gitignored). **Secret baru
  TIDAK ditulis ke repo** — simpan di password manager. Sisa belum: `GS_ACCESS_SECRET`,
  `GS_SESSION_SECRET`, `POSTGRES_PASSWORD`, `REDIS_PASSWORD` (butuh jendela, risiko
  lintas layanan).
- **Rotasi secret engine (Batch 50, 2026-10-12)**: `GS_ACCESS_SECRET` (HMAC cookie
  gate `gs_access` + id PoW `/_captcha`) & `GS_SESSION_SECRET` (HMAC cookie sesi
  portal `gs_session`) di `/opt/garudashield/.env` KEDUA node dirotasi ke 64-hex
  baru (backup `/root/backup-pre-rotate2-<ts>/.env`); `up -d engine` saja (keduanya
  engine-only, harus identik antar node). Verifikasi live: gate end-to-end di
  network `garudashield_edge` (GET `/` -> challenge -> solve PoW -> `POST
  /_captcha/verify` **200 `{"ok":true}`** + cookie -> `GET /` 200) lulus KEDUA
  node; portal `POST /api/auth/login` 200 + `gs_session` valid (`/api/v1/account`
  200); publik `/api/gs/status` 200/`/logo.jpg` 200/`/` 403; cluster 2/2. Catatan:
  `gs_ok` token sudah per-boot acak (`token.NewSecret()`) jadi tak terpengaruh;
  `POST /_captcha/verify` butuh header `Sec-Fetch-Site` **dan** `Origin`/`Referer`
  (gate csrf `harden.CSRF`) — klien HTTP mentah ditolak. Sisa belum: `POSTGRES_PASSWORD`,
  `REDIS_PASSWORD` (butuh `ALTER USER`/grow + recreate lintas layanan + storage
  redis Caddy shared — tunggu jendela).
- **Hardening release gate attack-suite (Batch 51, 2026-10-12)**: `internal/attacksuite`
  kirim **User-Agent browser default** (dulu probe pakai `Go-http-client` → diam-diam
  `blocked-ua`, "block" palsu & kontrol jinak gagal), **mengikuti redirect** (kasus
  traversal `..` dinetralkan ServeMux Go dgn 307 → diikuti → 403), tambah
  **`Baseline()`** (kontrol jinak `/health` harus lolos; kalau tidak → exit 2, env
  invalid), dan **`Category.Armed(cfg)`** yang benar-benar memakai `Depends`
  (toggle dimatikan → laporan **SKIP**, bukan gagal; nama toggle tak dikenal →
  error keras). `cmd/attacksuite` dapat flag **`-config`**. CI
  `.github/workflows/ci.yml`: engine kini di-start dgn `GS_ACCESS_SECRET` (sebelumnya
  gagal bind non-loopback → gate selalu merah) dan gate dipanggil dgn
  `-config garudashield.example.json`; job tetap jalan harian (`schedule` cron).
  Verifikasi: `go build/vet/test` hijau (9 test attacksuite baru), suite live
  `13/13 passed, exit 0`; config WAF mati → `7 skipped, exit 0`; engine mati →
  `exit 2`.
- **Rotasi POSTGRES_PASSWORD + REDIS_PASSWORD (Batch 52, 2026-10-12)**: dua
  kredensial terakhir dirotasi (48-hex, generate sekali lalu dipakai sama di dua
  node). Wiring terkonfirmasi: engine baca password Redis dari **JSON**
  `cluster.redis.password` (bukan env); Caddy dari `{$REDIS_PASSWORD}` (shared.yml);
  Redis node-1 `--requirepass` dari `.env`; node-2 Caddy → `172.236.152.58:6379`
  langsung. Compose: node-1 `prod+edge+shared`, node-2 `peer+edge2+shared`. Langkah:
  backup `/root/backup-pre-rotate3-<ts>/`; update `.env`(`POSTGRES_PASSWORD`,
  `GS_DATABASE_URL`, `REDIS_PASSWORD`)+JSON kedua node; `ALTER USER garuda WITH
  PASSWORD` (env Postgres hanya berlaku saat init); recreate `redis`(node-1) +
  `engine` + `caddy` kedua node. Verifikasi live: Redis pw baru `PONG`/lama gagal;
  engine `commercial store connected (postgres)`; PG TCP pw baru OK/lama gagal;
  BFF `/api/gs/auth/login` 200 kedua node; cluster `onlineNodes:2, degraded:false`;
  **TLS cert identik** (serial `0562760982F6953F3BE9D84E43D6720050ED`) → shared-Redis
  ACME aman. E2E final pasca-rotasi dua node **26/26** (health/publik/10 admin/403
  kunci lama/cluster 2/2/metrics/gate PoW/verify/WAF/honeypot) + publik/BFF **7/7**.
  (Login ke engine langsung 403 hanya CSRF Origin-vs-Host, bukan regresi.)
- **Housekeeping: gofmt + flaky test hardening + redeploy (Batch 53, 2026-10-12)**:
  `gofmt -w` 14 file (kanonikalisasi import/blank/godoc, tanpa perubahan logika,
  `gofmt -l .` bersih). Flaky `go test ./...` di bawah beban CPU penuh diperbaiki di
  akarnya — `internal/pyhook` + `internal/shield` pyhook test memakai timeout 5000 ms
  (spawn `python3` > 5 s saat mesin sarat → fail-closed `pyhook-timeout` → assertion
  gagal) dinaikkan ke 20000 (budget 30000); `internal/status/monitor_test.go` tak lagi
  balapan ticker (`m.runChecks()` sinkron); assertion event `internal/shield` dibuat
  order-independent. Verifikasi: build/vet hijau, `go test ./... -count=1` 7x hijau
  (3 run dengan 6–8 CPU burner). Deploy kode ke dua node (`/root/backup-pre-b53/`,
  engine rebuild+recreate dari source yang disinkron; MD5 source cocok): kedua node
  `Up (healthy)`, cluster `onlineNodes:2/degraded:false`, postgres connected,
  BFF `gs/status`+`gs/stats` 200, gate `/` 403, `/logo.jpg` 200 (UA browser),
  **TLS cert identik** serial `0562760982F6953F3BE9D84E43D6720050ED`.
- **Node edge 3 & 4 + proxy fleet agent (Batch 54, 2026-10-12)**: dua VPS baru
  `104.64.205.215` (node-3) + `104.64.205.217` (node-4) jadi **edge aktif penuh**
  (Ubuntu 22.04, Docker 29.9, Node 22 LTS). Image diangkut server→server via nginx
  sementara (`gs-tmp-http`, 320 MB, sha256 `1ae6e429…`) ke `/opt/garudashield` +
  aset umum `gs-common.tgz`; compose `peer+edge2+shared` (`image:` tanpa build),
  `cluster.nodes` 4 entri di semua node (`backup-pre-b54-*.json`). Firewall 6379
  node-1 dibuka ke node-2/3/4 + **persisten** via `gs-redis-firewall.service`.
  Live: keempat node `nodes=4`, Redis `gsnode:node-{1..4}:seen`,
  `onlineNodes:4/degraded:false`, TLS cert identik (shared-Redis ACME), publik
  node-3/4 `/api/status`+`/logo.jpg`+`/api/gs/status` 200 & `/` 403. **Proxy
  agent** `proxy/agent/` (`agent.js`+`checker.js`+`proxyfetch.js`, tanpa dep)
  di node-3: tiap 5 mnt scrape → liveness (HTTP **+ SOCKS5**) → `active.txt`;
  API localhost `127.0.0.1:8787` (`/health`,`/stats`,`/proxy/active`,`/refresh`,
  `/checkhost`); check-host.net via proxy terbukti `6/6 OK` (`example.com`).
- **Proxy agent hardening + observability (Batch 55, 2026-10-12)**: `checker.js` ukur
  **latency** + sortir terbaik-dulu, `active.json` kaya (`fresh`/`carried`/`proxies[]`),
  **carry-over** proxy bagus (`CHECK_CARRYOVER_MS=1800000`, tandai `stale`); modul baru
  `checkhost.js` (`checkHost`+`proxyGetJson`, CLI `node checkhost.js <host> [type]`);
  `agent.js` tambah **`GET /metrics`** (Prometheus: `garudashield_proxy_active{,_fresh}`,
  `_refresh_total`, `_refresh_errors_total`, `_checkhost_total`, `_checkhost_errors_total`,
  `_last_refresh_timestamp_seconds`, `_uptime_seconds`) + `/proxies/active?meta=1&limit=N`;
  systemd di-harden (`ProtectSystem=full`, `ReadWritePaths=/opt/gs-proxy`,
  `ProtectHome`, `PrivateTmp`, `NoNewPrivileges`). Live node-3: siklus penuh
  30447->3000->**23 aktif** (terbaik 23 ms) ~60 s, `/metrics` lengkap;
  `POST /checkhost` `example.com` **6/6 OK 200** & **`gg.garudashield.my.id` 6/6**
  dari 5 benua (`301` -> `172.236.152.58`/`172.104.37.113`) -> membuktikan
  round-robin 2-node + redirect probe monitor benar-benar jalan global.
- **Proxy fleet di dashboard + hardening agent + agent HA node-4 (Batch 56,
  2026-10-12)**: panel **"Proxy Fleet"** di `/dash` (nav `["Proxy Fleet","proxy"]`
  + `ProxyFleet()`: kartu metrik, tabel proxy+latency, tombol Refresh, form Uji
  check-host) lewat **BFF baru** `dashboard/app/api/gs/proxy/[[...path]]/route.ts`
  (cookie HttpOnly `gs_key` wajib; `PROXY_AGENT_TOKEN` disuntik server-side;
  `PROXY_AGENT_URLS` failover + `AbortSignal.timeout(8000)`; 503/502 jelas). Agent
  `agent.js` kini **wajib `AGENT_TOKEN`** (`X-Auth-Token`) untuk semua endpoint
  kecuali `GET /health`, bind `0.0.0.0` + **firewall** `gs-agent-firewall` (iptables
  :8787 hanya dari IP node cluster + `lo`); cache checkhost (`CHECKHOST_CACHE_MS`)
  + rate-limit POST (`AGENT_API_RATE`); `checker.js` `TEST_TARGET_2` + `CHECK_RETRY`.
  **Agent juga jalan di node-4** (Node 22 NodeSource baru dipasang; `gs-proxy-agent`
  active). Env `PROXY_AGENT_URLS`/`PROXY_AGENT_TOKEN` di `.env` + `web.environment`
  keempat node; image `web` dibangun ulang node-1/node-2 lalu diangkut ke node-3/4
  via nginx sementara. Verifikasi live 4 node: agent health/token OK, BFF
  `/proxy/{stats,proxies/active,checkhost}` **200** semua, **failover** terbukti
  (node-3 agent stop -> BFF node-1 tetap 200 via node-4), `/dash` memuat panel,
  cluster `nodes=4/onlineNodes=4/degraded=false`.
- **Polish UX console (Batch 57, 2026-10-12)**: tab `/dash` kini **deep-linkable**
  (hash `#waf-rules`, `#geo-map`, ...; pulih saat refresh, ikut back/forward,
  `document.title` sinkron); **command palette Ctrl/Cmd+K** (filter 16 tab, panah
  + Enter + Esc, trigger ikon `search` + kbd di topbar) dan **navigasi keyboard
  rail** (Arrow/Home/End memindah tab + fokus). Ikon `search` +
  `.kbd`/`.command-*` di `globals.css`; murni client-side (nol perubahan
  BFF/engine). Validasi: `tsc` 0 error, `next build` 19/19.

## Belum (per 2026-10-12)

- **DNS 4-way round-robin**: tambah A-record `gg.garudashield.my.id` →
  `104.64.205.215` + `104.64.205.217` di Clouden.id (manual) agar node-3/4 ikut
  melayani (saat ini DNS masih 2 node). Cert SSL node-3/4 sudah siap (shared Redis).
  Keempat node + agent sudah siap menerima traffic begitu DNS ditambah.
- **Rotasi `POSTGRES_PASSWORD`/`REDIS_PASSWORD` SELESAI (Batch 52)** — dua node,
  verifikasi live hijau (cluster 2/2, TLS cert identik, BFF login 200). Tidak ada
  item kritis tersisa; suite `go test ./...` kini deterministik (Batch 53). E2E dua
  node + publik/BFF LULUS (Batch 51: node-1 20/20,
  node-2 19/20→efektif 20/20 [artefak counter Prometheus], publik 7/7, PoW
  end-to-end); lintas-node Redis live (`gsnode:{node-1,node-2}:seen`, `garuda:sync`
  `op:block` diterapkan peer) & `TestPeerSyncCrossNode` jalan di CI (redis service).
- Opsional: push repo ke remote (belum ada remote). Unit test `internal/geo` tuntas
  (DB di-download CI); release gate attack-suite sudah di-harden + jalan harian.

## Jangan lakukan

- Jangan bawa kredensial plaintext (SSH root, gate secret) ke v3 — itu temuan
  keamanan v2 yang sengaja dibuang.
- Jangan "perbaiki" quirk paritas v2 tanpa catat di log.md (lihat prinsip #1).
- Jangan buat peta/visualisasi palsu bila data tidak ada — degrade gracefully.

## Referensi cepat

- `log.md` — kronologi pengerjaan lengkap (BACA untuk konteks historis).
- `docs/DESIGN.md` — arsitektur & kontrak.
- `docs/CUTOVER.md` — runbook cutover v2→v3, config reference, admin API, rollback.
- `garudashield.example.json` — contoh config lengkap (copy → `garudashield.json`).
- `README.md` — ringkasan stack & cara jalan.

## Agent skills (sudah ter-install di .agents/.claude/agent skills)

Skill di-load otomatis oleh Claude Code / Hermes saat relevan. Yang sudah ada di
repo ini (selain skill desain `.agents/skills/*`):

### GitHub
- `github-pr-workflow` — siklus PR penuh (branch → commit → PR → CI → merge). Pakai
  sebelum buka PR.
- `github-code-review` — review PR via `gh`/REST dengan komentar inline.
- `github-issues` / `github-issue-to-pr` — buat triage issue, bawa issue → PR terverifikasi.
- `codebase-inspection` — ukur LOC/bahasa/rasio dengan pygount sebelum refactor besar.

### Software engineering
- `test-driven-development` — RED-GREEN-REFACTOR; pakai untuk fitur engine baru.
- `systematic-debugging` — 4-fase root-cause; pakai SEBELUM menambal bug.
- `requesting-code-review` — pre-commit: security scan + quality gate + auto-fix.
- `simplify-code` — cleanup paralel 4-agent untuk perubahan terakhir.
- `plan` — tulis rencana markdown ke `.hermes/plans/` (tanpa eksekusi) untuk chunk besar.
- `nextjs-prisma-build-fix` — fix Next.js build gagal (relevan dashboard).
- `dogfood` — QA eksplorasi web app (cari bug di dashboard via browser).

### Creative / desain (dashboard Next.js + Motion)
- `design-md` — author/validasi token DESIGN.md (sinkron dengan docs/DESIGN.md).
- `popular-web-designs` — 54 design system nyata (Stripe/Linear/Vercel) sebagai referensi.
- `claude-design` / `sketch` — bikin/iterasi mockup HTML dashboard.

Konvensi: skill disimpan di `.agents/skills/<name>/` dan di-mirror ke `.claude/skills/`
serta `agent/skills/` (pola symlink di disk; di git tersimpan sebagai salinan karena
`core.symlinks=false` di Windows). Jangan hapus skill ini kecuali sudah tidak relevan.
