// Command genlicense prints a signed GarudaShield license key.
//
// Usage:
//
//	go run ./tools/genlicense <secret> <tenantId> <plan> <expiryUnix> [hostFingerprint]
//
// If hostFingerprint is omitted, the current machine's fingerprint is used
// (bind-to-this-host). Pass any non-matching string (e.g. "foreign") to produce
// a key bound to a different host — useful to prove the engine rejects it.
package main

import (
	"fmt"
	"os"
	"strconv"

	"github.com/ahkurdev/garudashield/internal/license"
)

func main() {
	if len(os.Args) < 5 {
		fmt.Fprintln(os.Stderr, "usage: genlicense <secret> <tenantId> <plan> <expiryUnix> [hostFingerprint]")
		os.Exit(2)
	}
	secret := os.Args[1]
	tid := os.Args[2]
	plan := license.Plan(os.Args[3])
	exp, err := strconv.ParseInt(os.Args[4], 10, 64)
	if err != nil {
		fmt.Fprintln(os.Stderr, "expiry must be unix seconds:", err)
		os.Exit(2)
	}
	host := ""
	if len(os.Args) >= 6 {
		host = os.Args[5]
	} else {
		host = license.FingerprintHash()
	}
	l := license.Sign(license.License{
		TenantID: tid,
		Plan:     plan,
		Expiry:   exp,
		Issued:   exp - 1,
		Host:     host,
	}, secret)
	fmt.Println(l.Key())
}
