#!/usr/bin/env bash
# Tes serangan sintetik ke engine GarudaShield (localhost).
# Engine harus sudah jalan & mem-proxy ke origin (lihat tools/attack-config.json).
# Penggunaan: ./attack-test.sh [BASE_URL]
set -u
BASE="${1:-http://localhost:8080}"
UA="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
ADMIN_KEY="${GS_API_KEY:-test-secret}"
fail=0

# reset_state mengosongkan blocklist, reputasi dan hitungan rate-limit engine.
# Wajib dipanggil sebelum tiap fase: serangan di fase sebelumnya menaikkan skor
# reputasi IP kita sampai engine memblokirnya secara menyeluruh, sehingga probe
# yang seharusnya LOLOS ikut kena blokir. Itu perilaku engine yang benar, jadi
# harness-lah yang harus memisahkan tiap fase.
reset_state() {
  curl -s --max-time 5 -X POST -H "x-gs-key: $ADMIN_KEY" \
    -H "Content-Type: application/json" -d '{}' "$BASE/api/reset" -o /dev/null
  sleep 0.3
}

# probe <label> <path> <block|pass> [ua] [extra curl args...]
probe() {
  local label="$1" path="$2" expect="$3"; shift 3
  local ua="${1:-$UA}"; [ $# -gt 0 ] && shift
  local code body mark tag why=""
  code=$(curl -s --max-time 5 -A "$ua" "$@" -o /dev/null -w "%{http_code}" "$BASE$path")
  body=$(curl -s --max-time 5 -A "$ua" "$@" "$BASE$path" | tr '\n' ' ')
  if [ "$code" -ge 400 ] 2>/dev/null; then blocked=1; tag="BLOCK($code)"; else blocked=0; tag="PASS($code)"; fi
  if [ "$expect" = "block" ]; then want=1; else want=0; fi
  if [ "$blocked" -eq "$want" ]; then mark="OK "; else mark="BAD"; fail=$((fail+1)); fi
  case "$body" in *"Blocked:"*) why="  [$(printf '%s' "$body" | sed -n 's/.*Blocked:[[:space:]]*\([^<]*\).*/\1/p')]";; esac
  printf "%s %-38s -> %s%s\n" "$mark" "$label" "$tag" "$why"
  sleep 0.25
}

echo "== Harus LOLOS (cek false positive) =="
probe "benign GET /"              "/"                                             pass
probe "search biasa"              "/?q=hello+world"                               pass
probe "nama pakai apostrof"       "/?q=O%27Brien"                                 pass
probe "kalimat panjang"           "/?q=where+is+my+order+from+shop"               pass
probe "pagination"                "/?page=2&sort=price&dir=asc"                   pass
probe "utm params"                "/?utm_source=google&utm_campaign=spring+sale"  pass
probe "redirect url ter-encode"   "/?to=https%3A%2F%2Fexample.com%2Fp%3Fa%3D1"    pass

echo "== WAF: harus DIBLOKIR =="
reset_state
probe "SQLi ' OR '="              "/?q=%27%20OR%20%27%3D"                         block
probe "SQLi double-encoded"       "/?q=%2527%2520OR%2520%2527%253D"               block
probe "SQLi plus-as-space"        "/?q=%27+OR+%27%3D"                             block
probe "SQLi union select"         "/?q=1%20union%20select%201"                    block
probe "XSS <script>"              "/?q=%3Cscript%3Ealert(1)%3C/script%3E"         block
probe "XSS double-encoded"        "/?q=%253Cscript%253Ealert(1)%253C/script%253E" block
probe "cmd injection"             "/?q=%3Bcat%20%2Fetc%2Fpasswd"                  block
probe "path traversal"            "/%2e%2e/%2e%2e/etc/passwd"                     block
probe "path traversal double-enc" "/%252e%252e%252f%252e%252e%252fetc%252fpasswd" block
probe "shellshock di User-Agent"  "/"                                             block "() { :; }; /bin/bash -c 'cat /etc/passwd'"

echo "== Layer 7: harus DIBLOKIR =="
reset_state
probe "scanner UA (sqlmap)"       "/"                                             block "sqlmap/1.6"
probe "path terlarang /wp-admin"  "/wp-admin"                                     block
probe "file sensitif /.env"       "/.env"                                         block
probe "UA kosong"                 "/"                                             block "x" -H "User-Agent;"

echo "== Rate limit / flood =="
echo "  (tools/attack-config.json set longgar agar WAF terlihat jelas."
echo "   Untuk tes flood, turunkan perIPRPS di config lalu ulangi.)"
ok=0; blocked_n=0
for _ in $(seq 1 25); do
  c=$(curl -s --max-time 5 -o /dev/null -w "%{http_code}" -A "$UA" "$BASE/")
  if [ "$c" -ge 400 ] 2>/dev/null; then blocked_n=$((blocked_n+1)); else ok=$((ok+1)); fi
done
echo "  25 req cepat -> $ok lolos, $blocked_n dibatasi"

echo
if [ "$fail" -eq 0 ]; then
  echo "SEMUA PROBE SESUAI HARAPAN"; exit 0
else
  echo "$fail probe TIDAK sesuai harapan (lihat baris BAD)"; exit 1
fi
