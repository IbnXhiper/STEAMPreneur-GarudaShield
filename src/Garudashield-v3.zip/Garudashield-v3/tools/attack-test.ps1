# Tes serangan sintetik ke engine GarudaShield (localhost).
# Engine harus sudah jalan & mem-proxy ke origin (lihat tools/attack-config.json).
# Penggunaan: .\attack-test.ps1 [-BaseUrl http://localhost:8080]
param(
  [string]$BaseUrl = "http://localhost:8080"
)

$UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36"
$AdminKey = if ($env:GS_API_KEY) { $env:GS_API_KEY } else { "test-secret" }
$script:fail = 0

# Reset-State mengosongkan blocklist, reputasi dan hitungan rate-limit engine.
# Wajib dipanggil sebelum tiap fase: serangan di fase sebelumnya menaikkan skor
# reputasi IP kita sampai engine memblokirnya secara menyeluruh, sehingga probe
# yang seharusnya LOLOS ikut kena blokir. Itu perilaku engine yang benar, jadi
# harness-lah yang harus memisahkan tiap fase.
function Reset-State {
  curl.exe -s --max-time 5 -X POST -H "x-gs-key: $AdminKey" -H "Content-Type: application/json" `
    -d "{}" "$BaseUrl/api/reset" -o /dev/null
  Start-Sleep -Milliseconds 300
}

# Probe mengirim satu request dan membandingkan hasilnya dengan yang diharapkan
# ("block" = harus >=400, "pass" = harus <400). Setiap mismatch dihitung sebagai
# kegagalan sehingga exit code bisa dipakai di CI.
# $extra dipakai untuk argumen curl tambahan (mis. memaksa header kosong).
function Probe($label, $path, $expect, $ua = $UA, $extra = @()) {
  $url = $BaseUrl + $path
  $args = @("-s", "--max-time", "5", "-A", $ua) + $extra
  $code = (curl.exe @args -o /dev/null -w "%{http_code}" $url)
  $body = ((curl.exe @args $url) -replace "`n", " ")
  $blocked = [int]$code -ge 400
  $want = ($expect -eq "block")
  if ($blocked -eq $want) { $mark = "OK " } else { $mark = "BAD"; $script:fail++ }
  if ($blocked) { $tag = "BLOCK($code)" } else { $tag = "PASS($code)" }
  $why = ""
  if ($body -match "Blocked:\s*([^<]+)") { $why = "  [" + $matches[1].Trim() + "]" }
  Write-Host ("{0} {1,-38} -> {2}{3}" -f $mark, $label, $tag, $why)
  Start-Sleep -Milliseconds 250
}

Write-Host "== Harus LOLOS (cek false positive) ==" -ForegroundColor Cyan
Probe "benign GET /"                  "/"                                                  "pass"
Probe "search biasa"                  "/?q=hello+world"                                    "pass"
Probe "nama pakai apostrof"           "/?q=O%27Brien"                                      "pass"
Probe "kalimat panjang"               "/?q=where+is+my+order+from+shop"                    "pass"
Probe "pagination"                    "/?page=2&sort=price&dir=asc"                        "pass"
Probe "utm params"                    "/?utm_source=google&utm_campaign=spring+sale"       "pass"
Probe "redirect url ter-encode"       "/?to=https%3A%2F%2Fexample.com%2Fp%3Fa%3D1"         "pass"

Write-Host "== WAF: harus DIBLOKIR ==" -ForegroundColor Cyan
Reset-State
Probe "SQLi ' OR '="                  "/?q=%27%20OR%20%27%3D"                              "block"
Probe "SQLi double-encoded"           "/?q=%2527%2520OR%2520%2527%253D"                    "block"
Probe "SQLi plus-as-space"            "/?q=%27+OR+%27%3D"                                  "block"
Probe "SQLi union select"             "/?q=1%20union%20select%201"                         "block"
Probe "XSS <script>"                  "/?q=%3Cscript%3Ealert(1)%3C/script%3E"              "block"
Probe "XSS double-encoded"            "/?q=%253Cscript%253Ealert(1)%253C/script%253E"      "block"
Probe "cmd injection"                 "/?q=%3Bcat%20%2Fetc%2Fpasswd"                       "block"
Probe "path traversal"                "/%2e%2e/%2e%2e/etc/passwd"                          "block"
Probe "path traversal double-enc"     "/%252e%252e%252f%252e%252e%252fetc%252fpasswd"      "block"
Probe "shellshock di User-Agent"      "/"                                                  "block" "() { :; }; /bin/bash -c 'cat /etc/passwd'"

Write-Host "== Layer 7: harus DIBLOKIR ==" -ForegroundColor Cyan
Reset-State
Probe "scanner UA (sqlmap)"           "/"                                                  "block" "sqlmap/1.6"
Probe "path terlarang /wp-admin"      "/wp-admin"                                          "block"
Probe "file sensitif /.env"           "/.env"                                              "block"
Probe "UA kosong"                     "/"                                                  "block" "x" @("-H", "User-Agent;")

Write-Host "== Rate limit / flood ==" -ForegroundColor Cyan
Write-Host "  (tools/attack-config.json set longgar agar WAF terlihat jelas."
Write-Host "   Untuk tes flood, turunkan perIPRPS di config lalu ulangi.)"
$ok = 0; $blocked = 0
for ($i = 0; $i -lt 25; $i++) {
  $c = (curl.exe -s --max-time 5 -o /dev/null -w "%{http_code}" -A $UA ($BaseUrl + "/"))
  if ([int]$c -ge 400) { $blocked++ } else { $ok++ }
}
Write-Host ("  25 req cepat -> $ok lolos, $blocked dibatasi")

Write-Host ""
if ($script:fail -eq 0) {
  Write-Host "SEMUA PROBE SESUAI HARAPAN" -ForegroundColor Green
  exit 0
} else {
  Write-Host "$script:fail probe TIDAK sesuai harapan (lihat baris BAD)" -ForegroundColor Red
  exit 1
}
