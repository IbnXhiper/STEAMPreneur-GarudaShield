#!/usr/bin/env bash
# Operator workflow after a WhatsApp order is confirmed.
# Usage: ./tools/onboard-customer.sh TENANT NAME DOMAIN PLAN EMAIL PASSWORD [MONTHS]
set -euo pipefail

cd "$(dirname "$0")/.."
test -f .env || { echo ".env not found" >&2; exit 1; }
set -a
# shellcheck disable=SC1091
. ./.env
set +a

TENANT="${1:?tenant id required}"
NAME="${2:?customer name required}"
DOMAIN="${3:?domain required}"
PLAN="${4:?plan required: free|pro|enterprise}"
EMAIL="${5:?owner email required}"
PASSWORD="${6:?temporary password required (minimum 12 chars)}"
MONTHS="${7:-1}"
BASE_URL="${GS_OPERATOR_URL:-https://localhost}"

onboard_payload=$(python -c 'import json,sys; print(json.dumps(dict(zip(("tenant","name","domain","plan","email","password"),sys.argv[1:]))))' \
  "$TENANT" "$NAME" "$DOMAIN" "$PLAN" "$EMAIL" "$PASSWORD")

curl -fsSk -X POST "$BASE_URL/api/admin/tenant/onboard" \
  -H "x-gs-key: $GS_ADMIN_SECRET" -H "Content-Type: application/json" \
  --data "$onboard_payload"
echo

if [ "$PLAN" != "free" ]; then
  license_payload=$(python -c 'import json,sys; print(json.dumps({"tenant":sys.argv[1],"plan":sys.argv[2],"months":int(sys.argv[3])}))' \
    "$TENANT" "$PLAN" "$MONTHS")
  curl -fsSk -X POST "$BASE_URL/api/admin/license/issue" \
    -H "x-gs-key: $GS_ADMIN_SECRET" -H "Content-Type: application/json" \
    --data "$license_payload"
  echo
fi

echo "Customer onboarded after WhatsApp confirmation. Send portal URL and temporary password via WhatsApp."