#!/usr/bin/env bash
#
# build-linux.sh — one-shot build + smoke test for GarudaShield v3 on WSL / Linux.
#
# Builds the parts that cannot be built/tested on the Windows dev box:
#   - Rust WAF matcher shared lib  (libwafmatcher.so)  -> rustffi_linux.go
#   - XDP eBPF object              (xdp_drop.o)        -> ebpf_offload.go
#   - Engine binary built -tags ebpf                  -> kernel offload enabled
# Then runs a smoke test proving:
#   - license host-binding fail-closed (foreign-host key rejected at boot)
#   - HTTP/3 (QUIC) listener answers over UDP
#   - XDP drop (only if run as root with a real interface)
#
# Usage:
#   ./tools/build-linux.sh            # build + smoke (XDP skipped unless root)
#   sudo ./tools/build-linux.sh       # also attaches XDP and verifies kernel drop
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

INTERFACE="${GS_WAF_IFACE:-eth0}"
ADMIN_KEY="${GS_ADMIN_SECRET:-$(openssl rand -hex 32)}"
LIC_SECRET="${GS_LICENSE_SECRET:-$(openssl rand -hex 32)}"

echo "==> [1/5] toolchain check"
for b in go cargo clang gcc bpftool openssl; do
  if ! command -v "$b" >/dev/null 2>&1; then
    echo "missing: $b"
    case "$b" in
      cargo) echo "  install: curl https://sh.rustup.rs -sSf | sh -s -- -y" ;;
      clang|gcc|bpftool) echo "  sudo apt-get install -y clang gcc libbpf-dev bpftool linux-headers-$(uname -r)" ;;
    esac
    exit 1
  fi
done

echo "==> [2/5] build Rust WAF matcher (libwafmatcher.so)"
( cd rust/wafmatcher && cargo build --release )
SO="$(pwd)/rust/wafmatcher/target/release/libwafmatcher.so"
ls -l "$SO"

echo "==> [3/5] build XDP eBPF object (xdp_drop.o)"
make -C internal/offload
ls -l internal/offload/xdp_drop.o

echo "==> [4/5] build engine with -tags ebpf"
CGO_ENABLED=1 go build -tags ebpf -o bin/gs-ebpf ./cmd/garudashield
ls -l bin/gs-ebpf

echo "==> [5/5] smoke tests"
BIN="$(pwd)/bin/gs-ebpf"
export GS_ADMIN_SECRET="$ADMIN_KEY"
export GS_LICENSE_SECRET="$LIC_SECRET"
export GS_WAF_LIB="$SO"
export GS_OFFLOAD_INTERFACE="$INTERFACE"

# 5a. license host-binding: a key bound to a FOREIGN host must make the engine
#     refuse to start (exit 1). Build one with a bogus fingerprint.
echo "--- license binding (expect: foreign-host key -> engine exits 1)"
FOREIGN_KEY="$(go run ./tools/genlicense "$LIC_SECRET" tenant-x pro 0 foreignhost123)"
echo "  generated foreign key: ${FOREIGN_KEY:0:24}..."
GS_LICENSE_KEY="$FOREIGN_KEY" "$BIN" -config /dev/null >/tmp/gs-lic.log 2>&1 && {
  echo "  FAIL: engine started despite foreign-host license (should have exited 1)"
} || {
  echo "  OK: engine refused to start with foreign-host license"
}

# 5b. QUIC listener: start engine with TLS+H3, confirm it logs the QUIC listener.
echo "--- QUIC listener (expect: 'http/3 (QUIC) listener starting')"
openssl req -x509 -newkey rsa:2048 -nodes -keyout /tmp/gs-smoke.key -out /tmp/gs-smoke.crt -days 1 -subj "/CN=localhost" >/dev/null 2>&1
cat > /tmp/gs-smoke.json <<JSON
{
  "version":"3.0.0","name":"smoke",
  "server":{
    "httpPort":18080,"host":"127.0.0.1","maxConcurrency":1000,
    "tls":{"enabled":true,"certFile":"/tmp/gs-smoke.crt","keyFile":"/tmp/gs-smoke.key"},
    "http3":{"enabled":true,"port":18083,"maxIncomingStreams":50}
  },
  "offload":{"enabled":false,"interface":"$INTERFACE"}
}
JSON
"$BIN" -config /tmp/gs-smoke.json >/tmp/gs-smoke.log 2>&1 &
PID=$!
sleep 2
if grep -q "QUIC" /tmp/gs-smoke.log; then echo "  OK: QUIC listener started"; else echo "  FAIL: QUIC not started"; tail -5 /tmp/gs-smoke.log; fi
kill "$PID" 2>/dev/null || true

# 5c. XDP (only if root)
if [ "$(id -u)" -eq 0 ]; then
  echo "--- XDP offload (root): expect 'XDP/eBPF attached' on $INTERFACE"
  cat > /tmp/gs-xdp.json <<JSON
{
  "version":"3.0.0","name":"xdp",
  "server":{"httpPort":18090,"host":"0.0.0.0","maxConcurrency":1000},
  "offload":{"enabled":true,"interface":"$INTERFACE"}
}
JSON
  "$BIN" -config /tmp/gs-xdp.json >/tmp/gs-xdp.log 2>&1 &
  XPID=$!
  sleep 2
  if grep -q "XDP/eBPF attached" /tmp/gs-xdp.log; then
    echo "  OK: XDP attached on $INTERFACE"
    echo "  verify kernel drop: sudo bpftool map dump name blocked_ips"
  else
    echo "  FAIL: XDP not attached (see /tmp/gs-xdp.log)"
  fi
  kill "$XPID" 2>/dev/null || true
else
  echo "--- XDP skipped (not root); re-run with: sudo ./tools/build-linux.sh"
fi

echo "==> done. Artifacts: $SO, internal/offload/xdp_drop.o, bin/gs-ebpf"
