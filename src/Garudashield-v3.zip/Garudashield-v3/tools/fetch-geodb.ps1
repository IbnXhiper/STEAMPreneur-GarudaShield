# fetch-geodb.ps1 — download GeoIP MMDB databases for offline IP enrichment
# (country + ASN) used by GarudaShield v3's internal/geo resolver.
#
# The databases are MaxMind GeoLite2 builds. The official MaxMind distribution
# requires a free account + license key; this script points at the
# P3TERX/GeoLite.mmdb mirror (raw GitHub) so it works with no account and no
# API key. No outbound call per visitor — the engine memory-maps these files
# locally.
#
# Usage (PowerShell):
#   .\tools\fetch-geodb.ps1            # default: ./data/GeoIP
#   .\tools\fetch-geodb.ps1 -OutDir C:\geo
#
# After downloading, enable geo in garudashield.json:
#   "geo": { "enabled": true, "countryDatabase": "data/GeoIP/geoip-country.mmdb", "asnDatabase": "data/GeoIP/geoip-asn.mmdb" }

param(
    [string]$OutDir = "data/GeoIP",
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# Base name before the /download mirror path (GeoLite2 filenames upstream);
# we store them locally as geoip-*.mmdb to match the default config paths.
$Base = "https://raw.githubusercontent.com/P3TERX/GeoLite.mmdb/download"
$Files = @(
    @{ Name = "geoip-country.mmdb"; Url = "$Base/GeoLite2-Country.mmdb" }
    @{ Name = "geoip-asn.mmdb";     Url = "$Base/GeoLite2-ASN.mmdb" }
)

# Resolve OutDir relative to the repository root (parent of tools/).
if (-not [System.IO.Path]::IsPathRooted($OutDir)) {
    $RepoRoot = Split-Path -Parent $PSScriptRoot
    $OutDir = Join-Path $RepoRoot $OutDir
}
New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

$ok = $true
foreach ($f in $Files) {
    $dest = Join-Path $OutDir $f.Name
    if ((Test-Path $dest) -and -not $Force) {
        Write-Host ("[skip]   {0} already exists (use -Force to overwrite)" -f $f.Name)
        continue
    }
    Write-Host ("[fetch]  {0}" -f $f.Name)
    try {
        # TLS 1.2+ required by GitHub raw.
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $f.Url -OutFile $dest -UseBasicParsing -ErrorAction Stop
        $size = (Get-Item $dest).Length
        Write-Host ("[ok]     {0} ({1} bytes)" -f $f.Name, $size)
    }
    catch {
        Write-Warning ("[fail]   {0}: {1}" -f $f.Name, $_.Exception.Message)
        $ok = $false
    }
}

if (-not $ok) {
    Write-Warning "One or more databases failed to download. The engine still runs with geo disabled."
    exit 1
}

Write-Host ""
Write-Host "Done. Databases are in: $OutDir"
Write-Host "Enable them in garudashield.json under the 'geo' block."
