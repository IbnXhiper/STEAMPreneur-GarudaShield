#!/usr/bin/env python3
"""GarudaShield Python policy hook (example, stdlib only).

The Go engine pipes one JSON object per request to stdin:
  {"ip","method","path","user_agent","score","wire_bytes"}
where score is the risk accumulated by the Go pipeline so far.

Print exactly one JSON verdict to stdout:
  {"action":"pass|challenge|block","score":N,"reason":"..."}
action=pass may add extra risk points (score) to the Go total.
Any crash/timeout/garbage output fails closed on the Go side (block).

This example uses cheap heuristics. Replace decide() with a real model
(load a pickle/sklearn/onnx once at import, score per request) to make
the shield genuinely smarter. Start in pyhook.mode=monitor to collect
labels, then switch to enforce.
"""
import json
import sys

SUSPICIOUS_UA = ("sqlmap", "nessus", "nikto", "masscan", "nmap", "hydra",
                 "commix", "dalfox", "ffuf", "gobuster")


def decide(f):
    path = (f.get("path") or "").lower()
    ua = (f.get("user_agent") or "").lower()
    base = int(f.get("score") or 0)

    # Obvious traversal / injection the Go WAF may have scored low.
    if ".." in path or "%2e%2e" in path:
        return {"action": "block", "score": 0, "reason": "py-traversal"}
    if "union" in path and "select" in path:
        return {"action": "block", "score": 0, "reason": "py-sqli"}
    if any(s in ua for s in SUSPICIOUS_UA):
        return {"action": "challenge", "score": 0, "reason": "py-scanner-ua"}
    # Amplify: a request Go already finds suspicious gets extra weight.
    if base >= 20:
        return {"action": "pass", "score": 15, "reason": "py-amplify"}
    return {"action": "pass", "score": 0, "reason": "py-ok"}


def main():
    # Worker mode: NDJSON loop for persistent use (argv --worker).
    if "--worker" in sys.argv[1:]:
        for line in sys.stdin:
            line = line.strip()
            if not line:
                continue
            try:
                features = json.loads(line)
            except Exception:
                print(json.dumps({"action": "pass", "score": 0,
                                   "reason": "py-bad-input"}), flush=True)
                continue
            print(json.dumps(decide(features)), flush=True)
        return
    try:
        features = json.load(sys.stdin)
    except Exception:
        # Go side treats missing/garbage stdout as fail-closed; still try
        # to answer cleanly so logs stay readable.
        print(json.dumps({"action": "pass", "score": 0,
                           "reason": "py-bad-input"}))
        return
    print(json.dumps(decide(features)))


if __name__ == "__main__":
    main()
