#!/usr/bin/env bash
# PostgreSQL backup/restore for GarudaShield commercial state.
# Usage: ./tools/postgres-backup.sh backup
#        ./tools/postgres-backup.sh restore backups/postgres/<file>.dump
set -euo pipefail

cd "$(dirname "$0")/.."
ACTION="${1:-backup}"
BACKUP_DIR="${GS_BACKUP_DIR:-backups/postgres}"
# Default: postgres service in the prod compose. Override GS_PG_EXEC for a
# different container, e.g. GS_PG_EXEC="docker exec -i gs-postgres" for the
# local dev database.
if [ -n "${GS_PG_EXEC:-}" ]; then
  read -r -a PG_EXEC <<< "$GS_PG_EXEC"
else
  PG_EXEC=(docker compose -f docker-compose.prod.yml --env-file .env exec -T postgres)
fi

case "$ACTION" in
  backup)
    mkdir -p "$BACKUP_DIR"
    file="$BACKUP_DIR/garudashield-$(date -u +%Y%m%dT%H%M%SZ).dump"
    "${PG_EXEC[@]}" pg_dump \
      -U "${POSTGRES_USER:-garuda}" -d "${POSTGRES_DB:-garudashield}" \
      --format=custom --no-owner --no-acl > "$file"
    test -s "$file"
    echo "Backup written: $file"
    ;;
  restore)
    file="${2:-}"
    test -n "$file" && test -s "$file" || { echo "Restore file missing or empty" >&2; exit 1; }
    "${PG_EXEC[@]}" pg_restore \
      -U "${POSTGRES_USER:-garuda}" -d "${POSTGRES_DB:-garudashield}" \
      --clean --if-exists --no-owner --no-acl < "$file"
    echo "Restore complete: $file"
    ;;
  *)
    echo "Usage: $0 backup | restore <dump-file>" >&2
    exit 1
    ;;
esac
