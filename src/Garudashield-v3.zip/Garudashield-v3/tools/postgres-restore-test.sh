#!/usr/bin/env bash
# Destructive restore verifier for an isolated database in the running PG container.
# Usage: GS_PG_EXEC="docker exec -i gs-postgres" ./tools/postgres-restore-test.sh <dump>
set -euo pipefail

file="${1:?dump file required}"
test -s "$file"
read -r -a PG_EXEC <<< "${GS_PG_EXEC:-docker compose -f docker-compose.prod.yml --env-file .env exec -T postgres}"
user="${POSTGRES_USER:-garuda}"
test_db="garudashield_restore_test"

"${PG_EXEC[@]}" psql -U "$user" -d postgres -v ON_ERROR_STOP=1 \
  -c "DROP DATABASE IF EXISTS $test_db" -c "CREATE DATABASE $test_db"
"${PG_EXEC[@]}" pg_restore -U "$user" -d "$test_db" --no-owner --no-acl < "$file"
"${PG_EXEC[@]}" psql -U "$user" -d "$test_db" -v ON_ERROR_STOP=1 \
  -c "SELECT count(*) FROM tenants" -c "SELECT count(*) FROM users"
"${PG_EXEC[@]}" psql -U "$user" -d postgres -v ON_ERROR_STOP=1 -c "DROP DATABASE $test_db"
echo "Restore verified: $file"