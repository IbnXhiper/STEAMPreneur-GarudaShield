# build-windows.ps1 — build + smoke test GarudaShield v3 di Windows.
#
# Build bagian yang bisa di-build di Windows:
#   - Rust WAF matcher DLL  (wafmatcher.dll)          -> rustffi_windows.go
#   - Engine binary Windows (default, tanpa -tags ebpf)
# Lalu smoke test (semua jalan di Windows):
#   - license host-binding fail-closed (foreign-host key -> engine exit 1)
#   - HTTP/3 (QUIC) listener jawab lewat UDP
# XDP eBPF TIDAK di-test di sini (butuh Linux+root) — lihat tools/build-linux.sh.
#
# Penggunaan:
#   .\tools\build-windows.ps1
# Prasyarat: Go 1.24+, Rust (cargo) via rustup, OpenSSL di PATH (untuk self-signed cert).

param(
  [string]$Interface = "eth0"
)

$ErrorActionPreference = "Continue"
$ROOT = (Get-Item $PSScriptRoot).Parent.FullName
Set-Location $ROOT

$ADMIN_KEY  = if ($env:GS_ADMIN_SECRET)  { $env:GS_ADMIN_SECRET }  else { (& openssl rand -hex 32) }
$LIC_SECRET = if ($env:GS_LICENSE_SECRET) { $env:GS_LICENSE_SECRET } else { (& openssl rand -hex 32) }

function Need($cmd) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) {
    Write-Host "missing: $cmd" -ForegroundColor Red
    if ($cmd -eq "cargo") { Write-Host "  install: https://rustup.rs (rustup-init.exe)" }
    if ($cmd -eq "go")    { Write-Host "  install: https://go.dev/dl" }
    if ($cmd -eq "openssl"){ Write-Host "  install: winget install OpenSSL" }
    exit 1
  }
}

Write-Host "==> [1/4] toolchain check"
foreach ($c in @("go","cargo","openssl")) { Need $c }

Write-Host "==> [2/4] build Rust WAF matcher (wafmatcher.dll)"
Push-Location rust/wafmatcher
cargo build --release
Pop-Location
$DLL = (Resolve-Path "rust/wafmatcher/target/release/wafmatcher.dll").Path
Write-Host "  $DLL"

Write-Host "==> [3/4] build engine (windows)"
go build -o bin/gs.exe ./cmd/garudashield
$BIN = (Resolve-Path "bin/gs.exe").Path
Write-Host "  $BIN"

Write-Host "==> [4/4] smoke tests"
$env:GS_ADMIN_SECRET  = $ADMIN_KEY
$env:GS_LICENSE_SECRET = $LIC_SECRET
$env:GS_WAF_LIB       = $DLL

# 4a. license host-binding: key terikat host ASING -> engine harus exit 1
Write-Host "--- license binding (expect: foreign-host key -> engine exits 1)"
$FOREIGN_KEY = (go run ./tools/genlicense $LIC_SECRET tenant-x pro 0 foreignhost123)
Write-Host "  foreign key: $($FOREIGN_KEY.Substring(0,24))..."
"" | Set-Content C:/temp/gs-lic.json
$env:GS_LICENSE_KEY = $FOREIGN_KEY
& $BIN -config C:/temp/gs-lic.json > C:/temp/gs-lic.log 2>&1
if ($LASTEXITCODE -eq 0) {
  Write-Host "  FAIL: engine started despite foreign-host license" -ForegroundColor Red
} else {
  Write-Host "  OK: engine refused to start with foreign-host license" -ForegroundColor Green
}
Remove-Item Env:GS_LICENSE_KEY

# 4b. QUIC listener: start engine TLS+H3, cek log QUIC
Write-Host "--- QUIC listener (expect: 'http/3 (QUIC) listener starting')"
openssl req -x509 -newkey rsa:2048 -nodes -keyout C:/temp/gs-smoke.key -out C:/temp/gs-smoke.crt -days 1 -subj "/CN=localhost" 2>$null
$smoke = @"
{
  "version":"3.0.0","name":"smoke",
  "server":{
    "httpPort":18080,"host":"127.0.0.1","maxConcurrency":1000,
    "tls":{"enabled":true,"certFile":"C:/temp/gs-smoke.crt","keyFile":"C:/temp/gs-smoke.key"},
    "http3":{"enabled":true,"port":18083,"maxIncomingStreams":50}
  },
  "offload":{"enabled":false,"interface":"$Interface"}
}
"@
$smoke | Set-Content C:/temp/gs-smoke.json
$proc = Start-Process -FilePath $BIN -ArgumentList "-config","C:/temp/gs-smoke.json" -RedirectStandardOutput C:/temp/gs-smoke.log -PassThru
Start-Sleep -Seconds 2
$log = Get-Content C:/temp/gs-smoke.log -Raw
if ($log -match "QUIC") {
  Write-Host "  OK: QUIC listener started" -ForegroundColor Green
} else {
  Write-Host "  FAIL: QUIC not started" -ForegroundColor Red
  Write-Host ($log -split "`n" | Select-Object -Last 5)
}
Stop-Process -Id $proc.Id -Force -ErrorAction SilentlyContinue

# 4c. XDP note
Write-Host "--- XDP eBPF: SKIPPED on Windows (needs Linux+root). Run tools/build-linux.sh in WSL."

Write-Host "==> done. Artifacts: $DLL, $BIN"
