"use strict";

// checkhost.js — outbound check-host.net client routed through the proxy fleet.
//
//   node checkhost.js <host> [type]   (type: http|https|ping|tcp|dns)
//
// check-host.net is always the target; only the *checked host* varies, so this
// is an outbound-only utility (never an open relay). It submits the check via a
// random active proxy (hiding our IP), then polls check-result via fresh proxies
// until results appear, falling back to the permanent_link.

const fs = require("fs");
const path = require("path");
const { proxyFetch } = require("./proxyfetch");

const DIR = process.env.PROXY_DIR || path.join(__dirname, "..");
const ACTIVE = path.join(DIR, "active.txt");
const ACTIVE_JSON = path.join(DIR, "active.json");
const WAIT = parseInt(process.env.CHECKHOST_WAIT_MS || "7000", 10);
const TRIES = parseInt(process.env.CHECKHOST_TRIES || "12", 10);
const POOL = parseInt(process.env.CHECKHOST_POOL || "20", 10);
const BASE = "https://check-host.net";
const HEADERS = { Referer: BASE + "/" };

const PATHS = { http: "/check-http", https: "/check-http", ping: "/check-ping", tcp: "/check-tcp", dns: "/check-dns" };

function readActiveFile() {
  try {
    return fs
      .readFileSync(ACTIVE, "utf8")
      .split("\n")
      .map((s) => s.trim())
      .filter(Boolean);
  } catch {
    return [];
  }
}

// readActiveMeta returns [{proxy, latencyMs}] sorted best-first when available.
function readActiveMeta() {
  try {
    const j = JSON.parse(fs.readFileSync(ACTIVE_JSON, "utf8"));
    if (Array.isArray(j.proxies)) return j.proxies.filter((p) => p && p.proxy);
  } catch {
    /* fall through */
  }
  return readActiveFile().map((proxy) => ({ proxy, latencyMs: 0 }));
}

function randInt(n) {
  return Math.floor(Math.random() * n);
}

// proxyGetJson fetches a URL through active proxies (fastest first, with a little
// randomisation) until one returns parseable JSON.
async function proxyGetJson(url, headers, list) {
  if (!list.length) throw new Error("no active proxies");
  const ordered = list.slice(0, POOL);
  for (let i = ordered.length - 1; i > 0; i--) {
    const j = randInt(i + 1);
    [ordered[i], ordered[j]] = [ordered[j], ordered[i]];
  }
  let lastErr = "no attempt";
  for (const item of ordered) {
    const proxy = typeof item === "string" ? item : item.proxy;
    try {
      const r = await proxyFetch(url, proxy, { timeout: 15000, headers });
      if (r.status !== 200) {
        lastErr = "http " + r.status;
        continue;
      }
      let j;
      try {
        j = JSON.parse(r.body);
      } catch {
        lastErr = "non-JSON";
        continue;
      }
      return { proxy, json: j };
    } catch (e) {
      lastErr = String(e && e.message ? e.message : e);
    }
  }
  throw new Error("all proxies failed (" + lastErr + ")");
}

async function checkHost(host, type, list) {
  const proxies = list && list.length ? list : readActiveMeta();
  const pth = PATHS[type] || PATHS.http;
  const url = `${BASE}${pth}?host=${encodeURIComponent(host)}&max_nodes=6`;
  const submit = await proxyGetJson(url, HEADERS, proxies);
  const sj = submit.json;
  if (!sj.request_id) throw new Error("check-host rejected: " + JSON.stringify(sj).slice(0, 160));
  let results = {};
  for (let i = 0; i < TRIES; i++) {
    await new Promise((r) => setTimeout(r, WAIT));
    try {
      results = (await proxyGetJson(`${BASE}/check-result/${sj.request_id}`, HEADERS, proxies)).json;
    } catch (e) {
      results = { error: String(e && e.message ? e.message : e) };
    }
    if (results && Object.values(results).some((v) => v != null)) break;
  }
  return { ok: true, proxy: submit.proxy, request_id: sj.request_id, permanent_link: sj.permanent_link, nodes: sj.nodes, result: results };
}

module.exports = { checkHost, proxyGetJson, readActiveFile, readActiveMeta };

if (require.main === module) {
  const host = process.argv[2];
  const type = process.argv[3] || "http";
  if (!host) {
    console.error("usage: node checkhost.js <host> [http|https|ping|tcp|dns]");
    process.exit(2);
  }
  checkHost(host, type)
    .then((r) => {
      console.log(JSON.stringify(r, null, 2));
      process.exit(0);
    })
    .catch((e) => {
      console.error("error: " + (e && e.message ? e.message : e));
      process.exit(1);
    });
}
