"use strict";

// checker.js — liveness probe + ranking for scraped Indonesian proxies.
//
// Reads `indo.txt`, tests each candidate (SOCKS5 and HTTP proxy modes) against
// TEST_TARGET (default: a small check-host.net asset, so retained proxies can
// really reach check-host), measures latency, and writes:
//   active.txt   -> reachable proxies, best (lowest) latency first
//   active.json  -> { checkedAt, candidates, tested, active, proxies:[{proxy,latencyMs}] }
// Previously-good proxies that fail this sweep are carried over for
// CHECK_CARRYOVER_MS (marked stale) so the fleet never drops to zero on a bad run.
// No external deps.

const fs = require("fs");
const path = require("path");
const { proxyFetch } = require("./proxyfetch");

const DIR = process.env.PROXY_DIR || path.join(__dirname, "..");
const INDO = path.join(DIR, "indo.txt");
const ACTIVE = path.join(DIR, "active.txt");
const ACTIVE_JSON = path.join(DIR, "active.json");

const TARGET = process.env.TEST_TARGET || "https://check-host.net/checkhost-favicon.png";
const TARGET2 = process.env.TEST_TARGET_2 || "";
const RETRY = parseInt(process.env.CHECK_RETRY || "0", 10);
const TIMEOUT = parseInt(process.env.CHECK_TIMEOUT_MS || "6000", 10);
const CONCURRENCY = parseInt(process.env.CHECK_CONCURRENCY || "250", 10);
const MAX_PROXIES = parseInt(process.env.CHECK_MAX || "3000", 10);
const CARRYOVER = parseInt(process.env.CHECK_CARRYOVER_MS || "1800000", 10);

const RE = /^\d{1,3}(\.\d{1,3}){3}:\d{1,5}$/;

function log(m) {
  console.log(new Date().toISOString() + " [checker] " + m);
}

function readProxies() {
  let txt = "";
  try {
    txt = fs.readFileSync(INDO, "utf8");
  } catch (e) {
    log("no indo.txt yet (" + e.message + ")");
    return [];
  }
  const set = new Set();
  for (const line of txt.split("\n")) {
    const p = line.trim();
    if (RE.test(p)) set.add(p);
  }
  return Array.from(set);
}

function readPrev() {
  try {
    const j = JSON.parse(fs.readFileSync(ACTIVE_JSON, "utf8"));
    return Array.isArray(j.proxies) ? j : { proxies: [] };
  } catch {
    return { proxies: [] };
  }
}

async function probeOnce(proxy, target) {
  const t0 = Date.now();
  try {
    const r = await proxyFetch(target, proxy, { timeout: TIMEOUT, headers: { Accept: "*/*" } });
    if (r && r.status > 0 && r.status < 500) return Date.now() - t0;
  } catch {
    /* dead */
  }
  return null;
}

// probe tries the primary target, then the fallback (if set) and extra retries.
async function probe(proxy) {
  const targets = TARGET2 ? [TARGET, TARGET2] : [TARGET];
  for (const t of targets) {
    const ms = await probeOnce(proxy, t);
    if (ms != null) return ms;
  }
  for (let i = 0; i < RETRY; i++) {
    const ms = await probeOnce(proxy, TARGET);
    if (ms != null) return ms;
  }
  return null;
}

// testOne resolves to { proxy, latencyMs } on first success, else null.
function testOne(raw) {
  return new Promise((resolve) => {
    let pending = 2;
    let done = false;
    const finish = (v) => {
      if (done) return;
      if (v) {
        done = true;
        resolve(v);
      } else if (--pending === 0) {
        done = true;
        resolve(null);
      }
    };
    const run = (label) => probe(label).then((ms) => finish(ms != null ? { proxy: label, latencyMs: ms } : null));
    run("socks5://" + raw);
    run(raw);
  });
}

async function pool(items, worker, limit) {
  const results = [];
  let idx = 0;
  const runners = [];
  for (let w = 0; w < limit; w++) {
    runners.push(
      (async () => {
        for (;;) {
          const cur = idx++;
          if (cur >= items.length) break;
          const r = await worker(items[cur]);
          if (r) results.push(r);
        }
      })()
    );
  }
  await Promise.all(runners);
  return results;
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

async function run() {
  const all = shuffle(readProxies());
  const sample = all.slice(0, MAX_PROXIES);
  log(`candidates=${all.length} testing=${sample.length} concurrency=${CONCURRENCY} timeout=${TIMEOUT}ms`);
  const started = Date.now();
  const fresh = await pool(sample, testOne, CONCURRENCY);
  fresh.sort((a, b) => a.latencyMs - b.latencyMs);

  const seen = new Set(fresh.map((x) => x.proxy));
  const carried = [];
  const now = Date.now();
  if (CARRYOVER > 0) {
    for (const p of readPrev().proxies) {
      if (!p || !p.proxy || seen.has(p.proxy)) continue;
      if (p.stale && now - (p.checkedAt || 0) > CARRYOVER) continue;
      carried.push({ proxy: p.proxy, latencyMs: p.latencyMs || 0, stale: true, checkedAt: now });
    }
  }
  const merged = fresh.map((x) => ({ proxy: x.proxy, latencyMs: x.latencyMs, stale: false, checkedAt: now })).concat(carried);

  fs.writeFileSync(ACTIVE, merged.length ? merged.map((x) => x.proxy).join("\n") + "\n" : "");
  fs.writeFileSync(
    ACTIVE_JSON,
    JSON.stringify(
      {
        checkedAt: now,
        elapsedMs: now - started,
        candidates: all.length,
        tested: sample.length,
        active: merged.length,
        fresh: fresh.length,
        carried: carried.length,
        proxies: merged,
      },
      null,
      2
    )
  );
  log(`active=${merged.length} (fresh=${fresh.length} carried=${carried.length}) in ${((Date.now() - started) / 1000).toFixed(1)}s`);
  return merged;
}

module.exports = { run, readProxies, testOne };

if (require.main === module) {
  run()
    .then(() => process.exit(0))
    .catch((e) => {
      console.error(e);
      process.exit(1);
    });
}
