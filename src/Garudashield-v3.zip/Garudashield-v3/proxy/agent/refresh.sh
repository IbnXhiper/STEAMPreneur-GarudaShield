#!/bin/sh
# refresh.sh — one-shot scrape + liveness check. The agent schedules this
# internally every REFRESH_INTERVAL_MS; run manually when needed.
set -e
cd "$(dirname "$0")/.."
node proxy_scrapper.js
node agent/checker.js
