"use strict";

// agent.js — long-running proxy fleet manager for GarudaShield.
//
// Every REFRESH_INTERVAL_MS (default 5 min): run `node proxy_scrapper.js`
// (fresh output) then checker.js (liveness ranking) -> active.txt / active.json.
//
// Localhost JSON API:
//   GET  /health
//   GET  /stats
//   GET  /metrics                    (Prometheus text)
//   GET  /proxies/active?limit=N&meta=1
//   POST /refresh                    {X-Auth-Token} if AGENT_TOKEN set
//   POST /checkhost {host,type}      {X-Auth-Token} if AGENT_TOKEN set
//
// Outbound-only utility: only check-host.net is ever called, never user traffic.

const http = require("http");
const fs = require("fs");
const path = require("path");
const { spawn } = require("child_process");
const checker = require("./checker");
const { checkHost, readActiveMeta } = require("./checkhost");

const ROOT = process.env.PROXY_DIR || path.join(__dirname, "..");
const ACTIVE_JSON = path.join(ROOT, "active.json");

const HOST = process.env.AGENT_HOST || "127.0.0.1";
const PORT = parseInt(process.env.AGENT_PORT || "8787", 10);
const TOKEN = process.env.AGENT_TOKEN || "";
const INTERVAL = parseInt(process.env.REFRESH_INTERVAL_MS || "300000", 10);

const STARTED = Date.now();
const counters = { refresh: 0, refreshErrors: 0, checkhost: 0, checkhostErrors: 0 };
let refreshing = false;
let lastRefresh = 0;
let lastError = null;

// check-host results are cached briefly and POST routes are rate-limited so the
// panel (or an operator) cannot hammer the upstream from the localhost API.
const CACHE_MS = parseInt(process.env.CHECKHOST_CACHE_MS || "60000", 10);
const RATE = parseInt(process.env.AGENT_API_RATE || "60", 10);
const RATE_WINDOW = parseInt(process.env.AGENT_API_RATE_WINDOW_MS || "60000", 10);
const chCache = new Map();
const hits = new Map();

function cacheGet(key) {
  const e = chCache.get(key);
  if (e && Date.now() - e.at < CACHE_MS) return e.value;
  if (e) chCache.delete(key);
  return null;
}

function cachePut(key, value) {
  chCache.set(key, { at: Date.now(), value });
}

function rateLimited(ip) {
  const now = Date.now();
  const arr = (hits.get(ip) || []).filter((t) => now - t < RATE_WINDOW);
  if (arr.length >= RATE) {
    hits.set(ip, arr);
    return true;
  }
  arr.push(now);
  hits.set(ip, arr);
  return false;
}

function log(m) {
  console.log(new Date().toISOString() + " [agent] " + m);
}

function readMeta() {
  try {
    return JSON.parse(fs.readFileSync(ACTIVE_JSON, "utf8"));
  } catch {
    return null;
  }
}

function readActive() {
  return readActiveMeta().map((p) => p.proxy);
}

function runScraper() {
  return new Promise((resolve, reject) => {
    const child = spawn("node", ["proxy_scrapper.js"], { cwd: ROOT });
    child.on("error", reject);
    child.on("close", (code) => (code === 0 ? resolve() : reject(new Error("scraper exit " + code))));
  });
}

async function refresh(reason) {
  if (refreshing) return { ok: false, error: "already running" };
  refreshing = true;
  try {
    log("refresh start (" + reason + ")");
    await runScraper();
    const active = await checker.run();
    counters.refresh++;
    lastRefresh = Date.now();
    lastError = null;
    log("refresh done, active=" + active.length);
    return { ok: true, active: active.length };
  } catch (e) {
    counters.refreshErrors++;
    lastError = String(e && e.message ? e.message : e);
    log("refresh failed: " + lastError);
    return { ok: false, error: lastError };
  } finally {
    refreshing = false;
  }
}

function json(res, code, obj) {
  const b = Buffer.from(JSON.stringify(obj));
  res.writeHead(code, { "Content-Type": "application/json", "Content-Length": b.length });
  res.end(b);
}

function text(res, code, body) {
  const b = Buffer.from(body);
  res.writeHead(code, { "Content-Type": "text/plain; version=0.0.4", "Content-Length": b.length });
  res.end(b);
}

function body(req) {
  return new Promise((resolve) => {
    let d = "";
    req.on("data", (c) => (d += c));
    req.on("end", () => resolve(d));
  });
}

function authed(req) {
  if (!TOKEN) return true;
  return req.headers["x-auth-token"] === TOKEN;
}

function metrics(meta) {
  const active = meta && typeof meta.active === "number" ? meta.active : 0;
  const lines = [
    "# HELP garudashield_proxy_active Active proxies in the fleet.",
    "# TYPE garudashield_proxy_active gauge",
    "garudashield_proxy_active " + active,
    "# HELP garudashield_proxy_active_fresh Freshly-verified proxies.",
    "# TYPE garudashield_proxy_active_fresh gauge",
    "garudashield_proxy_active_fresh " + ((meta && meta.fresh) || 0),
    "# HELP garudashield_proxy_refresh_total Completed refresh cycles.",
    "# TYPE garudashield_proxy_refresh_total counter",
    "garudashield_proxy_refresh_total " + counters.refresh,
    "# HELP garudashield_proxy_refresh_errors_total Failed refresh cycles.",
    "# TYPE garudashield_proxy_refresh_errors_total counter",
    "garudashield_proxy_refresh_errors_total " + counters.refreshErrors,
    "# HELP garudashield_proxy_checkhost_total check-host.net calls served.",
    "# TYPE garudashield_proxy_checkhost_total counter",
    "garudashield_proxy_checkhost_total " + counters.checkhost,
    "# HELP garudashield_proxy_checkhost_errors_total check-host.net calls that failed.",
    "# TYPE garudashield_proxy_checkhost_errors_total counter",
    "garudashield_proxy_checkhost_errors_total " + counters.checkhostErrors,
    "# HELP garudashield_proxy_last_refresh_timestamp_seconds Unix time of last refresh.",
    "# TYPE garudashield_proxy_last_refresh_timestamp_seconds gauge",
    "garudashield_proxy_last_refresh_timestamp_seconds " + Math.floor(lastRefresh / 1000),
    "# HELP garudashield_proxy_uptime_seconds Agent uptime.",
    "# TYPE garudashield_proxy_uptime_seconds gauge",
    "garudashield_proxy_uptime_seconds " + Math.floor((Date.now() - STARTED) / 1000),
  ];
  return lines.join("\n") + "\n";
}

const server = http.createServer(async (req, res) => {
  const u = new URL(req.url, "http://x");
  try {
    if (req.method === "GET" && u.pathname === "/health") {
      return json(res, 200, { ok: true, refreshing, lastRefresh, lastError, active: (readMeta() || {}).active || 0 });
    }
    if (u.pathname !== "/health" && !authed(req)) {
      return json(res, 401, { ok: false, error: "unauthorized" });
    }
    if (req.method === "GET" && u.pathname === "/stats") {
      return json(res, 200, {
        active: (readMeta() || {}).active || 0,
        counters,
        refreshing,
        lastRefresh,
        lastError,
        intervalMs: INTERVAL,
        uptimeMs: Date.now() - STARTED,
        meta: readMeta(),
      });
    }
    if (req.method === "GET" && u.pathname === "/metrics") {
      return text(res, 200, metrics(readMeta()));
    }
    if (req.method === "GET" && u.pathname === "/proxies/active") {
      const limit = Math.min(parseInt(u.searchParams.get("limit") || "50", 10) || 50, 5000);
      const meta = readActiveMeta();
      if (u.searchParams.get("meta") === "1") return json(res, 200, { count: meta.length, proxies: meta.slice(0, limit) });
      return json(res, 200, { count: meta.length, proxies: meta.slice(0, limit).map((p) => p.proxy) });
    }
    if (req.method === "POST" && u.pathname === "/refresh") {
      if (!authed(req)) return json(res, 401, { ok: false, error: "unauthorized" });
      const r = await refresh("api");
      return json(res, r.ok ? 200 : 409, r);
    }
    if (req.method === "POST" && u.pathname === "/checkhost") {
      if (!authed(req)) return json(res, 401, { ok: false, error: "unauthorized" });
      const raw = await body(req);
      let p = {};
      try {
        p = raw ? JSON.parse(raw) : {};
      } catch {
        return json(res, 400, { ok: false, error: "bad json" });
      }
      if (!p.host) return json(res, 400, { ok: false, error: "host required" });
      const ip = req.socket.remoteAddress || "local";
      if (rateLimited(ip)) return json(res, 429, { ok: false, error: "rate limited" });
      const cacheKey = `${p.type || "http"}:${p.host}`;
      const cached = cacheGet(cacheKey);
      if (cached) return json(res, 200, { ...cached, cached: true });
      counters.checkhost++;
      try {
        const r = await checkHost(p.host, p.type || "http", readActiveMeta());
        cachePut(cacheKey, r);
        return json(res, 200, { ...r, cached: false });
      } catch (e) {
        counters.checkhostErrors++;
        throw e;
      }
    }
    return json(res, 404, { ok: false, error: "not found" });
  } catch (e) {
    return json(res, 500, { ok: false, error: String(e && e.message ? e.message : e) });
  }
});

server.listen(PORT, HOST, () => {
  log(`listening on ${HOST}:${PORT} interval=${INTERVAL}ms token=${TOKEN ? "on" : "off"}`);
  readActive();
  refresh("startup");
  setInterval(() => refresh("timer"), INTERVAL);
});
