"use strict";

// proxyfetch.js — minimal outbound HTTP client that routes one request through
// an upstream proxy. No external deps.
//   * http://  target via HTTP proxy  -> absolute-URI request
//   * https:// target via HTTP proxy  -> CONNECT tunnel + TLS
//   * any target via SOCKS5 proxy     -> SOCKS5 handshake + (TLS) + request
//
// Proxy strings: "ip:port" (HTTP, default), "http://ip:port", "socks5://ip:port".
//
// Security note: free public proxies are untrusted relays. Only use this for
// OUTBOUND monitoring calls (never for user traffic).

const http = require("http");
const net = require("net");
const tls = require("tls");

const UA =
  process.env.PROXY_UA ||
  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36";

function parseProxy(str) {
  let proto = "http";
  let rest = str;
  const m = /^(socks5|socks4|http|https):\/\//.exec(str);
  if (m) {
    proto = m[1] === "https" ? "http" : m[1];
    rest = str.slice(m[0].length);
  } else if (/:1080$|:1081$|:9050$/.test(str)) {
    proto = "socks5"; // best-effort guess for the common SOCKS ports
  }
  const i = rest.lastIndexOf(":");
  if (i < 0) throw new Error("bad proxy " + str);
  return { proto, host: rest.slice(0, i), port: parseInt(rest.slice(i + 1), 10) };
}

function dechunk(buf) {
  const out = [];
  let i = 0;
  while (i < buf.length) {
    const j = buf.indexOf("\r\n", i);
    if (j < 0) break;
    const size = parseInt(buf.slice(i, j).toString("latin1").trim(), 16);
    if (isNaN(size)) break;
    i = j + 2;
    if (size === 0) break;
    out.push(buf.slice(i, i + size));
    i += size + 2;
  }
  return Buffer.concat(out);
}

function parseRawResponse(buf) {
  const sep = buf.indexOf("\r\n\r\n");
  if (sep < 0) throw new Error("no header terminator");
  const head = buf.slice(0, sep).toString("latin1");
  let body = buf.slice(sep + 4);
  const lines = head.split("\r\n");
  const m = /^HTTP\/\d\.\d\s+(\d+)/.exec(lines[0]);
  const status = m ? parseInt(m[1], 10) : 0;
  const headers = {};
  for (const line of lines.slice(1)) {
    const c = line.indexOf(":");
    if (c > 0) headers[line.slice(0, c).trim().toLowerCase()] = line.slice(c + 1).trim();
  }
  if ((headers["transfer-encoding"] || "").toLowerCase().includes("chunked")) body = dechunk(body);
  return { status, headers, body: body.toString("utf8") };
}

// socks5Connect opens a TCP tunnel to target host:port through a SOCKS5 proxy.
function socks5Connect(proxy, host, port, timeout) {
  return new Promise((resolve, reject) => {
    let buf = Buffer.alloc(0);
    let state = "greet";
    let settled = false;
    const fail = (e) => {
      if (settled) return;
      settled = true;
      sock.destroy();
      reject(e instanceof Error ? e : new Error(String(e)));
    };
    const sock = net.connect({ host: proxy.host, port: proxy.port });
    sock.setTimeout(timeout, () => fail(new Error("socks5 timeout")));
    sock.on("error", (e) => fail(e));
    sock.on("close", () => {
      if (state !== "done") fail(new Error("socks5 closed early"));
    });
    sock.on("connect", () => sock.write(Buffer.from([0x05, 0x01, 0x00])));
    sock.on("data", (d) => {
      buf = Buffer.concat([buf, d]);
      if (state === "greet") {
        if (buf.length < 2) return;
        if (buf[0] !== 0x05 || buf[1] !== 0x00) return fail(new Error("socks5 auth rejected"));
        buf = buf.slice(2);
        state = "reply";
        const hb = Buffer.from(host, "utf8");
        sock.write(
          Buffer.concat([Buffer.from([0x05, 0x01, 0x00, 0x03, hb.length]), hb, Buffer.from([(port >> 8) & 0xff, port & 0xff])])
        );
      }
      if (state === "reply") {
        if (buf.length < 4) return;
        if (buf[1] !== 0x00) return fail(new Error("socks5 connect code " + buf[1]));
        const atyp = buf[3];
        let need;
        if (atyp === 0x01) need = 10;
        else if (atyp === 0x04) need = 22;
        else if (atyp === 0x03) {
          if (buf.length < 5) return;
          need = 7 + buf[4];
        } else return fail(new Error("socks5 bad atyp"));
        if (buf.length < need) return;
        state = "done";
        settled = true;
        sock.setTimeout(0);
        sock.removeAllListeners("data");
        resolve(sock);
      }
    });
  });
}

// writeAndRead sends an HTTP/1.1 request over an already-connected socket.
function writeAndRead(socket, url, opts) {
  const timeout = opts.timeout || 15000;
  const method = opts.method || "GET";
  const baseHeaders = Object.assign(
    { Host: url.host, "User-Agent": UA, Accept: "application/json", "Accept-Encoding": "identity", Connection: "close" },
    opts.headers || {}
  );
  const bodyBuf = opts.body ? Buffer.from(opts.body) : null;
  if (bodyBuf) baseHeaders["Content-Length"] = String(bodyBuf.length);
  let raw = `${method} ${url.pathname}${url.search || ""} HTTP/1.1\r\n`;
  for (const [k, v] of Object.entries(baseHeaders)) raw += `${k}: ${v}\r\n`;
  raw += "\r\n";
  return new Promise((resolve, reject) => {
    const bufs = [];
    socket.setTimeout(timeout, () => socket.destroy(new Error("read timeout")));
    socket.on("data", (d) => bufs.push(d));
    socket.on("end", () => {
      try {
        resolve(parseRawResponse(Buffer.concat(bufs)));
      } catch (e) {
        reject(e);
      }
    });
    socket.on("error", reject);
    socket.write(raw);
    if (bodyBuf) socket.write(bodyBuf);
  });
}

function proxyFetch(urlStr, proxyStr, opts = {}) {
  const url = new URL(urlStr);
  const p = parseProxy(proxyStr);
  const timeout = opts.timeout || 15000;
  const isHttps = url.protocol === "https:";
  // Free proxies frequently MITM TLS. Only the public check-host.net data is
  // fetched through them, so verification may be relaxed via PROXY_TLS_INSECURE=1.
  const insecure = opts.insecure === true || process.env.PROXY_TLS_INSECURE === "1";
  const rejectUnauthorized = !insecure;

  if (p.proto === "socks5") {
    return socks5Connect(p, url.hostname, url.port || (isHttps ? 443 : 80), timeout).then((sock) => {
      if (!isHttps) return writeAndRead(sock, url, opts);
      return new Promise((resolve, reject) => {
        const ts = tls.connect({ socket: sock, servername: url.hostname, rejectUnauthorized }, () => {
          writeAndRead(ts, url, opts).then(resolve, reject);
        });
        ts.setTimeout(timeout, () => ts.destroy(new Error("tls timeout")));
        ts.on("error", reject);
      });
    });
  }

  if (p.proto !== "http") return Promise.reject(new Error("unsupported proxy protocol " + p.proto));

  if (!isHttps) {
    return new Promise((resolve, reject) => {
      const req = http.request({
        host: p.host,
        port: p.port,
        method: opts.method || "GET",
        path: url.href,
        headers: Object.assign({ Host: url.host, "User-Agent": UA, Accept: "*/*", Connection: "close" }, opts.headers || {}),
      });
      req.setTimeout(timeout, () => req.destroy(new Error("timeout")));
      req.on("error", reject);
      req.on("response", (res) => {
        const bufs = [];
        res.on("data", (d) => bufs.push(d));
        res.on("end", () => {
          const headers = {};
          for (const [k, v] of Object.entries(res.headers)) headers[k.toLowerCase()] = v;
          let body = Buffer.concat(bufs);
          if ((headers["transfer-encoding"] || "").toLowerCase().includes("chunked")) body = dechunk(body);
          resolve({ status: res.statusCode, headers, body: body.toString("utf8") });
        });
        res.on("error", reject);
      });
      if (opts.body) req.write(opts.body);
      req.end();
    });
  }

  return new Promise((resolve, reject) => {
    const req = http.request({
      host: p.host,
      port: p.port,
      method: "CONNECT",
      path: url.hostname + ":" + (url.port || 443),
      headers: { Host: url.host, "Proxy-Connection": "keep-alive", "User-Agent": UA },
    });
    req.setTimeout(timeout, () => req.destroy(new Error("connect timeout")));
    req.on("error", reject);
    req.on("connect", (res, socket) => {
      if (res.statusCode !== 200) {
        socket.destroy();
        return reject(new Error("proxy CONNECT " + res.statusCode));
      }
      const ts = tls.connect({ socket, servername: url.hostname, rejectUnauthorized }, () => {
        writeAndRead(ts, url, opts).then(resolve, reject);
      });
      ts.setTimeout(timeout, () => ts.destroy(new Error("tls timeout")));
      ts.on("error", reject);
    });
    req.end();
  });
}

module.exports = { proxyFetch, parseProxy, parseRawResponse, socks5Connect };
