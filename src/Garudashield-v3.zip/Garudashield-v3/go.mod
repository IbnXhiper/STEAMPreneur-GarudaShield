module github.com/ahkurdev/garudashield

go 1.26.0

require (
	github.com/cilium/ebpf v0.22.0
	github.com/jackc/pgx/v5 v5.7.1
	github.com/oschwald/maxminddb-golang/v2 v2.5.0
	github.com/prometheus/client_golang v1.24.1
	github.com/quic-go/quic-go v0.62.0
	github.com/redis/go-redis/v9 v9.22.0
	golang.org/x/crypto v0.55.0
	golang.org/x/net v0.58.0
)

require (
	github.com/beorn7/perks v1.0.1 // indirect
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/munnerz/goautoneg v0.0.0-20191010083416-a7dc8b61c822 // indirect
	github.com/prometheus/client_model v0.6.2 // indirect
	github.com/prometheus/common v0.70.1 // indirect
	github.com/prometheus/procfs v0.21.1 // indirect
	github.com/quic-go/qpack v0.6.0 // indirect
	go.uber.org/atomic v1.11.0 // indirect
	golang.org/x/sync v0.22.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
	google.golang.org/protobuf v1.36.11 // indirect
)
