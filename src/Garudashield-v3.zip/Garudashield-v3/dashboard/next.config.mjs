/** @type {import('next').NextConfig} */

// Security headers applied to every response emitted by this Next.js app
// (pages, static assets and the /api BFF route handlers). Values stay narrow:
// MIME sniffing and ambient permissions are disabled and COOP keeps
// cross-origin opener leaks away. A Content-Security-Policy is deliberately
// NOT set here: the engine already sends frame-ancestors 'none' on every
// edge response and Caddy sends X-Frame-Options: DENY, so clickjacking is
// covered upstream — and a resource-restricting CSP breaks the Google Fonts
// <link> Plus Jakarta Sans uses.
const securityHeaders = [
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  { key: "Permissions-Policy", value: "camera=(), microphone=(), geolocation=(), browsing-topics=()" },
  { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
];

// Static asset caching. Public marketing pages are pre-rendered (SSG) so the
// landing site is served as static HTML; the build-hashed /_next/static bundle
// is safe to cache immutably for a year. Uploaded/brand assets get a shorter
// window so a logo swap propagates without a full redeploy.
const immutableCache = [
  { key: "Cache-Control", value: "public, max-age=31536000, immutable" },
];
const assetCache = [
  { key: "Cache-Control", value: "public, max-age=86400, stale-while-revalidate=604800" },
];

const nextConfig = {
  reactStrictMode: true,
  poweredByHeader: false,
  compress: true,
  async headers() {
    return [
      { source: "/:path*", headers: securityHeaders },
      { source: "/_next/static/:path*", headers: immutableCache },
      { source: "/logo.jpg", headers: assetCache },
      { source: "/icon.svg", headers: assetCache },
    ];
  },
};

export default nextConfig;