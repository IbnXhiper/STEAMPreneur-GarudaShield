import Link from "next/link";
import Logo from "@/components/Logo";

export default function Footer() {
  return (
    <footer className="border-t border-edge bg-white mt-24">
      <div className="container-x py-12 grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2.5 mb-3">
            <Logo size={36} />
            <span className="font-display text-lg font-semibold text-slate-900">
              Garuda<span className="text-[#8A6D1F]">Shield</span>
            </span>
          </div>
          <p className="text-sm text-muted max-w-sm">
            Lapisan mitigasi DDoS Layer 4 &amp; 7 dan WAF edge. Tetap online, bahkan saat diserang.
          </p>
          <a
            href="https://wa.me/6283187815456"
            className="btn mt-4 inline-flex items-center gap-2"
            target="_blank"
            rel="noreferrer"
          >
            Order via WhatsApp
          </a>
        </div>

        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted mb-4">Produk</div>
          <ul className="space-y-1 text-sm">
            <li><Link href="/features" className="inline-block py-1 text-muted hover:text-slate-900">Fitur</Link></li>
            <li><Link href="/status" className="inline-block py-1 text-muted hover:text-slate-900">Status Jaringan</Link></li>
            <li><Link href="/docs" className="inline-block py-1 text-muted hover:text-slate-900">Dokumentasi</Link></li>
            <li><Link href="/chat" className="inline-block py-1 text-muted hover:text-slate-900">AI Garuda</Link></li>
          </ul>
        </div>

        <div>
          <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-muted mb-4">Sponsor</div>
          <p className="text-sm text-muted">
            Didukung oleh{" "}
            <a href="https://bagibagi.co" target="_blank" rel="noreferrer" className="text-accent-ink hover:text-slate-900 hover:underline">
              BagiBagi.co
            </a>{" "}
            — platform sawer &amp; support untuk streamer Indonesia.
          </p>
          <p className="text-xs text-muted mt-4">© {new Date().getFullYear()} GarudaShield. Seluruh hak cipta dilindungi.</p>
        </div>
      </div>
    </footer>
  );
}
