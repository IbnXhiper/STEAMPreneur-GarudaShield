"use client";

/**
 * Icon set for the console and marketing shell.
 *
 * Presentation only: a single 1.6px stroke, 24px grid and one colour rule so
 * navigation, status rows and buttons read as one system. Icons never carry
 * meaning on their own — every usage pairs them with a visible text label.
 */

export type IconName =
  | "overview"
  | "traffic"
  | "charts"
  | "geo"
  | "top"
  | "logs"
  | "blocklist"
  | "whitelist"
  | "reputation"
  | "waf"
  | "ratelimit"
  | "protect"
  | "cluster"
  | "alerts"
  | "settings"
  | "proxy"
  | "shield"
  | "shield-check"
  | "shield-alert"
  | "check"
  | "alert"
  | "info"
  | "unknown"
  | "server"
  | "activity"
  | "zap"
  | "lock"
  | "external"
   | "menu"
   | "pause"
   | "play"
   | "search";

const PATHS: Record<IconName, React.ReactNode> = {
  overview: (
    <>
      <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
      <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
      <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
    </>
  ),
  traffic: (
    <>
      <path d="M3 17h4l2.5-7 3 11 2.5-8 1.5 4H21" />
    </>
  ),
  charts: (
    <>
      <path d="M4 20V10M10 20V4M16 20v-7M22 20H2" />
    </>
  ),
  geo: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18M12 3c2.5 2.5 3.8 5.7 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.7-3.8-9s1.3-6.5 3.8-9z" />
    </>
  ),
  top: (
    <>
      <path d="M4 20h16M4 20V9M9.5 20V4M15 20v-8M20.5 20v-5" />
    </>
  ),
  logs: (
    <>
      <path d="M5 3.5h9l5 5V20a1 1 0 01-1 1H5a1 1 0 01-1-1V4.5a1 1 0 011-1z" />
      <path d="M14 3.5V9h5M8 13h8M8 17h5" />
    </>
  ),
  blocklist: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M6 18L18 6" />
    </>
  ),
  whitelist: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M8.5 12.2l2.4 2.4 4.6-5" />
    </>
  ),
  reputation: (
    <>
      <path d="M12 3l7.5 3v5.4c0 4.6-3.1 8.3-7.5 9.6-4.4-1.3-7.5-5-7.5-9.6V6L12 3z" />
      <path d="M12 8.5v3.5M12 15h.01" />
    </>
  ),
  waf: (
    <>
      <rect x="3.5" y="4.5" width="17" height="15" rx="2" />
      <path d="M3.5 9.5h17M8 4.5v5" />
      <circle cx="12" cy="14.5" r="2.2" />
    </>
  ),
  ratelimit: (
    <>
      <path d="M12 3.5a8.5 8.5 0 108.5 8.5" />
      <path d="M12 7.5V12l3 2" />
      <path d="M16.5 16.5l4 4" />
    </>
  ),
  protect: (
    <>
      <path d="M12 3l7.5 3v5.4c0 4.6-3.1 8.3-7.5 9.6-4.4-1.3-7.5-5-7.5-9.6V6L12 3z" />
      <path d="M9.3 12.2l1.9 1.9 3.6-3.9" />
    </>
  ),
  cluster: (
    <>
      <circle cx="12" cy="5.5" r="2.2" />
      <circle cx="5.5" cy="19" r="2.2" />
      <circle cx="18.5" cy="19" r="2.2" />
      <path d="M12 7.7v4.3M12 12L6.7 16.8M12 12l5.3 4.8" />
    </>
  ),
  proxy: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M3.5 12h17" />
      <path d="M12 3.5c2.4 2.3 3.7 5.2 3.7 8.5s-1.3 6.2-3.7 8.5c-2.4-2.3-3.7-5.2-3.7-8.5s1.3-6.2 3.7-8.5z" />
    </>
  ),
  alerts: (
    <>
      <path d="M12 4l8.5 15h-17L12 4z" />
      <path d="M12 10v4M12 17h.01" />
    </>
  ),
  settings: (
    <>
      <circle cx="12" cy="12" r="2.8" />
      <path d="M12 3.5v2.2M12 18.3v2.2M20.5 12h-2.2M5.7 12H3.5M18 6l-1.6 1.6M7.6 16.4L6 18M18 18l-1.6-1.6M7.6 7.6L6 6" />
    </>
  ),
  shield: (
    <>
      <path d="M12 3l7.5 3v5.4c0 4.6-3.1 8.3-7.5 9.6-4.4-1.3-7.5-5-7.5-9.6V6L12 3z" />
    </>
  ),
  "shield-check": (
    <>
      <path d="M12 3l7.5 3v5.4c0 4.6-3.1 8.3-7.5 9.6-4.4-1.3-7.5-5-7.5-9.6V6L12 3z" />
      <path d="M9.2 12.1l2 2 3.7-4" />
    </>
  ),
  "shield-alert": (
    <>
      <path d="M12 3l7.5 3v5.4c0 4.6-3.1 8.3-7.5 9.6-4.4-1.3-7.5-5-7.5-9.6V6L12 3z" />
      <path d="M12 9v4M12 16.2h.01" />
    </>
  ),
  check: (
    <>
      <path d="M5 12.5l4.5 4.5L19 7" />
    </>
  ),
  alert: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 7.5v5M12 16h.01" />
    </>
  ),
  info: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M12 11v5.5M12 7.8h.01" />
    </>
  ),
  unknown: (
    <>
      <circle cx="12" cy="12" r="8.5" />
      <path d="M9.6 9.4a2.5 2.5 0 114.1 2.1c-.9.7-1.7 1.1-1.7 2.3M12 16.6h.01" />
    </>
  ),
  server: (
    <>
      <rect x="3.5" y="4" width="17" height="6.5" rx="1.6" />
      <rect x="3.5" y="13.5" width="17" height="6.5" rx="1.6" />
      <path d="M7 7.2h.01M7 16.8h.01" />
    </>
  ),
  activity: (
    <>
      <path d="M3 12h4l3-7 4 14 3-7h4" />
    </>
  ),
  zap: (
    <>
      <path d="M13.5 3L5 13.5h6L10.5 21 19 10.5h-6L13.5 3z" />
    </>
  ),
  lock: (
    <>
      <rect x="4.5" y="10" width="15" height="10" rx="2" />
      <path d="M8 10V7a4 4 0 018 0v3" />
    </>
  ),
  external: (
    <>
      <path d="M14 4h6v6M20 4l-8.5 8.5" />
      <path d="M18 14.5V19a1.5 1.5 0 01-1.5 1.5h-11A1.5 1.5 0 014 19V8a1.5 1.5 0 011.5-1.5H10" />
    </>
  ),
   menu: (
     <>
       <path d="M4 7h16M4 12h16M4 17h16" />
     </>
   ),
   pause: (
     <>
       <path d="M10 4H6v16h4V4zM18 4h-4v16h4V4z" />
     </>
   ),
   play: (
     <>
       <path d="M6 4l14 8-14 8V4z" />
     </>
   ),
   search: (
     <>
       <circle cx="10.5" cy="10.5" r="6.5" />
       <path d="M15.3 15.3L20 20" />
     </>
   ),
 };

export function Icon({ name, size = 18, className = "", strokeWidth = 1.6 }: { name: IconName; size?: number; className?: string; strokeWidth?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
      focusable="false"
    >
      {PATHS[name]}
    </svg>
  );
}

/** Status glyph per semantic tone: state never depends on colour alone. */
export const TONE_ICON = {
  ok: "shield-check",
  warn: "alert",
  danger: "shield-alert",
  info: "info",
  muted: "unknown",
} as const;
