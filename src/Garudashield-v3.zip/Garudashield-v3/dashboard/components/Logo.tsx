import Image from "next/image";

/**
 * Brand logo mark. Renders the GarudaShield logo image inside a rounded tile so
 * it composes the same on light marketing chrome and the navy console rail.
 * The image lives at /public/logo.jpg and is served as a static asset, so no
 * remote image configuration is needed.
 */
export default function Logo({
  size = 36,
  className = "",
  rounded = "rounded-[10px]",
}: {
  size?: number;
  className?: string;
  rounded?: string;
}) {
  return (
    <span
      className={`relative inline-grid shrink-0 place-items-center overflow-hidden bg-[#0A192F] shadow-card ring-1 ring-black/5 ${rounded} ${className}`}
      style={{ width: size, height: size }}
    >
      <Image
        src="/logo.jpg"
        alt="GarudaShield"
        width={size}
        height={size}
        className="h-full w-full object-cover"
      />
    </span>
  );
}
