"use client";

import { useEffect, useState } from "react";

type PublicStatus = {
  overall?: string;
  storeMode?: string;
  components?: { name: string; status: string; detail?: string }[];
};

/**
 * Live status card for the landing page. Reads the public /api/status
 * endpoint only — no invented uptime figure, no hardcoded "AKTIF" states. When
 * the engine is unreachable the card says so instead of showing green.
 */
export default function LiveStatusCard() {
  const [status, setStatus] = useState<PublicStatus | null>(null);
  const [state, setState] = useState<"loading" | "live" | "offline">("loading");

  useEffect(() => {
    let alive = true;
    const load = () =>
      fetch("/api/gs/status")
        .then((r) => (r.ok ? r.json() : Promise.reject()))
        .then((d) => {
          if (!alive) return;
          setStatus(d);
          setState("live");
        })
        .catch(() => alive && setState("offline"));
    load();
    const iv = setInterval(load, 10000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, []);

  const tone = state === "offline" ? "text-danger-ink" : "text-ok-ink";
  const headline =
    state === "loading" ? "Memuat…"
      : state === "offline" ? "Engine offline"
        : status?.overall === "ok" || status?.overall === "up" ? "All systems normal"
          : "Perlu perhatian";

  return (
    <div className="card relative overflow-hidden">
      <div className="pointer-events-none absolute -right-12 -top-12 h-44 w-44 rounded-full bg-[#D4AF37]/12 blur-3xl" />
      <div className="pointer-events-none absolute -left-10 -bottom-12 h-36 w-36 rounded-full bg-[#0A192F]/8 blur-3xl" />
      <div className="relative flex items-center justify-between mb-5">
        <span className="text-[13px] font-semibold tracking-tight">Status Engine</span>
        <a className={`tag ${state === "offline" ? "bg-danger/15 text-danger-ink" : "bg-ok/15 text-ok-ink"}`} href="/status">
          {headline}
        </a>
      </div>

      {state === "loading" ? (
        <div className="grid grid-cols-2 gap-3" role="status" aria-busy="true" aria-label="Memuat status engine">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="rounded-xl border border-edge bg-white p-3.5">
              <div className="skeleton skeleton-line w-1/2" />
              <div className="skeleton skeleton-line mt-2 w-2/3" />
            </div>
          ))}
        </div>
      ) : (
        <div className="relative grid grid-cols-2 gap-2.5">
          {(status?.components ?? []).slice(0, 4).map((c) => {
            const ok = c.status === "ok" || c.status === "up";
            return (
              <div key={c.name} className="rounded-xl border border-edge bg-white p-3.5">
                <div className="text-xs text-muted">{c.name}</div>
                <div className={`text-sm font-semibold mt-0.5 ${ok ? "text-ok-ink" : "text-danger-ink"}`}>
                  {ok ? "OK" : c.status}
                </div>
              </div>
            );
          })}
          {(status?.components ?? []).length === 0 && state === "live" ? (
            <div className="col-span-2 rounded-lg border border-edge bg-white p-3 text-xs text-muted">
              Engine belum melaporkan health check.
            </div>
          ) : null}
          {state === "offline" ? (
            <div className="col-span-2 rounded-lg border border-edge bg-white p-3 text-xs text-muted">
              Tidak dapat menghubungi engine. Halaman{" "}
              <a className="text-slate-900 underline" href="/status">status publik</a>{" "}
              akan pulih otomatis saat engine hidup lagi.
            </div>
          ) : null}
        </div>
      )}

      <div className="mt-4 rounded-xl border border-edge bg-slate-50 p-3.5 text-[12.5px] text-muted">
        {state === "live" && status?.storeMode ? (
          <>State layer: <span className={`font-semibold ${tone}`}>{status.storeMode}</span></>
        ) : state === "offline" ? (
          <span className="text-danger-ink">Proteksi edge tetap berjalan independen dari dashboard ini.</span>
        ) : (
          "Mengambil health check dari engine…"
        )}
      </div>
    </div>
  );
}