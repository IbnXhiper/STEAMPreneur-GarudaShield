"use client";

import { useEffect, useState } from "react";

export default function LiveStats() {
  const [data, setData] = useState<{ ok: boolean; uptime?: number; version?: string }>({ ok: false });

  useEffect(() => {
    let alive = true;
    fetch("/api/gs/status")
      .then((r) => (r.ok ? r.json() : Promise.reject()))
      .then((d) => alive && setData({ ok: true, uptime: d.uptimeSec, version: d.version }))
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, []);

  if (!data.ok) return null;

  const up = data.uptime ? `${Math.floor(data.uptime / 86400)}h ${Math.floor((data.uptime % 86400) / 3600)}m` : "—";

  return (
    <div className="flex items-center gap-2 mt-4 text-xs">
      <span className="relative flex h-2.5 w-2.5">
        <span className="absolute inline-flex h-full w-full rounded-full bg-ok opacity-75 animate-pulse-ring" />
        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-ok" />
      </span>
      <span className="text-muted">
        Engine hidup · uptime {up} · v{data.version || "—"}
      </span>
    </div>
  );
}
