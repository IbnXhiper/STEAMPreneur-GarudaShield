"use client";

import { useEffect, useRef, useState } from "react";

// AnimatedNumber tweens a live metric toward its latest value with a short
// ease-out curve, so console numbers that re-poll every second read as a
// continuous stream instead of hard-clipping between values. `prefers-reduced-
// motion` is honoured: the final value is shown immediately with no tween.
// The component is stateless between polls — it only ever advances display
// toward `value`, so it never drifts away from the real stat.
function useReducedMotionPref(): boolean {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const onChange = (e: MediaQueryListEvent) => setReduced(e.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);
  return reduced;
}

export default function AnimatedNumber({
  value,
  format = (v: number) => String(Math.round(v)),
  duration = 340,
  className,
}: {
  value: number | null | undefined;
  format?: (v: number) => string;
  duration?: number;
  className?: string;
}) {
  const reduced = useReducedMotionPref();
  const [display, setDisplay] = useState(Number(value || 0));
  const raf = useRef<number | null>(null);

  useEffect(() => {
    const target = Number(value || 0);
    if (reduced) {
      setDisplay(target);
      return;
    }
    const from = display;
    if (from === target) return;
    const start = performance.now();
    const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
    const tick = (now: number) => {
      const t = Math.min(1, (now - start) / duration);
      setDisplay(from + (target - from) * easeOut(t));
      if (t < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => {
      if (raf.current) cancelAnimationFrame(raf.current);
    };
  }, [value, reduced]); // eslint-disable-line react-hooks/exhaustive-deps

  return <span className={className ?? ""}>{format(display)}</span>;
}