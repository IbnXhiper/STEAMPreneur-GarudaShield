"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import Logo from "@/components/Logo";

const NAV = [
  { href: "/features", label: "Fitur" },
  { href: "/status", label: "Status" },
  { href: "/docs", label: "Dokumentasi" },
  { href: "/chat", label: "AI Garuda" },
];

export default function Navbar() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setOpen(false), [pathname]);

  const isDash = pathname?.startsWith("/dash");

  return (
    <header
      className={`sticky top-0 z-50 transition-colors ${
        scrolled || open ? "bg-white/95 backdrop-blur-md border-b border-edge" : "border-b border-transparent"
      }`}
    >
      <div className="container-x flex h-16 items-center justify-between">
        <Link href="/" className="flex items-center gap-2.5 group">
          <Logo size={36} />
          <span className="font-display text-lg font-semibold tracking-tight text-slate-900">
            Garuda<span className="text-[#8A6D1F]">Shield</span>
          </span>
        </Link>

        <nav className="hidden md:flex items-center gap-1">
          {NAV.map((n) => {
            const active = pathname === n.href;
            return (
              <Link
                key={n.href}
                href={n.href}
                className={`px-3 py-2 text-sm rounded-lg transition-colors ${
                  active ? "text-slate-900 bg-white shadow-card font-medium" : "text-muted hover:text-slate-900 hover:bg-white/70"
                }`}
              >
                {n.label}
              </Link>
            );
          })}
          {isDash && <Link href="/dash/customers" className="btn-ghost ml-2">Pelanggan</Link>}
          <Link href={isDash ? "/dash" : "/login"} className="btn-primary ml-2">
            {isDash ? "Dashboard" : "Masuk"}
          </Link>
        </nav>

        <button
          className="md:hidden grid h-9 w-9 place-items-center rounded-xl border border-edge bg-white text-slate-900 shadow-card"
          aria-label={open ? "Tutup menu" : "Menu"}
          aria-expanded={open}
          aria-controls="mobile-nav"
          onClick={() => setOpen((v) => !v)}
        >
          <div className="space-y-1.5">
            <span className="block h-0.5 w-5 bg-slate-900" />
            <span className="block h-0.5 w-5 bg-slate-900" />
            <span className="block h-0.5 w-5 bg-slate-900" />
          </div>
        </button>
      </div>

      {open && (
        <div id="mobile-nav" className="md:hidden border-t border-edge bg-white">
          <div className="container-x py-3 space-y-1">
            {NAV.map((n) => (
              <Link
                key={n.href}
                href={n.href}
                className={`block rounded-xl px-3 py-2.5 text-sm transition-colors ${
                  pathname === n.href ? "bg-white text-slate-900 font-medium shadow-card" : "text-muted hover:text-slate-900 hover:bg-white/70"
                }`}
              >
                {n.label}
              </Link>
            ))}
            {isDash ? (
              <Link
                href="/dash/customers"
                className={`block rounded-xl px-3 py-2.5 text-sm transition-colors ${
                  pathname === "/dash/customers" ? "bg-white text-slate-900 font-medium shadow-card" : "text-muted hover:text-slate-900 hover:bg-white/70"
                }`}
              >
                Pelanggan
              </Link>
            ) : null}
            <Link href={isDash ? "/dash" : "/login"} className="btn-primary w-full mt-2 text-center">
              {isDash ? "Dashboard" : "Masuk"}
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
