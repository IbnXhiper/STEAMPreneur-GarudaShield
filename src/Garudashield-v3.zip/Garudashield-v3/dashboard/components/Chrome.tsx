"use client";

import { usePathname } from "next/navigation";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

/* Chrome renders the marketing navbar + footer only on public pages. The
   console (/dash) has its own sidebar + topbar, and the status page (/status)
   has its own header — wrapping them in the marketing chrome produced a double
   header and a stray mid-page footer. */
export default function Chrome({ children }: { children: React.ReactNode }) {
  const pathname = usePathname() || "/";
  const bare = pathname.startsWith("/dash") || pathname.startsWith("/status");

  if (bare) return <>{children}</>;

  return (
    <>
      <Navbar />
      <div className="flex-1">{children}</div>
      <Footer />
    </>
  );
}
