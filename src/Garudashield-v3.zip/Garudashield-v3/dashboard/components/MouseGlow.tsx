"use client";

import { useEffect, useRef } from "react";

// A fixed, non-interactive glow that trails the pointer. It is deliberately
// cheap: one element, one rAF loop that only runs while the pointer is moving
// (and eases to rest), no React re-renders per frame. Disabled for users who
// prefer reduced motion or on coarse-pointer (touch) devices, and painted at
// -z-10 so it sits above the page base colour but behind all content.
export default function MouseGlow() {
  const ref = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    if (window.matchMedia("(pointer: coarse)").matches) return;

    let tx = window.innerWidth * 0.75;
    let ty = window.innerHeight * 0.22;
    let x = tx;
    let y = ty;
    let raf = 0;

    const paint = () => {
      x += (tx - x) * 0.14;
      y += (ty - y) * 0.14;
      el.style.setProperty("--mx", x.toFixed(1) + "px");
      el.style.setProperty("--my", y.toFixed(1) + "px");
      if (Math.abs(tx - x) > 0.5 || Math.abs(ty - y) > 0.5) {
        raf = requestAnimationFrame(paint);
      } else {
        raf = 0;
        el.style.opacity = "1";
      }
    };

    const onMove = (e: PointerEvent) => {
      tx = e.clientX;
      ty = e.clientY;
      if (!raf) raf = requestAnimationFrame(paint);
    };

    window.addEventListener("pointermove", onMove, { passive: true });
    return () => {
      window.removeEventListener("pointermove", onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div
      ref={ref}
      aria-hidden="true"
      className="pointer-events-none fixed inset-0 -z-10 opacity-0 transition-opacity duration-700"
      style={{
        background:
          "radial-gradient(560px circle at var(--mx, 75%) var(--my, 22%), rgba(212,175,55,0.12), transparent 68%), radial-gradient(420px circle at var(--mx, 75%) var(--my, 22%), rgba(10,25,47,0.05), transparent 70%)",
      }}
    />
  );
}
