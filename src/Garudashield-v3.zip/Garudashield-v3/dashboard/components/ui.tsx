"use client";

/**
 * Shared UI kit for GarudaShield.
 *
 * Every console/status surface renders through these primitives so a card,
 * badge, table, skeleton or empty state looks and behaves the same everywhere.
 * Components are presentational only: they never fetch, and they never weaken
 * any security decision (auth, validation and rate limiting stay in the BFF
 * and the engine).
 */

import { ReactNode, useCallback, useEffect, useRef, useState } from "react";

/* ---------- layout ---------- */

export function Stack({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`stack ${className}`}>{children}</div>;
}

export function SectionTitle({ children, hint }: { children: ReactNode; hint?: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-3">
      <h2 className="section-title">{children}</h2>
      {hint ? <span className="text-[11px] text-muted">{hint}</span> : null}
    </div>
  );
}

/* ---------- surfaces ---------- */

export function Panel({
  title,
  subtitle,
  actions,
  children,
  className = "",
  bodyClassName = "",
}: {
  title?: ReactNode;
  subtitle?: ReactNode;
  actions?: ReactNode;
  children: ReactNode;
  className?: string;
  bodyClassName?: string;
}) {
  return (
    <section className={`panel ${className}`}>
      {title ? (
        <header className="panel-head">
          <div className="min-w-0">
            <div className="panel-title truncate">{title}</div>
            {subtitle ? <div className="mt-0.5 text-[11px] text-muted">{subtitle}</div> : null}
          </div>
          {actions ? <div className="flex flex-wrap items-center gap-2">{actions}</div> : null}
        </header>
      ) : null}
      <div className={bodyClassName || "panel-body"}>{children}</div>
    </section>
  );
}

/* ---------- status ---------- */

export type Tone = "ok" | "warn" | "danger" | "info" | "muted";

const TONE_TAG: Record<Tone, string> = {
  ok: "tag-ok",
  warn: "tag-warn",
  danger: "tag-danger",
  info: "tag-info",
  muted: "tag-muted",
};

const TONE_DOT: Record<Tone, string> = {
  ok: "dot-ok",
  warn: "dot-warn",
  danger: "dot-danger",
  info: "dot-info",
  muted: "dot-muted",
};

export function Tag({ tone = "muted", children, title }: { tone?: Tone; children: ReactNode; title?: string }) {
  return (
    <span className={`tag ${TONE_TAG[tone]}`} title={title}>
      {children}
    </span>
  );
}

export function StatusDot({ tone = "muted", pulse = false, label }: { tone?: Tone; pulse?: boolean; label?: string }) {
  return (
    <>
      <span className={`dot ${TONE_DOT[tone]} ${pulse ? "dot-pulse" : ""}`} aria-hidden="true" />
      {label ? <span className="sr-only">{label}</span> : null}
    </>
  );
}

/** Row of dot + label, the canonical way this product shows a state. */
export function StateLine({ tone, label, pulse = false }: { tone: Tone; label: string; pulse?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2">
      <StatusDot tone={tone} pulse={pulse} />
      <span>{label}</span>
    </span>
  );
}

/* ---------- metrics ---------- */

export function MetricCard({
  label,
  value,
  hint,
  tone = "plain",
  loading = false,
}: {
  label: string;
  value: ReactNode;
  hint?: ReactNode;
  tone?: "plain" | "ok" | "warn" | "danger" | "accent";
  loading?: boolean;
}) {
  const toneClass =
    tone === "plain" ? "text-slate-900"
      : tone === "ok" ? "text-ok-ink"
        : tone === "warn" ? "text-warn-ink"
          : tone === "danger" ? "text-danger-ink"
            : "text-accent-ink";
  return (
    <div className="metric-card">
      <div className="metric-label">{label}</div>
      {loading ? (
        <div className="skeleton skeleton-title mt-2 w-2/3" />
      ) : (
        <div className={`metric-value mt-2 ${toneClass}`}>{value ?? "—"}</div>
      )}
      {hint ? <div className="metric-hint">{hint}</div> : null}
    </div>
  );
}

export function MetricGrid({ children, cols }: { children: ReactNode; cols?: 2 | 3 | 4 }) {
  const cls = cols === 2 ? "grid grid-cols-1 sm:grid-cols-2 gap-3"
    : cols === 3 ? "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3"
      : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3";
  return <div className={cls}>{children}</div>;
}

/* ---------- data display ---------- */

/**
 * Table wrapper that keeps wide data readable on small screens: the table
 * scrolls horizontally inside the panel instead of forcing the page to.
 */
export function TableBox({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`table-scroll ${className}`}>{children}</div>;
}

export function DataTable({ children, minWidth = true }: { children: ReactNode; minWidth?: boolean }) {
  return <table className={`data-table ${minWidth ? "data-table-min" : ""}`}>{children}</table>;
}

export function KeyValue({ label, children }: { label: ReactNode; children: ReactNode }) {
  return (
    <div className="kv">
      <span>{label}</span>
      <span className="mono">{children}</span>
    </div>
  );
}

/* ---------- loading / empty / error ---------- */

export function SkeletonLine({ width = "100%", className = "" }: { width?: string; className?: string }) {
  return <div className={`skeleton skeleton-line ${className}`} style={{ width }} />;
}

/** Loading placeholder that mirrors the shape of the content it replaces. */
export function SkeletonBlock({ rows = 3, label }: { rows?: number; label?: string }) {
  return (
    <div className="stack" role="status" aria-live="polite" aria-busy="true">
      {label ? <span className="text-[11px] text-muted">{label}</span> : null}
      {Array.from({ length: rows }).map((_, i) => (
        <SkeletonLine key={i} width={i === rows - 1 && rows > 1 ? "62%" : "100%"} />
      ))}
    </div>
  );
}

export function SkeletonCards({ count = 4 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3" role="status" aria-busy="true" aria-label="Memuat metrik keamanan">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="metric-card">
          <div className="skeleton skeleton-line w-1/2" />
          <div className="skeleton skeleton-title mt-3 w-2/3" />
        </div>
      ))}
    </div>
  );
}

export function EmptyState({
  title,
  description,
  icon = "◇",
  action,
}: {
  title: string;
  description?: string;
  icon?: ReactNode;
  action?: ReactNode;
}) {
  return (
    <div className="state" role="status">
      <span className="state-icon" aria-hidden="true">{icon}</span>
      <span className="state-title">{title}</span>
      {description ? <span className="state-desc">{description}</span> : null}
      {action}
    </div>
  );
}

export function ErrorState({
  title = "Unable to load data",
  description,
  detail,
  onRetry,
  retryLabel = "Retry",
}: {
  title?: string;
  description?: string;
  detail?: string;
  onRetry?: () => void;
  retryLabel?: string;
}) {
  return (
    <div className="state state-error" role="alert">
      <span className="state-icon" aria-hidden="true">!</span>
      <span className="state-title">{title}</span>
      {description ? <span className="state-desc">{description}</span> : null}
      {detail ? <span className="state-desc mono text-[11px] opacity-70">{detail}</span> : null}
      {onRetry ? (
        <button className="btn mt-1" onClick={onRetry}>
          {retryLabel}
        </button>
      ) : null}
    </div>
  );
}

export function Note({ children, accent = false, className = "" }: { children: ReactNode; accent?: boolean; className?: string }) {
  return <div className={`note ${accent ? "note-accent" : ""} ${className}`}>{children}</div>;
}

/* ---------- small helpers ---------- */

export function Toolbar({ children }: { children: ReactNode }) {
  return <div className="toolbar">{children}</div>;
}

/* ---------- list tools (search / filter / export) ---------- */

/**
 * Controlled search box with a clear affordance. Presentational only: the
 * caller owns the query string and decides what it filters. Padding is set
 * inline so the value always wins over the `.input` component class regardless
 * of stylesheet order.
 */
export function SearchInput({
  value,
  onChange,
  placeholder = "Cari…",
  ariaLabel,
  className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  ariaLabel?: string;
  className?: string;
}) {
  return (
    <div className={`relative ${className}`}>
      <span className="pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-muted" aria-hidden="true">⌕</span>
      <input
        type="search"
        className="input"
        style={{ paddingLeft: "1.9rem", paddingRight: value ? "1.9rem" : undefined }}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        aria-label={ariaLabel || placeholder}
      />
      {value ? (
        <button
          type="button"
          onClick={() => onChange("")}
          aria-label="Bersihkan pencarian"
          className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded-md px-1.5 py-0.5 text-muted transition-colors hover:text-slate-900"
        >
          ×
        </button>
      ) : null}
    </div>
  );
}

/** Segmented control for a small set of mutually exclusive filters. */
export function Segmented<T extends string>({
  options,
  value,
  onChange,
  ariaLabel,
}: {
  options: ReadonlyArray<readonly [T, string]>;
  value: T;
  onChange: (v: T) => void;
  ariaLabel?: string;
}) {
  return (
    <div className="flex overflow-hidden rounded-lg border border-edge bg-white" role="group" aria-label={ariaLabel}>
      {options.map(([key, label]) => (
        <button
          key={key}
          type="button"
          className={`px-2.5 py-1 text-[12px] font-medium ${value === key ? "bg-blue-600 text-white" : "text-muted hover:text-slate-900"}`}
          aria-pressed={value === key}
          onClick={() => onChange(key)}
        >
          {label}
        </button>
      ))}
    </div>
  );
}

/** Quiet toolbar button that downloads the current (filtered) rows as CSV. */
export function ExportButton({
  onClick,
  disabled = false,
  label = "Ekspor CSV",
  title,
}: {
  onClick: () => void;
  disabled?: boolean;
  label?: string;
  title?: string;
}) {
  return (
    <button type="button" className="btn px-2.5 py-1 text-[12px]" onClick={onClick} disabled={disabled} title={title || label}>
      {label}
    </button>
  );
}

/**
 * usePoller polls an async loader on an interval and exposes explicit
 * loading / error / data state, so no panel ever renders as an empty box and
 * every panel shares the same refresh + retry behaviour.
 */
export function usePoller<T>(
  loader: () => Promise<T>,
  intervalMs: number,
  deps: unknown[] = [],
) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [nonce, setNonce] = useState(0);
  const loaderRef = useRef(loader);
  loaderRef.current = loader;

  useEffect(() => {
    let active = true;
    let timer: ReturnType<typeof setTimeout> | undefined;

    const tick = async (first: boolean) => {
      if (first) setLoading(true);
      try {
        const value = await loaderRef.current();
        if (!active) return;
        setData(value);
        setError("");
      } catch (e: any) {
        if (!active) return;
        setError(String(e?.message || e));
      } finally {
        if (!active) return;
        setLoading(false);
        if (intervalMs > 0) timer = setTimeout(() => tick(false), intervalMs);
      }
    };

    tick(true);
    return () => {
      active = false;
      if (timer) clearTimeout(timer);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [intervalMs, nonce, ...deps]);

  const reload = useCallback(() => setNonce((n) => n + 1), []);
  return { data, error, loading, reload };
}