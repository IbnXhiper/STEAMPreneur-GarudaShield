/**
 * Reveal plays a one-shot fade-up using a pure CSS animation.
 *
 * Visibility must never depend on JavaScript. Earlier versions used Motion with
 * an `initial: { opacity: 0 }`, which is emitted as inline `opacity:0` during
 * SSR — if hydration or the in-view observer misfired, the content stayed
 * invisible forever (the blank landing page). A CSS animation with
 * `animation-fill-mode: both` always settles on the visible end state, and is
 * disabled wholesale under `prefers-reduced-motion`.
 *
 * This is a server component on purpose: no client JS is needed for it.
 */
export default function Reveal({
  children,
  className = "",
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  return (
    <div
      className={`reveal-up ${className}`}
      style={delay ? { animationDelay: `${delay}ms` } : undefined}
    >
      {children}
    </div>
  );
}
