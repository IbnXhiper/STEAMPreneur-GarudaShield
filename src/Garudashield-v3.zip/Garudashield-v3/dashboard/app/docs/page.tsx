import Reveal from "@/components/Reveal";

function Code({ children }: { children: React.ReactNode }) {
  return (
    <pre className="mt-3 overflow-auto rounded-lg border border-edge bg-slate-50 p-4 text-xs leading-relaxed text-muted">
      <code>{children}</code>
    </pre>
  );
}

function Section({ id, n, title, children }: { id: string; n: string; title: string; children: React.ReactNode }) {
  return (
    <Reveal>
      <section id={id} className="scroll-mt-24">
        <h2 className="font-display text-2xl font-semibold flex items-baseline gap-3">
          <span className="text-accent-ink text-base tabular">{n}</span>
          {title}
        </h2>
        <div className="mt-2 space-y-3">{children}</div>
      </section>
    </Reveal>
  );
}

function ApiTable({ rows }: { rows: [string, string, string][] }) {
  return (
    <div className="mt-3 overflow-hidden rounded-lg border border-edge">
      <table className="w-full text-xs">
        <thead className="bg-slate-50 text-muted">
          <tr>
            <th className="px-3 py-2 text-left font-medium">Method</th>
            <th className="px-3 py-2 text-left font-medium">Endpoint</th>
            <th className="px-3 py-2 text-left font-medium">Fungsi</th>
          </tr>
        </thead>
        <tbody className="font-mono">
          {rows.map(([m, e, d]) => (
            <tr key={e + m} className="border-t border-edge">
              <td className="px-3 py-2 text-accent-ink">{m}</td>
              <td className="px-3 py-2 text-slate-900">{e}</td>
              <td className="px-3 py-2 font-sans text-muted">{d}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const TOC = [
  ["build", "Build & Jalankan"],
  ["config", "Struktur Config"],
  ["multisite", "Multi-Site & Proxy"],
  ["trust", "Trust Proxy"],
  ["waf", "WAF Engine"],
  ["ratelimit", "Rate Limit"],
  ["protect", "Verify Browser (Protect)"],
  ["cluster", "Cluster Sync"],
  ["alerts", "Webhook Alert"],
  ["api", "Admin API"],
  ["dashboard", "Dashboard & Status"],
  ["faq", "FAQ"],
];

export default function DocsPage() {
  return (
    <div className="bg-grid">
      <section className="container-x pt-16 pb-6">
        <Reveal>
          <span className="eyebrow">Dokumentasi</span>
          <h1 className="mt-3 font-display text-4xl md:text-5xl font-bold tracking-tight">
            Menjalankan <span className="text-gradient">GarudaShield.</span>
          </h1>
          <p className="mt-4 text-muted max-w-2xl">
            Engine edge ditulis dalam Go dengan WAF matcher opsional (Rust, FFI). Panduan ini
            mencakup instalasi, konfigurasi tiap lapisan pertahanan, admin API, hingga dashboard.
          </p>
        </Reveal>
      </section>

      <section className="container-x pb-16 grid lg:grid-cols-[220px_1fr] gap-10">
        <aside className="hidden lg:block">
          <div className="sticky top-24">
            <div className="text-xs uppercase tracking-widest text-muted mb-3">Daftar isi</div>
            <ul className="space-y-1.5 text-sm">
              {TOC.map(([id, label]) => (
                <li key={id}>
                  <a href={`#${id}`} className="text-muted hover:text-slate-900 transition-colors">{label}</a>
                </li>
              ))}
            </ul>
          </div>
        </aside>

        <div className="max-w-3xl space-y-12">
          <Section id="build" n="01" title="Build & Jalankan">
            <p className="text-muted text-sm">
              Engine membutuhkan Go 1.24+. WAF matcher Rust bersifat opsional; jika DLL tidak tersedia,
              engine otomatis memakai matcher bawaan Go. Dashboard ada di folder <code>dashboard/</code> (Next.js).
            </p>
            <Code>{`# engine
go build -o bin/gs ./cmd/garudashield        # Windows: -o bin/gs.exe
cp garudashield.example.json garudashield.json
./bin/gs -config garudashield.json           # default :8080

# dashboard (terpisah)
cd dashboard
$env:GS_API_URL="http://localhost:8080"      # URL engine
$env:GS_API_KEY="<admin.secret>"             # sama dgn config
npm install && npm run build && npm start     # http://localhost:3000

# Windows: cukup jalankan run.ps1 (origin + engine + dashboard sekaligus)
./run.ps1`}</Code>
          </Section>

          <Section id="config" n="02" title="Struktur Config">
            <p className="text-muted text-sm">
              Config berbentuk JSON dan kompatibel dengan v2 (<code>config/default.js</code>). Field kosong
              memakai default aman. Berikut bentuk minimal untuk produksi:
            </p>
            <Code>{`{
  "version": "3.0.0",
  "server":   { "httpPort": 8080, "host": "0.0.0.0", "maxConcurrency": 2048 },
  "upstream": { "host": "127.0.0.1", "port": 9000 },
  "admin":    { "enabled": true, "secret": "GANTI-DENGAN-KEY-KUAT" },
  "proxy":    { "trustProxy": false },
  "defense": {
    "waf":       { "enabled": true, "sqli": true, "xss": true, "commandInjection": true,
                   "pathTraversal": true, "lfi": true, "rfi": true, "shellshock": true, "scanners": true },
    "rateLimit": { "perIPRPS": 50, "perIPBurst": 100, "globalMaxRPS": 50000, "slidingWindowMs": 1000 },
    "layer4":    { "bogonFilter": true }
  },
  "reputation": { "enabled": true, "blockThreshold": 80, "challengeThreshold": 60 },
  "access":     { "enabled": true, "protectAll": false, "hosts": {} },
  "allowedHosts": [],
  "whitelist": ["127.0.0.1", "::1"]
}`}</Code>
          </Section>

          <Section id="multisite" n="03" title="Multi-Site & Proxy">
            <p className="text-muted text-sm">
              Setiap host dipetakan ke satu site. Engine mengevaluasi keamanan di <strong>setiap</strong> request
              (termasuk yang diproxy). Host tak dikenal jatuh ke <code>upstream</code> global.
            </p>
            <Code>{`{
  "sites": {
    "app.example.com":  { "type": "proxy", "upstream": { "host": "10.0.0.5", "port": 8080 } },
    "shop.example.com": { "type": "proxy", "upstream": { "host": "10.0.0.6", "port": 3000 } }
  },
  "upstream": { "host": "127.0.0.1", "port": 9000 }
}`}</Code>
          </Section>

          <Section id="trust" n="04" title="Trust Proxy (keamanan header)">
            <p className="text-muted text-sm">
              IP klien hanya diambil dari <code>X-Forwarded-For</code> / <code>X-Real-IP</code> bila koneksi
              berasal dari proxy terpercaya. Ini mencegah spoofing IP oleh klien langsung.
            </p>
            <Code>{`{
  "proxy": {
    "trustProxy": true,
    "realIpHeader": "X-Forwarded-For",
    "trustedProxies": ["10.0.0.0/24", "192.168.1.10"]
  }
}`}</Code>
          </Section>

          <Section id="waf" n="05" title="WAF Engine">
            <p className="text-muted text-sm">
              Modul bawaan: SQLi, XSS, Command Injection, Path Traversal, LFI/RFI, Shellshock, Scanner.
              Skor tiap aturan diakumulasi; total ≥ 50 memblokir request. Payload ter-encode (single,
              double, plus) dinormalisasi sebelum dicocokkan, jadi tidak bisa di-bypass dengan encoding.
            </p>
            <Code>{`# toggle modul tanpa restart
POST /api/waf  {"modules": {"sqli": true, "xss": false}}

# tambah custom rule (regex) — skor >= 50 memblokir
POST /api/rules  {"name":"block-bot","pattern":"(?i)evil-agent","score":60}
DELETE /api/rules            # hapus semua custom rule`}</Code>
          </Section>

          <Section id="ratelimit" n="06" title="Rate Limit">
            <p className="text-muted text-sm">
              Batas per-IP, per-path, dan global dengan sliding window. RED (Random Early Drop) menurunkan
              beban sebelum limit keras tercapai. Mode adaptif mengetatkan ambang otomatis saat serangan.
            </p>
            <Code>{`POST /api/ratelimit  {
  "perIPRPS": 50, "perIPBurst": 100,
  "perPathRPS": 200, "globalMaxRPS": 50000,
  "slidingWindowMs": 1000
}`}</Code>
          </Section>

          <Section id="protect" n="07" title="Verify Browser (Protect)">
            <p className="text-muted text-sm">
              Interstitial gaya Cloudflare untuk pengunjung pertama. Request tanpa cookie <code>gs_ok</code>
              dijawab challenge ringan; jawaban valid menerbitkan cookie (TTL default 1800 detik). Klien
              non-browser (curl, skrip) diblokir, bukan di-challenge. Aktifkan per-host dari tab
              <strong> Protect</strong> di dashboard, atau nyalakan Protect All untuk seluruh host.
            </p>
            <Code>{`GET  /api/access/hosts                    # daftar host + protectAll
POST /api/access/hosts   {"host":"app.example.com","enabled":true}
POST /api/access/protectall {"enabled":true}`}</Code>
          </Section>

          <Section id="cluster" n="08" title="Cluster Sync (opsional)">
            <p className="text-muted text-sm">
              Sync antar node bersifat opsional — satu node sudah cukup untuk melindungi seluruh traffic.
              Blokir disiarkan lewat shared bus (Redis) ke node lain bila ada; full-sync berkala menjaga
              konsistensi dan tombstone mencegah node stale memasukkan kembali IP yang di-unblock.
              Tambahkan node kedua kapan saja lewat <code>cluster.nodes</code>; node yang ditandai
              <code> required: true</code> membuat status degraded bila offline, sedangkan node opsional
              tidak akan mengganggu proteksi. Environment <code>SYNC_NODE_COUNT</code> adalah jalan pintas
              untuk membuat node opsional secara otomatis.
            </p>
            <Code>{`{
  "cluster": {
    "enabled": true,
    "nodeId": "node-1",
    "nodes": [
      { "id": "node-1", "required": true },
      { "id": "node-2", "address": "10.0.0.12:8080", "role": "edge", "required": false }
    ],
    "redis": { "enabled": true, "address": "127.0.0.1:6379", "keyPrefix": "gs" }
  }
}
# jalan pintas (hanya dipakai bila cluster.nodes kosong)
SYNC_NODE_COUNT=2`}</Code>
          </Section>

          <Section id="alerts" n="09" title="Webhook Alert (Telegram & Discord)">
            <p className="text-muted text-sm">
              Notifikasi otomatis saat serangan terdeteksi/reda, mode emergency/aggressive/flood berubah,
              atau ada log kritikal. Filter berdasarkan severity minimum dengan cooldown antar-alert.
            </p>
            <Code>{`{
  "alerts": {
    "enabled": true, "minSeverity": "warning", "cooldownMs": 60000,
    "telegram": { "botToken": "...", "chatId": "..." },
    "discord":  { "webhookUrl": "https://discord.com/api/webhooks/..." }
  }
}
# uji koneksi
POST /api/alerts/test`}</Code>
          </Section>

          <Section id="api" n="10" title="Admin API">
            <p className="text-muted text-sm">
              Semua endpoint butuh <code>x-gs-key</code> (atau <code>Authorization: Bearer</code>), kecuali
              <code> /api/status</code> yang terbuka. Dashboard menyambung via BFF <code>/api/gs/*</code> yang
              menyuntikkan key di server.
            </p>
            <ApiTable
              rows={[
                ["GET", "/api/status", "Health & komponen (terbuka)"],
                ["GET", "/api/stats", "Statistik lengkap + volume"],
                ["GET", "/api/stats/stream", "SSE metrik live"],
                ["GET", "/api/top", "Top IP & path"],
                ["GET", "/api/logs", "Event keamanan terbaru"],
                ["GET", "/api/waf", "Konfigurasi & aturan WAF"],
                ["POST", "/api/waf", "Toggle modul WAF"],
                ["GET", "/api/ratelimit", "Konfigurasi & stats rate-limit"],
                ["GET", "/api/reputation", "Skor reputasi per IP"],
                ["POST", "/api/block", "Blokir IP {ip,reason,duration}"],
                ["POST", "/api/unblock", "Cabut blokir {ip}"],
                ["POST", "/api/whitelist", "Tambah whitelist {ip}"],
                ["GET", "/api/cluster", "Status cluster & peer"],
                ["GET", "/api/backup", "Ekspor konfigurasi"],
                ["POST", "/api/backup/restore", "Impor konfigurasi"],
                ["POST", "/api/reset", "Reset counter/blocklist/reputasi"],
              ]}
            />
          </Section>

          <Section id="dashboard" n="11" title="Dashboard & Status">
            <p className="text-muted text-sm">
              Set <code>GS_API_URL</code> &amp; <code>GS_API_KEY</code>, build, lalu buka <code>/login</code> dan
              masukkan admin key. Konsol <code>/dash</code> memuat Overview, Traffic, Charts, Geo Map, Top, Logs,
              Reputation, WAF Rules, Rate Limit, Protect, Cluster, Alerts, dan Settings secara live (polling
              1 detik). Halaman status publik terpisah di <code>/status</code> — menampilkan uptime, kesehatan
              5 komponen, dan riwayat insiden.
            </p>
          </Section>

          <Section id="faq" n="12" title="FAQ">
            <ul className="space-y-3 text-sm text-muted">
              <li><strong className="text-slate-900">Apakah butuh Redis?</strong> Tidak wajib. Engine jalan hybrid; Redis opsional untuk shared state antar-instance (cluster).</li>
              <li><strong className="text-slate-900">WAF matcher Rust gagal load?</strong> Engine otomatis fallback ke matcher Go — tidak fatal, performa tetap baik.</li>
              <li><strong className="text-slate-900">Cara mematikan WAF sementara?</strong> <code>POST /api/waf {`{"modules":{"sqli":false,...}}`}</code> tanpa restart.</li>
              <li><strong className="text-slate-900">Volume DDoS diukur bagaimana?</strong> Engine menghitung byte on-the-wire tiap request; total dan bagian yang diblokir tampil di Overview/Charts dalam KB/MB/GB/TB.</li>
              <li><strong className="text-slate-900">Bisa jalan di belakang Cloudflare/NGINX?</strong> Bisa. Aktifkan <code>trustProxy</code> dan daftarkan rentang IP proxy agar IP klien terbaca benar.</li>
            </ul>
          </Section>

          <Reveal>
            <div className="card p-8 flex flex-col md:flex-row md:items-center md:justify-between gap-5">
              <div>
                <h2 className="font-display text-xl font-bold">Butuh bantuan setup?</h2>
                <p className="mt-1 text-sm text-muted">Tim teknis membantu konfigurasi dan trial 7 hari.</p>
              </div>
              <a href="https://wa.me/6283187815456" target="_blank" rel="noreferrer" className="btn-primary shrink-0">Konsultasi via WhatsApp</a>
            </div>
          </Reveal>
        </div>
      </section>
    </div>
  );
}
