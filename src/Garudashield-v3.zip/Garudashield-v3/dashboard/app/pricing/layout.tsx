import type { Metadata } from "next";

export const metadata: Metadata = { title: "Harga & paket" };

export default function PricingLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
