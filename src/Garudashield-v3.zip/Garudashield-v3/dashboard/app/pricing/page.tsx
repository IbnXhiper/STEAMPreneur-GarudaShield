"use client";

import { useState } from "react";
import { motion } from "motion/react";

// Public pricing page (Bahasa Indonesia). Tiers map to license.Plan:
// free | pro | enterprise. Prices IDR, billed monthly. Purchases are WhatsApp
// only: every CTA opens a WA chat; the operator then onboards the tenant and
// issues a signed license (no payment-gateway webhook by design).

type Tier = {
  id: string;
  name: string;
  price: string;
  tagline: string;
  features: string[];
  cta: string;
  highlight?: boolean;
};

const tiers: Tier[] = [
  {
    id: "free",
    name: "Free",
    price: "Rp 0",
    tagline: "Coba proteksi dasar untuk 1 domain.",
    features: [
      "WAF & DDoS L7 dasar",
      "GeoIP (1 negara)",
      "Dashboard real-time",
      "Rate limit standar",
      "Support komunitas",
    ],
    cta: "Mulai Gratis",
  },
  {
    id: "pro",
    name: "Pro",
    price: "Rp 499.000/bln",
    tagline: "Untuk UMKM & bisnis online Indonesia.",
    features: [
      "Semua fitur Free",
      "DDoS L4 + L7 penuh",
      "Reputation & challenge",
      "GeoIP global (negara + ASN)",
      "Anti-bot & crawler",
      "Support email 24/7",
    ],
    cta: "Pilih Pro",
    highlight: true,
  },
  {
    id: "enterprise",
    name: "Enterprise",
    price: "Hubungi Kami",
    tagline: "Multi-node, SLA, on-prem.",
    features: [
      "Semua fitur Pro",
      "Sync multi-node (node opsional)",
      "TLS termination & custom domain",
      "SLA 99,9%",
      "On-prem / dedicated",
      "Support prioritas + CSM",
    ],
    cta: "Hubungi Sales",
  },
];

export default function PricingPage() {
  const [billing, setBilling] = useState<"monthly" | "yearly">("monthly");

  return (
    <main className="min-h-screen bg-grid px-6 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="max-w-5xl mx-auto text-center"
      >
        <h1 className="font-display text-4xl font-bold tracking-tight text-slate-900 mb-3">Harga GarudaShield</h1>
        <p className="text-muted mb-8">
          Proteksi DDoS L3–L7, WAF, dan anti-bot untuk situs Indonesia.
        </p>
        <div className="inline-flex gap-1 mb-12 bg-white border border-edge p-1 rounded-full shadow-card">
          <button
            onClick={() => setBilling("monthly")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${billing === "monthly" ? "bg-[#D4AF37] text-[#0A192F] font-semibold" : "text-muted hover:text-slate-900"}`}
          >
            Bulanan
          </button>
          <button
            onClick={() => setBilling("yearly")}
            className={`px-4 py-1.5 rounded-full text-sm font-medium transition-colors ${billing === "yearly" ? "bg-[#D4AF37] text-[#0A192F] font-semibold" : "text-muted hover:text-slate-900"}`}
          >
            Tahunan (−15%)
          </button>
        </div>

        <div className="grid md:grid-cols-3 gap-6 text-left">
          {tiers.map((t, i) => {
            const hi = !!t.highlight;
            return (
            <motion.div
              key={t.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.08, duration: 0.4 }}
              className={`relative rounded-2xl p-6 border ${
                hi
                  ? "border-[#D4AF37] bg-[#FBF6E7] text-slate-900 shadow-card"
                  : "border-edge bg-white text-slate-900 shadow-card"
              }`}
            >
              {hi && (
                <span className="absolute -top-3 left-6 rounded-full bg-[#0A192F] px-3 py-1 text-[11px] font-semibold text-[#D4AF37] shadow-card">
                  Terpopuler
                </span>
              )}
              <h2 className="text-xl font-semibold font-display">{t.name}</h2>
              <p className="text-2xl font-bold mt-2">
                {billing === "yearly" && t.id === "pro"
                  ? "Rp 5.089.000/thn"
                  : t.price}
              </p>
              <p className="text-sm mt-2 mb-4 text-muted">{t.tagline}</p>
              <ul className="space-y-2 text-sm mb-6">
                {t.features.map(f => (
                  <li key={f} className="flex gap-2">
                    <span className={hi ? "text-[#8A6D1F]" : "text-accent-ink"}>✓</span>
                    <span>{f}</span>
                  </li>
                ))}
              </ul>
              <a
                href={t.id === "enterprise" ? "https://wa.me/6283187815456" : `https://wa.me/6283187815456?text=${encodeURIComponent("Halo, saya mau order paket " + t.name + " GarudaShield")}`}
                target="_blank"
                rel="noreferrer"
                className={`w-full py-2.5 rounded-lg font-semibold text-center block transition-colors ${
                  hi
                    ? "bg-[#D4AF37] text-[#0A192F] hover:bg-[#C29B24] shadow-card"
                    : "btn-primary"
                }`}
              >
                {t.cta}
              </a>
            </motion.div>
            );
          })}
        </div>

        <p className="text-xs text-muted mt-12">
          Pemesanan dan pembayaran via WhatsApp. Aktivasi dilakukan tim kami
          setelah konfirmasi order — lisensi dikirim ke WhatsApp Anda.
        </p>
      </motion.div>
    </main>
  );
}
