import Link from "next/link";
import Reveal from "@/components/Reveal";
import LiveStats from "@/components/LiveStats";
import LiveStatusCard from "@/components/LiveStatusCard";
import { HoverCard, FloatCard } from "@/components/Motion";
import { Icon as GsIcon, type IconName } from "@/components/Icons";
import Logo from "@/components/Logo";

/* Banner ini sengaja tanpa angka. Semua metrik originates dari /api/gs/status
   dan /api/gs/stats, jadi tidak ada klaim lokasi, throughput, atau uptime
   yang tidak bisa diverifikasi oleh pembaca. */
const CAPABILITIES: { v: string; l: string; icon: IconName }[] = [
  { v: "L4 + L7", l: "Mitigasi di transport & aplikasi", icon: "shield" },
  { v: "50 ms", l: "Budget evaluasi per request", icon: "zap" },
  { v: "Fail-closed", l: "Verdict konservatif saat budget habis", icon: "lock" },
  { v: "Go + Rust", l: "Reverse proxy & WAF matcher", icon: "server" },
];

const FEATURES = [
  {
    icon: "shield",
    title: "Mitigasi DDoS Layer 4 & Layer 7",
    body: "Guard volumetric (SYN/ACK flood) dan perilaku aplikasi diproses di edge. Request yang lolos seluruh pemeriksaan diteruskan ke server asal, sisanya diblokir atau di-challenge.",
  },
  {
    icon: "bolt",
    title: "Satu verdict per request",
    body: "WAF, reputasi, rate-limit, fingerprint, dan deteksi anomali dijalankan berurutan dengan budget 50 ms. Melewati budget berarti verdict konservatif, bukan request lolos tanpa diperiksa.",
  },
  {
    icon: "globe",
    title: "Cluster multi-node",
    body: "Beberapa node berbagi state lewat Redis: reputasi, blocklist, dan status sinkron antar node. Saat Redis mati, engine otomatis turun ke mode lokal, bukan ikut mati.",
  },
  {
    icon: "lock",
    title: "WAF & access gate",
    body: "Aturan SQLi/XSS, rate-limiting adaptif, cookie token terikat IP, dan interstitial verifikasi browser untuk memisahkan bot dari manusia.",
  },
];

function Icon({ name }: { name: string }) {
  const common = {
    width: 24,
    height: 24,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 1.6,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
  };
  switch (name) {
    case "shield":
      return (
        <svg {...common}><path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3z" /><path d="M9.5 12l1.8 1.8L15 10" /></svg>
      );
    case "bolt":
      return <svg {...common}><path d="M13 2L4 14h7l-1 8 9-12h-7l1-8z" /></svg>;
    case "globe":
      return (
        <svg {...common}><circle cx="12" cy="12" r="9" /><path d="M3 12h18M12 3c2.5 2.5 3.8 5.7 3.8 9s-1.3 6.5-3.8 9c-2.5-2.5-3.8-5.7-3.8-9s1.3-6.5 3.8-9z" /></svg>
      );
    case "lock":
      return (
        <svg {...common}><rect x="4.5" y="10" width="15" height="10" rx="2" /><path d="M8 10V7a4 4 0 018 0v3" /></svg>
      );
    default:
      return null;
  }
}

export default function Landing() {
  return (
    <div className="bg-grid">
      {/* HERO */}
      <section className="container-x pt-16 pb-10 md:pt-24 md:pb-16">
        <div className="grid gap-10 lg:grid-cols-[1.15fr_0.85fr] lg:items-center">
          <div>
            <Reveal>
              <span className="mb-6 inline-flex items-center gap-3">
                <Logo size={44} rounded="rounded-xl" />
                <span className="font-display text-xl font-bold tracking-tight text-slate-900">
                  Garuda<span className="text-[#8A6D1F]">Shield</span>
                </span>
              </span>
            </Reveal>
            <Reveal>
              <span className="eyebrow">
                <span className="h-1.5 w-1.5 rounded-full bg-ok animate-pulse-ring" />
                Live · Multi-layer DDoS protection
              </span>
            </Reveal>
            <Reveal delay={60}>
              <h1 className="mt-4 font-display text-4xl md:text-6xl font-bold leading-[1.05] tracking-tight">
                Tetap online,
                <br />
                <span className="text-gradient">bahkan saat diserang.</span>
              </h1>
            </Reveal>
            <Reveal delay={120}>
              <p className="mt-6 text-[17px] leading-relaxed text-muted max-w-xl">
                GarudaShield adalah reverse proxy multi-layer. Setiap request melewati pipeline
                pemeriksaan di transport maupun layer aplikasi sebelum menyentuh server asal —
                yang lolos diteruskan, yang mencurigakan di-challenge, sisanya diblokir.
              </p>
            </Reveal>
            <Reveal delay={180}>
              <div className="mt-8 flex flex-wrap items-center gap-3">
                <a href="https://wa.me/6283187815456" target="_blank" rel="noreferrer" className="btn-gradient">
                  Order via WhatsApp
                </a>
                <Link href="/pricing" className="btn-ghost">
                  Lihat paket &amp; fitur →
                </Link>
              </div>
            </Reveal>
            <Reveal delay={200}>
              <Link href="/portal" className="inline-block py-1 text-[13px] font-medium text-accent-ink hover:text-slate-900 hover:underline">
                Sudah pelanggan? Masuk ke portal →
              </Link>
            </Reveal>
            <Reveal delay={220}>
              <LiveStats />
            </Reveal>
          </div>

          <Reveal delay={120} className="lg:justify-self-end w-full max-w-md">
            <FloatCard>
            {/* Live card: the public /api/status endpoint is the only source.
                No invented uptime percentage, no hardcoded "AKTIF". */}
            <LiveStatusCard />
            </FloatCard>
          </Reveal>
        </div>
      </section>

      {/* CAPABILITY BAND — faktual, tanpa angka fabrikasi */}
      <section className="container-x pb-12">
        <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
          {CAPABILITIES.map((s, i) => (
            <Reveal key={s.l} delay={i * 50}>
              <div className="group gs-gradient bg-[#0A192F] relative h-full overflow-hidden rounded-2xl border border-white/5 p-5 shadow-navy transition-transform duration-300 ease-out hover:-translate-y-1">
                <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-[#D4AF37]/10 blur-2xl transition-opacity duration-300 group-hover:opacity-100" />
                <span className="relative inline-grid h-9 w-9 place-items-center rounded-xl border border-[#D4AF37]/30 bg-[#D4AF37]/10 text-[#D4AF37]">
                    <GsIcon name={s.icon} size={17} />
                </span>
                <div className="relative mt-4 font-display text-2xl font-bold leading-none text-[#D4AF37] md:text-[28px]">{s.v}</div>
                <div className="relative mt-2 text-[12.5px] text-slate-300">{s.l}</div>
              </div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section id="fitur" className="container-x py-14">
        <Reveal>
          <span className="eyebrow">Kemampuan</span>
          <h2 className="mt-3 font-display text-3xl md:text-4xl font-bold tracking-tight">
            Satu lapisan, semua ancaman.
          </h2>
        </Reveal>
        <div className="mt-10 grid gap-4 md:grid-cols-2">
          {FEATURES.map((f, i) => (
            <Reveal key={f.title} delay={i * 60}>
              <HoverCard className="h-full">
                <div className="card card-hover h-full group">
                  <div className="grid h-11 w-11 place-items-center rounded-xl text-white shadow-glow transition-transform duration-200 group-hover:scale-105 gs-gradient">
                    <Icon name={f.icon} />
                  </div>
                  <h3 className="mt-5 font-display text-[17px] font-semibold tracking-tight">{f.title}</h3>
                  <p className="mt-2 text-[13.5px] text-muted leading-relaxed">{f.body}</p>
                </div>
              </HoverCard>
            </Reveal>
          ))}
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="container-x py-14">
        <Reveal>
          <span className="eyebrow">Cara Kerja</span>
          <h2 className="mt-3 font-display text-3xl md:text-4xl font-bold tracking-tight">
            Dari request ke verdict, satu alur.
          </h2>
        </Reveal>
        <div className="relative mt-10">
          {/* Connector rail behind the numbered nodes (md+ only). */}
          <div
            className="pointer-events-none absolute left-[16.6%] right-[16.6%] top-6 hidden h-px md:block"
            style={{ background: "linear-gradient(90deg, rgba(212,175,55,0.15), rgba(212,175,55,0.55), rgba(212,175,55,0.15))" }}
            aria-hidden="true"
          />
          <div className="grid gap-6 md:grid-cols-3">
            {[
              { n: "01", t: "Terima di edge", d: "Request masuk ke reverse proxy dan dicatat sebagai window traffic aktif untuk analisis anomali." },
              { n: "02", t: "Periksa berurutan", d: "Rate-limit, reputasi, WAF, fingerprint, dan deteksi anomali dijalankan dalam budget 50 ms. Bot dicurigai diberi challenge, bukan langsung lolos." },
              { n: "03", t: "Teruskan yang lolos", d: "Hanya request yang lolos seluruh lapis yang diteruskan ke upstream. Log, statistik, dan alert mengalir ke dashboard." },
            ].map((s, i) => (
              <Reveal key={s.n} delay={i * 80}>
                <div className="flex h-full flex-col items-center text-center">
                  <span className="gs-gradient relative z-10 grid h-12 w-12 place-items-center rounded-2xl bg-[#0A192F] font-display text-[15px] font-bold text-[#D4AF37] shadow-navy ring-4 ring-[#F5F7FA]">
                    {s.n}
                  </span>
                  <div className="card card-hover mt-4 w-full">
                    <h3 className="font-display text-[15px] font-semibold tracking-tight">{s.t}</h3>
                    <p className="mt-1.5 text-[13.5px] leading-relaxed text-muted">{s.d}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* NETWORK CTA */}
      <section className="container-x py-14">
        <Reveal>
          <div className="gs-gradient bg-[#0A192F] relative overflow-hidden rounded-2xl border border-white/10 p-10 md:p-14 shadow-navy">
            <div className="absolute -left-24 -bottom-24 h-72 w-72 rounded-full bg-[#D4AF37]/15 blur-3xl" />
            <div className="absolute -right-20 -top-24 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
            <div className="relative max-w-2xl">
              <h2 className="font-display text-3xl md:text-4xl font-bold tracking-tight text-white">
                Satu proxy yang menjaga origin Anda.
              </h2>
              <p className="mt-4 text-slate-300">
                Jangan tunggu serangan berikutnya. Pasang GarudaShield di depan aplikasi Anda dan
                biarkan lapisan mitigasi yang bekerja di setiap request.
              </p>
              <div className="mt-7 flex flex-wrap gap-3">
                <a
                  href="https://wa.me/6283187815456"
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold bg-[#D4AF37] text-[#0A192F] shadow-glow transition-all duration-150 hover:bg-[#C9A227] hover:shadow-[0_10px_30px_rgba(212,175,55,0.34)] active:translate-y-px"
                >
                  Mulai sekarang
                </a>
                <Link
                  href="/docs"
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/30 px-4 py-2.5 text-sm font-medium text-white transition-all duration-150 hover:bg-white/10"
                >
                  Baca dokumentasi →
                </Link>
              </div>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
