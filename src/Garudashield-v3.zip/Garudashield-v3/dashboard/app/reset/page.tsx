"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import Logo from "@/components/Logo";

// Password reset. Two modes on one route:
//   - no ?token=  -> request a reset link by email
//   - ?token=...  -> set a new password (link from the reset email)
const ease: [number, number, number, number] = [0.22, 1, 0.36, 1];

export default function ResetPage() {
  const [token, setToken] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);
  const reduced = useReducedMotion();

  useEffect(() => {
    if (typeof window === "undefined") return;
    const t = new URLSearchParams(window.location.search).get("token") || "";
    setToken(t);
  }, []);

  async function request(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setMsg("");
    setBusy(true);
    try {
      const res = await fetch("/api/gs/v1/auth/password/reset-request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });
      if (!res.ok) {
        setErr("Permintaan reset gagal. Coba lagi nanti.");
        return;
      }
      setMsg("Jika email terdaftar, tautan reset telah dikirim (berlaku 60 menit).");
    } finally {
      setBusy(false);
    }
  }

  async function confirm(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setMsg("");
    setBusy(true);
    try {
      const res = await fetch("/api/gs/v1/auth/password/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, newPassword: password }),
      });
      if (!res.ok) {
        setErr(res.status === 401 ? "Tautan tidak valid atau kedaluwarsa." : "Password baru minimal 12 karakter.");
        return;
      }
      setDone(true);
      setMsg("Password berhasil diubah. Silakan masuk kembali.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="flex min-h-screen items-center justify-center bg-grid px-4 py-12 sm:px-6 sm:py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={reduced ? { duration: 0 } : { duration: 0.4, ease }}
        className="card w-full max-w-sm p-8"
      >
        <Logo size={44} rounded="rounded-xl" />
        <h1 className="mt-5 font-display text-xl font-semibold tracking-tight mb-1.5">
          {token ? "Atur Password Baru" : "Lupa Password"}
        </h1>
        <p className="text-[13px] text-muted mb-6">
          {token ? "Masukkan password baru untuk akun Anda." : "Kami akan mengirim tautan reset ke email Anda."}
        </p>

        {done ? (
          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} transition={reduced ? { duration: 0 } : { duration: 0.3, ease }}>
            <div className="mb-4 flex items-center gap-2.5 rounded-xl border border-[#20C997]/45 bg-[#20C997]/10 p-3 text-[13px] text-[#0B7A57]">
              <span className="dot dot-ok" />
              Password berhasil diperbarui.
            </div>
            <a href="/portal" className="btn-primary block w-full text-center">Ke Portal</a>
          </motion.div>
        ) : token ? (
          <form onSubmit={confirm} className="grid gap-3">
            <PasswordField value={password} onChange={setPassword} minLength={12} />
            <Btn loading={busy} type="submit">Simpan password</Btn>
          </form>
        ) : (
          <form onSubmit={request} className="grid gap-3">
            <input
              type="email"
              required
              autoComplete="email"
              placeholder="email@perusahaan.com"
              value={email}
              onChange={e => setEmail(e.target.value)}
              className="input"
            />
            <Btn loading={busy} type="submit">Kirim tautan reset</Btn>
          </form>
        )}

        <AnimatePresence>
          {msg && !done && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              role="status"
              className="text-[13px] text-[#0B7A57] mt-4"
            >
              {msg}
            </motion.p>
          )}
          {err && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              role="alert"
              className="text-[13px] text-danger-ink mt-4"
            >
              {err}
            </motion.p>
          )}
        </AnimatePresence>

        {!done && (
          <p className="mt-5 text-xs text-muted">
            <a href="/portal" className="text-accent-ink hover:text-slate-900">Kembali ke portal</a>
          </p>
        )}
      </motion.div>
    </main>
  );
}

function Btn({ loading, children, ...rest }: React.ButtonHTMLAttributes<HTMLButtonElement> & { loading?: boolean }) {
  return (
    <button className="btn-primary w-full" disabled={loading} aria-busy={loading || undefined} {...rest}>
      {loading && <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" aria-hidden="true" />}
      {children}
    </button>
  );
}

function PasswordField({ value, onChange, minLength }: { value: string; onChange: (v: string) => void; minLength?: number }) {
  const [show, setShow] = useState(false);
  return (
    <div className="relative">
      <input
        type={show ? "text" : "password"}
        required
        minLength={minLength}
        autoComplete="new-password"
        placeholder="password baru (min 12)"
        value={value}
        onChange={e => onChange(e.target.value)}
        className="input pr-16"
      />
      <button
        type="button"
        tabIndex={-1}
        onClick={() => setShow(s => !s)}
        aria-label={show ? "Sembunyikan password" : "Tampilkan password"}
        className="absolute inset-y-0 right-1.5 my-auto h-7 rounded-md px-2 text-xs font-medium text-muted transition-colors hover:text-slate-900"
      >
        {show ? "Sembunyi" : "Lihat"}
      </button>
    </div>
  );
}
