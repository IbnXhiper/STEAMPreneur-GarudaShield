import "./globals.css";
import type { Metadata } from "next";
import Chrome from "@/components/Chrome";
import MouseGlow from "@/components/MouseGlow";

export const metadata: Metadata = {
  title: {
    default: "GarudaShield — Perlindungan DDoS Layer 4/7 & WAF Edge",
    template: "%s — GarudaShield",
  },
  description:
    "GarudaShield adalah reverse proxy multi-layer: mitigasi DDoS Layer 4 & Layer 7, WAF, rate-limit, reputasi, dan challenge di edge, sebelum request mencapai server asal.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="id">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-[#F5F7FA] text-slate-900 antialiased min-h-screen flex flex-col">
        <MouseGlow />
        <Chrome>{children}</Chrome>
      </body>
    </html>
  );
}
