"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Logo from "@/components/Logo";

export default function LoginPage() {
  const router = useRouter();
  const [key, setKey] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);

  // Only redirect to /dash if we already have a VALID admin session. Using the
  // public /api/gs/status here caused a loop: it's 200 for everyone, so the
  // login page bounced to /dash, the middleware bounced back to /login, and
  // the form became hard to click.
  useEffect(() => {
    fetch("/api/auth/check", { credentials: "include" })
      .then((r) => r.json())
      .then((d) => {
        if (d?.authed) router.replace("/dash");
        else setChecking(false);
      })
      .catch(() => setChecking(false));
  }, [router]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      const r = await fetch("/api/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ key }),
      });
      if (r.status === 429) throw new Error("Terlalu banyak percobaan. Tunggu sebentar.");
      if (!r.ok) throw new Error("login gagal");
      router.replace("/dash");
    } catch {
      setErr("API key tidak valid atau server tidak reachable.");
      setLoading(false);
    }
  }

  if (checking) {
    return (
      <div className="container-x flex min-h-[70vh] items-center justify-center">
        <p className="text-muted">Memeriksa sesi…</p>
      </div>
    );
  }

  return (
    <div className="container-x flex min-h-[70vh] items-center justify-center py-12">
      <form onSubmit={submit} className="card w-full max-w-sm space-y-4">
        <Logo size={44} />
        <h1 className="font-display text-xl font-bold">
          Garuda<span className="gs-gradient-text">Shield</span> Dashboard
        </h1>
        <p className="text-sm text-muted">Masukkan API key admin untuk mengakses dashboard.</p>
        <input
          className="input"
          placeholder="x-gs-key / Bearer token"
          value={key}
          onChange={(e) => setKey(e.target.value)}
          autoFocus
        />
        {err && <p className="text-danger-ink text-sm">{err}</p>}
        <button className="btn-primary w-full" disabled={loading || !key}>
          {loading ? "Memeriksa…" : "Masuk"}
        </button>
        <Link href="/" className="block py-1.5 text-center text-xs text-muted hover:text-slate-900">
          ← Kembali ke beranda
        </Link>
      </form>
    </div>
  );
}
