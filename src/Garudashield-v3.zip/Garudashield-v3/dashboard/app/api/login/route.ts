import { NextRequest, NextResponse } from "next/server";

// Brute-force guard for the login endpoint. The admin key is the single gate
// to the whole console, so the BFF keeps a small in-memory sliding window per
// client IP: 10 attempts / minute, then 429 until the window rolls over.
// Node-local only — the dashboard runs one replica per engine node, which is
// exactly the surface this protects. Caddy sets X-Forwarded-For in front.
const WINDOW_MS = 60_000;
const MAX_ATTEMPTS = 10;
const rl = new Map<string, { count: number; reset: number }>();

function clientIp(req: NextRequest): string {
  const xff = req.headers.get("x-forwarded-for");
  if (xff) return xff.split(",")[0].trim();
  return req.headers.get("x-real-ip") || "unknown";
}

export async function POST(req: NextRequest) {
  const now = Date.now();
  const id = clientIp(req);
  const slot = rl.get(id);
  if (!slot || slot.reset < now) {
    rl.set(id, { count: 1, reset: now + WINDOW_MS });
  } else {
    slot.count += 1;
    if (slot.count > MAX_ATTEMPTS) {
      return NextResponse.json(
        { ok: false, error: "rate-limited", retryAfter: Math.ceil((slot.reset - now) / 1000) },
        { status: 429 },
      );
    }
  }
  // Keep the map bounded: drop expired slots once it grows.
  if (rl.size > 4096) {
    for (const [k, v] of rl) if (v.reset < now) rl.delete(k);
  }

  const { key } = await req.json().catch(() => ({ key: "" }));
  if (!key || typeof key !== "string") {
    return NextResponse.json({ ok: false, error: "missing-key" }, { status: 400 });
  }

  // Verify before persisting. Previously any non-empty value was accepted,
  // causing a redirect loop followed by repeated 403/429 dashboard requests.
  const upstream = await fetch(`${process.env.GS_API_URL || "http://localhost:8080"}/api/stats`, {
    headers: { "x-gs-key": key },
    cache: "no-store",
  }).catch(() => null);
  if (!upstream) {
    return NextResponse.json({ ok: false, error: "engine-unreachable" }, { status: 503 });
  }
  if (!upstream.ok) {
    return NextResponse.json({ ok: false, error: "invalid-key" }, { status: 401 });
  }

  const res = NextResponse.json({ ok: true });
  res.cookies.set("gs_key", key, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production" && process.env.GS_COOKIE_SECURE !== "false",
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 8,
  });
  return res;
}