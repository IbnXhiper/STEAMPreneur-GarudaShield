import { NextRequest } from "next/server";

// BFF bridge to the outbound-only proxy fleet agent (see repo proxy/agent).
// The agent lives on a separate node and is never exposed to browsers: only the
// logged-in dashboard (HttpOnly gs_key cookie) can reach it, and the shared
// token is injected server-side so it never lands in client code.
//
//   PROXY_AGENT_URL   single agent base   (e.g. http://104.64.205.215:8787)
//   PROXY_AGENT_URLS  comma list for failover (takes precedence over _URL)
//   PROXY_AGENT_TOKEN shared secret sent as X-Auth-Token

function agents(): string[] {
  const multi = process.env.PROXY_AGENT_URLS;
  if (multi) return multi.split(",").map((s) => s.trim()).filter(Boolean);
  const one = process.env.PROXY_AGENT_URL;
  return one ? [one] : [];
}

function json(status: number, body: unknown) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  });
}

async function handle(req: NextRequest, path: string[] | undefined, method: "GET" | "POST") {
  if (!req.cookies.get("gs_key")?.value) return json(401, { ok: false, error: "unauthorized" });

  const list = agents();
  if (!list.length) return json(503, { ok: false, error: "proxy agent not configured" });

  const token = process.env.PROXY_AGENT_TOKEN || "";
  const sub = (path || []).join("/");
  const qs = req.nextUrl.search;
  const bodyText = method === "POST" ? await req.text() : undefined;

  let lastErr = "unreachable";
  for (const base of list) {
    const url = `${base.replace(/\/$/, "")}/${sub}${qs}`;
    const headers: Record<string, string> = { Accept: "application/json, text/plain, */*" };
    if (token) headers["X-Auth-Token"] = token;
    if (method === "POST") headers["Content-Type"] = "application/json";
    try {
      const upstream = await fetch(url, { method, headers, body: bodyText, cache: "no-store", signal: AbortSignal.timeout(8000) });
      const text = await upstream.text();
      return new Response(text, {
        status: upstream.status,
        headers: {
          "Content-Type": upstream.headers.get("content-type") || "application/json",
          "Cache-Control": "no-store",
        },
      });
    } catch (e: any) {
      lastErr = String(e?.message || e);
    }
  }
  return json(502, { ok: false, error: `proxy agent unreachable (${lastErr})` });
}

export async function GET(req: NextRequest, { params }: { params: { path?: string[] } }) {
  return handle(req, params.path, "GET");
}

export async function POST(req: NextRequest, { params }: { params: { path?: string[] } }) {
  return handle(req, params.path, "POST");
}
