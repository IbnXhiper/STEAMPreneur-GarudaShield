import { NextRequest, NextResponse } from "next/server";

function apiBase() {
  return process.env.GS_API_URL || "http://localhost:8080";
}

function keyFrom(req: NextRequest): string {
  // Server-side sources only: the HttpOnly gs_key cookie (set at login)
  // or the server env. Never forward a client-supplied x-gs-key header —
  // that would let any visitor make the BFF spend the operator's key
  // and turns the BFF into an open admin relay.
  const fromCookie = req.cookies.get("gs_key")?.value;
  if (fromCookie) return fromCookie;
  return process.env.GS_API_KEY || "";
}

async function proxy(req: NextRequest, path: string[], method: string) {
  const base = apiBase();
  const qs = req.nextUrl.search;
  const url = `${base}/api/${path.join("/")}${qs}`;
  const key = keyFrom(req);

  const headers = new Headers();
  headers.set("x-gs-key", key);
  headers.set("Accept", req.headers.get("accept") || "*/*");
  // Forward the tenant session cookie so session-authenticated commercial
  // routes (/api/v1/account, /api/v1/keys, /api/v1/quota, MFA) work through
  // the BFF. Only gs_session is forwarded — never gs_key (that is the
  // server-side operator secret and must not leak to the engine as a cookie).
  const sess = req.cookies.get("gs_session")?.value;
  if (sess) headers.set("cookie", "gs_session=" + sess);
  if (method === "POST") {
    const ct = req.headers.get("content-type");
    if (ct) headers.set("content-type", ct);
  }

  const init: RequestInit = { method, headers };
  if (method === "POST") {
    init.body = await req.text();
  }

  const upstream = await fetch(url, init);
  const out = new Headers();
  upstream.headers.forEach((v, k) => {
    const lk = k.toLowerCase();
    if (lk === "connection" || lk === "transfer-encoding") return;
    out.set(k, v);
  });
  out.set("Cache-Control", "no-store");
  // Forward the session cookie the engine sets on login so the browser keeps
  // the authenticated session for /api/tenant/me etc.
  const setCookie = upstream.headers.get("set-cookie");
  if (setCookie) out.set("set-cookie", setCookie);
  return new Response(upstream.body, {
    status: upstream.status,
    headers: out,
  });
}

export async function GET(req: NextRequest, { params }: { params: { path: string[] } }) {
  return proxy(req, params.path, "GET");
}

export async function POST(req: NextRequest, { params }: { params: { path: string[] } }) {
  return proxy(req, params.path, "POST");
}

export async function DELETE(req: NextRequest, { params }: { params: { path: string[] } }) {
  return proxy(req, params.path, "DELETE");
}
