import type { Metadata } from "next";

export const metadata: Metadata = { title: "Fitur proteksi" };

export default function FeaturesLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
