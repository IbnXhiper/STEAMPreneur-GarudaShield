import Link from "next/link";
import Reveal from "@/components/Reveal";

const sections = [
  {
    eyebrow: "Layer 3 / 4",
    title: "Proteksi jaringan & transport",
    description: "Serangan volumetrik ditahan sebelum menghabiskan koneksi, bandwidth, atau resource origin.",
    items: ["SYN Flood", "UDP Flood", "ACK / RST Flood", "DNS / NTP / SSDP Amplification", "ICMP Flood", "Bogon & Port Scan"],
  },
  {
    eyebrow: "Layer 7",
    title: "Proteksi aplikasi & Web Application Firewall",
    description: "Request dianalisis sebelum mencapai aplikasi: manusia, bot, payload, path, header, cookie, dan body.",
    items: ["HTTP / HTTPS Flood", "Slowloris & Slow POST", "Brute-force Login", "Web Scraping", "Custom WAF Rules", "Per-Path Rate Limit"],
  },
  {
    eyebrow: "WAF modules",
    title: "Signature engine yang dapat dikendalikan",
    description: "Aturan bawaan menangkap pola umum serangan dan bisa di-toggle tanpa restart dari dashboard atau API.",
    items: ["SQL Injection", "Cross-Site Scripting (XSS)", "Path Traversal", "Command Injection", "LFI / RFI", "Shellshock & Scanner"],
  },
  {
    eyebrow: "Verify browser",
    title: "Interstitial untuk pengunjung pertama",
    description: "Challenge ringan memisahkan browser manusia dari skrip otomatis. IP kantor dapat di-whitelist.",
    items: ["Challenge per-host", "Signed access cookie", "Private paths", "Exempt paths", "Latency hold", "CAPTCHA rate limit"],
  },
  {
    eyebrow: "Traffic control",
    title: "Kontrol laju lintas yang presisi",
    description: "Ambang global, per-IP, per-path, koneksi, token bucket, dan mode adaptif untuk mengendalikan lonjakan.",
    items: ["Global RPS", "Per-IP RPS & burst", "Per-path rules", "Adaptive ladder", "RED early drop", "Connection limit"],
  },
  {
    eyebrow: "Command center",
    title: "Pusat kendali real-time",
    description: "Semua keputusan pertahanan terlihat dari satu konsol yang mengutamakan scanning, comparison, dan aksi cepat.",
    items: ["Overview & posture", "RPS & bandwidth charts", "Top IP & paths", "Blocked event log", "GB / TB ingress volume", "Blocklist & whitelist"],
  },
  {
    eyebrow: "Operations",
    title: "Operasional dan integrasi",
    description: "Engine siap dioperasikan sebagai reverse proxy maupun multi-site edge dengan API yang dapat diautomasi.",
    items: ["Reverse proxy", "Multi-subdomain routing", "Trust proxy", "Circuit breaker", "Health monitor", "Backup & restore"],
  },
  {
    eyebrow: "Signals",
    title: "Observabilitas keamanan",
    description: "Traffic, reputation, anomaly, event, dan kesehatan komponen dikumpulkan untuk keputusan yang bisa diaudit.",
    items: ["Request counters", "Ingress bytes", "Blocked bytes", "Reputation score", "Anomaly detection", "Incident history"],
  },
  {
    eyebrow: "Cluster",
    title: "Satu cluster, satu kebijakan",
    description: "Perubahan blocklist dan sinkronisasi state menjaga beberapa node bertindak sebagai satu perimeter.",
    items: ["Realtime broadcast", "Full sync berkala", "Tombstone unblock", "Health heartbeat", "Shared Redis state", "Node status"],
  },
  {
    eyebrow: "Alerts",
    title: "Notifikasi saat ancaman terjadi",
    description: "Tim mendapat sinyal cepat ketika attack detected, emergency, aggressive, flood, atau critical event aktif.",
    items: ["Telegram bot", "Discord webhook", "Severity filter", "Cooldown", "Test delivery", "Alert history"],
  },
  {
    eyebrow: "Geo monitoring",
    title: "Ketahui asal traffic & penyerang",
    description: "IP, negara, kota, dan koordinat dapat diperkaya untuk membantu triage dan investigasi sumber request.",
    items: ["Geo map", "Top sources", "Enriched blocklist", "Enriched whitelist", "Challenge failures", "Country distribution"],
  },
  {
    eyebrow: "Delivery",
    title: "Fondasi untuk production",
    description: "Komponen pendukung membantu menjaga deployment tetap cepat, tersedia, dan mudah dipulihkan.",
    items: ["SSL automation", "HTTP/3 readiness", "Load balancing", "Origin failover", "Dashboard BFF", "Operator runbook"],
  },
];

export default function FeaturesPage() {
  return (
    <div className="bg-grid">
      <section className="container-x pt-16 pb-10">
        <Reveal>
          <span className="eyebrow">Fitur Lengkap</span>
          <h1 className="mt-3 max-w-6xl font-display text-4xl md:text-6xl font-bold tracking-tight">
            Semua lapisan pertahanan dalam <span className="text-gradient">satu engine.</span>
          </h1>
          <p className="mt-5 max-w-3xl text-muted text-lg leading-relaxed">
            GarudaShield menangani proteksi jaringan, aplikasi, WAF, browser verification, observability,
            operasi multi-site, dan sinkronisasi cluster melalui satu edge yang bisa dikendalikan.
          </p>
        </Reveal>
      </section>

      <section className="container-x pb-12">
        <div className="feature-rail">
          {sections.slice(0, 6).map((section, i) => (
            <Reveal key={section.title} delay={(i % 3) * 60} className="h-full">
              <article className="feature-card h-full">
                <div className="feature-number">{String(i + 1).padStart(2, "0")}</div>
                <div className="eyebrow">{section.eyebrow}</div>
                <h2 className="mt-3 font-display text-xl font-bold">{section.title}</h2>
                <p className="mt-2 text-sm text-muted leading-relaxed">{section.description}</p>
                <ul className="mt-5 space-y-2 text-sm">
                  {section.items.map((item) => <li key={item} className="feature-item"><span>+</span>{item}</li>)}
                </ul>
              </article>
            </Reveal>
          ))}
        </div>
      </section>

      <section className="feature-band">
        <div className="container-x py-14">
          <Reveal>
            <div className="max-w-2xl">
              <span className="eyebrow">Capability map</span>
              <h2 className="mt-3 font-display text-3xl md:text-4xl font-bold">Dari packet sampai operator.</h2>
              <p className="mt-3 text-muted leading-relaxed">Satu alur kerja: tangkap sinyal, putuskan verdict, mitigasi request, catat event, lalu tampilkan bukti di console.</p>
            </div>
          </Reveal>
          <div className="feature-strip-grid mt-9">
            {sections.slice(6).map((section, i) => (
              <Reveal key={section.title} delay={(i % 3) * 50}>
                <article className="feature-mini">
                  <div className="eyebrow">{section.eyebrow}</div>
                  <h3 className="mt-2 font-display text-lg font-bold">{section.title}</h3>
                  <p className="mt-2 text-sm text-muted leading-relaxed">{section.description}</p>
                  <div className="mt-4 flex flex-wrap gap-2">{section.items.map((item) => <span key={item} className="feature-chip">{item}</span>)}</div>
                </article>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      <section className="container-x pb-16 pt-14">
        <Reveal>
          <div className="feature-cta">
            <div>
              <span className="eyebrow">Mulai protection</span>
              <h2 className="mt-3 font-display text-2xl md:text-3xl font-bold">Siap pasang di depan aplikasi Anda?</h2>
              <p className="mt-2 text-muted max-w-xl">Mulai dari config lokal, hubungkan origin, lalu pantau keputusan engine dari dashboard.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <Link href="/docs" className="btn-primary">Baca Dokumentasi</Link>
              <Link href="/chat" className="btn">Tanya AI Garuda</Link>
              <a href="https://wa.me/6283187815456" target="_blank" rel="noreferrer" className="btn-ghost">Konsultasi via WhatsApp</a>
            </div>
          </div>
        </Reveal>
      </section>
    </div>
  );
}
