"use client";

/**
 * Last-resort boundary for failures in the root layout. It cannot rely on the
 * app shell styles being available, so it ships the minimum CSS it needs.
 */
export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="id">
      <body
        style={{
          margin: 0,
          minHeight: "100vh",
          display: "grid",
          placeItems: "center",
          background: "#F5F7FA",
          color: "#0A192F",
          fontFamily: "ui-sans-serif, system-ui, sans-serif",
          padding: 24,
        }}
      >
        <div style={{ maxWidth: 440, textAlign: "center", background: "#FFFFFF", border: "1px solid #E5E7EB", borderRadius: 18, padding: 30, boxShadow: "0 4px 16px rgba(10,25,47,.06)" }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: "#B02A37", letterSpacing: ".06em" }}>DASHBOARD TIDAK TERSEDIA</div>
          <p style={{ margin: "12px 0 0", fontSize: 13, lineHeight: 1.65, color: "#475569" }}>
            Halaman gagal dimuat. Mitigasi di edge tetap berjalan normal — hanya tampilan dashboard yang
            terpengaruh.
          </p>
          {error.digest ? <p style={{ margin: "10px 0 0", fontSize: 11, color: "#475569" }}>ref: {error.digest}</p> : null}
          <div style={{ marginTop: 18, display: "flex", gap: 8, justifyContent: "center" }}>
            <button
              onClick={reset}
              style={{ border: 0, borderRadius: 10, padding: "9px 16px", background: "#0A192F", color: "#FFFFFF", fontWeight: 700, fontSize: 12, cursor: "pointer", boxShadow: "0 4px 12px rgba(10,25,47,.18)" }}
            >
              Coba lagi
            </button>
            <a
              href="/"
              style={{ background: "#FFFFFF", border: "1px solid #E5E7EB", borderRadius: 10, padding: "9px 16px", color: "#0A192F", fontSize: 12, fontWeight: 600, textDecoration: "none" }}
            >
              Beranda
            </a>
          </div>
        </div>
      </body>
    </html>
  );
}