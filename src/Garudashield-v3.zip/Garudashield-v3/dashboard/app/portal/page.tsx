"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import PolicyEditor from "./PolicyEditor";
import Logo from "@/components/Logo";
import { ExportButton, SearchInput, Segmented } from "@/components/ui";
import { csvFilename, downloadCsv } from "@/lib/csv";
import { filterRows } from "@/lib/search";

// Customer portal. Auth is real (Postgres-backed) end to end via the BFF:
//   login -> (optional 2nd factor) -> tenant/me + account + quota, plus
//   self-service password change, TOTP MFA enrollment and protected-domain
//   management. Success/error feedback for the signed-in area arrives as
//   toasts; the auth cards keep their inline messages.
type Me = { tenant: string; name: string; plan: string; domain: string; license: { status: string; exp: number } };
type Account = { tenant: string; email: string; role: string };
type Quota = { plan: string; period: string; limit: number; used: number; remaining: number };
type Asset = { id: number; domain: string; originHost?: string; originPort?: number; status: string; verifyToken: string };
type Member = { id: number; email: string; role: string; createdAt: string };
type AuditEntry = { id: number; tenant: string; actor: string; action: string; detail: string; ip: string; at: number; time: string };
type Toast = { id: number; msg: string; kind: "ok" | "err" };

async function postJSON(path: string, body: unknown) {
  return fetch(`/api/gs/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
}
async function getJSON(path: string) {
  return fetch(`/api/gs/${path}`, { credentials: "include" });
}
async function delJSON(path: string) {
  return fetch(`/api/gs/${path}`, { method: "DELETE", credentials: "include" });
}

const ease: [number, number, number, number] = [0.22, 1, 0.36, 1];

function useStagger() {
  const reduced = useReducedMotion();
  const dur = reduced ? 0 : 0.42;
  return {
    container: { hidden: {}, show: { transition: { staggerChildren: reduced ? 0 : 0.06, delayChildren: reduced ? 0 : 0.04 } } },
    item: {
      hidden: { opacity: 0, y: reduced ? 0 : 14 },
      show: { opacity: 1, y: 0, transition: { duration: dur, ease } },
    },
  };
}

export default function PortalPage() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [regName, setRegName] = useState("");
  const [code, setCode] = useState("");
  const [mfaToken, setMfaToken] = useState("");
  const [needMfa, setNeedMfa] = useState(false);

  const [me, setMe] = useState<Me | null>(null);
  const [account, setAccount] = useState<Account | null>(null);
  const [quota, setQuota] = useState<Quota | null>(null);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [domainLimit, setDomainLimit] = useState(0);
  const [newDomain, setNewDomain] = useState("");
  const [newOrigin, setNewOrigin] = useState("");
  const [configAsset, setConfigAsset] = useState<Asset | null>(null);
  const [assetQuery, setAssetQuery] = useState("");
  const [assetStatus, setAssetStatus] = useState<"all" | "verified" | "pending">("all");

  const [members, setMembers] = useState<Member[]>([]);
  const [myRole, setMyRole] = useState("");
  const [newMemberEmail, setNewMemberEmail] = useState("");
  const [newMemberPassword, setNewMemberPassword] = useState("");
  const [newMemberRole, setNewMemberRole] = useState("viewer");
  const [auditEntries, setAuditEntries] = useState<AuditEntry[]>([]);
  const [auditTotal, setAuditTotal] = useState(0);
  const [auditAction, setAuditAction] = useState("");
  const [auditQuery, setAuditQuery] = useState("");

  const [error, setError] = useState("");
  const [toasts, setToasts] = useState<Toast[]>([]);
  const [busy, setBusy] = useState("");
  const [loading, setLoading] = useState(false);

  // password change
  const [curPw, setCurPw] = useState("");
  const [newPw, setNewPw] = useState("");
  // MFA
  const [setup, setSetup] = useState<{ secret: string; otpauthUrl: string } | null>(null);
  const [enableCode, setEnableCode] = useState("");
  const [disableCode, setDisableCode] = useState("");
  const [recovery, setRecovery] = useState<string[]>([]);

  const v = useStagger();
  const reduced = useReducedMotion();
  const enter = reduced ? { duration: 0 } : { duration: 0.4, ease };

  // Plan cap on protected domains. domainLimit <= 0 means "unlimited" (paid
  // tier or unknown), so the notice only appears when the tenant is pinned at a
  // finite cap. planLabel drives the upgrade copy.
  const planLabel = (me?.plan || "free").toUpperCase();
  const atDomainLimit = domainLimit > 0 && assets.length >= domainLimit;

  function toast(msg: string, kind: "ok" | "err" = "ok") {
    const id = Date.now() + Math.random();
    setToasts(t => [...t, { id, msg, kind }]);
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 4200);
  }

  // Restore an existing session on load: if the gs_session cookie is still
  // valid the portal opens straight into the dashboard; if not (or expired),
  // we silently fall back to the login/register card with no error shown.
  useEffect(() => {
    let alive = true;
    (async () => {
      const res = await getJSON("tenant/me");
      if (alive && res.ok) await loadAll();
    })();
    return () => { alive = false; };
  }, []);

  async function login(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setRecovery([]);
    setBusy("login");
    try {
      const res = await postJSON("v1/auth/login", { email, password });
      if (res.status === 202) {
        const body = await res.json();
        setMfaToken(body.mfaToken || "");
        setNeedMfa(true);
        return;
      }
      if (!res.ok) {
        setError("Login gagal. Periksa email/password.");
        return;
      }
      await loadAll();
    } finally {
      setBusy("");
    }
  }

  // Registration creates the account + free-plan subscription atomically on the
  // engine and auto-logs in (session cookie), so we just reload the portal and
  // the "Paket Aktif" card renders the FREE plan straight from the backend.
  function registerError(status: number, body: string): string {
    if (status === 409) return "Email sudah terdaftar. Coba masuk atau pakai email lain.";
    if (status === 429) return "Terlalu banyak pendaftaran dari jaringan ini. Coba lagi nanti.";
    if (status === 400) {
      const t = body.toLowerCase();
      if (t.includes("password")) return "Password minimal 12 karakter.";
      if (t.includes("email")) return "Masukkan email yang valid.";
      return "Data pendaftaran tidak valid. Periksa kembali.";
    }
    return "Pendaftaran gagal. Silakan coba lagi.";
  }

  async function register(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setRecovery([]);
    setBusy("register");
    try {
      const res = await postJSON("v1/auth/register", { email, password, name: regName });
      if (!res.ok) {
        setError(registerError(res.status, await res.text()));
        return;
      }
      await loadAll();
    } finally {
      setBusy("");
    }
  }

  function switchMode(next: "login" | "register") {
    setMode(next);
    setError("");
    setPassword("");
    setRegName("");
  }

  async function verifyMfa(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setBusy("mfa");
    try {
      const res = await postJSON("v1/auth/mfa/verify", { mfaToken, code });
      if (!res.ok) {
        setError("Kode salah atau kedaluwarsa.");
        return;
      }
      setNeedMfa(false);
      setCode("");
      await loadAll();
    } finally {
      setBusy("");
    }
  }

  async function loadAll() {
    setLoading(true);
    try {
      const meRes = await getJSON("tenant/me");
      if (!meRes.ok) {
        setError("Sesi tidak valid.");
        return;
      }
      setMe(await meRes.json());
      const [acct, q, a, mem, au] = await Promise.all([
        getJSON("v1/account"),
        getJSON("v1/quota"),
        getJSON("v1/assets"),
        getJSON("v1/members"),
        getJSON("v1/audit?limit=200"),
      ]);
      if (acct.ok) setAccount(await acct.json());
      if (q.ok) setQuota(await q.json());
      if (a.ok) {
        const body = await a.json();
        setAssets(body.assets || []);
        setDomainLimit(typeof body.domainLimit === "number" ? body.domainLimit : 0);
      }
      if (mem.ok) {
        const body = await mem.json();
        setMembers(body.members || []);
        setMyRole(body.role || "");
      }
      if (au.ok) {
        const body = await au.json();
        setAuditEntries(body.entries || []);
        setAuditTotal(body.total || 0);
      }
    } finally {
      setLoading(false);
    }
  }

  async function refreshAssets() {
    const a = await getJSON("v1/assets");
    if (a.ok) {
      const body = await a.json();
      setAssets(body.assets || []);
      setDomainLimit(typeof body.domainLimit === "number" ? body.domainLimit : 0);
    }
  }

  async function refreshMembers() {
    const mem = await getJSON("v1/members");
    if (mem.ok) {
      const body = await mem.json();
      setMembers(body.members || []);
      setMyRole(body.role || "");
    }
  }

  async function refreshAudit(action = auditAction) {
    const res = await getJSON(`v1/audit?limit=200${action ? `&action=${encodeURIComponent(action)}` : ""}`);
    if (res.ok) {
      const body = await res.json();
      setAuditEntries(body.entries || []);
      setAuditTotal(body.total || 0);
    }
  }

  async function reloadAudit(e: React.FormEvent) {
    e.preventDefault();
    setBusy("audit");
    try {
      await refreshAudit();
    } finally {
      setBusy("");
    }
  }

  async function addMember(e: React.FormEvent) {
    e.preventDefault();
    setBusy("member-add");
    try {
      const res = await postJSON("v1/members", { email: newMemberEmail, password: newMemberPassword, role: newMemberRole });
      if (!res.ok) {
        toast(
          res.status === 409
            ? "Email itu sudah menjadi anggota."
            : res.status === 403
            ? "Hanya owner yang bisa menambah anggota."
            : "Gagal menambah anggota (cek email/password, min 12 karakter).",
          "err",
        );
        return;
      }
      setNewMemberEmail("");
      setNewMemberPassword("");
      setNewMemberRole("viewer");
      await refreshMembers();
      await refreshAudit();
      toast("Anggota ditambahkan.");
    } finally {
      setBusy("");
    }
  }

  async function removeMember(id: number) {
    setBusy(`member-del-${id}`);
    try {
      const res = await delJSON(`v1/members/${id}`);
      if (!res.ok) {
        toast(
          res.status === 409
            ? "Tidak bisa menghapus diri sendiri atau owner terakhir."
            : res.status === 403
              ? "Hanya owner yang bisa menghapus anggota."
              : "Gagal menghapus anggota.",
          "err",
        );
        return;
      }
      await refreshMembers();
      await refreshAudit();
      toast("Anggota dihapus.");
    } finally {
      setBusy("");
    }
  }

  async function logout() {
    await postJSON("auth/logout", {});
    setMe(null);
    setAccount(null);
    setQuota(null);
    setAssets([]);
    setMembers([]);
    setAuditEntries([]);
    setAuditTotal(0);
    setMyRole("");
    setPassword("");
    setMode("login");
    setToasts([]);
  }

  async function changePassword(e: React.FormEvent) {
    e.preventDefault();
    setBusy("pw");
    try {
      const res = await postJSON("v1/account/password", { currentPassword: curPw, newPassword: newPw });
      if (!res.ok) {
        toast(res.status === 401 ? "Password lama salah." : "Ganti password gagal (min 12 karakter, harus beda).", "err");
        return;
      }
      setCurPw("");
      setNewPw("");
      toast("Password diperbarui. Sesi lain telah dikeluarkan.");
    } finally {
      setBusy("");
    }
  }

  async function mfaSetup() {
    setBusy("mfa-setup");
    try {
      const res = await postJSON("v1/account/mfa/setup", {});
      if (!res.ok) {
        toast("Inisialisasi MFA gagal.", "err");
        return;
      }
      setSetup(await res.json());
      setRecovery([]);
    } finally {
      setBusy("");
    }
  }

  async function mfaEnable(e: React.FormEvent) {
    e.preventDefault();
    setBusy("mfa-enable");
    try {
      const res = await postJSON("v1/account/mfa/enable", { code: enableCode });
      if (!res.ok) {
        toast("Kode verifikasi salah.", "err");
        return;
      }
      const body = await res.json();
      setRecovery(body.recoveryCodes || []);
      setSetup(null);
      setEnableCode("");
      toast("MFA aktif. Simpan recovery code sekarang — hanya ditampilkan sekali.");
    } finally {
      setBusy("");
    }
  }

  async function mfaDisable(e: React.FormEvent) {
    e.preventDefault();
    setBusy("mfa-disable");
    try {
      const res = await postJSON("v1/account/mfa/disable", { code: disableCode });
      if (!res.ok) {
        toast("Kode salah; MFA tetap aktif.", "err");
        return;
      }
      setDisableCode("");
      setRecovery([]);
      toast("MFA dinonaktifkan.");
    } finally {
      setBusy("");
    }
  }

  async function addAsset(e: React.FormEvent) {
    e.preventDefault();
    if (atDomainLimit) {
      toast(`Batas domain paket ${planLabel} tercapai. Upgrade ke Pro untuk menambah domain.`, "err");
      return;
    }
    setBusy("asset-add");
    try {
      const res = await postJSON("v1/assets", { domain: newDomain, originHost: newOrigin });
      if (!res.ok) {
        if (res.status === 402) {
          let msg = `Batas domain paket ${planLabel} tercapai. Upgrade ke Pro untuk menambah domain lain.`;
          try {
            const body = await res.json();
            if (body && typeof body.error === "string" && body.error) msg = body.error;
            const lim = body && (typeof body.limit === "number" ? body.limit : body.domainLimit);
            if (typeof lim === "number") setDomainLimit(lim);
          } catch {
            /* non-JSON error body - keep the generic message */
          }
          await refreshAssets();
          toast(msg, "err");
          return;
        }
        toast(res.status === 409 ? "Domain sudah terdaftar." : "Gagal menambah domain (cek format/alamat).", "err");
        return;
      }
      setNewDomain("");
      setNewOrigin("");
      await refreshAssets();
      toast("Domain ditambahkan. Buat TXT record lalu klik Verifikasi.");
    } finally {
      setBusy("");
    }
  }

  async function verifyAsset(id: number) {
    setBusy(`asset-verify-${id}`);
    try {
      const res = await postJSON(`v1/assets/${id}/verify`, {});
      if (!res.ok) {
        let msg = "Verifikasi gagal. Coba lagi.";
        try {
          const body = await res.json();
          if (body && typeof body.error === "string" && body.error) msg = body.error;
        } catch {
          /* non-JSON error body - keep the generic message */
        }
        toast(msg, "err");
        return;
      }
      await refreshAssets();
      toast("Domain terverifikasi dan aktif di edge.");
    } finally {
      setBusy("");
    }
  }

  async function deleteAsset(id: number) {
    setBusy(`asset-del-${id}`);
    try {
      const res = await delJSON(`v1/assets/${id}`);
      if (!res.ok) {
        toast("Gagal menghapus domain.", "err");
        return;
      }
      setAssets(assets.filter(x => x.id !== id));
      toast("Domain dihentikan perlindungannya.");
    } finally {
      setBusy("");
    }
  }

  if (needMfa) {
    return (
      <Shell>
        <motion.form
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={enter}
          onSubmit={verifyMfa}
          className="card w-full max-w-sm p-8"
        >
          <ShieldMark />
          <h1 className="font-display text-xl font-semibold tracking-tight mb-1.5 mt-5">Verifikasi Dua Langkah</h1>
          <p className="text-[13px] text-muted mb-6">Masukkan kode dari aplikasi authenticator atau recovery code.</p>
          <input
            inputMode="text"
            autoComplete="one-time-code"
            autoFocus
            required
            placeholder="123456"
            value={code}
            onChange={e => setCode(e.target.value)}
            className="input mb-4 tracking-[0.3em] text-center"
          />
          <AnimatePresence>
            {error && (
              <motion.p
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                role="alert"
                className="text-[13px] text-danger-ink mb-3"
              >
                {error}
              </motion.p>
            )}
          </AnimatePresence>
          <Btn type="submit" loading={busy === "mfa"} className="w-full">Verifikasi</Btn>
          <button type="button" onClick={() => { setNeedMfa(false); setCode(""); setError(""); }} className="btn w-full mt-3">
            Kembali
          </button>
        </motion.form>
      </Shell>
    );
  }

  if (me) {
    const pct = quota && quota.limit > 0 ? Math.min(100, Math.round((quota.used / quota.limit) * 100)) : 0;
    const barColor = pct >= 90 ? "var(--gs-danger)" : pct >= 70 ? "var(--gs-accent)" : "var(--gs-ok)";
    const barInk = pct >= 90 ? "text-danger-ink" : pct >= 70 ? "text-[#8A6D1F]" : "text-[#0B7A57]";
    const licenseExp = me.license?.exp ? new Date(me.license.exp * 1000).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }) : "—";
    const role = (account?.role || myRole || "").toLowerCase();
    const isOwner = role === "owner";

    const shownAssets = filterRows(assets, assetQuery, ["domain", "originHost"], (a) =>
      assetStatus === "all" ? true : assetStatus === "verified" ? a.status === "verified" : a.status !== "verified",
    );
    const shownAudit = filterRows(auditEntries, auditQuery, ["action", "detail", "actor", "ip"]);

    const exportAssets = () =>
      downloadCsv(
        csvFilename("domain"),
        ["Domain", "Origin", "Port", "Status"],
        shownAssets.map(a => [a.domain, a.originHost || "", a.originPort || "", a.status === "verified" ? "terverifikasi" : "menunggu"]),
      );
    const exportAudit = () =>
      downloadCsv(
        csvFilename("aktivitas"),
        ["Waktu", "Aksi", "Detail", "Aktor", "IP"],
        shownAudit.map(e => [
          e.at ? new Date(e.at * 1000).toISOString() : "",
          e.action || "",
          e.detail || "",
          e.actor || "",
          e.ip || "",
        ]),
      );

    return (
      <Shell wide>
        <Toasts toasts={toasts} reduced={!!reduced} onDismiss={id => setToasts(t => t.filter(x => x.id !== id))} />
        <motion.div variants={v.container} initial="hidden" animate="show" className="max-w-4xl mx-auto">
          {/* Top bar */}
          <motion.header
            variants={v.item}
            className="mb-7 flex flex-wrap items-center gap-3 rounded-2xl border border-edge bg-panel px-4 py-3 shadow-card"
          >
            <Logo />
            <span className="font-display text-lg font-semibold text-slate-900">
              Garuda<span className="text-[#8A6D1F]">Shield</span>
            </span>
            <span className="hidden text-xs text-muted sm:inline">/ Portal Pelanggan</span>
            <div className="spacer" />
            {account && (
              <span className="hidden items-center gap-2 rounded-full border border-edge px-3 py-1.5 text-xs text-muted sm:inline-flex">
                <span className="dot dot-ok" />
                {account.email}
              </span>
            )}
            <button onClick={logout} className="btn">Keluar</button>
          </motion.header>

          <motion.h1 variants={v.item} className="text-[26px] font-display font-bold tracking-tight mb-5">
            Ringkasan Tenant
          </motion.h1>

          {/* Stat cards */}
          <motion.div variants={v.item} className="grid grid-cols-2 gap-3 md:grid-cols-3">
            <Stat title="Tenant" value={me.tenant} />
            <Stat title="Paket Aktif" value={me.plan.toUpperCase()} tone="accent" />
            <Stat title="Status Lisensi" value={me.license.status.toUpperCase()} tone={me.license.status === "active" ? "ok" : "warn"} />
            <Stat title="Domain" value={me.domain || "—"} />
            <Stat title="Email" value={account?.email || "—"} />
            <Stat title="Peran" value={(account?.role || "owner").toUpperCase()} />
          </motion.div>

          {/* Quota */}
          <motion.section variants={v.item} className="card mt-4 p-5">
            <SectionHead title="Kuota permintaan hari ini" hint={quota ? `Periode ${quota.period}` : undefined} />
            {loading && !quota ? (
              <SkeletonLines />
            ) : quota ? (
              <>
                <div className="flex flex-wrap items-baseline justify-between gap-1 mb-3">
                  <span className="text-2xl font-display font-bold text-slate-900 tabular">
                    {quota.limit > 0 ? quota.used.toLocaleString("id-ID") : "∞"}
                  </span>
                  <span className="text-[13px] text-muted">
                    {quota.limit > 0
                      ? `dari ${quota.limit.toLocaleString("id-ID")} · sisa ${quota.remaining.toLocaleString("id-ID")}`
                      : "paket tanpa batas"}
                  </span>
                </div>
                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100" role="progressbar" aria-valuenow={pct} aria-valuemin={0} aria-valuemax={100}>
                  <motion.div
                    className="h-full rounded-full"
                    style={{ background: barColor }}
                    initial={{ width: 0 }}
                    animate={{ width: `${pct}%` }}
                    transition={{ duration: 0.7, ease }}
                  />
                </div>
                <p className={`text-xs mt-2 ${barInk}`}>
                  {pct}% terpakai · plan {quota.plan.toUpperCase()}
                </p>
              </>
            ) : (
              <p className="text-[13px] text-muted">Kuota tidak aktif untuk deployment ini.</p>
            )}
          </motion.section>

          {/* Protected domains (assets) */}
          <motion.section variants={v.item} className="card mt-4 p-5">
            <SectionHead
              title="Domain terlindungi"
              hint={
                domainLimit > 0
                  ? `${assets.length} dari ${domainLimit} domain (paket ${planLabel})`
                  : assets.length
                    ? `${shownAssets.length} dari ${assets.length} domain`
                    : undefined
              }
            />

            {atDomainLimit && (
              <div
                role="alert"
                className="mb-4 flex flex-col gap-3 rounded-xl border border-[#D4AF37] bg-[#D4AF37]/10 p-4 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="flex items-start gap-3">
                  <span aria-hidden="true" className="mt-0.5 text-lg leading-none text-[#8A6D1F]">★</span>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">
                      Batas domain paket {planLabel} tercapai ({assets.length}/{domainLimit})
                    </p>
                    <p className="mt-0.5 text-[13px] text-muted">
                      Paket {planLabel} hanya dapat melindungi {domainLimit} domain. Upgrade ke paket Pro untuk
                      melindungi domain lain.
                    </p>
                  </div>
                </div>
                <div className="flex shrink-0 flex-wrap items-center gap-2">
                  <a href="/pricing" className="btn-primary sm:w-auto">Upgrade ke Pro</a>
                  <a href="https://wa.me/6283187815456" target="_blank" rel="noreferrer" className="btn sm:w-auto">
                    Hubungi kami
                  </a>
                </div>
              </div>
            )}

            <form onSubmit={addAsset} className="mb-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-start">
              <input
                required
                placeholder="domain (mis. shop.perusahaan.id)"
                value={newDomain}
                onChange={e => setNewDomain(e.target.value)}
                className="input sm:max-w-[260px]"
              />
              <input
                placeholder="origin (opsional, host publik)"
                value={newOrigin}
                onChange={e => setNewOrigin(e.target.value)}
                className="input sm:max-w-[240px]"
              />
              <Btn type="submit" loading={busy === "asset-add"} className="sm:w-auto">Tambah domain</Btn>
            </form>

            {assets.length > 0 && (
              <div className="mb-4 flex flex-wrap items-center gap-2">
                <Segmented
                  options={[["all", "Semua"], ["verified", "Terverifikasi"], ["pending", "Menunggu"]] as ReadonlyArray<readonly ["all" | "verified" | "pending", string]>}
                  value={assetStatus}
                  onChange={setAssetStatus}
                  ariaLabel="Filter status domain"
                />
                <SearchInput value={assetQuery} onChange={setAssetQuery} placeholder="Cari domain / origin…" ariaLabel="Cari domain" className="w-52" />
                <ExportButton onClick={exportAssets} disabled={shownAssets.length === 0} title="Ekspor hasil filter ke CSV" />
              </div>
            )}

            {assets.length === 0 ? (
              <EmptyState
                icon="◈"
                title="Belum ada domain terlindungi"
                desc="Tambahkan domain publik yang Anda miliki, lalu verifikasi kepemilikan via record DNS TXT."
              />
            ) : shownAssets.length === 0 ? (
              <EmptyState icon="⌕" title="Tidak ada hasil" desc="Tidak ada domain yang cocok dengan filter atau pencarian." />
            ) : (
              <div className="grid gap-3">
                <AnimatePresence initial={false}>
                  {shownAssets.map(a => (
                    <motion.div
                      key={a.id}
                      layout
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8, height: 0 }}
                      transition={{ duration: 0.3, ease }}
                      className="rounded-xl border border-edge p-4 transition-colors hover:border-[#D4AF37]/50"
                    >
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="truncate font-semibold text-slate-900">{a.domain}</span>
                        <span className={`tag ${a.status === "verified" ? "tag-ok" : "tag-warn"}`}>
                          <span className={`dot ${a.status === "verified" ? "dot-ok" : "dot-warn"}`} />
                          {a.status === "verified" ? "Terverifikasi" : "Menunggu TXT"}
                        </span>
                      </div>
                      {a.originHost && (
                        <p className="mt-1.5 text-xs text-muted">
                          origin → <span className="mono text-slate-700">{a.originHost}{a.originPort ? `:${a.originPort}` : ""}</span>
                        </p>
                      )}
                      {a.status !== "verified" && (
                        <div className="mt-3 rounded-lg border border-edge bg-slate-100 p-3">
                          <p className="mb-2 text-xs text-muted">Tambahkan record DNS berikut, lalu tunggu propagasi:</p>
                          <div className="space-y-1.5">
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="w-20 shrink-0 text-xs text-muted">Tipe</span>
                              <code className="mono rounded bg-white px-2 py-1 text-slate-800">TXT</code>
                            </div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="w-20 shrink-0 text-xs text-muted">Nama/Host</span>
                              <code className="mono break-all rounded bg-white px-2 py-1 text-slate-800">{`_garudashield.${a.domain}`}</code>
                              <Copy text={`_garudashield.${a.domain}`} label="Salin nama" />
                            </div>
                            <div className="flex flex-wrap items-center gap-2">
                              <span className="w-20 shrink-0 text-xs text-muted">Nilai/Value</span>
                              <code className="mono break-all rounded bg-white px-2 py-1 text-slate-800">{`gs-verify=${a.verifyToken}`}</code>
                              <Copy text={`gs-verify=${a.verifyToken}`} label="Salin nilai" />
                            </div>
                          </div>
                          <p className="mt-2 text-[11px] leading-relaxed text-muted">
                            Isi kolom <strong>Nama/Host</strong> dan <strong>Nilai/Value</strong> secara terpisah — jangan menempel satu baris
                            penuh ke kolom nilai. Sebagian panel DNS menaruh TXT di domain induk; keduanya diterima selama token sama. Contoh:{" "}
                            <span className="mono">{a.domain}</span> TXT <span className="mono">{`gs-verify=${a.verifyToken}`}</span>.
                          </p>
                        </div>
                      )}
                      <div className="mt-3 flex flex-wrap gap-2">
                        <Btn variant="plain" onClick={() => setConfigAsset(a)}>
                          Atur proteksi
                        </Btn>
                        {a.status !== "verified" && (
                          <Btn variant="plain" loading={busy === `asset-verify-${a.id}`} onClick={() => verifyAsset(a.id)}>
                            Verifikasi
                          </Btn>
                        )}
                        <Btn
                          variant="plain"
                          loading={busy === `asset-del-${a.id}`}
                          onClick={() => deleteAsset(a.id)}
                          className="hover:!border-[#DC3545] hover:!text-[#B02A37]"
                        >
                          Hapus
                        </Btn>
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </motion.section>

          {/* Team members (RBAC) */}
          <motion.section variants={v.item} className="card mt-4 p-5">
            <SectionHead
              title="Anggota tim"
              hint={members.length ? `${members.length} pengguna · peran Anda ${role.toUpperCase() || "—"}` : undefined}
            />
            {isOwner && (
              <form onSubmit={addMember} className="mb-4 flex flex-col gap-2 sm:flex-row sm:flex-wrap sm:items-start">
                <input
                  type="email"
                  required
                  placeholder="email anggota"
                  value={newMemberEmail}
                  onChange={e => setNewMemberEmail(e.target.value)}
                  className="input sm:max-w-[240px]"
                />
                <PasswordInput
                  placeholder="password (min 12)"
                  value={newMemberPassword}
                  onChange={setNewMemberPassword}
                  required
                  minLength={12}
                  autoComplete="new-password"
                />
                <select
                  value={newMemberRole}
                  onChange={e => setNewMemberRole(e.target.value)}
                  aria-label="Peran anggota baru"
                  className="input sm:max-w-[140px]"
                >
                  <option value="viewer">Viewer</option>
                  <option value="admin">Admin</option>
                </select>
                <Btn type="submit" loading={busy === "member-add"} className="sm:w-auto">Tambah anggota</Btn>
              </form>
            )}
            {members.length === 0 ? (
              <EmptyState
                icon="◆"
                title="Belum ada anggota"
                desc={isOwner ? "Tambahkan rekan tim dengan peran admin atau viewer." : "Daftar anggota tenant akan tampil di sini."}
              />
            ) : (
              <div className="grid gap-2">
                <AnimatePresence initial={false}>
                  {members.map(m => (
                    <motion.div
                      key={m.id}
                      layout
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8, height: 0 }}
                      transition={{ duration: 0.3, ease }}
                      className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-edge px-4 py-3"
                    >
                      <div className="min-w-0">
                        <p className="truncate font-medium text-slate-900">{m.email}</p>
                        <p className="text-xs text-muted">
                          sejak {new Date(m.createdAt).toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" })}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`tag ${m.role === "owner" ? "tag-warn" : m.role === "admin" ? "tag-info" : "tag-muted"}`}>
                          {m.role.toUpperCase()}
                        </span>
                        {isOwner && (
                          <Btn
                            variant="plain"
                            loading={busy === `member-del-${m.id}`}
                            onClick={() => removeMember(m.id)}
                            className="hover:!border-[#DC3545] hover:!text-[#B02A37]"
                          >
                            Hapus
                          </Btn>
                        )}
                      </div>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </motion.section>

          {/* Audit history (read-only) */}
          <motion.section variants={v.item} className="card mt-4 p-5">
            <SectionHead
              title="Riwayat aktivitas"
              hint={auditEntries.length ? `${shownAudit.length} dari ${auditEntries.length} dimuat · ${auditTotal} total` : undefined}
            />
            <form onSubmit={reloadAudit} className="mb-4 flex flex-wrap items-start gap-2">
              <input
                placeholder="filter aksi (mis. member.add)"
                value={auditAction}
                onChange={e => setAuditAction(e.target.value)}
                className="input sm:max-w-[220px]"
              />
              <Btn type="submit" variant="plain" loading={busy === "audit"} className="sm:w-auto">Muat ulang</Btn>
              <SearchInput
                value={auditQuery}
                onChange={setAuditQuery}
                placeholder="Cari aksi / detail / aktor…"
                ariaLabel="Cari aktivitas"
                className="w-full sm:w-[240px]"
              />
              <ExportButton onClick={exportAudit} disabled={shownAudit.length === 0} title="Ekspor hasil filter ke CSV" />
            </form>
            {auditEntries.length === 0 ? (
              <EmptyState icon="≡" title="Belum ada aktivitas" desc="Tindakan akun, kunci, domain, dan anggota akan tercatat di sini." />
            ) : shownAudit.length === 0 ? (
              <EmptyState icon="⌕" title="Tidak ada hasil" desc="Tidak ada aktivitas yang cocok dengan pencarian." />
            ) : (
              <div className="grid gap-2">
                {shownAudit.map(e => (
                  <div key={e.id} className="flex flex-wrap items-start justify-between gap-2 rounded-xl border border-edge px-4 py-3">
                    <div className="min-w-0">
                      <p className="text-[13px] text-slate-900">
                        <span className="mono font-semibold">{e.action}</span>
                        {e.detail ? ` · ${e.detail}` : ""}
                      </p>
                      <p className="text-xs text-muted">
                        oleh {e.actor || "sistem"}
                        {e.ip ? ` · ${e.ip}` : ""}
                      </p>
                    </div>
                    <span className="whitespace-nowrap text-xs text-muted">
                      {new Date(e.at * 1000).toLocaleString("id-ID", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </motion.section>

          {/* Settings: password + MFA side by side on large screens */}
          <div className="mt-4 grid gap-4 lg:grid-cols-2">
            <motion.section variants={v.item} className="card p-5">
              <SectionHead title="Ubah password" />
              <form onSubmit={changePassword} className="grid gap-3">
                <PasswordInput placeholder="password saat ini" value={curPw} onChange={setCurPw} required autoComplete="current-password" />
                <PasswordInput placeholder="password baru (min 12)" value={newPw} onChange={setNewPw} required minLength={12} autoComplete="new-password" />
                <Btn type="submit" loading={busy === "pw"} className="justify-self-start">Perbarui password</Btn>
              </form>
            </motion.section>

            <motion.section variants={v.item} className="card p-5">
              <SectionHead title="Autentikasi dua langkah (TOTP)" />
              <AnimatePresence>
                {recovery.length > 0 && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="mb-4 overflow-hidden"
                  >
                    <div className="rounded-xl border border-[#D4AF37]/40 bg-[#D4AF37]/5 p-4">
                      <div className="mb-2 flex items-center justify-between gap-2">
                        <p className="text-[13px] font-semibold text-[#8A6D1F]">Recovery code (simpan offline, sekali tampil)</p>
                        <Copy text={recovery.join("\n")} label="Salin semua" />
                      </div>
                      <div className="grid grid-cols-2 gap-1.5 font-mono text-[13px] text-slate-800">
                        {recovery.map(c => <span key={c}>{c}</span>)}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {setup ? (
                <form onSubmit={mfaEnable} className="grid gap-3">
                  <p className="text-[13px] text-muted">Isi secret ini di aplikasi authenticator, lalu masukkan kode 6 digit.</p>
                  <div className="flex items-center gap-2">
                    <code className="mono flex-1 break-all rounded-lg bg-slate-100 px-3 py-2 text-slate-800">{setup.secret}</code>
                    <Copy text={setup.secret} />
                  </div>
                  <input
                    inputMode="numeric"
                    autoFocus
                    required
                    placeholder="kode 6 digit"
                    value={enableCode}
                    onChange={e => setEnableCode(e.target.value)}
                    className="input tracking-[0.3em] text-center"
                  />
                  <div className="flex flex-wrap gap-3">
                    <Btn type="submit" loading={busy === "mfa-enable"}>Aktifkan MFA</Btn>
                    <button type="button" onClick={() => setSetup(null)} className="btn">Batal</button>
                  </div>
                </form>
              ) : (
                <div className="grid gap-3">
                  <Btn variant="plain" loading={busy === "mfa-setup"} onClick={mfaSetup} className="justify-self-start">
                    Aktifkan / reset MFA
                  </Btn>
                  <form onSubmit={mfaDisable} className="flex flex-wrap items-start gap-2">
                    <input
                      inputMode="numeric"
                      required
                      placeholder="kode untuk matikan"
                      value={disableCode}
                      onChange={e => setDisableCode(e.target.value)}
                      className="input sm:max-w-[180px]"
                    />
                    <Btn type="submit" variant="plain" loading={busy === "mfa-disable"}>Matikan</Btn>
                  </form>
                </div>
              )}
            </motion.section>
          </div>

          <AnimatePresence>
            {configAsset && (
              <PolicyEditor
                key={configAsset.id}
                assetId={configAsset.id}
                domain={configAsset.domain}
                canEdit={isOwner || role === "admin"}
                onClose={() => setConfigAsset(null)}
                onSaved={() => {
                  refreshAssets();
                  toast("Pengaturan proteksi disimpan");
                }}
              />
            )}
          </AnimatePresence>

          <motion.p variants={v.item} className="mt-6 text-center text-xs text-muted">
            Lisensi berlaku hingga {licenseExp} · Dukungan via{" "}
            <a href="https://wa.me/6283187815456" target="_blank" rel="noreferrer" className="text-accent-ink hover:text-slate-900">WhatsApp</a>
          </motion.p>
        </motion.div>
      </Shell>
    );
  }

  const isRegister = mode === "register";
  return (
    <Shell>
      <motion.form
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={enter}
        onSubmit={isRegister ? register : login}
        className="card w-full max-w-sm p-8"
      >
        <ShieldMark />
        <h1 className="font-display text-xl font-semibold tracking-tight mb-1.5 mt-5">
          {isRegister ? "Daftar Akun Gratis" : "Masuk Portal"}
        </h1>
        <p className="text-[13px] text-muted mb-6">
          {isRegister
            ? "Buat akun untuk mulai melindungi domain Anda — paket Free otomatis aktif."
            : "Akses data tenant, lisensi, dan domain Anda."}
        </p>
        <input
          type="email"
          required
          autoComplete="email"
          placeholder="email@perusahaan.com"
          value={email}
          onChange={e => setEmail(e.target.value)}
          className="input mb-3"
        />
        {isRegister && (
          <input
            type="text"
            autoComplete="organization"
            placeholder="nama perusahaan / tim (opsional)"
            value={regName}
            onChange={e => setRegName(e.target.value)}
            className="input mb-3"
          />
        )}
        <PasswordInput
          placeholder={isRegister ? "password (min. 12 karakter)" : "password"}
          value={password}
          onChange={setPassword}
          required
          minLength={isRegister ? 12 : undefined}
          autoComplete={isRegister ? "new-password" : "current-password"}
          className="mb-4"
        />
        <AnimatePresence>
          {error && (
            <motion.p
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              role="alert"
              className="text-[13px] text-danger-ink mb-3"
            >
              {error}
            </motion.p>
          )}
        </AnimatePresence>
        <Btn type="submit" loading={busy === (isRegister ? "register" : "login")} className="w-full">
          {isRegister ? "Daftar Gratis" : "Masuk"}
        </Btn>
        {isRegister ? (
          <p className="mt-4 text-xs text-muted">
            Sudah punya akun?{" "}
            <button type="button" onClick={() => switchMode("login")} className="text-accent-ink hover:text-slate-900">
              Masuk di sini
            </button>
          </p>
        ) : (
          <>
            <div className="mt-4 flex items-center justify-between text-xs text-muted">
              <a href="/reset" className="text-accent-ink hover:text-slate-900">Lupa password?</a>
              <a href="/pricing" className="text-accent-ink hover:text-slate-900">Lihat paket</a>
            </div>
            <p className="mt-4 text-xs text-muted">
              {"Belum punya akun? "}
              <button type="button" onClick={() => switchMode("register")} className="text-accent-ink hover:text-slate-900">
                Daftar gratis
              </button>
              {" atau order paket via "}
              <a href="https://wa.me/6283187815456" className="text-accent-ink hover:text-slate-900" target="_blank" rel="noreferrer">WhatsApp</a>
            </p>
          </>
        )}
      </motion.form>
    </Shell>
  );
}

/* ---------- primitives ---------- */

function Shell({ children, wide }: { children: React.ReactNode; wide?: boolean }) {
  return (
    <main className={`min-h-screen bg-grid px-4 py-12 sm:px-6 sm:py-16 ${wide ? "" : "flex items-center justify-center"}`}>
      {children}
    </main>
  );
}

function ShieldMark() {
  return <Logo size={44} rounded="rounded-xl" />;
}

function Spinner() {
  return (
    <span
      className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent"
      aria-hidden="true"
    />
  );
}

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { loading?: boolean; variant?: "primary" | "plain" | "ghost" };

function Btn({ loading, variant = "primary", className = "", children, disabled, ...rest }: BtnProps) {
  const base = variant === "primary" ? "btn-primary" : variant === "ghost" ? "btn-ghost" : "btn";
  return (
    <button className={`${base} ${className}`} disabled={disabled || loading} aria-busy={loading || undefined} {...rest}>
      {loading && <Spinner />}
      {children}
    </button>
  );
}

function PasswordInput({
  value, onChange, placeholder, required, minLength, autoComplete, className = "",
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder?: string;
  required?: boolean;
  minLength?: number;
  autoComplete?: string;
  className?: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <div className={`relative ${className}`}>
      <input
        type={show ? "text" : "password"}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
        minLength={minLength}
        autoComplete={autoComplete}
        className="input pr-16"
      />
      <button
        type="button"
        onClick={() => setShow(s => !s)}
        tabIndex={-1}
        aria-label={show ? "Sembunyikan password" : "Tampilkan password"}
        className="absolute inset-y-0 right-1.5 my-auto h-7 rounded-md px-2 text-xs font-medium text-muted transition-colors hover:text-slate-900"
      >
        {show ? "Sembunyi" : "Lihat"}
      </button>
    </div>
  );
}

function Copy({ text, label = "Salin" }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  async function go() {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      /* clipboard unavailable (insecure context) — silent */
    }
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }
  return (
    <button
      type="button"
      onClick={go}
      className={`btn-ghost !px-2.5 !py-1 text-xs ${copied ? "!text-[#0B7A57]" : ""}`}
      aria-live="polite"
    >
      {copied ? "Tersalin" : label}
    </button>
  );
}

function SectionHead({ title, hint }: { title: string; hint?: string }) {
  return (
    <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
      <h2 className="font-display text-[15px] font-semibold text-slate-900">{title}</h2>
      {hint && <span className="text-xs text-muted">{hint}</span>}
    </div>
  );
}

function Stat({ title, value, tone = "default" }: { title: string; value: string; tone?: "default" | "accent" | "ok" | "warn" }) {
  const color =
    tone === "ok" ? "text-[#0B7A57]" : tone === "warn" ? "text-[#8A6D1F]" : tone === "accent" ? "text-[#0A192F]" : "text-slate-900";
  return (
    <div className="card card-hover flex flex-col gap-1.5 p-4">
      <span className="metric-label">{title}</span>
      <span className={`truncate font-display text-[15px] font-bold ${color}`}>{value}</span>
    </div>
  );
}

function SkeletonLines() {
  return (
    <div className="space-y-3">
      <div className="skeleton skeleton-title w-1/3" />
      <div className="skeleton skeleton-line w-full" />
      <div className="skeleton skeleton-line w-2/3" />
    </div>
  );
}

function EmptyState({ icon, title, desc }: { icon: string; title: string; desc: string }) {
  return (
    <div className="state">
      <span className="state-icon" aria-hidden="true">{icon}</span>
      <span className="state-title">{title}</span>
      <span className="state-desc">{desc}</span>
    </div>
  );
}

function Toasts({ toasts, reduced, onDismiss }: { toasts: Toast[]; reduced: boolean; onDismiss: (id: number) => void }) {
  return (
    <div className="fixed bottom-4 right-4 z-50 flex w-[min(92vw,360px)] flex-col gap-2" role="region" aria-label="Notifikasi">
      <AnimatePresence>
        {toasts.map(t => (
          <motion.button
            key={t.id}
            layout
            initial={{ opacity: 0, y: 16, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, x: 24 }}
            transition={reduced ? { duration: 0 } : { duration: 0.28, ease }}
            onClick={() => onDismiss(t.id)}
            className={`card flex items-start gap-2.5 p-3 text-left text-[13px] ${
              t.kind === "err" ? "border-[#DC3545]/45" : "border-[#20C997]/45"
            }`}
          >
            <span className={`dot mt-1.5 ${t.kind === "err" ? "dot-danger" : "dot-ok"}`} />
            <span className="text-slate-700">{t.msg}</span>
          </motion.button>
        ))}
      </AnimatePresence>
    </div>
  );
}
