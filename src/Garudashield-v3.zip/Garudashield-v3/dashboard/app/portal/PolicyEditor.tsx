"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";

export type WAFRule = { name: string; pattern: string; score: number };

type WAFPolicy = {
  enabled: boolean;
  sqli: boolean;
  xss: boolean;
  commandInjection: boolean;
  pathTraversal: boolean;
  lfi: boolean;
  rfi: boolean;
  shellshock: boolean;
  scanners: boolean;
  customRules: WAFRule[];
};

type RatePolicy = {
  globalMaxRPS: number | null;
  perIPRPS: number | null;
  perIPBurst: number | null;
  perPathRPS: number | null;
  connLimitPerIP: number | null;
  slidingWindowMs: number | null;
};

// DomainPolicy mirrors the engine's internal/policy.Policy JSON contract.
export type DomainPolicy = {
  mode?: string;
  budgetMs?: number;
  verifyOnFirstVisit?: boolean;
  waf?: Partial<WAFPolicy>;
  rateLimit?: Partial<Record<keyof RatePolicy, number>>;
  geo?: { blocklistCountries?: string[]; allowlistCountries?: string[] };
};

type NumericField = "perIPRPS" | "perIPBurst" | "perPathRPS" | "globalMaxRPS" | "connLimitPerIP" | "slidingWindowMs";

const numericFields: { key: NumericField; label: string; hint: string; step?: string }[] = [
  { key: "perIPRPS", label: "Batas RPS per IP", hint: "permintaan/detik per alamat IP" },
  { key: "perIPBurst", label: "Burst per IP", hint: "lonjakan sesaat yang ditoleransi" },
  { key: "perPathRPS", label: "Batas RPS per path", hint: "per permintaan/detik per URL" },
  { key: "globalMaxRPS", label: "RPS global", hint: "plafon seluruh trafik domain" },
  { key: "connLimitPerIP", label: "Batas koneksi per IP", hint: "koneksi bersamaan" },
  { key: "slidingWindowMs", label: "Jendela geser (ms)", hint: "panjang jendela penghitungan" },
];

const wafModules: { key: keyof Omit<WAFPolicy, "enabled" | "customRules">; label: string }[] = [
  { key: "sqli", label: "SQL Injection" },
  { key: "xss", label: "Cross-site Scripting" },
  { key: "commandInjection", label: "Command Injection" },
  { key: "pathTraversal", label: "Path Traversal" },
  { key: "lfi", label: "Local File Inclusion" },
  { key: "rfi", label: "Remote File Inclusion" },
  { key: "shellshock", label: "Shellshock" },
  { key: "scanners", label: "Scanner / Recon" },
];

function splitCC(s: string): string[] {
  return s
    .split(/[\s,]+/)
    .map(x => x.trim().toUpperCase())
    .filter(Boolean);
}

export default function PolicyEditor({
  assetId,
  domain,
  canEdit,
  onClose,
  onSaved,
}: {
  assetId: number;
  domain: string;
  canEdit: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const reduced = useReducedMotion();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [clearing, setClearing] = useState(false);
  const [err, setErr] = useState("");
  const [enforced, setEnforced] = useState(false);

  const [mode, setMode] = useState("");
  const [budgetMs, setBudgetMs] = useState("");
  const [verify, setVerify] = useState(false);
  const [wafOn, setWafOn] = useState(false);
  const [mods, setMods] = useState<Record<string, boolean>>({});
  const [rules, setRules] = useState<WAFRule[]>([]);
  const [rate, setRate] = useState<Record<NumericField, string>>({
    perIPRPS: "", perIPBurst: "", perPathRPS: "", globalMaxRPS: "", connLimitPerIP: "", slidingWindowMs: "",
  });
  const [blockCC, setBlockCC] = useState("");
  const [allowCC, setAllowCC] = useState("");

  useEffect(() => {
    let live = true;
    (async () => {
      try {
        const r = await fetch(`/api/gs/v1/assets/${assetId}/policy`, { credentials: "include" });
        if (r.ok) {
          const body = await r.json();
          const p: DomainPolicy = body.policy || {};
          if (!live) return;
          setEnforced(!!body.enforced);
          if (p.mode) setMode(p.mode);
          if (typeof p.budgetMs === "number") setBudgetMs(String(p.budgetMs));
          setVerify(!!p.verifyOnFirstVisit);
          if (p.waf) {
            setWafOn(!!p.waf.enabled);
            const m: Record<string, boolean> = {};
            wafModules.forEach(x => (m[x.key] = !!p.waf![x.key]));
            setMods(m);
            setRules(Array.isArray(p.waf.customRules) ? p.waf.customRules : []);
          }
          if (p.rateLimit) {
            const next = { ...rate };
            numericFields.forEach(f => {
              const val = p.rateLimit![f.key];
              next[f.key] = typeof val === "number" ? String(val) : "";
            });
            setRate(next);
          }
          if (p.geo) {
            setBlockCC((p.geo.blocklistCountries || []).join(", "));
            setAllowCC((p.geo.allowlistCountries || []).join(", "));
          }
        }
      } catch {
        /* leave defaults */
      } finally {
        if (live) setLoading(false);
      }
    })();
    return () => {
      live = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [assetId]);

  function buildPolicy(): DomainPolicy {
    const rl: Partial<Record<NumericField, number>> = {};
    numericFields.forEach(f => {
      const raw = rate[f.key].trim();
      if (raw !== "") rl[f.key] = Number(raw);
    });
    const custom: WAFRule[] = rules
      .map(r => ({ name: r.name.trim(), pattern: r.pattern.trim(), score: Number(r.score) || 0 }))
      .filter(r => r.pattern !== "");
    const waf: WAFPolicy = {
      enabled: wafOn,
      sqli: !!mods.sqli,
      xss: !!mods.xss,
      commandInjection: !!mods.commandInjection,
      pathTraversal: !!mods.pathTraversal,
      lfi: !!mods.lfi,
      rfi: !!mods.rfi,
      shellshock: !!mods.shellshock,
      scanners: !!mods.scanners,
      customRules: custom,
    };
    const p: DomainPolicy = { waf, rateLimit: rl };
    if (mode) p.mode = mode;
    const b = budgetMs.trim();
    if (b !== "") p.budgetMs = Number(b);
    if (verify) p.verifyOnFirstVisit = true;
    const bCC = splitCC(blockCC);
    const aCC = splitCC(allowCC);
    if (bCC.length || aCC.length) p.geo = { blocklistCountries: bCC, allowlistCountries: aCC };
    return p;
  }

  async function save() {
    setErr("");
    setSaving(true);
    try {
      const r = await fetch(`/api/gs/v1/assets/${assetId}/policy`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify(buildPolicy()),
      });
      if (!r.ok) {
        const b = await r.json().catch(() => ({}));
        setErr(b.error || "Gagal menyimpan");
        return;
      }
      onSaved();
      onClose();
    } catch {
      setErr("Gagal menyimpan");
    } finally {
      setSaving(false);
    }
  }

  async function resetGlobal() {
    setErr("");
    setClearing(true);
    try {
      const r = await fetch(`/api/gs/v1/assets/${assetId}/policy`, { method: "DELETE", credentials: "include" });
      if (!r.ok) {
        setErr("Gagal mengembalikan ke default");
        return;
      }
      onSaved();
      onClose();
    } catch {
      setErr("Gagal mengembalikan ke default");
    } finally {
      setClearing(false);
    }
  }

  // One-click protection presets. Each fills the posture, browser verification,
  // WAF modules and per-IP rate ceilings; the operator still reviews and saves.
  function applyPreset(name: "normal" | "aggressive" | "lockdown" | "emergency") {
    const allMods: Record<string, boolean> = {};
    wafModules.forEach(x => (allMods[x.key] = true));
    const clearRate: Record<NumericField, string> = {
      perIPRPS: "", perIPBurst: "", perPathRPS: "", globalMaxRPS: "", connLimitPerIP: "", slidingWindowMs: "",
    };
    setWafOn(true);
    setMods(allMods);
    switch (name) {
      case "normal":
        setMode("auto");
        setVerify(false);
        setRate(clearRate);
        break;
      case "aggressive":
        setMode("aggressive");
        setVerify(true);
        setRate({ ...clearRate, perIPRPS: "30", perIPBurst: "60", connLimitPerIP: "15" });
        break;
      case "lockdown":
        setMode("aggressive");
        setVerify(true);
        setRate({ ...clearRate, perIPRPS: "10", perIPBurst: "20", connLimitPerIP: "8" });
        break;
      case "emergency":
        setMode("emergency");
        setVerify(true);
        setRate({ ...clearRate, perIPRPS: "5", perIPBurst: "10", connLimitPerIP: "5" });
        break;
    }
  }

  const presets: { key: "normal" | "aggressive" | "lockdown" | "emergency"; label: string; hint: string }[] = [
    { key: "normal", label: "Normal", hint: "WAF penuh, tanpa pembatasan tambahan" },
    { key: "aggressive", label: "Agresif", hint: "verifikasi browser + rate ketat" },
    { key: "lockdown", label: "Lockdown", hint: "hanya pengunjung terverifikasi" },
    { key: "emergency", label: "Darurat", hint: "blok semua non-whitelist" },
  ];


  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/50 p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true">
      <motion.div
        initial={reduced ? {} : { opacity: 0, y: 24 }}
        animate={reduced ? {} : { opacity: 1, y: 0 }}
        className="flex max-h-[92vh] w-full max-w-2xl flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl"
      >
        <div className="flex items-start justify-between gap-3 border-b border-edge px-5 py-4">
          <div className="min-w-0">
            <h3 className="truncate font-display text-lg font-bold text-navy">Pengaturan proteksi</h3>
            <p className="truncate text-xs text-muted">
              <span className="mono">{domain}</span>
              {enforced ? " · aktif di edge" : " · menunggu verifikasi domain"}
            </p>
          </div>
          <button onClick={onClose} className="btn-ghost shrink-0 px-2 py-1" aria-label="Tutup">✕</button>
        </div>

        <div className="min-h-0 flex-1 overflow-y-auto px-5 py-4">
          {loading ? (
            <p className="py-10 text-center text-sm text-muted">Memuat…</p>
          ) : (
            <fieldset disabled={!canEdit} className="space-y-6">
              {/* Quick presets */}
              <div className="rounded-xl border border-edge bg-slate-50 p-3">
                <p className="mb-2 text-xs font-semibold text-navy">Preset proteksi cepat</p>
                <div className="flex flex-wrap gap-2">
                  {presets.map(pr => (
                    <button
                      key={pr.key}
                      type="button"
                      onClick={() => applyPreset(pr.key)}
                      title={pr.hint}
                      className={`btn-ghost text-xs ${pr.key === "emergency" ? "text-danger-ink" : ""}`}
                    >
                      {pr.label}
                    </button>
                  ))}
                </div>
                <p className="mt-2 text-[11px] text-muted">Preset mengisi postur, WAF, dan batas laju. Tinjau lalu Simpan.</p>
              </div>

              {/* Mode & budget */}
              <div>
                <h4 className="text-sm font-semibold text-navy">Mode</h4>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="text-xs text-muted">
                    Postur
                    <select value={mode} onChange={e => setMode(e.target.value)} className="input mt-1">
                      <option value="">Ikut global</option>
                      <option value="auto">Auto (normal)</option>
                      <option value="aggressive">Agresif</option>
                      <option value="emergency">Darurat (blok semua)</option>
                    </select>
                  </label>
                  <label className="text-xs text-muted">
                    Anggaran evaluasi (ms)
                    <input inputMode="numeric" value={budgetMs} onChange={e => setBudgetMs(e.target.value)} className="input mt-1" placeholder="ikut global" />
                  </label>
                </div>
                <label className="mt-3 flex items-center gap-2 text-xs text-muted">
                  <input type="checkbox" checked={verify} onChange={e => setVerify(e.target.checked)} />
                  Verifikasi browser pada kunjungan pertama
                </label>
              </div>

              {/* WAF */}
              <div>
                <div className="flex items-center justify-between">
                  <h4 className="text-sm font-semibold text-navy">WAF</h4>
                  <label className="flex items-center gap-2 text-xs text-muted">
                    <input type="checkbox" checked={wafOn} onChange={e => setWafOn(e.target.checked)} />
                    Aktif
                  </label>
                </div>
                <div className="mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3">
                  {wafModules.map(m => (
                    <label key={m.key} className="flex items-center gap-2 text-xs text-slate-700">
                      <input type="checkbox" checked={!!mods[m.key]} onChange={e => setMods(s => ({ ...s, [m.key]: e.target.checked }))} disabled={!wafOn} />
                      {m.label}
                    </label>
                  ))}
                </div>

                <div className="mt-3">
                  <p className="mb-1 text-xs text-muted">Aturan kustom</p>
                  <AnimatePresence initial={false}>
                    {rules.map((r, i) => (
                      <motion.div
                        key={i}
                        initial={reduced ? {} : { opacity: 0, height: 0 }}
                        animate={reduced ? {} : { opacity: 1, height: "auto" }}
                        exit={reduced ? {} : { opacity: 0, height: 0 }}
                        className="mb-2 flex flex-col gap-2 sm:flex-row sm:items-center"
                      >
                        <input
                          value={r.name}
                          onChange={e => setRules(s => s.map((x, j) => (j === i ? { ...x, name: e.target.value } : x)))}
                          className="input sm:max-w-[180px]"
                          placeholder="nama"
                        />
                        <input
                          value={r.pattern}
                          onChange={e => setRules(s => s.map((x, j) => (j === i ? { ...x, pattern: e.target.value } : x)))}
                          className="input mono flex-1"
                          placeholder="pola regex"
                        />
                        <input
                          inputMode="numeric"
                          value={String(r.score)}
                          onChange={e => setRules(s => s.map((x, j) => (j === i ? { ...x, score: Number(e.target.value) || 0 } : x)))}
                          className="input w-20"
                          placeholder="skor"
                        />
                        <button
                          type="button"
                          onClick={() => setRules(s => s.filter((_, j) => j !== i))}
                          className="btn-ghost px-2 py-1 text-danger-ink"
                          aria-label="Hapus aturan"
                        >
                          ✕
                        </button>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                  <button type="button" onClick={() => setRules(s => [...s, { name: "", pattern: "", score: 30 }])} className="btn-ghost text-xs" disabled={!wafOn}>
                    + Tambah aturan
                  </button>
                </div>
              </div>

              {/* Rate limit */}
              <div>
                <h4 className="text-sm font-semibold text-navy">Batas laju (rate limit)</h4>
                <div className="mt-2 grid gap-3 sm:grid-cols-3">
                  {numericFields.map(f => (
                    <label key={f.key} className="text-xs text-muted">
                      {f.label}
                      <input inputMode="decimal" value={rate[f.key]} onChange={e => setRate(s => ({ ...s, [f.key]: e.target.value }))} className="input mt-1" placeholder="ikut global" />
                      <span className="mt-0.5 block text-[10px] text-slate-400">{f.hint}</span>
                    </label>
                  ))}
                </div>
              </div>

              {/* Geo */}
              <div>
                <h4 className="text-sm font-semibold text-navy">Negara (GeoIP)</h4>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="text-xs text-muted">
                    Blokir (ISO-2, pisahkan koma)
                    <input value={blockCC} onChange={e => setBlockCC(e.target.value)} className="input mt-1 mono" placeholder="mis. CN, RU" />
                  </label>
                  <label className="text-xs text-muted">
                    Izinkan saja (kosong = semua)
                    <input value={allowCC} onChange={e => setAllowCC(e.target.value)} className="input mt-1" placeholder="mis. ID, SG" />
                  </label>
                </div>
                <p className="mt-1 text-[11px] text-muted">Bila daftar izin terisi, hanya negara tersebut yang boleh masuk.</p>
              </div>

              {err && <p className="text-xs text-danger-ink">{err}</p>}
              {!canEdit && <p className="text-xs text-muted">Hanya admin atau owner yang dapat mengubah pengaturan ini.</p>}
            </fieldset>
          )}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-2 border-t border-edge bg-slate-50 px-5 py-3">
          <button onClick={resetGlobal} disabled={!canEdit || clearing || loading} className="btn-ghost text-xs">
            {clearing ? "…" : "Kembalikan ke global"}
          </button>
          <div className="flex gap-2">
            <button onClick={onClose} className="btn-ghost">Batal</button>
            <button onClick={save} disabled={!canEdit || saving || loading} className="btn-primary">
              {saving ? "Menyimpan…" : "Simpan"}
            </button>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
