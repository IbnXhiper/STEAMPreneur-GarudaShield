"use client";

import { useEffect, useRef, useState } from "react";

type Msg = { role: "user" | "bot"; text: string; chips?: string[] };

function renderInline(s: string, keyBase: string) {
  const parts = s.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((p, i) => {
    if (p.startsWith("**") && p.endsWith("**")) {
      return (
        <strong key={`${keyBase}-${i}`} className="font-semibold text-slate-900">
          {p.slice(2, -2)}
        </strong>
      );
    }
    return <span key={`${keyBase}-${i}`}>{p}</span>;
  });
}

function Answer({ text, keyBase }: { text: string; keyBase: string }) {
  const blocks = text.split(/```/g);
  return (
    <div className="text-sm leading-relaxed text-muted space-y-2">
      {blocks.map((b, i) => {
        if (i % 2 === 1) {
          return (
            <pre key={`${keyBase}-c${i}`} className="overflow-auto rounded-lg border border-edge bg-slate-50 p-3 text-xs text-slate-800">
              <code>{b.replace(/^\n/, "")}</code>
            </pre>
          );
        }
        const lines = b.split("\n").filter((l) => l.length > 0);
        return (
          <div key={`${keyBase}-t${i}`} className="space-y-1.5">
            {lines.map((l, j) => {
              if (l.startsWith("- ")) {
                return (
                  <div key={`${keyBase}-l${i}-${j}`} className="flex gap-2">
                    <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-ok animate-pulse-ring" />
                    <span>{renderInline(l.slice(2), `${keyBase}-li${i}-${j}`)}</span>
                  </div>
                );
              }
              return <p key={`${keyBase}-p${i}-${j}`}>{renderInline(l, `${keyBase}-p${i}-${j}`)}</p>;
            })}
          </div>
        );
      })}
    </div>
  );
}

const SUGGESTIONS = [
  "Apa itu GarudaShield?",
  "Bagaimana cara memasang?",
  "Berapa harganya?",
  "Apa itu WAF?",
];

export default function ChatPage() {
  const [msgs, setMsgs] = useState<Msg[]>([
    {
      role: "bot",
      text:
        "Halo! Saya **asisten GarudaShield** berbasis knowledge base (bukan LLM eksternal). Tanyakan seputar fitur, harga, setup, WAF, cluster sync, atau webhook.",
      chips: SUGGESTIONS,
    },
  ]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [msgs, busy]);

  async function send(text: string) {
    const q = text.trim();
    if (!q || busy) return;
    setInput("");
    setBusy(true);
    setMsgs((m) => [...m, { role: "user", text: q }]);
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: q }),
      });
      const d = await r.json();
      setMsgs((m) => [...m, { role: "bot", text: d.answer, chips: d.chips || [] }]);
    } catch {
      setMsgs((m) => [
        ...m,
        { role: "bot", text: "Maaf, asisten sedang tidak reachable. Coba lagi nanti atau hubungi tim via WhatsApp +62 831-8781-5456." },
      ]);
    } finally {
      setBusy(false);
      inputRef.current?.focus();
    }
  }

  return (
    <div className="bg-grid min-h-[86vh]">
      <section className="container-x pt-10 pb-14">
        <div className="mx-auto max-w-4xl">
          <div className="mb-6 flex items-center gap-3">
            <span className="gs-gradient grid h-11 w-11 place-items-center rounded-xl text-white text-lg font-display font-bold shadow-glow">AI</span>
            <div>
              <div className="eyebrow">AI Garuda</div>
              <h1 className="font-display text-2xl md:text-3xl font-bold tracking-tight leading-tight">
                Tanya jawab <span className="text-gradient">GarudaShield.</span>
              </h1>
            </div>
          </div>

          {/* Chat surface renders unconditionally — no scroll/viewport gate, so
              the box is always present even before any reveal animation runs. */}
          <div className="card flex h-[70vh] min-h-[560px] flex-col p-0 overflow-hidden">
            <div className="flex items-center justify-between border-b border-edge px-4 py-2.5">
              <span className="flex items-center gap-2 text-xs text-muted">
                <span className="h-2 w-2 rounded-full bg-ok animate-pulse-ring" /> Knowledge base · cepat &amp; privat
              </span>
              <span className="text-[11px] text-muted/70">tanpa LLM eksternal</span>
            </div>

            <div ref={scrollRef} className="flex-1 overflow-auto space-y-4 p-4">
              {msgs.map((m, i) => (
                <div key={i} className={m.role === "user" ? "flex justify-end" : "flex justify-start gap-2.5"}>
                  {m.role === "bot" && (
                    <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-accent/10 text-[11px] font-bold text-accent-ink">AI</span>
                  )}
                  <div
                    className={`max-w-[85%] rounded-2xl px-4 py-3 ${
                      m.role === "user"
                        ? "bg-accent text-ink rounded-br-sm"
                        : "bg-white border border-edge rounded-bl-sm"
                    }`}
                  >
                    {m.role === "user" ? (
                      <p className="text-sm">{m.text}</p>
                    ) : (
                      <Answer text={m.text} keyBase={`m${i}`} />
                    )}
                    {m.chips && m.chips.length > 0 && (
                      <div className="mt-3 flex flex-wrap gap-2">
                        {m.chips.map((c) => (
                          <button
                            key={c}
                            onClick={() => send(c)}
                            className="rounded-full border border-edge bg-white px-3 py-1 text-xs text-muted hover:text-slate-900 hover:border-accent transition"
                          >
                            {c}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ))}
              {busy && (
                <div className="flex justify-start gap-2.5">
                  <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-accent/10 text-[11px] font-bold text-accent-ink">AI</span>
                  <div className="rounded-2xl rounded-bl-sm border border-edge bg-white px-4 py-3 text-sm">
                    Mengetik…
                  </div>
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                send(input);
              }}
              className="flex gap-2 border-t border-edge p-3"
            >
              <input
                ref={inputRef}
                className="input"
                placeholder="Tulis pertanyaan… mis. berapa kapasitas mitigasi?"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                disabled={busy}
                aria-label="Pertanyaan untuk AI Garuda"
              />
              <button className="btn-primary shrink-0" disabled={busy || !input.trim()}>
                Kirim
              </button>
            </form>
          </div>

          <p className="mt-3 text-center text-xs text-muted">
            Jawaban berasal dari basis pengetahuan internal GarudaShield. Untuk konsultasi teknis:{" "}
            <a className="text-accent-ink hover:underline" href="https://wa.me/6283187815456" target="_blank" rel="noreferrer">WhatsApp tim</a>.
          </p>
        </div>
      </section>
    </div>
  );
}
