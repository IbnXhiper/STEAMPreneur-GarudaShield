"use client";

/**
 * Route-level error boundary. Keeps a rendering failure inside one route
 * instead of a blank page, and never leaks internals: only the digest that
 * Next.js hands us is shown.
 */
export default function RouteError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <main className="flex min-h-screen items-center justify-center bg-grid px-5">
      <div className="panel w-full max-w-md p-0">
        <div className="state state-error">
          <span className="state-icon" aria-hidden="true">!</span>
          <span className="state-title">Something went wrong in this view</span>
          <span className="state-desc">
            The page failed to render. Protection keeps running on the edge — this only affects the dashboard view. Retry, or go back to the overview.
          </span>
          {error.digest ? <span className="state-desc mono text-[11px] opacity-70">ref: {error.digest}</span> : null}
          <div className="mt-2 flex flex-wrap justify-center gap-2">
            <button className="btn" onClick={reset}>Retry</button>
            <a className="btn-ghost" href="/dash">Back to overview</a>
          </div>
        </div>
      </div>
    </main>
  );
}