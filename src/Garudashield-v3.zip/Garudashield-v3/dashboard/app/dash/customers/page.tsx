"use client";

import { useState } from "react";
import Link from "next/link";

// Operator page: after a WhatsApp order is confirmed, the admin onboards the
// customer here. Two delivery modes:
//   1. managed  — customer's domain is served through OUR edge; license lives
//                 in our Postgres; edge gate activates immediately.
//   2. selfhost — customer runs the engine on their own server; we hand them
//                 the signed license key + install instructions via WhatsApp.
// Auth: the admin key (gs_key cookie from /login) is forwarded by /api/gs proxy.

type Result = {
  tenant: string;
  plan: string;
  domain: string;
  owner: string;
  password: string;
  licenseKey?: string;
  expiresAt?: number;
  mode: "managed" | "selfhost";
};

export default function CustomersPage() {
  const [mode, setMode] = useState<"managed" | "selfhost">("managed");
  const [tenant, setTenant] = useState("");
  const [name, setName] = useState("");
  const [domain, setDomain] = useState("");
  const [plan, setPlan] = useState("pro");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [months, setMonths] = useState(1);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState<Result | null>(null);

  function genPassword() {
    const chars = "abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789";
    let out = "";
    const buf = new Uint32Array(20);
    crypto.getRandomValues(buf);
    for (const v of buf) out += chars[v % chars.length];
    setPassword(out);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setResult(null);
    setBusy(true);
    try {
      const on = await fetch("/api/gs/admin/tenant/onboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ tenant, name, domain, plan, email, password }),
      });
      if (on.status === 409) throw new Error("Tenant/email sudah ada (409).");
      if (on.status === 403) throw new Error("Admin key salah — login ulang di /login.");
      if (!on.ok) throw new Error("Onboard gagal: HTTP " + on.status);

      let licenseKey: string | undefined;
      let expiresAt: number | undefined;
      if (plan !== "free") {
        const li = await fetch("/api/gs/admin/license/issue", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ tenant, plan, months }),
        });
        if (!li.ok) throw new Error("Tenant dibuat, tapi issue license gagal: HTTP " + li.status);
        const data = await li.json();
        licenseKey = data.licenseKey;
        expiresAt = data.expiresAt;
      }
      setResult({ tenant, plan, domain, owner: email, password, licenseKey, expiresAt, mode });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Gagal.");
    } finally {
      setBusy(false);
    }
  }

  function waReply(r: Result): string {
    const exp = r.expiresAt ? new Date(r.expiresAt * 1000).toLocaleDateString("id-ID") : "-";
    if (r.mode === "selfhost") {
      return [
        `Halo, order GarudaShield ${r.plan.toUpperCase()} (self-hosted) sudah aktif.`,
        ``,
        `License key:`,
        `${r.licenseKey ?? "(free — tanpa key)"}`,
        `Berlaku sampai: ${exp}`,
        ``,
        `Cara pasang: jalankan engine GarudaShield di server Anda, set`,
        `GS_LICENSE_KEY di .env, lalu restart. Panduan lengkap kami kirim terpisah.`,
        ``,
        `Login portal: https://SITUS-ANDA/portal`,
        `Email: ${r.owner}`,
        `Password sementara: ${r.password} (segera ganti)`,
      ].join("\n");
    }
    return [
      `Halo, order GarudaShield ${r.plan.toUpperCase()} (managed) sudah aktif.`,
      ``,
      `Domain ${r.domain} sudah terdaftar di edge kami.`,
      `Arahkan DNS A/CNAME domain Anda ke edge GarudaShield, setelah itu`,
      `traffic otomatis terlindungi. Berlaku sampai: ${exp}`,
      ``,
      `Login portal: https://SITUS-ANDA/portal`,
      `Email: ${r.owner}`,
      `Password sementara: ${r.password} (segera ganti)`,
    ].join("\n");
  }

  return (
    <div className="container-x py-10 max-w-2xl">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold">Tambah Pelanggan (Order WhatsApp)</h1>
        <Link href="/dash" className="btn-ghost text-sm">← Dashboard</Link>
      </div>

      <div className="card space-y-4">
        <div className="flex gap-2">
          <button type="button" onClick={() => setMode("managed")}
            className={mode === "managed" ? "btn-primary" : "btn-ghost"}>
            Cara 1 — Managed SaaS
          </button>
          <button type="button" onClick={() => setMode("selfhost")}
            className={mode === "selfhost" ? "btn-primary" : "btn-ghost"}>
            Cara 2 — Self-hosted License
          </button>
        </div>
        <p className="text-sm text-muted">
          {mode === "managed"
            ? "Domain pelanggan dilayani lewat edge kita. Setelah dibuat, tenant langsung aktif di edge; pelanggan tinggal arahkan DNS."
            : "Pelanggan menjalankan engine di server sendiri. Setelah dibuat, salin license key dan kirim ke pelanggan via WhatsApp."}
        </p>

        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <input className="input" required placeholder="tenant-id (mis. acme)" value={tenant}
              onChange={(e) => setTenant(e.target.value.toLowerCase())} pattern="[a-z0-9][a-z0-9-]{1,62}" />
            <input className="input" required placeholder="Nama perusahaan" value={name}
              onChange={(e) => setName(e.target.value)} />
          </div>
          <input className="input" required placeholder="domain (mis. acme.co.id)" value={domain}
            onChange={(e) => setDomain(e.target.value.toLowerCase())} />
          <div className="grid grid-cols-2 gap-3">
            <select className="input" value={plan} onChange={(e) => setPlan(e.target.value)}>
              <option value="free">free</option>
              <option value="pro">pro</option>
              <option value="enterprise">enterprise</option>
            </select>
            <select className="input" value={months} disabled={plan === "free"}
              onChange={(e) => setMonths(Number(e.target.value))}>
              {[1, 3, 6, 12, 24].map((m) => <option key={m} value={m}>{m} bulan</option>)}
            </select>
          </div>
          <input className="input" required type="email" placeholder="email owner" value={email}
            onChange={(e) => setEmail(e.target.value.toLowerCase())} />
          <div className="flex gap-2">
            <input className="input flex-1" required minLength={12} placeholder="password sementara (min 12)"
              value={password} onChange={(e) => setPassword(e.target.value)} />
            <button type="button" className="btn-ghost" onClick={genPassword}>Generate</button>
          </div>
          {error && <p className="text-danger-ink text-sm">{error}</p>}
          <button className="btn-primary w-full" disabled={busy}>
            {busy ? "Memproses…" : "Buat tenant" + (plan !== "free" ? " + terbitkan lisensi" : "")}
          </button>
        </form>
      </div>

      {result && (
        <div className="card mt-6 space-y-3">
          <h2 className="font-display font-semibold">
            Aktif: {result.tenant} ({result.plan}, {result.mode === "managed" ? "Managed" : "Self-hosted"})
          </h2>
          {result.licenseKey && (
            <div>
              <p className="text-xs text-muted mb-1">License key (simpan — hanya tampil sekali di sini):</p>
              <code className="block break-all rounded bg-panel p-3 text-xs">{result.licenseKey}</code>
            </div>
          )}
          <div>
            <p className="text-xs text-muted mb-1">Balasan WhatsApp siap kirim:</p>
            <textarea readOnly className="input h-52 text-xs" value={waReply(result)} />
          </div>
          <button type="button" className="btn-ghost"
            onClick={() => navigator.clipboard.writeText(waReply(result))}>
            Salin balasan WA
          </button>
        </div>
      )}
    </div>
  );
}
