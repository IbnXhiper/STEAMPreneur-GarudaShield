"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import { gsGet, gsPost, gsDelete } from "@/lib/api";
import { csvFilename, downloadCsv } from "@/lib/csv";
import { filterRows } from "@/lib/search";
import AnimatedNumber from "@/components/AnimatedNumber";
import { Icon, type IconName } from "@/components/Icons";
import Logo from "@/components/Logo";
import {
  DataTable,
  EmptyState,
  ErrorState,
  ExportButton,
  KeyValue,
  MetricCard,
  MetricGrid,
  Note,
  Panel,
  SearchInput,
  SectionTitle,
  Segmented,
  SkeletonBlock,
  SkeletonCards,
  StateLine,
  Stack,
  StatusDot,
  TableBox,
  Tag,
  Tone,
  usePoller,
} from "@/components/ui";

type Stats = any;
type Sample = { rps: number; bps: number };
type NodeRow = {
  id: string;
  address?: string;
  role?: string;
  site?: string;
  required: boolean;
  self: boolean;
  state: "online" | "offline" | "unknown";
  ageMs: number;
  note?: string;
};
type ClusterInfo = {
  enabled: boolean;
  nodeId: string;
  connected: boolean;
  mode: "single" | "cluster";
  role?: string;
  site?: string;
  expectedNodes: number;
  onlineNodes: number;
  requiredOffline: number;
  state: "online" | "degraded" | "partial";
  degraded: boolean;
  subscribed: boolean;
  reconnects: number;
  heartbeatMs: number;
  lastSentMs: number;
  lastSyncMs: number;
  lastSeenMs: number;
  appliedOps: number;
  lastError?: string;
  nodes: NodeRow[];
};

const NAV_GROUPS = [
  {
    label: "Monitor",
    items: [
      ["Overview", "overview"],
      ["Traffic", "traffic"],
      ["Charts", "charts"],
      ["Geo Map", "geo"],
      ["Top", "top"],
      ["Logs", "logs"],
      ["Proxy Fleet", "proxy"],
    ],
  },
  {
    label: "Threats",
    items: [
      ["Blocklist", "blocklist"],
      ["Whitelist", "whitelist"],
      ["Reputation", "reputation"],
    ],
  },
  {
    label: "Protection",
    items: [
      ["WAF Rules", "waf"],
      ["Rate Limit", "ratelimit"],
      ["Protect", "protect"],
      ["Cluster", "cluster"],
      ["Alerts", "alerts"],
      ["Settings", "settings"],
    ],
  },
] as const satisfies ReadonlyArray<{ label: string; items: ReadonlyArray<readonly [string, IconName]> }>;
type Tab = (typeof NAV_GROUPS)[number]["items"][number][0];

/* Flat tab order powers keyboard navigation, the command palette and URL
   deep-linking, so every way of reaching a section agrees on the same order. */
const TABS = NAV_GROUPS.flatMap((g) => g.items.map((i) => i[0])) as Tab[];

/* A tab becomes a stable, human-readable URL fragment ("WAF Rules" -> "waf-rules")
   so a tab can be bookmarked, shared and restored on reload. */
function tabSlug(t: string) {
  return t.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function tabFromSlug(slug: string): Tab | undefined {
  return TABS.find((t) => tabSlug(t) === slug);
}

/* Node topology drives the sidebar + topbar chips so node status is visible
   from every tab, not buried in one panel. Polled once at the shell level. */
function useCluster(intervalMs = 5000) {
  return usePoller<ClusterInfo>(() => gsGet("cluster") as Promise<ClusterInfo>, intervalMs);
}

export default function Dash() {
  const [tab, setTab] = useState<Tab>("Overview");
  const [stats, setStats] = useState<Stats | null>(null);
  const [history, setHistory] = useState<Sample[]>([]);
  const [navOpen, setNavOpen] = useState(false);
  const [connected, setConnected] = useState(false);
  const [paletteOpen, setPaletteOpen] = useState(false);
  const railRef = useRef<HTMLElement>(null);
  const firstTabEffect = useRef(true);
  const [liveError, setLiveError] = useState("");
  const cluster = useCluster();
  const reduced = useReducedMotion();

  useEffect(() => {
    let active = true;
    const refresh = async () => {
      try {
        const data = await gsGet("stats");
        if (active) {
          setStats(data);
          setHistory((prev) => [...prev, { rps: Number(data.currentRps || 0), bps: Number(data.bandwidthBps || 0) }].slice(-60));
          setConnected(true);
          setLiveError("");
        }
      } catch (e: any) {
        if (active) {
          setConnected(false);
          setLiveError(String(e?.message || e));
        }
      }
    };
    refresh();
    const iv = setInterval(refresh, 1000);
    return () => {
      active = false;
      clearInterval(iv);
    };
  }, []);

  // Overlays (mobile rail, command palette) trap the scroll and close on Escape
  // so a keyboard user is never stuck behind one.
  useEffect(() => {
    if (!navOpen && !paletteOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setNavOpen(false);
        setPaletteOpen(false);
      }
    };
    const prevOverflow = document.documentElement.style.overflow;
    document.documentElement.style.overflow = "hidden";
    window.addEventListener("keydown", onKey);
    return () => {
      window.removeEventListener("keydown", onKey);
      document.documentElement.style.overflow = prevOverflow;
    };
  }, [navOpen, paletteOpen]);

  // Ctrl/Cmd+K opens the quick tab-switcher from anywhere in the console.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setPaletteOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  // Deep links: restore the tab named in the URL hash on first load and follow
  // browser back/forward afterwards. A bare visit normalises to #overview.
  useEffect(() => {
    const apply = () => {
      const next = tabFromSlug(window.location.hash.replace(/^#/, ""));
      if (next) setTab(next);
    };
    const initial = tabFromSlug(window.location.hash.replace(/^#/, ""));
    if (initial) {
      setTab(initial);
      document.title = `${initial} · GarudaShield`;
    } else {
      window.history.replaceState(null, "", "#overview");
    }
    window.addEventListener("hashchange", apply);
    return () => window.removeEventListener("hashchange", apply);
  }, []);

  // Keep the URL hash + document title in step with the active tab so the view
  // is shareable, refreshable and reads correctly in history (skips first pass —
  // the deep-link effect already seeded it).
  useEffect(() => {
    if (firstTabEffect.current) {
      firstTabEffect.current = false;
      return;
    }
    const slug = tabSlug(tab);
    if (window.location.hash.replace(/^#/, "") !== slug) window.location.hash = slug;
    document.title = `${tab} · GarudaShield`;
  }, [tab]);

  const selectTab = (next: Tab) => {
    setTab(next);
    setNavOpen(false);
    setPaletteOpen(false);
    window.scrollTo({ top: 0, behavior: reduced ? "auto" : "smooth" });
  };

  // Up/Down (and Home/End) walk the rail like a real menu, moving both the
  // active tab and DOM focus so a keyboard user never reaches for the mouse.
  const onRailKeyDown = (e: React.KeyboardEvent) => {
    const order = TABS as Tab[];
    const i = order.indexOf(tab);
    let next: Tab | undefined;
    if (e.key === "ArrowDown" || e.key === "ArrowRight") next = order[(i + 1) % order.length];
    else if (e.key === "ArrowUp" || e.key === "ArrowLeft") next = order[(i - 1 + order.length) % order.length];
    else if (e.key === "Home") next = order[0];
    else if (e.key === "End") next = order[order.length - 1];
    if (!next) return;
    e.preventDefault();
    selectTab(next);
    railRef.current?.querySelector<HTMLButtonElement>(`button[data-nav-tab="${next}"]`)?.focus();
  };

  const mode = stats?.emergency ? "emergency" : stats?.aggressive ? "aggressive" : "normal";
  const modeTone: Tone = mode === "emergency" ? "danger" : mode === "aggressive" ? "warn" : "ok";
  const nodes = cluster.data?.nodes || [];
  // Until the first /api/cluster answer lands we show a placeholder, never a
  // confident "0/1" that would read as "the node is down".
  const clusterReady = !!cluster.data;
  const onlineNodes = cluster.data?.onlineNodes ?? 1;
  const expectedNodes = cluster.data?.expectedNodes ?? 1;
  const nodeChip = clusterReady ? `${onlineNodes}/${expectedNodes}` : "…";

  return (
    <div className="min-h-screen bg-grid">
      <aside className={`command-sidebar ${navOpen ? "command-sidebar-open" : ""}`} aria-label="Dashboard navigation">
        <div className="brand-lockup">
          <Logo size={34} />
          <div className="min-w-0">
            <div className="font-display text-[15px] font-bold leading-tight text-white truncate">
              Garuda<span className="text-[#D4AF37]">Shield</span>
            </div>
            <div className="brand-kicker">Security Operations</div>
          </div>
        </div>
        {/* Engine reachability is a real signal: it tracks whether /api/stats is
            answering, never a hardcoded "online". */}
        <div className="rail-status">
          <StatusDot tone={connected ? "ok" : "danger"} pulse={connected} />
          <span className="truncate text-white/80">{connected ? "Engine online" : "Engine offline"}</span>
          <span className="ml-auto text-white/50 tabular">{nodeChip} node</span>
        </div>
        <nav className="rail-nav" aria-label="Sections" ref={railRef} onKeyDown={onRailKeyDown}>
          {NAV_GROUPS.map((group) => (
            <div key={group.label} className="nav-group">
              <div className="nav-group-label">{group.label}</div>
              <div className="nav-group-items">
                {group.items.map(([label, icon]) => {
                  const active = tab === label;
                  return (
                    <button
                      key={label}
                      data-nav-tab={label}
                      className={`nav-item ${active ? "nav-item-active" : ""}`}
                      onClick={() => selectTab(label)}
                      aria-current={active ? "page" : undefined}
                    >
                      <span className="nav-icon">
                        <Icon name={icon as IconName} size={17} />
                      </span>
                      <span className="truncate">{label}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          ))}
        </nav>
        <div className="rail-footer">
          <span className="truncate text-white/60">{connected ? "Streaming metrics" : "Stream interrupted"}</span>
          <span className="ml-auto mono tabular text-white">{stats?.currentRps || 0} rps</span>
        </div>
      </aside>
      {navOpen && <button className="sidebar-scrim" onClick={() => setNavOpen(false)} aria-label="Close navigation" />}
      <main className="command-main">
        <header className="command-topbar">
          <div className="flex items-center gap-3 min-w-0">
            <button className="mobile-menu" onClick={() => setNavOpen(true)} aria-label="Open navigation">
              <Icon name="menu" size={18} />
            </button>
            <span className="breadcrumb-muted">GarudaShield</span>
            <span className="breadcrumb-separator">/</span>
            <strong className="truncate min-w-0 max-w-[220px] text-slate-900">{tab}</strong>
          </div>
          <div className="topbar-controls">
            {/* Mode + node chips read live engine data, never placeholders. */}
            <span className={`mode-pill mode-pill-${modeTone}`}>
              <StatusDot tone={modeTone} pulse={mode !== "normal"} />
              <span className="truncate">{mode.toUpperCase()}</span>
            </span>
            <span className="topbar-chip" title={clusterReady ? `${onlineNodes} dari ${expectedNodes} sync node online` : "Status node sedang dimuat"}>
              <Icon name="cluster" size={14} className="text-muted" />
              <span className="tabular text-slate-900">{nodeChip}</span>
              <small>NODE</small>
            </span>
            <span className={`topbar-chip ${connected ? "topbar-chip-live" : "topbar-chip-off"}`} title={connected ? "Stream metrik aktif (refresh 1 detik)" : "Stream metrik terputus"}>
              <span className="relative flex h-2 w-2" aria-hidden="true">
                {connected ? <span className="absolute inline-flex h-full w-full rounded-full bg-ok opacity-70 animate-pulse-ring" /> : null}
                <span className={`relative inline-flex h-2 w-2 rounded-full ${connected ? "bg-ok" : "bg-danger"}`} />
              </span>
              <span className="tabular">{connected ? "LIVE" : "OFFLINE"}</span>
            </span>
            <span className="topbar-stat topbar-uptime">
              <b>
                <AnimatedNumber value={stats?.currentRps ?? 0} />
              </b>
              <small>RPS</small>
            </span>
            <span className="topbar-stat topbar-uptime">
              <b className="truncate">
                <AnimatedNumber value={stats?.bandwidthBps || 0} format={formatBytes} />
                /s
              </b>
              <small>INGRESS</small>
            </span>
            <span className="topbar-divider" aria-hidden="true" />
            <button
              className="command-trigger"
              onClick={() => setPaletteOpen(true)}
              aria-label="Cari tab (Ctrl+K)"
              title="Cari tab · Ctrl/Cmd+K"
            >
              <Icon name="search" size={14} />
              <span className="hidden sm:inline">Cari</span>
              <kbd className="kbd hidden sm:inline-flex">Ctrl K</kbd>
            </button>
            <span className="topbar-divider" aria-hidden="true" />
            <a className="btn-ghost topbar-link" href="/status">Status</a>
            <button
              className="btn-ghost topbar-link"
              onClick={async () => {
                await fetch("/api/logout", { method: "POST" });
                location.href = "/";
              }}
            >
              Logout
            </button>
          </div>
        </header>
        <div className="command-content">
          {/* A dropped stats stream degrades one banner, not the whole console. */}
          {liveError && connected === false && stats === null ? (
            <div className="mb-4">
              <Panel bodyClassName="p-0">
                <ErrorState
                  title="Unable to load security metrics"
                  description="The dashboard could not retrieve the latest data from the protection engine. Protection itself keeps running on the edge — this panel will recover automatically, or retry now."
                  detail={liveError}
                  onRetry={() => location.reload()}
                />
              </Panel>
            </div>
          ) : null}
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={tab}
              initial={reduced ? false : { opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={reduced ? undefined : { opacity: 0, y: -8 }}
              transition={{ duration: 0.22, ease: [0.22, 1, 0.36, 1] }}
              aria-live="polite"
            >
              {tab === "Overview" && <Overview stats={stats} history={history} loading={stats === null} cluster={cluster} />}
              {tab === "Traffic" && <Traffic stats={stats} history={history} loading={stats === null} />}
              {tab === "Charts" && <Charts stats={stats} history={history} loading={stats === null} />}
              {tab === "Geo Map" && <GeoMap stats={stats} loading={stats === null} />}
              {tab === "Top" && <TopTalkers />}
              {tab === "Logs" && <Logs />}
              {tab === "Proxy Fleet" && <ProxyFleet />}
              {tab === "Reputation" && <Reputation />}
              {tab === "WAF Rules" && <WAFRules />}
              {tab === "Rate Limit" && <RateLimit />}
              {tab === "Protect" && <Protect />}
              {tab === "Cluster" && <Cluster cluster={cluster} />}
              {tab === "Alerts" && <Alerts />}
              {tab === "Settings" && <Settings stats={stats} />}
              {tab === "Blocklist" && <Blocklist />}
              {tab === "Whitelist" && <Whitelist />}
            </motion.div>
          </AnimatePresence>
        </div>
      </main>
      <AnimatePresence>
        {paletteOpen ? <CommandPalette onClose={() => setPaletteOpen(false)} onSelect={selectTab} /> : null}
      </AnimatePresence>
    </div>
  );
}

/* Quick tab-switcher (Ctrl/Cmd+K). Client-only, keyboard-first: type to filter
   across every section, arrows to move, Enter to jump, Escape to dismiss. */
function CommandPalette({ onClose, onSelect }: { onClose: () => void; onSelect: (t: Tab) => void }) {
  const reduced = useReducedMotion();
  const [q, setQ] = useState("");
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);

  const results = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return NAV_GROUPS.flatMap((group) =>
      group.items
        .filter(([label]) => !needle || label.toLowerCase().includes(needle) || group.label.toLowerCase().includes(needle))
        .map(([label, icon]) => ({ label, icon, group: group.label })),
    );
  }, [q]);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);
  useEffect(() => {
    setActive(0);
  }, [q]);

  const commit = (label: Tab) => {
    onSelect(label);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setActive((a) => Math.min(a + 1, results.length - 1));
    } else if (e.key === "ArrowUp") {
      e.preventDefault();
      setActive((a) => Math.max(a - 1, 0));
    } else if (e.key === "Enter") {
      e.preventDefault();
      const hit = results[active];
      if (hit) commit(hit.label);
    }
  };

  return (
    <motion.div
      className="command-overlay"
      initial={reduced ? false : { opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={reduced ? undefined : { opacity: 0 }}
      transition={{ duration: 0.16 }}
      onClick={onClose}
      role="presentation"
    >
      <motion.div
        className="command-panel"
        role="dialog"
        aria-modal="true"
        aria-label="Pindah tab"
        initial={reduced ? false : { opacity: 0, y: -8, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={reduced ? undefined : { opacity: 0, y: -8, scale: 0.98 }}
        transition={{ duration: 0.18, ease: [0.22, 1, 0.36, 1] }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="command-input">
          <Icon name="search" size={16} className="text-muted" />
          <input
            ref={inputRef}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={onKeyDown}
            placeholder="Cari tab… (mis. logs, cluster, waf)"
            aria-label="Cari tab"
            spellCheck={false}
            autoComplete="off"
          />
          <kbd className="kbd">Esc</kbd>
        </div>
        <div className="command-list" role="listbox" aria-label="Hasil">
          {results.length === 0 ? (
            <div className="command-empty">Tidak ada tab yang cocok dengan “{q}”</div>
          ) : (
            results.map((r, i) => (
              <button
                key={r.label}
                type="button"
                role="option"
                aria-selected={i === active}
                className={`command-item ${i === active ? "command-item-active" : ""}`}
                onMouseMove={() => setActive(i)}
                onClick={() => commit(r.label)}
              >
                <span className="command-item-icon">
                  <Icon name={r.icon} size={16} />
                </span>
                <span className="truncate">{r.label}</span>
                <span className="command-item-group">{r.group}</span>
              </button>
            ))
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}

/* Healthy while every node that is configured is online; degraded when the
   sync bus is down, partial while optional nodes are still missing. */
function nodeTone(info: ClusterInfo | null): Tone {
  if (!info) return "muted";
  if (info.state === "degraded") return "danger";
  if (info.state === "partial") return "warn";
  return "ok";
}

function formatBytes(value: number | undefined) {
  const bytes = Number(value || 0);
  if (bytes < 1024) return `${bytes.toFixed(0)} B`;
  const units = ["KB", "MB", "GB", "TB"];
  let n = bytes;
  let unit = "B";
  for (const next of units) {
    n /= 1024;
    unit = next;
    if (n < 1024 || next === "TB") break;
  }
  return `${n.toFixed(n >= 100 ? 0 : n >= 10 ? 1 : 2)} ${unit}`;
}

function fmtNum(value: number | undefined) {
  const n = Number(value || 0);
  return n.toLocaleString("en-US");
}

function fmtAgo(ms: number) {
  if (!ms) return "—";
  const s = Math.max(0, Math.round(ms / 1000));
  if (s < 60) return `${s}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m`;
  return `${Math.floor(s / 3600)}h`;
}

/* Overview follows one reading order so the first question ("are we safe?") is
   answered before the second ("how much traffic, and what happened to it?"):

     L1 posture verdict  →  L2 critical counters  →  L3 traffic & verdict split
     →  L4 engine/node health  →  L5 mode & runtime

   Every number here comes from the same /api/stats + /api/cluster payloads the
   other tabs already use; only the presentation is new. */
function Overview({
  stats,
  history,
  loading,
  cluster,
}: {
  stats: Stats;
  history: Sample[];
  loading: boolean;
  cluster: ReturnType<typeof useCluster>;
}) {
  const attack = !!stats?.attackActive;
  const info = cluster.data;
  const onlineNodes = info?.onlineNodes ?? 1;
  const expectedNodes = info?.expectedNodes ?? 1;

  const passed = Number(stats?.passed || 0);
  const blocked = Number(stats?.blocked || 0);
  const challenged = Number(stats?.challenged || 0);
  const total = Math.max(1, passed + blocked + challenged);
  const pct = (n: number) => `${((n / total) * 100).toFixed(1)}%`;

  /* One word an operator can read at a glance. Derived from values the engine
     already reports — no new state, no inference beyond "is anything wrong". */
  const nodeState = nodeTone(info);
  const posture: { label: string; tone: Tone; icon: IconName; headline: string; detail: string } = loading
    ? {
        label: "MEMUAT",
        tone: "muted",
        icon: "unknown",
        headline: "Mengambil status keamanan",
        detail: "Menghubungkan ke protection engine",
      }
    : attack
      ? {
          label: "UNDER ATTACK",
          tone: "danger",
          icon: "shield-alert",
          headline: `Mitigasi aktif · ${(stats?.attackTypes || []).join(", ") || "anomaly"}`,
          detail: `${fmtNum(blocked)} request diblokir, ${fmtNum(challenged)} di-challenge`,
        }
      : nodeState === "danger" || nodeState === "warn"
        ? {
            label: "DEGRADED",
            tone: nodeState,
            icon: "alert",
            headline: "Perlindungan berjalan, sinkronisasi node bermasalah",
            detail: `${onlineNodes}/${expectedNodes} node online · periksa tab Cluster`,
          }
        : {
            label: "PROTECTED",
            tone: "ok",
            icon: "shield-check",
            headline: "Semua lapisan keamanan aktif",
            detail: stats?.baselineLocked ? "Baseline terkunci · deteksi anomali aktif" : "Baseline sedang dipelajari",
          };

  return (
    <Stack className="gap-5">
      {/* ---------- L1 · overall security status ---------- */}
      <section className={`posture-banner posture-${posture.tone}`} aria-label="Status keamanan keseluruhan">
        <span className="posture-shield" aria-hidden="true">
          <Icon name={posture.icon} size={26} strokeWidth={1.7} />
        </span>
        <div className="posture-copy">
          <div className="posture-eyebrow">{posture.label}</div>
          <div className="posture-title">{loading ? "Memuat status keamanan…" : posture.headline}</div>
          <div className="posture-sub">{posture.detail}</div>
        </div>
        <div className="posture-metrics">
          <div>
            {loading ? (
              <span className="metric-value text-slate-900">—</span>
            ) : (
              <AnimatedNumber value={stats?.currentRps ?? 0} className="metric-value text-slate-900" />
            )}
            <span className="metric-label">RPS</span>
          </div>
          <div>
            {loading ? (
              <span className="metric-value text-slate-900">—</span>
            ) : (
              <span className="metric-value text-slate-900">
                <AnimatedNumber value={stats?.bandwidthBps || 0} format={formatBytes} />
                /s
              </span>
            )}
            <span className="metric-label">Bandwidth</span>
          </div>
        </div>
      </section>

      {/* ---------- L2 · critical counters ---------- */}
      <div>
        <SectionTitle hint={loading ? undefined : `${fmtNum(stats?.processed)} request diproses`}>Kritik</SectionTitle>
        <div className="mt-3">
          {loading ? (
            <SkeletonCards />
          ) : (
            <div className="kpi-row">
              <MetricCard label="Requests" value={<AnimatedNumber value={stats?.processed} format={fmtNum} />} hint="total diproses" />
              <MetricCard label="Allowed" value={<AnimatedNumber value={passed} format={fmtNum} />} tone="ok" hint={pct(passed)} />
              <MetricCard label="Blocked" value={<AnimatedNumber value={blocked} format={fmtNum} />} tone="danger" hint={pct(blocked)} />
              <MetricCard label="Challenged" value={<AnimatedNumber value={challenged} format={fmtNum} />} tone="warn" hint={pct(challenged)} />
            </div>
          )}
        </div>
      </div>

      {/* ---------- L3 · traffic & security visualisation ---------- */}
      <div className="grid gap-4 lg:grid-cols-[1.35fr_1fr]">
        <div className="stack">
          <Sparkline
            data={history.map((h) => h.rps)}
            color="#D4AF37"
            label="Request / detik"
            format={(v) => `${Math.round(v)} rps`}
            fill={false}
          />
          <Panel title="Traffic & risiko" subtitle="Akumulasi sejak engine start">
            <div className="grid grid-cols-2 gap-x-6 gap-y-4 sm:grid-cols-4 lg:grid-cols-2 xl:grid-cols-4">
              <MetricInline label="Traffic masuk" value={formatBytes(stats?.bytesIn)} hint="ingress kumulatif" />
              <MetricInline label="Volume DDoS" value={formatBytes(stats?.blockedBytes)} tone="danger" hint="payload diblokir" />
              <MetricInline
                label="Peak RPS"
                value={stats?.peakRps != null ? Math.round(stats.peakRps) : "—"}
                hint="puncak tercatat"
              />
              <MetricInline
                label="Anomaly"
                value={stats?.anomalyScore != null ? `${Number(stats.anomalyScore).toFixed(1)}σ` : "—"}
                tone={attack ? "danger" : "plain"}
                hint={attack ? "di atas baseline" : "deviasi baseline"}
              />
            </div>
          </Panel>
        </div>

        <Panel
          title="Verdict split"
          subtitle="Proporsi keputusan engine"
          actions={<Tag tone="muted">{fmtNum(total)} keputusan</Tag>}
        >
          <div className="verdict-legend">
            <span className="verdict-legend-item">
              <i className="verdict-key verdict-pass" /> Diizinkan <b className="tabular">{fmtNum(passed)}</b>
            </span>
            <span className="verdict-legend-item">
              <i className="verdict-key verdict-challenge" /> Challenge <b className="tabular">{fmtNum(challenged)}</b>
            </span>
            <span className="verdict-legend-item">
              <i className="verdict-key verdict-block" /> Diblokir <b className="tabular">{fmtNum(blocked)}</b>
            </span>
          </div>
          <div
            className="verdict-bar verdict-bar-tall mt-3"
            role="img"
            aria-label={`Diizinkan ${pct(passed)}, challenge ${pct(challenged)}, diblokir ${pct(blocked)}`}
          >
            <span className="verdict-pass" style={{ width: pct(passed) }} />
            <span className="verdict-challenge" style={{ width: pct(challenged) }} />
            <span className="verdict-block" style={{ width: pct(blocked) }} />
          </div>
          <div className="mt-4 grid grid-cols-3 gap-3 border-t border-edge pt-4">
            <div>
              <div className="metric-label">Diizinkan</div>
              <div className="text-ok-ink tabular text-base font-semibold">{pct(passed)}</div>
            </div>
            <div>
              <div className="metric-label">Challenge</div>
              <div className="text-warn-ink tabular text-base font-semibold">{pct(challenged)}</div>
            </div>
            <div>
              <div className="metric-label">Diblokir</div>
              <div className="text-danger-ink tabular text-base font-semibold">{pct(blocked)}</div>
            </div>
          </div>
        </Panel>
      </div>

      {/* ---------- L4 · engine / node health ---------- */}
      <Panel
        title="Engine & node health"
        subtitle="Topologi aktif dari config"
        actions={info ? <Tag tone="muted">mode: {info.mode === "single" ? "single" : "cluster"}</Tag> : null}
      >
        {cluster.loading && !info ? (
          <SkeletonBlock rows={2} label="Memuat status node…" />
        ) : cluster.error && !info ? (
          <ErrorState
            title="Unable to load node status"
            description="Node status could not be read from the protection engine."
            detail={cluster.error}
            onRetry={cluster.reload}
          />
        ) : (
          <div className="mb-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
            <MetricInline
              label="Node online"
              value={`${onlineNodes}/${expectedNodes}`}
              tone={nodeState === "muted" ? "plain" : nodeState}
            />
            <MetricInline
              label="Sinkronisasi"
              value={info?.enabled ? (info?.subscribed ? "Aktif" : "Menyambung") : "Single node"}
              tone={info?.enabled && !info?.subscribed ? "warn" : "plain"}
            />
            <MetricInline label="Heartbeat" value={info?.heartbeatMs != null ? `${info.heartbeatMs} ms` : "—"} />
            <MetricInline label="Op diterapkan" value={info?.appliedOps != null ? fmtNum(info.appliedOps) : "—"} />
          </div>
        )}
        <NodeRows nodes={info?.nodes || []} loading={cluster.loading && !info} />
      </Panel>

      {/* ---------- L5 · mode & runtime ---------- */}
      <Panel
        title="Mode & runtime"
        subtitle="Flag operative engine saat ini"
        actions={
          <a className="tag tag-muted inline-flex items-center gap-1.5 transition-colors hover:border-accent hover:text-accent-ink" href="/status">
            Status publik
            <Icon name="external" size={12} />
          </a>
        }
      >
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <RuntimeFlag label="Normal" on={!stats?.aggressive && !stats?.flood && !stats?.emergency} />
          <RuntimeFlag label="Aggressive" on={!!stats?.aggressive} tone="warn" />
          <RuntimeFlag label="Flood mode" on={!!stats?.flood} tone="danger" />
          <RuntimeFlag label="Emergency" on={!!stats?.emergency} tone="danger" />
        </div>
        <div className="mt-4 border-t border-edge pt-4">
          <KeyValue label="Whitelist">{fmtNum((stats?.whitelist || []).length)} entri</KeyValue>
          <KeyValue label="Baseline">{stats?.baselineLocked ? "Terkunci" : "Belum terkunci"}</KeyValue>
          <KeyValue label="Reconnects">{fmtNum(info?.reconnects)}</KeyValue>
        </div>
      </Panel>
    </Stack>
  );
}

/* Compact label/value used inside dense panels — same hierarchy as MetricCard
   at a smaller scale so secondary metrics never shout over the primary ones. */
function MetricInline({
  label,
  value,
  hint,
  tone = "plain",
}: {
  label: string;
  value: React.ReactNode;
  hint?: string;
  tone?: "plain" | "ok" | "warn" | "danger" | "info" | "muted";
}) {
  const toneClass =
    tone === "plain" || tone === "muted"
      ? "text-slate-900"
      : tone === "ok"
        ? "text-ok-ink"
        : tone === "warn"
          ? "text-warn-ink"
          : tone === "danger"
            ? "text-danger-ink"
            : "text-accent-ink";
  return (
    <div>
      <div className="metric-label">{label}</div>
      <div className={`mt-1.5 font-display text-lg font-bold leading-none tabular ${toneClass}`}>{value ?? "—"}</div>
      {hint ? <div className="metric-hint">{hint}</div> : null}
    </div>
  );
}

/* Runtime flags read as ON/OFF state, never as a bare colour change. */
function RuntimeFlag({ label, on, tone = "ok" }: { label: string; on: boolean; tone?: "ok" | "warn" | "danger" }) {
  return (
    <div className={`runtime-flag ${on ? `runtime-flag-on runtime-flag-${tone}` : ""}`}>
      <span className="flex items-center gap-1.5 text-[13px] font-medium">
        {on ? <Icon name="check" size={14} /> : <Icon name="unknown" size={14} className="text-muted" />}
        {label}
      </span>
      <span className="metric-label">{on ? "ON" : "OFF"}</span>
    </div>
  );
}

/* Node table + the "N / N Online" headline the brief asks for. Shared by the
   Overview panel and the full Cluster tab. */
function NodeRows({ nodes, loading }: { nodes: NodeRow[]; loading: boolean }) {
  if (loading) return <SkeletonBlock rows={2} label="Memuat node…" />;
  if (!nodes.length) {
    return (
      <EmptyState
        title="No sync nodes reported"
        description="The engine did not return a node topology. Check that cluster.nodeId is set in the configuration."
        icon="⌘"
      />
    );
  }
  return (
    <TableBox>
      <DataTable>
        <thead>
          <tr>
            <th>Node</th>
            <th>Status</th>
            <th className="hidden sm:table-cell">Role</th>
            <th className="text-right">Seen</th>
          </tr>
        </thead>
        <tbody>
          {nodes.map((n) => (
            <tr key={n.id}>
              <td>
                <div className="flex items-center gap-2">
                  <span className="mono">{n.id}</span>
                  {n.self ? <Tag tone="info">THIS NODE</Tag> : null}
                  {n.required ? <Tag tone="warn">REQUIRED</Tag> : null}
                </div>
                {n.address ? <div className="mono text-[11px] text-muted">{n.address}</div> : null}
              </td>
              <td>
                <Tag tone={n.state === "online" ? "ok" : n.state === "offline" ? "danger" : "muted"}>
                  {n.state === "online" ? "ONLINE" : n.state === "offline" ? "OFFLINE" : "UNKNOWN"}
                </Tag>
                {n.note ? <div className="mt-1 text-[11px] text-muted">{n.note}</div> : null}
              </td>
              <td className="hidden sm:table-cell text-muted">{n.role || "all"}{n.site ? ` · ${n.site}` : ""}</td>
              <td className="text-right tabular text-muted">{n.self ? "now" : fmtAgo(n.ageMs)}</td>
            </tr>
          ))}
        </tbody>
      </DataTable>
    </TableBox>
  );
}

/* Local alias kept for the compact metric rows used across tabs. */
function Stat({ label, value, tone, hint, loading = false }: { label: string; value: any; tone?: string; hint?: string; loading?: boolean }) {
  const map: Record<string, "plain" | "ok" | "warn" | "danger" | "accent"> = {
    "text-ok": "ok",
    "text-ok-ink": "ok",
    "text-warn": "warn",
    "text-warn-ink": "warn",
    "text-danger": "danger",
    "text-danger-ink": "danger",
    "text-accent": "accent",
    "text-accent-ink": "accent",
    "text-accent2": "accent",
    "text-slate-900": "plain",
  };
  return <MetricCard label={label} value={value} hint={hint} tone={map[tone || ""] || "plain"} loading={loading} />;
}

/* Form field wrapper: label above control, one type scale for every form in the
   console so Blocklist / Whitelist / Protect read as the same instrument. */
function Field({ label, className = "", children }: { label: string; className?: string; children: React.ReactNode }) {
  return (
    <div className={className}>
      <label className="metric-label">{label}</label>
      {children}
    </div>
  );
}

function Blocklist() {
  const [rows, setRows] = useState<any[]>([]);
  const [ip, setIp] = useState("");
  const [reason, setReason] = useState("manual");
  const [dur, setDur] = useState("3600000");
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");

  async function load() {
    try {
      const d = await gsGet("blocklist");
      // The engine returns a bare array; accept the wrapped shape too so a
      // future envelope never silently renders an empty table.
      setRows(Array.isArray(d) ? d : d.blocklist || []);
    } catch (e: any) {
      setErr(e.message);
    }
  }
  useEffect(() => {
    load();
  }, []);

  const shown = useMemo(
    () => filterRows(rows, query, ["ip", (r: any) => r.reason, (r: any) => r.detail]),
    [rows, query],
  );

  function exportCsv() {
    downloadCsv(
      csvFilename("blocklist"),
      ["IP", "Alasan", "Kedaluwarsa"],
      shown.map((r: any) => [r.ip, r.reason || r.detail || "", r.expires ? new Date(r.expires).toISOString() : ""]),
    );
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    try {
      await gsPost("block", { ip, reason, duration: Number(dur) });
      setIp("");
      load();
    } catch (e: any) {
      setErr(e.message);
    }
  }
  async function unblock(ip: string) {
    await gsPost("unblock", { ip });
    load();
  }

  return (
    <Stack className="gap-4">
      {err ? <ErrorCard message={err} /> : null}

      <Panel title="Tambah blocklist" subtitle="Blokir IP manual di edge">
        <form onSubmit={add} className="flex flex-wrap items-end gap-3">
          <Field label="IP" className="flex-1 min-w-[180px]">
            <input className="input mt-1.5" placeholder="203.0.113.10" value={ip} onChange={(e) => setIp(e.target.value)} required />
          </Field>
          <Field label="Alasan" className="w-44">
            <input className="input mt-1.5" value={reason} onChange={(e) => setReason(e.target.value)} />
          </Field>
          <Field label="Durasi (ms)" className="w-36">
            <input className="input mt-1.5 tabular" value={dur} onChange={(e) => setDur(e.target.value)} />
          </Field>
          <button className="btn-primary h-[38px]">Block</button>
        </form>
        {err ? <p className="mt-3 text-danger-ink text-[13px]">{err}</p> : null}
      </Panel>

      <Panel
        title="Entri blocklist"
        subtitle={`${shown.length} dari ${rows.length} IP ditampilkan`}
        bodyClassName=""
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <SearchInput value={query} onChange={setQuery} placeholder="Cari IP / alasan…" ariaLabel="Cari blocklist" className="w-48" />
            <ExportButton onClick={exportCsv} disabled={shown.length === 0} title="Ekspor hasil filter ke CSV" />
          </div>
        }
      >
        <TableBox>
          <DataTable>
            <thead>
              <tr>
                <th>IP</th>
                <th>Alasan</th>
                <th className="hidden sm:table-cell">Kedaluwarsa</th>
                <th className="text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.ip}</td>
                  <td className="text-muted">{r.reason || r.detail || "—"}</td>
                  <td className="hidden sm:table-cell text-muted tabular">{new Date(r.expires).toLocaleString()}</td>
                  <td className="text-right">
                    <button className="btn px-2.5 py-1 text-[12px]" onClick={() => unblock(r.ip)}>
                      Unblock
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </DataTable>
          {rows.length === 0 ? (
            <EmptyState title="Blocklist kosong" description="Belum ada IP yang diblokir manual." icon="blocklist" />
          ) : shown.length === 0 ? (
            <EmptyState title="Tidak ada hasil" description="Tidak ada entri blocklist yang cocok dengan pencarian." icon={<Icon name="search" size={20} />} />
          ) : null}
        </TableBox>
      </Panel>
    </Stack>
  );
}

function Whitelist() {
  const [rows, setRows] = useState<any[]>([]);
  const [ip, setIp] = useState("");
  const [err, setErr] = useState("");
  const [query, setQuery] = useState("");

  async function load() {
    try {
      const d = await gsGet("whitelist/detailed");
      setRows(Array.isArray(d) ? d : d.whitelist || []);
    } catch (e: any) {
      setErr(e.message);
    }
  }
  useEffect(() => {
    load();
  }, []);

  const shown = useMemo(
    () => filterRows(rows, query, ["ip", (r: any) => r.source]),
    [rows, query],
  );

  function exportCsv() {
    downloadCsv(
      csvFilename("whitelist"),
      ["IP", "Sumber"],
      shown.map((r: any) => [r.ip, r.source || "manual"]),
    );
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    try {
      await gsPost("whitelist", { ip });
      setIp("");
      load();
    } catch (e: any) {
      setErr(e.message);
    }
  }
  async function remove(ip: string) {
    await gsPost("unwhitelist", { ip });
    load();
  }
  return (
    <Stack className="gap-4">
      <Panel title="Tambah whitelist" subtitle="IP yang selalu diizinkan engine">
        <form onSubmit={add} className="flex flex-wrap items-end gap-3">
          <Field label="IP" className="flex-1 min-w-[180px]">
            <input className="input mt-1.5" placeholder="203.0.113.10" value={ip} onChange={(e) => setIp(e.target.value)} required />
          </Field>
          <button className="btn-primary h-[38px]">Whitelist</button>
        </form>
        {err ? <p className="mt-3 text-danger-ink text-[13px]">{err}</p> : null}
      </Panel>

      <Panel
        title="Entri whitelist"
        subtitle={`${shown.length} dari ${rows.length} IP ditampilkan`}
        bodyClassName=""
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <SearchInput value={query} onChange={setQuery} placeholder="Cari IP / sumber…" ariaLabel="Cari whitelist" className="w-48" />
            <ExportButton onClick={exportCsv} disabled={shown.length === 0} title="Ekspor hasil filter ke CSV" />
          </div>
        }
      >
        <TableBox>
          <DataTable minWidth={false}>
            <thead>
              <tr>
                <th>IP</th>
                <th>Sumber</th>
                <th className="text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.ip}</td>
                  <td><Tag tone="muted">{r.source || "manual"}</Tag></td>
                  <td className="text-right">
                    <button className="btn px-2.5 py-1 text-[12px]" onClick={() => remove(r.ip)}>
                      Hapus
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </DataTable>
          {rows.length === 0 ? (
            <EmptyState title="Whitelist kosong" description="Belum ada IP yang dikecualikan dari filtering." icon="whitelist" />
          ) : shown.length === 0 ? (
            <EmptyState title="Tidak ada hasil" description="Tidak ada entri whitelist yang cocok dengan pencarian." icon={<Icon name="search" size={20} />} />
          ) : null}
        </TableBox>
      </Panel>
    </Stack>
  );
}

function TopTalkers() {
  const [ips, setIps] = useState<[string, number][]>([]);
  const [paths, setPaths] = useState<[string, number][]>([]);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    const load = () =>
      gsGet("top", "?limit=20")
        .then((d) => {
          if (!active) return;
          setIps(d.ips || []);
          setPaths(d.paths || []);
          setErr("");
        })
        .catch((e) => active && setErr(e.message))
        .finally(() => active && setLoading(false));
    load();
    const iv = setInterval(load, 2000);
    return () => {
      active = false;
      clearInterval(iv);
    };
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <Panel title="Top IP"><SkeletonBlock rows={4} /></Panel>
        <Panel title="Top Path"><SkeletonBlock rows={4} /></Panel>
      </div>
    );
  }
  if (err) return <ErrorCard message={err} />;
  if (ips.length === 0 && paths.length === 0) return <EmptyCard message="Belum ada trafik tercatat." />;

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
      <FreqTable title="Top IP" rows={ips} headLabel="IP" />
      <FreqTable title="Top Path" rows={paths} headLabel="Path" />
    </div>
  );
}

/* Frequency leaderboard: a share bar behind each key so the reader ranks rows
   without reading every number. Same component for top IPs and top paths. */
function FreqTable({ title, rows, headLabel }: { title: string; rows: [string, number][]; headLabel: string }) {
  const max = Math.max(1, ...rows.map((r) => r[1]));
  const total = rows.reduce((sum, r) => sum + r[1], 0);
  return (
    <Panel title={title} subtitle={`${rows.length} sumber teratas`} bodyClassName="">
      <TableBox>
        <DataTable minWidth={false}>
          <thead>
            <tr>
              <th>{headLabel}</th>
              <th className="w-32 text-right">Share</th>
              <th className="w-24 text-right">Request</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(([key, count], i) => (
              <tr key={i}>
                <td>
                  <div className="truncate max-w-[22rem] font-mono text-[13px]" title={key}>{key}</div>
                  <div className="freq-bar mt-1.5">
                    <span style={{ width: `${(count / max) * 100}%` }} />
                  </div>
                </td>
                <td className="text-right tabular text-muted">{total ? `${((count / total) * 100).toFixed(1)}%` : "—"}</td>
                <td className="text-right font-display font-semibold tabular">{fmtNum(count)}</td>
              </tr>
            ))}
          </tbody>
        </DataTable>
        {rows.length === 0 ? <EmptyState title="Belum ada data" description="Leaderboard terisi setelah engine mencatat trafik." icon="top" /> : null}
      </TableBox>
    </Panel>
  );
}

/* Loading / empty / error all resolve to the shared components so a quiet
   screen and a broken one never look like two different products. */
function ErrorCard({ message }: { message: string }) {
  return <ErrorState title="Unable to load data" description="The protection engine did not return this data. Nothing about your protection changed — the panel will retry." detail={message} />;
}

function EmptyCard({ message }: { message: string }) {
  return <EmptyState title={message} description="Data will appear here as soon as the engine records traffic." />;
}

function Reputation() {
  const [rows, setRows] = useState<any[]>([]);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [query, setQuery] = useState("");
  const [band, setBand] = useState<"all" | "block" | "challenge" | "clean">("all");
  async function load() {
    try {
      const d = await gsGet("reputation", "?limit=100");
      setRows(Array.isArray(d) ? d : d.reputation || []);
      setErr("");
    } catch (e: any) {
      setErr(e.message);
    }
  }
  useEffect(() => {
    load();
    const iv = setInterval(load, 2000);
    return () => clearInterval(iv);
  }, []);

  const shown = useMemo(() => {
    const pred = (r: any) => {
      const s = Number(r.score) || 0;
      if (band === "block") return s >= 80;
      if (band === "challenge") return s >= 60 && s < 80;
      if (band === "clean") return s < 60;
      return true;
    };
    return filterRows(rows, query, ["ip", (r: any) => r.reason, (r: any) => r.detail], pred);
  }, [rows, query, band]);

  const bands: ReadonlyArray<readonly ["all" | "block" | "challenge" | "clean", string]> = [
    ["all", "Semua"],
    ["block", "≥80"],
    ["challenge", "60–79"],
    ["clean", "<60"],
  ];

  function exportCsv() {
    downloadCsv(
      csvFilename("reputation"),
      ["IP", "Score", "Reason"],
      shown.map((r: any) => [r.ip, Number(r.score) || 0, r.reason || r.detail || ""]),
    );
  }

  async function resetIp(ip: string) {
    setBusy(true);
    setErr("");
    try {
      await gsPost("reputation/reset", { ip });
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }
  if (err) return <ErrorCard message={err} />;
  return (
    <Stack className="gap-4">
      <Panel
        title="Reputasi IP"
        subtitle={`${shown.length} dari ${rows.length} sumber dinilai — score ≥ 80 blok, 60–79 challenge`}
        bodyClassName=""
        actions={
          <div className="flex flex-wrap items-center gap-2">
            <Segmented options={bands} value={band} onChange={setBand} ariaLabel="Filter pita skor reputasi" />
            <SearchInput value={query} onChange={setQuery} placeholder="Cari IP / reason…" ariaLabel="Cari reputasi" className="w-48" />
            <ExportButton onClick={exportCsv} disabled={shown.length === 0} title="Ekspor hasil filter ke CSV" />
          </div>
        }
      >
        <TableBox>
          <DataTable>
            <thead>
              <tr>
                <th>IP</th>
                <th className="text-right">Score</th>
                <th>Reason</th>
                <th className="text-right">Aksi</th>
              </tr>
            </thead>
            <tbody>
              {shown.map((r, i) => (
                <tr key={i}>
                  <td className="mono">{r.ip}</td>
                  <td className="text-right tabular font-semibold">
                    <span className={Number(r.score) >= 60 ? "text-danger-ink" : Number(r.score) >= 20 ? "text-warn-ink" : ""}>{r.score}</span>
                  </td>
                  <td className="text-muted">{r.reason || r.detail || "—"}</td>
                  <td className="text-right">
                    <button className="btn px-2.5 py-1 text-[12px]" onClick={() => resetIp(r.ip)} disabled={busy}>
                      Reset
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </DataTable>
          {rows.length === 0 ? (
            <EmptyState title="Belum ada reputasi tercatat" description="Skor muncul setelah engine menilai IP sumber trafik." icon="reputation" />
          ) : shown.length === 0 ? (
            <EmptyState title="Tidak ada hasil" description="Tidak ada IP yang cocok dengan pencarian atau pita skor ini." icon={<Icon name="search" size={20} />} />
          ) : null}
        </TableBox>
      </Panel>
      <Note>
        Reset menghapus skor (except <code className="mono">subnet:</code>/<code className="mono">reason:</code> persisten v2) untuk IP tersebut —
        evaluasi ulang dilakukan pada request berikutnya.
      </Note>
    </Stack>
  );
}

function moduleLabel(m: string): string {
  const map: Record<string, string> = {
    sqli: "SQL Injection",
    xss: "Cross-site Scripting",
    commandInjection: "Command Injection",
    pathTraversal: "Path Traversal",
    lfi: "Local File Include",
    rfi: "Remote File Include",
    shellshock: "Shellshock",
    scanners: "Scanner",
  };
  return map[m] || m;
}

function WAFRules() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const [rule, setRule] = useState({ name: "", pattern: "", score: "40" });

  async function load() {
    try {
      setData(await gsGet("waf"));
      setErr("");
    } catch (e: any) {
      setErr(e.message);
    }
  }
  useEffect(() => {
    load();
    const iv = setInterval(load, 3000);
    return () => clearInterval(iv);
  }, []);

  if (err && !data) return <ErrorCard message={err} />;
  const config = data?.config || {};
  const stats = data?.stats || {};
  const modules = ["sqli", "xss", "commandInjection", "pathTraversal", "lfi", "rfi", "shellshock", "scanners"];
  const activeCount = modules.filter((m) => config[m]).length;
  const rules: any[] = data?.rules || [];

  async function toggleModule(name: string, on: boolean) {
    setBusy(true);
    setErr("");
    try {
      await gsPost("waf", { modules: { [name]: on } });
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function addRule(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setErr("");
    setNote("");
    try {
      await gsPost("rules", {
        name: rule.name.trim(),
        pattern: rule.pattern,
        score: Number(rule.score) || 0,
      });
      setRule({ name: "", pattern: "", score: "40" });
      setNote("Custom rule ditambahkan.");
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function clearRules() {
    if (!window.confirm("Hapus SEMUA custom rule? Aturan bawaan tidak terpengaruh.")) return;
    setBusy(true);
    setErr("");
    setNote("");
    try {
      await gsDelete("rules");
      setNote("Semua custom rule dihapus.");
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Stack className="gap-4">
      {err ? <ErrorCard message={err} /> : null}
      {note ? <div role="status" className="card flex items-center gap-2 text-[13px] text-ok-ink"><Icon name="check" size={16} />{note}</div> : null}

      <MetricGrid cols={4}>
        <MetricCard label="Rules Aktif" value={`${stats.enabledCount ?? rules.filter((r) => r.enabled).length}/${stats.rulesCount ?? rules.length}`} tone="ok" />
        <MetricCard label="Request Dropped" value={fmtNum(stats.droppedCount)} tone="danger" />
        <MetricCard label="Custom Rules" value={stats.customRules ?? rules.filter((r) => r.custom).length} tone="accent" />
        <MetricCard label="Modul Aktif" value={`${activeCount}/${modules.length}`} hint={config.enabled ? "WAF menyala" : "WAF mati total"} tone={config.enabled ? "ok" : "warn"} />
      </MetricGrid>

      <Panel
        title="Modul WAF"
        subtitle="Nyalakan/matikan kategori deteksi — berubah langsung di engine tanpa restart"
        actions={<Tag tone={config.enabled ? "ok" : "warn"}>{config.enabled ? "WAF ON" : "WAF OFF"}</Tag>}
      >
        <div className="space-y-3">
          <div className="flex items-center justify-between rounded-lg border border-edge px-3 py-2">
            <div>
              <div className="text-sm font-semibold text-slate-900">Master switch</div>
              <div className="text-[11px] text-muted">Nonaktifkan semua deteksi WAF (mode bypass)</div>
            </div>
            <button
              className={config.enabled ? "btn-primary h-[34px]" : "btn h-[34px]"}
              onClick={() => toggleModule("enabled", !config.enabled)}
              disabled={busy}
              aria-pressed={!!config.enabled}
            >
              {config.enabled ? "Aktif" : "Nonaktif"}
            </button>
          </div>
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {modules.map((m) => {
              const on = !!config[m];
              return (
                <button
                  key={m}
                  className={`text-left rounded-xl border px-3 py-3 transition-colors ${
                    on ? "border-blue-300 bg-blue-50" : "border-edge bg-white hover:border-slate-300"
                  }`}
                  onClick={() => toggleModule(m, !on)}
                  disabled={busy || !config.enabled}
                  aria-pressed={on}
                  title={on ? "Klik untuk nonaktifkan" : "Klik untuk nyalakan"}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-[13px] font-semibold text-slate-900">{moduleLabel(m)}</span>
                    <span className={`dot ${on ? "dot-ok" : "dot-muted"}`} aria-hidden="true" />
                  </div>
                  <div className={`mt-1 text-[11px] font-bold tracking-wide ${on ? "text-ok-ink" : "text-muted"}`}>
                    {on ? "ON" : "OFF"}
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </Panel>

      <Panel
        title="Rule aktif"
        subtitle="Aturan yang sedang dinilai engine"
        actions={<Tag tone="muted">{rules.length} rule</Tag>}
        bodyClassName=""
      >
        <TableBox>
          <DataTable>
            <thead>
              <tr>
                <th>Rule</th>
                <th>Type</th>
                <th className="text-right">Score</th>
                <th className="hidden sm:table-cell text-right">Matches</th>
                <th className="text-right">Status</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((r, i) => (
                <tr key={i}>
                  <td>
                    {r.name}
                    {r.custom ? <Tag tone="info" title="Custom rule">CUSTOM</Tag> : null}
                  </td>
                  <td className="text-muted">{r.type}</td>
                  <td className="text-right tabular">{r.score}</td>
                  <td className="hidden sm:table-cell text-right tabular">{fmtNum(r.matches)}</td>
                  <td className="text-right">
                    <Tag tone={r.enabled ? "ok" : "muted"}>{r.enabled ? "Yes" : "No"}</Tag>
                  </td>
                </tr>
              ))}
            </tbody>
          </DataTable>
        </TableBox>
      </Panel>

      <Panel
        title="Custom rules"
        subtitle="Regex tambahan — nama sama akan menggantikan rule lama"
        actions={
          <button className="btn hover:!border-danger hover:!text-danger-ink" onClick={clearRules} disabled={busy}>
            Hapus semua
          </button>
        }
      >
        <form onSubmit={addRule} className="flex flex-wrap items-end gap-3">
          <Field label="Nama" className="w-40">
            <input className="input mt-1.5" placeholder="my-rule-1" value={rule.name} onChange={(e) => setRule({ ...rule, name: e.target.value })} required />
          </Field>
          <Field label="Pattern (regex)" className="flex-1 min-w-[220px]">
            <input className="input mt-1.5 mono" placeholder="(?i)foo.{0,20}bar" value={rule.pattern} onChange={(e) => setRule({ ...rule, pattern: e.target.value })} required />
          </Field>
          <Field label="Score" className="w-24">
            <input className="input mt-1.5 tabular" inputMode="numeric" placeholder="40" value={rule.score} onChange={(e) => setRule({ ...rule, score: e.target.value.replace(/[^0-9]/g, "") })} />
          </Field>
          <button className="btn-primary h-[38px]" disabled={busy}>Tambah rule</button>
        </form>
      </Panel>
    </Stack>
  );
}

function RateLimit() {
  const [data, setData] = useState<any>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [note, setNote] = useState("");
  const [draft, setDraft] = useState<any>(null);
  const [newPath, setNewPath] = useState("");
  const [newRps, setNewRps] = useState("");

  async function load(keepDraft = false) {
    try {
      const d = await gsGet("ratelimit");
      setData(d);
      setErr("");
      if (!keepDraft && !draft) setDraft(d.config || {});
    } catch (e: any) {
      setErr(e.message);
    }
  }
  useEffect(() => {
    load();
    const iv = setInterval(() => load(true), 3000);
    return () => clearInterval(iv);
  }, []);

  if (err && !data) return <ErrorCard message={err} />;
  const c = data?.config || {};
  const s = data?.stats || {};
  const d = draft || c;
  const pathRules: any[] = Array.isArray(d.pathRules) ? d.pathRules : [];

  function field(name: string, value: string | number) {
    setDraft({ ...d, [name]: value === "" ? 0 : Number(value) });
  }

  function addPath(e: React.FormEvent) {
    e.preventDefault();
    const path = newPath.trim();
    if (!path) return;
    const next = [...pathRules, { path, ...(newRps.trim() ? { rps: Number(newRps) } : {}) }];
    setDraft({ ...d, pathRules: next });
    setNewPath("");
    setNewRps("");
  }

  function removePath(i: number) {
    setDraft({ ...d, pathRules: pathRules.filter((_, j) => j !== i) });
  }

  async function save() {
    setBusy(true);
    setErr("");
    setNote("");
    try {
      const resp = await gsPost("ratelimit", { ...d, pathRules });
      setData(resp);
      setDraft(resp.config || { ...d, pathRules });
      setNote("Rate policy disimpan ke engine.");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <Stack className="gap-4">
      {err ? <ErrorCard message={err} /> : null}
      {note ? <div role="status" className="card flex items-center gap-2 text-[13px] text-ok-ink"><Icon name="check" size={16} />{note}</div> : null}

      <MetricGrid>
        <MetricCard label="Global RPS" value={s.globalRPS ?? "—"} />
        <MetricCard label="Effective IP RPS" value={s.effectiveIPRPS != null ? Math.round(s.effectiveIPRPS) : "—"} />
        <MetricCard label="Dropped" value={fmtNum(s.droppedCount)} tone="danger" />
        <MetricCard label="Throttled IP" value={s.throttledIPs ?? "—"} tone="warn" />
      </MetricGrid>

      <Panel
        title="Rate policy"
        subtitle="Draft edit lokal — klik simpan untuk menerapkan ke engine"
        actions={
          <button className="btn-primary h-[34px]" onClick={save} disabled={busy}>
            Simpan policy
          </button>
        }
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Per-IP RPS">
            <input className="input mt-1.5 tabular" inputMode="numeric" value={d.perIPRPS ?? ""} onChange={(e) => field("perIPRPS", e.target.value)} />
          </Field>
          <Field label="Per-IP Burst">
            <input className="input mt-1.5 tabular" inputMode="numeric" value={d.perIPBurst ?? ""} onChange={(e) => field("perIPBurst", e.target.value)} />
          </Field>
          <Field label="Per-Path RPS">
            <input className="input mt-1.5 tabular" inputMode="numeric" value={d.perPathRPS ?? ""} onChange={(e) => field("perPathRPS", e.target.value)} />
          </Field>
          <Field label="Global Max RPS">
            <input className="input mt-1.5 tabular" inputMode="numeric" value={d.globalMaxRPS ?? ""} onChange={(e) => field("globalMaxRPS", e.target.value)} />
          </Field>
          <Field label="Sliding Window (ms)">
            <input className="input mt-1.5 tabular" inputMode="numeric" value={d.slidingWindowMs ?? ""} onChange={(e) => field("slidingWindowMs", e.target.value)} />
          </Field>
          <Field label="Adaptive">
            <div className="mt-2">
              <button
                className={d.adaptive ? "btn-primary h-[34px]" : "btn h-[34px]"}
                onClick={() => setDraft({ ...d, adaptive: !d.adaptive })}
                aria-pressed={!!d.adaptive}
              >
                {d.adaptive ? "Aktif" : "Off"}
              </button>
            </div>
          </Field>
        </div>
      </Panel>

      <Panel title="Path rules" subtitle="Limit per path tertentu (default per-path berlaku untuk semua)" bodyClassName="">
        <form onSubmit={addPath} className="flex flex-wrap items-end gap-3">
          <Field label="Path" className="flex-1 min-w-[200px]">
            <input className="input mt-1.5 mono" placeholder="/api/login" value={newPath} onChange={(e) => setNewPath(e.target.value)} />
          </Field>
          <Field label="RPS (opsional)" className="w-28">
            <input className="input mt-1.5 tabular" inputMode="numeric" placeholder="20" value={newRps} onChange={(e) => setNewRps(e.target.value.replace(/[^0-9]/g, ""))} />
          </Field>
          <button className="btn-primary h-[38px]" disabled={!newPath.trim()}>Tambah path</button>
        </form>

        {pathRules.length === 0 ? (
          <EmptyState title="Belum ada path rule" description="Tambahkan path dengan limit khusus di atas." icon="ratelimit" />
        ) : (
          <div className="mt-4">
            <DataTable minWidth={false}>
              <thead>
                <tr><th>Path</th><th className="text-right">RPS</th><th className="text-right">Aksi</th></tr>
              </thead>
              <tbody>
                {pathRules.map((p, i) => (
                  <tr key={i}>
                    <td className="mono">{p.path}</td>
                    <td className="text-right tabular">{p.rps ?? "default"}</td>
                    <td className="text-right">
                      <button className="btn px-2.5 py-1 text-[12px] hover:!border-danger hover:!text-danger-ink" onClick={() => removePath(i)}>
                        Hapus
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </div>
        )}
      </Panel>
    </Stack>
  );
}

/* Protect = subdomain / per-host access gate ("Verify Browser" interstitial).
   Backed by /api/access/hosts and /api/access/protectall: protectAll gates every
   host, while the per-host map lets you enable the interstitial on selected
   subdomains only. */
function Protect() {
  const [hosts, setHosts] = useState<Record<string, boolean>>({});
  const [protectAll, setProtectAll] = useState(false);
  const [cookie, setCookie] = useState<any>(null);
  const [host, setHost] = useState("");
  const [port, setPort] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  async function load() {
    try {
      const d = await gsGet("access/hosts");
      setHosts(d.hosts || {});
      setProtectAll(!!d.protectAll);
      setErr("");
    } catch (e: any) {
      setErr(e.message);
    }
    try {
      setCookie(await gsGet("access/cookietokens"));
    } catch {
      /* cookie config is optional context, not a blocker */
    }
  }

  useEffect(() => {
    load();
    const iv = setInterval(load, 5000);
    return () => clearInterval(iv);
  }, []);

  async function setHostEnabled(name: string, enabled: boolean) {
    setBusy(true);
    try {
      await gsPost("access/hosts", { host: name, enabled });
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function toggleAll() {
    setBusy(true);
    try {
      await gsPost("access/protectall", { enabled: !protectAll });
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function removeHost(name: string) {
    setBusy(true);
    try {
      await gsPost("access/hosts/remove", { host: name });
      await load();
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function addHost(e: React.FormEvent) {
    e.preventDefault();
    const raw = host.trim().toLowerCase();
    if (!raw) return;
    // Port opsional: engine mencocokkan Host header, yang menyertakan port
    // hanya bila non-standar. Menyimpan "host:port" membuat entry cocok dengan
    // apa yang benar-benar dikirim browser pada listener non-80/443.
    const p = port.trim();
    const name = p ? `${raw}:${p}` : raw;
    setHost("");
    setPort("");
    await setHostEnabled(name, true);
  }

  const entries = Object.entries(hosts);

  return (
    <Stack className="gap-4">
      {err ? <ErrorCard message={err} /> : null}

      <div className="flex flex-wrap gap-3">
        <Stat label="Protect All Host" value={protectAll ? "ON" : "OFF"} tone={protectAll ? "text-ok-ink" : "text-muted"} hint="gate semua host" />
        <Stat label="Host Terdaftar" value={entries.length} hint="per-subdomain" />
        <Stat label="Host Aktif" value={entries.filter(([, on]) => on).length} tone="text-ok-ink" />
        <Stat label="Cookie" value={cookie?.cookieName || "—"} hint={cookie?.cookieSecure ? "secure" : "non-secure"} />
      </div>

      <Panel
        title="Verify Browser · Subdomain Protect"
        subtitle="Interstitial untuk pengunjung pertama"
        actions={
          <button className="btn" onClick={toggleAll} disabled={busy}>
            {protectAll ? "Matikan Protect All" : "Aktifkan Protect All"}
          </button>
        }
      >
        <div className="space-y-3">
          <p className="text-[13px] text-muted leading-relaxed">
            Interstitial ringan untuk pengunjung pertama. Klien non-browser (curl, skrip) diblokir,
            bukan di-challenge. Aktifkan hanya pada subdomain yang perlu, atau nyalakan{" "}
            <span className="text-slate-900">Protect All</span> untuk seluruh host.
          </p>
          <form onSubmit={addHost} className="flex flex-wrap gap-2 items-end">
            <div className="flex-1 min-w-[220px]">
              <label className="metric-label" htmlFor="protect-host">Host / subdomain</label>
              <input id="protect-host" className="input mt-1" placeholder="mis. app.example.com" value={host} onChange={(e) => setHost(e.target.value)} />
            </div>
            <div className="w-28">
              <label className="metric-label" htmlFor="protect-port">Port (opsional)</label>
              <input id="protect-port" className="input mt-1" placeholder="8080" value={port} onChange={(e) => setPort(e.target.value.replace(/[^0-9]/g, ""))} inputMode="numeric" />
            </div>
            <button className="btn-primary h-[38px]" disabled={busy || !host.trim()}>Lindungi Host</button>
          </form>
        </div>
      </Panel>

      <Panel title="Host terlindungi" actions={<Tag tone="muted">{entries.length} host</Tag>} bodyClassName="">
        {entries.length === 0 ? (
          <div className="p-4">
            <EmptyState title="Belum ada host terdaftar" description="Tambahkan subdomain di atas untuk menyalakan gate." icon={<Icon name="protect" size={20} />} />
          </div>
        ) : (
          <TableBox>
            <DataTable minWidth={false}>
              <thead>
                <tr><th>Host</th><th>Status</th><th className="text-right">Aksi</th></tr>
              </thead>
              <tbody>
                {entries.map(([name, on]) => (
                  <tr key={name}>
                    <td className="mono">{name}</td>
                    <td><Tag tone={on ? "ok" : "muted"}>{on ? "PROTECTED" : "OFF"}</Tag></td>
                    <td className="text-right">
                      <div className="inline-flex gap-2">
                        <button className="btn px-2.5 py-1 text-[12px]" onClick={() => setHostEnabled(name, !on)} disabled={busy}>
                          {on ? "Matikan" : "Aktifkan"}
                        </button>
                        <button className="btn px-2.5 py-1 text-[12px] hover:!border-danger hover:!text-danger-ink" onClick={() => removeHost(name)} disabled={busy} aria-label={`Hapus ${name}`}>
                          Hapus
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </TableBox>
        )}
      </Panel>
    </Stack>
  );
}

/* Cluster = node topology + sync bus health. Everything shown here comes from
   the authenticated /api/cluster endpoint; nothing is inferred client-side. */
function Cluster({ cluster }: { cluster: ReturnType<typeof useCluster> }) {
  const info = cluster.data;
  if (cluster.loading && !info) {
    return (
      <Stack className="gap-4">
        <Panel title="Sync bus"><SkeletonBlock rows={3} label="Memuat topologi node…" /></Panel>
        <Panel title="Node"><SkeletonBlock rows={3} /></Panel>
      </Stack>
    );
  }
  if (cluster.error && !info) {
    return (
      <Panel bodyClassName="p-0">
        <ErrorState
          title="Unable to load cluster status"
          description="The protection engine did not return sync node information."
          detail={cluster.error}
          onRetry={cluster.reload}
        />
      </Panel>
    );
  }
  if (!info) return null;

  const single = info.mode === "single";
  return (
    <Stack className="gap-4">
      <Panel
        title="Sync bus"
        subtitle={single ? "Single-node mode — multi-node sync is off" : "Multi-node sync via shared bus"}
        actions={<Tag tone={nodeTone(info)}>{info.state.toUpperCase()}</Tag>}
      >
        <Stack>
          {/* "N / N Online" — the headline operators look for first. */}
          <div className="flex flex-wrap items-baseline gap-3">
            <span className="metric-value text-slate-900">{info.onlineNodes}/{info.expectedNodes} Online</span>
            {info.degraded ? <Tag tone="danger">DEGRADED</Tag> : single ? <Tag tone="muted">SINGLE NODE</Tag> : null}
          </div>
          <div className="row text-[11px] text-muted">
            <StatusDot tone={info.subscribed ? "ok" : "warn"} pulse={info.subscribed} />
            <span>{info.subscribed ? "Subscribed to shared sync bus" : single ? "Shared bus not required in single-node mode" : "Waiting for shared bus"}</span>
          </div>
          {/* Optional peers missing is normal for a one-node deployment, so it
              reads as an explanation rather than an alarm. */}
          {!single && info.state === "partial" ? (
            <Note>
              {info.onlineNodes} of {info.expectedNodes} nodes online. Optional peers stay optional — this node keeps protecting traffic on its own.
            </Note>
          ) : null}
          {info.state === "degraded" ? (
            <Note accent>
              A required node is offline or the shared bus is unavailable{info.requiredOffline > 0 ? ` (${info.requiredOffline} required node)` : ""}. Protection on this edge is unaffected.
            </Note>
          ) : null}
          {info.lastError ? <Note accent>Last sync error: {info.lastError}</Note> : null}
        </Stack>
      </Panel>

      <Panel title="Node" subtitle="Configured topology">
        <NodeRows nodes={info.nodes} loading={false} />
      </Panel>

      <MetricGrid cols={2}>
        <Panel title="Sync metrics">
          <KeyValue label="Node ID">{info.nodeId}</KeyValue>
          <KeyValue label="Role">{info.role || "all"}</KeyValue>
          <KeyValue label="Site">{info.site || "—"}</KeyValue>
          <KeyValue label="Heartbeat">{info.heartbeatMs ? `${info.heartbeatMs} ms` : "—"}</KeyValue>
          <KeyValue label="Reconnects">{fmtNum(info.reconnects)}</KeyValue>
        </Panel>
        <Panel title="Freshness">
          <KeyValue label="Last published">{fmtAgo(info.lastSentMs)}</KeyValue>
          <KeyValue label="Last applied sync">{fmtAgo(info.lastSyncMs)}</KeyValue>
          <KeyValue label="Last seen peer">{fmtAgo(info.lastSeenMs)}</KeyValue>
          <KeyValue label="Ops applied">{fmtNum(info.appliedOps)}</KeyValue>
          <KeyValue label="Required offline">{fmtNum(info.requiredOffline)}</KeyValue>
        </Panel>
      </MetricGrid>
    </Stack>
  );
}

function latencyTone(ms: number): Tone {
  if (!ms) return "muted";
  if (ms <= 300) return "ok";
  if (ms <= 1500) return "warn";
  return "muted";
}

/* Proxy Fleet mirrors the Cluster panel: live numbers from the outbound-only
   fleet agent (via the BFF bridge), never a client-side key. The agent keeps
   the proxy list fresh itself; this panel only reads and can nudge a refresh. */
function ProxyFleet() {
  const stats = usePoller<any>(() => gsGet("proxy/stats"), 5000);
  const list = usePoller<any>(() => gsGet("proxy/proxies/active", "?meta=1&limit=60"), 5000);
  const [busy, setBusy] = useState(false);
  const [probeHost, setProbeHost] = useState("");
  const [probe, setProbe] = useState<any>(null);
  const [probeErr, setProbeErr] = useState("");

  const s = stats.data;
  const notConfigured = stats.error === "503" || list.error === "503";

  if (notConfigured) {
    return (
      <Panel bodyClassName="p-0">
        <EmptyState
          icon="◇"
          title="Proxy fleet belum dikonfigurasi"
          description="Set PROXY_AGENT_URL(S) + PROXY_AGENT_TOKEN pada lingkungan web agar panel ini tampil."
        />
      </Panel>
    );
  }
  if (stats.loading && !s) {
    return (
      <Stack className="gap-4">
        <SkeletonCards count={4} />
        <Panel title="Proxy aktif"><SkeletonBlock rows={4} label="Memuat armada proxy…" /></Panel>
      </Stack>
    );
  }
  if (stats.error && !s) {
    return (
      <Panel bodyClassName="p-0">
        <ErrorState
          title="Proxy agent tidak terjangkau"
          description="Dashboard tidak bisa menghubungi agen proxy. Armada mungkin sedang hidup; panel akan pulih otomatis."
          detail={stats.error}
          onRetry={stats.reload}
        />
      </Panel>
    );
  }

  const meta = s?.meta || {};
  const counters = s?.counters || {};
  const active = Number(meta.active ?? s?.active ?? 0);
  const fresh = Number(meta.fresh ?? 0);
  const checkedAt = Number(meta.checkedAt ?? s?.lastRefresh ?? 0);
  const uptime = Number(s?.uptimeMs ?? 0);
  const proxies: { proxy: string; latencyMs: number; stale?: boolean }[] = Array.isArray(list.data?.proxies) ? list.data.proxies : [];

  async function refreshNow() {
    setBusy(true);
    try {
      await gsPost("proxy/refresh", {});
      stats.reload();
      list.reload();
    } catch {
      /* the poller surfaces failures */
    } finally {
      setBusy(false);
    }
  }

  async function runProbe() {
    const host = probeHost.trim();
    if (!host) return;
    setProbeErr("");
    setProbe(null);
    setBusy(true);
    try {
      setProbe(await gsPost("proxy/checkhost", { host }));
    } catch (e: any) {
      setProbeErr(String(e?.message || e));
    } finally {
      setBusy(false);
    }
  }

  const probeRows: [string, any][] =
    probe && probe.result && typeof probe.result === "object" ? Object.entries(probe.result) : [];

  return (
    <Stack className="gap-4">
      <MetricGrid>
        <MetricCard label="Proxy aktif" value={<AnimatedNumber value={active} />} tone={active > 0 ? "ok" : "warn"} hint={fresh ? `${fresh} segar (fresh)` : "menunggu siklus"} />
        <MetricCard label="Siklus refresh" value={fmtNum(counters.refresh || 0)} hint={counters.refreshErrors ? `${counters.refreshErrors} gagal` : "0 gagal"} />
        <MetricCard label="Uji check-host" value={fmtNum(counters.checkhost || 0)} hint={counters.checkhostErrors ? `${counters.checkhostErrors} gagal` : "0 gagal"} />
        <MetricCard label="Uptime agent" value={fmtAgo(uptime)} hint={checkedAt ? `sweep ${fmtAgo(Date.now() - checkedAt)} lalu` : "—"} />
      </MetricGrid>

      <Panel
        title="Proxy aktif"
        subtitle={list.data ? `${proxies.length} dari ${fmtNum(list.data.count ?? proxies.length)} teratas` : "Daftar hidup dari sweep terakhir"}
        actions={
          <>
            <Tag tone={s?.refreshing ? "warn" : active > 0 ? "ok" : "muted"}>
              {s?.refreshing ? "REFRESH…" : active > 0 ? "SIAGA" : "KOSONG"}
            </Tag>
            <button className="btn" onClick={refreshNow} disabled={busy}>
              {busy ? "…" : "Refresh"}
            </button>
          </>
        }
      >
        {list.loading && !list.data ? (
          <SkeletonBlock rows={4} />
        ) : proxies.length === 0 ? (
          <EmptyState
            icon="◇"
            title="Belum ada proxy aktif"
            description="Agen belum menyelesaikan siklus sweep, atau tidak ada proxy Indonesia yang lolos uji."
            action={<button className="btn" onClick={refreshNow} disabled={busy}>Mulai sweep sekarang</button>}
          />
        ) : (
          <TableBox>
            <DataTable>
              <thead>
                <tr>
                  <th>Proxy</th>
                  <th>Latency</th>
                  <th>Kualitas</th>
                </tr>
              </thead>
              <tbody>
                {proxies.map((p, i) => (
                  <tr key={`${p.proxy}-${i}`}>
                    <td className="mono">{p.proxy}</td>
                    <td className="mono tabular">{p.latencyMs ? `${p.latencyMs} ms` : "—"}</td>
                    <td>
                      <Tag tone={p.stale ? "warn" : latencyTone(Number(p.latencyMs))}>
                        {p.stale ? "stale" : p.latencyMs <= 300 ? "cepat" : p.latencyMs <= 1500 ? "sedang" : "lambat"}
                      </Tag>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </TableBox>
        )}
      </Panel>

      <Panel title="Uji keluar lewat proxy" subtitle="Kirim permintaan ke check-host.net memakai proxy aktif — bukan untuk menerima traffic">
        <div className="flex flex-wrap items-end gap-2">
          <label className="min-w-[220px] flex-1 text-[12px]">
            <span className="mb-1 block text-muted">Host tujuan</span>
            <input
              className="input mono"
              placeholder="https://example.com atau gg.garudashield.my.id"
              value={probeHost}
              onChange={(e) => setProbeHost(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") runProbe();
              }}
            />
          </label>
          <button className="btn" onClick={runProbe} disabled={busy || !probeHost.trim()}>
            {busy ? "…" : "Uji"}
          </button>
        </div>
        {probeErr ? (
          <div className="mt-3">
            <Note accent>Gagal: {probeErr}</Note>
          </div>
        ) : null}
        {probe ? (
          <div className="mt-3 space-y-1.5">
            <KeyValue label="Proxy dipakai">{probe.proxy || "—"}</KeyValue>
            <KeyValue label="Sumber hasil">{probe.cached ? "cache" : "live"}</KeyValue>
            {probe.permanent_link ? (
              <div className="kv">
                <span>Laporan lengkap</span>
                <span className="mono">
                  <a className="underline text-slate-900 hover:text-accent-ink" href={probe.permanent_link} target="_blank" rel="noreferrer noopener">
                    check-host.net
                  </a>
                </span>
              </div>
            ) : null}
            {probeRows.length ? (
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {probeRows.map(([node, val]) => {
                  const first = Array.isArray(val) && Array.isArray(val[0]) ? val[0] : null;
                  const status = first ? String(first[2] ?? "") : "";
                  const code = first ? String(first[3] ?? "") : "";
                  const ok = /ok|2\d\d/i.test(`${first ? first[2] : ""}`) || String(first?.[3] || "").startsWith("2") || first?.[2] === "OK";
                  return (
                    <div key={node} className="flex items-center justify-between rounded-lg border border-edge bg-white px-3 py-2">
                      <span className="mono text-[11px] text-muted">{node.replace(".node.check-host.net", "")}</span>
                      <Tag tone={!first ? "muted" : val[0] && (first[2] === "OK" || Number(first[3]) > 0) ? "ok" : "warn"}>
                        {first ? `${first[2] ?? "?"}${first[3] ? " " + first[3] : ""}` : "menunggu"}
                      </Tag>
                    </div>
                  );
                })}
              </div>
            ) : (
              <Note>Belum ada hasil dari node check-host (mungkin masih diproses).</Note>
            )}
          </div>
        ) : null}
      </Panel>
    </Stack>
  );
}

function alertTone(sev: string): Tone {
  const s = String(sev || "").toLowerCase();
  if (s === "danger" || s === "error" || s === "critical") return "danger";
  if (s === "warn" || s === "warning") return "warn";
  if (s === "info" || s === "notice") return "info";
  return "muted";
}

function Alerts() {
  const [data, setData] = useState<any>(null);
  const [hist, setHist] = useState<any[]>([]);
  const [result, setResult] = useState("");
  useEffect(() => {
    gsGet("alerts/config").then(setData).catch(() => setData({ enabled: false }));
    const tick = () => gsGet("alerts/log", "?limit=50")
      .then((d) => setHist(Array.isArray(d?.log) ? d.log : []))
      .catch(() => {});
    tick();
    const iv = setInterval(tick, 5000);
    return () => clearInterval(iv);
  }, []);
  async function test() { try { setResult(""); const d = await gsPost("alerts/test", {}); setResult(JSON.stringify(d.result || d)); } catch (e: any) { setResult(e.message); } }

  const channels: Record<string, boolean> = data?.channels || {};
  const channelNames: [string, string][] = [
    ["discord", "Discord"],
    ["slack", "Slack"],
    ["telegram", "Telegram"],
    ["email", "Email/SMTP"],
  ];

  return (
    <Stack className="gap-4">
      <Panel
        title="Alert channels"
        subtitle="Konfigurasi notifikasi engine (hanya-baca via API)"
        actions={<button className="btn" onClick={test}>Kirim alert uji</button>}
      >
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div className="space-y-2">
            <KeyValue label="Min. Severity">{(data?.minSeverity || "—").toUpperCase()}</KeyValue>
            <KeyValue label="Cooldown">{(data?.cooldownMs ?? data?.cooldown ?? "—")} ms</KeyValue>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {channelNames.map(([key, label]) => {
              const on = !!channels[key];
              return (
                <div key={key} className={`flex items-center justify-between rounded-lg border px-3 py-2 ${on ? "border-blue-300 bg-blue-50" : "border-edge bg-white"}`}>
                  <span className="text-sm font-medium text-slate-900">{label}</span>
                  <Tag tone={on ? "ok" : "muted"}>{on ? "ON" : "OFF"}</Tag>
                </div>
              );
            })}
          </div>
        </div>
        {result ? <div className="mt-3"><Note>Hasil uji: {result}</Note></div> : null}
      </Panel>

      <Panel
        title="Riwayat alert"
        subtitle="Entri yang sudah dikirim ke channel (auto-refresh 5 detik)"
        actions={<Tag tone="muted">{hist.length} entri</Tag>}
        bodyClassName="max-h-[55vh] overflow-auto p-0"
      >
        <TableBox>
          <DataTable>
            <thead>
              <tr>
                <th>Waktu</th>
                <th>Severity</th>
                <th>Judul</th>
                <th className="hidden sm:table-cell">Detail</th>
              </tr>
            </thead>
            <tbody>
              {hist.map((h, i) => (
                <tr key={i}>
                  <td className="text-muted tabular whitespace-nowrap">{new Date(h.time).toLocaleString()}</td>
                  <td><Tag tone={alertTone(h.severity)}>{String(h.severity || "?").toUpperCase()}</Tag></td>
                  <td className="font-medium text-slate-900">{h.title}</td>
                  <td className="hidden sm:table-cell text-muted">{h.detail}</td>
                </tr>
              ))}
            </tbody>
          </DataTable>
          {hist.length === 0 ? <EmptyState title="Belum ada alert" description="Alert muncul setelah severitas melewati ambang &amp; cooldown." icon={<Icon name="alerts" size={20} />} /> : null}
        </TableBox>
      </Panel>
    </Stack>
  );
}

/* Shared table for the simpler tabs. Uses the same data-table chrome as the
   console-wide tables so header weight, padding and hover never drift. */
function SimpleTable({ headers, rows }: { headers: string[]; rows: any[][] }) {
  return (
    <TableBox>
      <DataTable>
        <thead>
          <tr>
            {headers.map((h) => (
              <th key={h}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, i) => (
            <tr key={i}>
              {row.map((cell, j) => (
                <td key={j}>{String(cell)}</td>
              ))}
            </tr>
          ))}
        </tbody>
      </DataTable>
      {rows.length === 0 ? <EmptyState title="Belum ada data" description="Data akan muncul setelah engine mencatat aktivitas." icon={<Icon name="logs" size={20} />} /> : null}
    </TableBox>
  );
}

function Logs() {
  const [rows, setRows] = useState<any[]>([]);
  const [filter, setFilter] = useState("all");
  const [limit, setLimit] = useState(100);
  const [running, setRunning] = useState(true);
  const [query, setQuery] = useState("");
  useEffect(() => {
    let iv: ReturnType<typeof setInterval> | null = null;
    const tick = () =>
      gsGet("logs", `?limit=${limit}`)
        .then((d) => setRows(d.logs || []))
        .catch(() => {});
    tick();
    if (running) iv = setInterval(tick, 5000);
    return () => { if (iv) clearInterval(iv); };
  }, [limit, running]);

  const shown = useMemo(
    () =>
      filterRows(
        rows,
        query,
        ["type", "ip", "detail", "reason"],
        (r: any) => filter === "all" || String(r.type || "").toLowerCase().includes(filter),
      ),
    [rows, filter, query],
  );
  const filters: ReadonlyArray<readonly [string, string]> = [["all", "Semua"], ["block", "Block"], ["challenge", "Challenge"]];

  function exportCsv() {
    downloadCsv(
      csvFilename("logs"),
      ["Waktu", "Tipe", "IP", "Score", "Alasan"],
      shown.map((r: any) => [
        r.time ? new Date(r.time).toISOString() : "",
        r.type || "",
        r.ip || "",
        typeof r.score === "number" ? r.score : "",
        r.detail || r.reason || "",
      ]),
    );
  }

  return (
    <Panel
      title="Event log"
      subtitle={`${shown.length} entri (auto-refresh ${running ? "5 detik" : "jeda"})`}
      bodyClassName="max-h-[70vh] overflow-auto p-0"
      actions={
        <div className="flex flex-wrap items-center gap-2">
          <Segmented options={filters} value={filter} onChange={setFilter} ariaLabel="Filter tipe log" />
          <SearchInput value={query} onChange={setQuery} placeholder="Cari IP / alasan…" ariaLabel="Cari log" className="w-44" />
          <label className="flex items-center gap-1.5 text-[12px] text-muted">
            Limit
            <select
              className="rounded-lg border border-edge bg-white px-1.5 py-1 text-[12px]"
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
            >
              <option value={50}>50</option>
              <option value={100}>100</option>
              <option value={200}>200</option>
              <option value={500}>500</option>
            </select>
          </label>
          <ExportButton onClick={exportCsv} disabled={shown.length === 0} title="Ekspor hasil filter ke CSV" />
          <button
            className="btn px-2.5 py-1 text-[12px]"
            onClick={() => setRunning((v) => !v)}
            aria-pressed={running}
            title={running ? "Jeda auto-refresh" : "Aktifkan auto-refresh"}
          >
            <Icon name={running ? "pause" : "play"} size={14} />
          </button>
        </div>
      }
    >
      <TableBox>
        <DataTable>
          <thead>
            <tr>
              <th>Waktu</th>
              <th>Tipe</th>
              <th>IP</th>
              <th className="text-right">Score</th>
              <th>Alasan</th>
            </tr>
          </thead>
          <tbody>
            {shown.map((r, i) => (
              <tr key={i}>
                <td className="text-muted tabular whitespace-nowrap">{new Date(r.time).toLocaleTimeString()}</td>
                <td>
                  <Tag tone={logTone(r.type)}>{r.type}</Tag>
                </td>
                <td className="mono">{r.ip}</td>
                <td className="text-right tabular">{typeof r.score === "number" ? r.score : "—"}</td>
                <td className="text-muted">{r.detail || r.reason || "—"}</td>
              </tr>
            ))}
          </tbody>
        </DataTable>
        {rows.length === 0 ? (
          <EmptyState title="Log masih kosong" description="Entri muncul saat engine mencatat keputusan pada request." icon={<Icon name="logs" size={20} />} />
        ) : shown.length === 0 ? (
          <EmptyState title="Tidak ada hasil" description="Tidak ada log yang cocok dengan filter atau pencarian." icon={<Icon name="search" size={20} />} />
        ) : null}
      </TableBox>
    </Panel>
  );
}

/* Log severity by type name so the column scans without reading every reason. */
function logTone(type: string): Tone {
  const t = String(type || "").toLowerCase();
  if (t.includes("block")) return "danger";
  if (t.includes("challenge")) return "warn";
  if (t.includes("allow") || t.includes("pass")) return "ok";
  return "muted";
}

/* Sparkline: 60 samples of the already-polled series, drawn as an area + line
   with a labelled last value. Cyan is the single chart highlight so a reader
   scans one series, not a rainbow. */
function Sparkline({ data, color, label, format, fill = true }: { data: number[]; color: string; label: string; format: (v: number) => string; fill?: boolean }) {
  const w = 600;
  const h = 120;
  const max = Math.max(1, ...data);
  const step = data.length > 1 ? w / (data.length - 1) : w;
  const pts = data.map((v, i) => `${(i * step).toFixed(1)},${(h - (v / max) * (h - 10) - 4).toFixed(1)}`).join(" ");
  const area = data.length > 0 ? `0,${h} ${pts} ${((data.length - 1) * step).toFixed(1)},${h}` : "";
  const last = data.length > 0 ? data[data.length - 1] : 0;
  return (
    <div className={`panel${fill ? " h-full" : ""}`}>
      <div className="panel-head">
        <span className="panel-title">{label}</span>
        <span className="font-display text-sm font-bold tabular text-slate-900">{format(last)}</span>
      </div>
      <div className="px-4 pt-3 pb-1">
        <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-24" preserveAspectRatio="none" role="img" aria-label={`${label}: ${format(last)}`}>
          <line x1="0" y1={h - 4} x2={w} y2={h - 4} stroke="#E5E7EB" strokeWidth={1} vectorEffect="non-scaling-stroke" />
          <line x1="0" y1={h / 2} x2={w} y2={h / 2} stroke="#F5F7FA" strokeWidth={1} vectorEffect="non-scaling-stroke" />
          {area && <polygon points={area} fill={color} opacity={0.1} />}
          {data.length > 1 && <polyline points={pts} fill="none" stroke={color} strokeWidth={2} strokeLinejoin="round" strokeLinecap="round" vectorEffect="non-scaling-stroke" />}
        </svg>
      </div>
      <div className="flex items-center justify-between px-5 pb-3.5 text-[11px] text-muted">
        <span>window 60 detik</span>
        <span>puncak {format(max)}</span>
      </div>
    </div>
  );
}

function Charts({ stats, history, loading }: { stats: Stats; history: Sample[]; loading: boolean }) {
  const rpsSeries = history.map((h) => h.rps);
  const bpsSeries = history.map((h) => h.bps);
  return (
    <Stack className="gap-4">
      <MetricGrid cols={4}>
        <MetricCard label="RPS Saat Ini" value={stats?.currentRps != null ? <AnimatedNumber value={stats.currentRps} /> : "—"} tone="accent" loading={loading} />
        <MetricCard label="Peak RPS" value={stats?.peakRps != null ? <AnimatedNumber value={stats.peakRps} /> : "—"} loading={loading} />
        <MetricCard label="Total Traffic" value={<AnimatedNumber value={stats?.bytesIn} format={formatBytes} />} loading={loading} />
        <MetricCard label="Volume DDoS Diblokir" value={<AnimatedNumber value={stats?.blockedBytes} format={formatBytes} />} tone="danger" loading={loading} />
      </MetricGrid>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Sparkline data={rpsSeries} color="#D4AF37" label="Request / detik" format={(v) => `${Math.round(v)} rps`} />
        <Sparkline data={bpsSeries} color="#0A192F" label="Bandwidth masuk / detik" format={(v) => `${formatBytes(v)}/s`} />
      </div>
      <Note><span className="font-semibold text-slate-900">Volume DDoS diblokir</span> menghitung total byte payload dari semua request yang diblokir engine (WAF, rate-limit, reputation, Layer 4/7). Ditampilkan otomatis dalam B / KB / MB / GB / TB.</Note>
    </Stack>
  );
}

/* Traffic memisahkan pandangan throughput dari Charts: fokus pada laju masuk,
   verdict split (pass/block/challenge), dan sumber teraktif — pertanyaan
   pertama saat traffic melonjak. */
function Traffic({ stats, history, loading }: { stats: Stats; history: Sample[]; loading: boolean }) {
  const rpsSeries = history.map((h) => h.rps);
  const bpsSeries = history.map((h) => h.bps);
  const passed = Number(stats?.passed || 0);
  const blocked = Number(stats?.blocked || 0);
  const challenged = Number(stats?.challenged || 0);
  const total = Math.max(1, passed + blocked + challenged);
  const pct = (n: number) => `${((n / total) * 100).toFixed(1)}%`;

  return (
    <Stack className="gap-4">
      <MetricGrid>
        <Stat label="RPS Saat Ini" value={<AnimatedNumber value={stats?.currentRps ?? 0} />} tone="text-accent-ink" loading={loading} />
        <Stat label="Peak RPS" value={stats?.peakRps != null ? <AnimatedNumber value={stats.peakRps} /> : "—"} loading={loading} />
        <Stat label="Bandwidth" value={<span><AnimatedNumber value={stats?.bandwidthBps || 0} format={formatBytes} />/s</span>} tone="text-accent-ink" loading={loading} />
        <Stat label="Total Ingress" value={<AnimatedNumber value={stats?.bytesIn} format={formatBytes} />} hint="kumulatif" loading={loading} />
      </MetricGrid>
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Sparkline data={rpsSeries} color="#D4AF37" label="Request / detik" format={(v) => `${Math.round(v)} rps`} />
        <Sparkline data={bpsSeries} color="#0A192F" label="Bandwidth masuk / detik" format={(v) => `${formatBytes(v)}/s`} />
      </div>

      <Panel title="Verdict split" subtitle="Proporsi keputusan engine" actions={<Tag tone="muted">{fmtNum(total)} keputusan</Tag>}>
        <div className="verdict-legend">
          <span className="verdict-legend-item"><i className="verdict-key verdict-pass" /> Diizinkan <b className="tabular">{fmtNum(passed)}</b></span>
          <span className="verdict-legend-item"><i className="verdict-key verdict-challenge" /> Challenge <b className="tabular">{fmtNum(challenged)}</b></span>
          <span className="verdict-legend-item"><i className="verdict-key verdict-block" /> Diblokir <b className="tabular">{fmtNum(blocked)}</b></span>
        </div>
        <div
          className="verdict-bar verdict-bar-tall mt-3"
          role="img"
          aria-label={`Diizinkan ${pct(passed)}, challenge ${pct(challenged)}, diblokir ${pct(blocked)}`}
        >
          <span className="verdict-pass" style={{ width: pct(passed) }} />
          <span className="verdict-challenge" style={{ width: pct(challenged) }} />
          <span className="verdict-block" style={{ width: pct(blocked) }} />
        </div>
        <div className="mt-4 grid grid-cols-3 gap-3 border-t border-edge pt-4">
          <div><div className="metric-label">Diizinkan</div><div className="text-ok-ink tabular text-base font-semibold">{pct(passed)}</div></div>
          <div><div className="metric-label">Challenge</div><div className="text-warn-ink tabular text-base font-semibold">{pct(challenged)}</div></div>
          <div><div className="metric-label">Diblokir</div><div className="text-danger-ink tabular text-base font-semibold">{pct(blocked)}</div></div>
        </div>
      </Panel>

      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <FreqTable title="Sumber teraktif" rows={(stats?.topIps || []) as [string, number][]} headLabel="IP" />
        <FreqTable title="Path teraktif" rows={(stats?.topPaths || []) as [string, number][]} headLabel="Path" />
      </div>
    </Stack>
  );
}

/* GeoMap: pulls geo-enriched traffic sources from the engine's /api/geo
   endpoint (enabled in the config under `geo`). When geo is disabled or no
   database is loaded, the engine reports available=false and we degrade
   gracefully to the raw top-IP list instead of showing a fake map. */
type GeoSource = { ip: string; requests: number; countryCode?: string; country?: string; asn?: string; org?: string };
type GeoCountry = { code: string; country?: string; requests: number; sources: number };
type GeoData = { available: boolean; sources: GeoSource[]; countries: GeoCountry[] };

function GeoMap({ stats, loading }: { stats: Stats; loading: boolean }) {
  const [geo, setGeo] = useState<GeoData | null>(null);
  const [geoLoading, setGeoLoading] = useState(true);
  const ips = (stats?.topIps || []) as [string, number][];
  const blocklist = (stats?.blocklist || []) as { ip: string; reason?: string }[];
  const maxReq = Math.max(1, ...ips.map((r) => r[1]));

  useEffect(() => {
    let active = true;
    gsGet("geo")
      .then((d: GeoData) => { if (active) setGeo(d); })
      .catch(() => { if (active) setGeo({ available: false, sources: [], countries: [] }); })
      .finally(() => { if (active) setGeoLoading(false); });
    return () => { active = false; };
  }, [stats]);

  const enriched = (geo?.sources || []).length > 0;
  const maxGeoReq = Math.max(1, ...(geo?.sources || []).map((s) => s.requests));

  return (
    <Stack className="gap-4">
      <div className="metric-grid">
        <Stat label="Sumber Unik" value={ips.length} hint="window aktif" loading={loading} />
        <Stat label="IP Diblokir" value={blocklist.length} tone="text-danger-ink" loading={loading} />
        <Stat label="Total Request" value={fmtNum(stats?.processed)} loading={loading} />
        <Stat
          label="Negara"
          value={geo?.available ? (geo.countries?.length || 0) : "—"}
          hint={geoLoading ? "memuat…" : geo?.available ? "dari GeoIP" : "geo nonaktif"}
          loading={loading || geoLoading}
        />
      </div>

      {!geo?.available && (
        <Note>
          <span className="font-semibold text-slate-900">GeoIP nonaktif.</span> Aktifkan blok <code className="mono">geo</code> di config
          dan unduh database MMDB (lihat <code className="mono">tools/fetch-geodb.ps1</code>) untuk melihat distribusi negara &amp; ASN.
          Sumber traffic tetap ditampilkan apa adanya.
        </Note>
      )}

      {geo?.available && geo.countries.length > 0 && (
        <Panel title="Distribusi negara" subtitle="Agregasi sumber traffic per negara" actions={<Tag tone="muted">{geo.countries.length} negara</Tag>}>
          <TableBox>
            <DataTable>
              <thead><tr><th>Negara</th><th className="text-right">Request</th><th className="text-right">Sumber</th></tr></thead>
              <tbody>
                {geo.countries.map((c) => (
                  <tr key={c.code}>
                    <td className="mono">{c.code}{c.country ? ` · ${c.country}` : ""}</td>
                    <td className="text-right tabular">{fmtNum(c.requests)}</td>
                    <td className="text-right tabular">{c.sources}</td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </TableBox>
        </Panel>
      )}

      <Panel
        title="Sumber traffic"
        actions={<Tag tone="muted">{enriched ? `${geo?.sources.length} IP` : `${ips.length} IP`}</Tag>}
      >
        {enriched ? (
          <TableBox>
            <DataTable>
              <thead><tr><th>IP Address</th><th>Lokasi</th><th className="hidden sm:table-cell">ASN</th><th className="text-right">Request</th></tr></thead>
              <tbody>
                {geo?.sources.map((s) => (
                  <tr key={s.ip}>
                    <td className="mono">{s.ip}</td>
                    <td className="text-xs">{s.countryCode ? `${s.countryCode}${s.country ? ` · ${s.country}` : ""}` : <span className="text-muted">—</span>}</td>
                    <td className="mono text-xs hidden sm:table-cell">{s.asn ? `${s.asn}${s.org ? ` (${s.org})` : ""}` : <span className="text-muted">—</span>}</td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="geo-bar"><span style={{ width: `${(s.requests / maxGeoReq) * 100}%` }} /></span>
                        <span className="tabular w-12 text-right">{s.requests}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </TableBox>
        ) : loading ? (
          <SkeletonBlock rows={4} label="Memuat sumber traffic…" />
        ) : ips.length === 0 ? (
          <EmptyState title="Belum ada traffic tercatat" description="Sumber traffic akan muncul di sini setelah engine menerima request." />
        ) : (
          <TableBox>
            <DataTable>
              <thead><tr><th>IP Address</th><th>Lokasi</th><th className="text-right">Request</th></tr></thead>
              <tbody>
                {ips.map(([ip, count]) => (
                  <tr key={ip}>
                    <td className="mono">{ip}</td>
                    <td className="text-muted text-xs">— <span className="text-muted">geo belum aktif</span></td>
                    <td className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="geo-bar"><span style={{ width: `${(count / maxReq) * 100}%` }} /></span>
                        <span className="tabular w-12 text-right">{count}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </DataTable>
          </TableBox>
        )}
      </Panel>
    </Stack>
  );
}

/* Settings mengumpulkan kontrol runtime yang sebelumnya hanya bisa lewat API:
   shield mode, reset counter, dan snapshot konfigurasi/backup. */
function Settings({ stats }: { stats: Stats }) {
  const [config, setConfig] = useState<any>(null);
  const [err, setErr] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    gsGet("config").then(setConfig).catch((e) => setErr(e.message));
  }, []);

  const mode = stats?.emergency ? "emergency" : stats?.aggressive ? "aggressive" : "normal";
  const server = config?.server || {};
  const upstream = config?.upstream || {};

  async function setMode(next: string) {
    setBusy(true);
    setNote("");
    try {
      if (next === "emergency") {
        await gsPost("emergency", { enabled: true });
      } else {
        await gsPost("emergency", { enabled: false });
        await gsPost("mode", { mode: next });
      }
      setNote(`Mode diubah ke ${next}.`);
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function resetCounters() {
    setBusy(true);
    setNote("");
    try {
      await gsPost("reset", {});
      setNote("Counter, blocklist, dan reputasi direset.");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  async function downloadBackup() {
    setBusy(true);
    try {
      const snap = await gsGet("backup");
      const blob = new Blob([JSON.stringify(snap, null, 2)], { type: "application/json" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `garudashield-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click();
      URL.revokeObjectURL(url);
      setNote("Backup diunduh.");
    } catch (e: any) {
      setErr(e.message);
    } finally {
      setBusy(false);
    }
  }

  const [restoreFile, setRestoreFile] = useState<File | null>(null);
  const [restoreBusy, setRestoreBusy] = useState(false);
  const [restoreErr, setRestoreErr] = useState("");
  const [restoreMsg, setRestoreMsg] = useState("");

  async function applyRestore() {
    if (!restoreFile) return;
    setRestoreBusy(true);
    setRestoreErr("");
    setRestoreMsg("");
    try {
      const text = await restoreFile.text();
      const payload = JSON.parse(text);
      await gsPost("backup/restore", payload);
      setRestoreMsg("Backup berhasil dipulihkan.");
      setRestoreFile(null);
    } catch (e: any) {
      setRestoreErr(e.message || "Gagal memulihkan backup");
    } finally {
      setRestoreBusy(false);
    }
  }
  return (
    <Stack className="gap-4">
      {err ? <ErrorCard message={err} /> : null}
      {note ? <div role="status" className="card flex items-center gap-2 text-[13px] text-ok-ink"><Icon name="check" size={16} />{note}</div> : null}
      <div className="grid grid-cols-1 gap-4 lg:grid-cols-2">
        <Panel
          title="Shield mode"
          subtitle="Ambang keputusan engine"
          actions={<Tag tone={mode === "normal" ? "ok" : mode === "aggressive" ? "warn" : "danger"}>{mode.toUpperCase()}</Tag>}
        >
          <div className="space-y-3">
            <p className="text-[13px] text-muted leading-relaxed">
              <span className="text-slate-900">Normal</span> — ambang standar. <span className="text-slate-900">Aggressive</span> — lebih ketat saat serangan.{" "}
              <span className="text-slate-900">Emergency</span> — blokir semua kecuali whitelist.
            </p>
            <div className="mode-switch" role="group" aria-label="Shield mode">
              {["normal", "aggressive", "emergency"].map((m) => (
                <button key={m} className={`mode-option ${mode === m ? "mode-option-active" : ""}`} onClick={() => setMode(m)} disabled={busy} aria-pressed={mode === m}>
                  {m.toUpperCase()}
                </button>
              ))}
            </div>
            {/* Reset menghapus blocklist, reputasi, dan counter — tidak bisa
                dibatalkan, jadi diberi peringatan eksplisit. */}
            <div className="flex flex-wrap items-center gap-2 pt-1">
              <button className="btn hover:!border-danger hover:!text-danger-ink" onClick={resetCounters} disabled={busy}>Reset Counters</button>
              <button className="btn" onClick={downloadBackup} disabled={busy}>Download Backup</button>
              <span className="text-[11px] text-muted">Menghapus blocklist, reputasi, dan statistik. Tidak dapat dibatalkan.</span>
            </div>
          </div>
        </Panel>

        <Panel
          title="Network"
          subtitle="Binding, upstream, dan versi engine"
          actions={<Tag tone="muted">PORT {server.httpPort ?? "—"}</Tag>}
          bodyClassName="p-0"
        >
          <TableBox>
            <DataTable minWidth={false}>
              <tbody>
                <tr><td className="text-muted">API Bind</td><td className="text-right mono">{server.host || "—"}</td></tr>
                <tr><td className="text-muted">HTTP Port</td><td className="text-right mono">{server.httpPort ?? "—"}</td></tr>
                <tr><td className="text-muted">Upstream</td><td className="text-right mono">{upstream.host ? `${upstream.host}:${upstream.port}` : "—"}</td></tr>
                <tr><td className="text-muted">Max Concurrency</td><td className="text-right mono">{server.maxConcurrency ?? "—"}</td></tr>
                <tr><td className="text-muted">Trust Proxy</td><td className="text-right mono">{config?.proxy?.trustProxy ? "yes" : "no"}</td></tr>
                <tr><td className="text-muted">Version</td><td className="text-right mono">{config?.version || "—"}</td></tr>
              </tbody>
            </DataTable>
          </TableBox>
        </Panel>
      </div>

      <Panel title="Backup & Restore" subtitle="Download snapshot engine, pulihkan subset konfigurasi">
        <Stack className="gap-2.5">
          <div className="flex flex-wrap items-center gap-2">
            <button className="btn" onClick={downloadBackup} disabled={busy || restoreBusy}>Download Backup (.json)</button>
            <label className="flex items-center gap-2 rounded-lg border border-edge bg-white px-2.5 py-1.5 text-[12px]">
              <input type="file" accept="application/json,.json" onChange={(e) => setRestoreFile(e.target.files?.[0] || null)} />
            </label>
            <button className="btn-primary h-[34px]" onClick={applyRestore} disabled={!restoreFile || restoreBusy || busy}>Restore</button>
          </div>
          {restoreFile ? <div className="text-[11px] text-muted">Terpilih: {restoreFile.name}</div> : null}
          {restoreMsg ? <Note>{restoreMsg}</Note> : null}
          {restoreErr ? <ErrorCard message={restoreErr} /> : null}
        </Stack>
      </Panel>
    </Stack>
  );
}
