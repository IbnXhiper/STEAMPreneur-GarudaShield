"use client";

import { useEffect, useMemo, useState } from "react";
import { EmptyState, ErrorState } from "@/components/ui";
import Logo from "@/components/Logo";

type Component = { name: string; status: string; detail?: string; updatedAt?: number };
type Incident = { time: number; level: string; message: string };
type Status = {
  version?: string;
  uptimeSec?: number;
  overall?: string;
  storeMode?: string;
  attackActive?: boolean;
  components?: Component[];
  incidents?: Incident[];
  system?: Record<string, unknown>;
};

const TABS = ["Overview", "Services & Sites", "History"] as const;
type Tab = (typeof TABS)[number];

/* Slug + icon per component name so the public page reads like a real status
   page (edge / api / cluster / storage / internet) instead of raw labels. */
const META: Record<string, { slug: string; icon: string }> = {
  Shield: { slug: "edge", icon: "S" },
  Proxy: { slug: "edge", icon: "P" },
  Dashboard: { slug: "api", icon: "A" },
  RedisStore: { slug: "storage", icon: "D" },
  Upstream: { slug: "internet", icon: "O" },
};

function fmtUptime(s?: number) {
  if (!s) return "—";
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  return d ? `${d}d ${h}h ${m}m` : h ? `${h}h ${m}m` : `${m}m`;
}

/** Last health check reported by the engine, or an honest "—". */
function fmtSeen(updatedAt?: number) {
  if (!updatedAt) return "—";
  const secs = Math.max(0, Math.round((Date.now() - updatedAt) / 1000));
  if (secs < 60) return `checked ${secs}s ago`;
  return `checked ${Math.round(secs / 60)}m ago`;
}

function isHealthy(status: string) {
  return status === "ok" || status === "up";
}

const WINDOW_DAYS = 60;

/** One bucket per day for the last WINDOW_DAYS days, oldest first. A bucket is
 *  only filled when an incident actually happened that day. */
function uptimeDays(incidents: Incident[]): (Incident | null)[] {
  const buckets: (Incident | null)[] = new Array(WINDOW_DAYS).fill(null);
  if (!incidents.length) return buckets;
  const startOfDay = (ms: number) => {
    const d = new Date(ms);
    d.setHours(0, 0, 0, 0);
    return d.getTime();
  };
  const today = startOfDay(Date.now());
  for (const inc of incidents) {
    const idx = WINDOW_DAYS - 1 - Math.round((today - startOfDay(inc.time)) / 86400000);
    if (idx < 0 || idx >= WINDOW_DAYS) continue;
    const current = buckets[idx];
    if (!current || inc.level === "critical") buckets[idx] = inc;
  }
  return buckets;
}

function uptimePct(days: (Incident | null)[]) {
  const clean = days.filter((d) => d === null).length;
  return `${((clean / days.length) * 100).toFixed(1)}%`;
}

function overallLabel(status?: string) {
  if (status === "ok" || status === "up") return { text: "All Systems Operational", tag: "Operational", tone: "ok" as const };
  if (status === "degraded") return { text: "Partial Degradation", tag: "Degraded", tone: "warn" as const };
  return { text: "Major Outage", tag: "Down", tone: "danger" as const };
}

export default function StatusPage() {
  const [s, setS] = useState<Status | null>(null);
  const [err, setErr] = useState(false);
  const [tab, setTab] = useState<Tab>("Overview");
  const [updatedAt, setUpdatedAt] = useState<string>("");

  useEffect(() => {
    let alive = true;
    const load = () =>
      fetch("/api/gs/status")
        .then((r) => (r.ok ? r.json() : Promise.reject()))
        .then((d) => {
          if (!alive) return;
          setS(d);
          setErr(false);
          setUpdatedAt(new Date().toLocaleTimeString());
        })
        .catch(() => alive && setErr(true));
    load();
    const iv = setInterval(load, 5000);
    return () => {
      alive = false;
      clearInterval(iv);
    };
  }, []);

  const overall = overallLabel(s?.overall);
  const node = (s?.system?.hostname as string) || "edge";

  return (
    <div className="status-shell">
      <header className="status-topbar">
        <div className="status-brand">
          <Logo size={28} />
          <span className="font-display font-bold text-slate-900">Garuda<span className="text-[#8A6D1F]">Shield</span></span>
          <span className="status-kicker">STATUS</span>
        </div>
        <div className="status-live">
          <span className={`status-dot ${err ? "status-dot-danger" : "status-dot-ok"}`} />
          <span className={err ? "text-danger-ink" : "text-ok-ink"}>{err ? "Offline" : "Live"}</span>
          {updatedAt && <span className="text-muted">updated {updatedAt}</span>}
        </div>
      </header>

      <nav className="status-tabs" aria-label="Status sections">
        {TABS.map((t) => (
          <button key={t} className={`status-tab ${tab === t ? "status-tab-active" : ""}`} onClick={() => setTab(t)} aria-current={tab === t ? "page" : undefined}>
            {t}
          </button>
        ))}
      </nav>

      <main className="status-body">
        {/* Before the engine answers, the page has no <h1> yet — keep an
            accessible heading so screen readers still get a page title. */}
        {!s && <h1 className="sr-only">Status GarudaShield</h1>}
        {/* Public page: shows only what the engine publishes. Node topology and
            sync internals stay behind the authenticated console. */}
        {err && !s && (
          <div className="status-card p-0">
            <ErrorState
              title="Status page cannot reach the engine"
              description="This page reads the public /api/status endpoint. Make sure GS_API_URL points at a running engine, then retry."
              onRetry={() => location.reload()}
            />
          </div>
        )}
        {!err && !s && (
          <div className="status-card p-5 space-y-3" role="status" aria-busy="true">
            <div className="skeleton skeleton-title w-2/5" />
            <div className="skeleton skeleton-line w-full" />
            <div className="skeleton skeleton-line w-4/5" />
            <div className="skeleton skeleton-block w-full" />
          </div>
        )}

        {s && tab === "Overview" && <OverviewTab s={s} overall={overall} node={node} />}
        {s && tab === "Services & Sites" && <ServicesTab s={s} />}
        {s && tab === "History" && <HistoryTab s={s} />}
      </main>

      <footer className="status-footer">
        node: {node} · garudashield v{s?.version ?? "?"} · uptime: {fmtUptime(s?.uptimeSec)} · real-time polling 5s
      </footer>
    </div>
  );
}

function OverviewTab({ s, overall, node }: { s: Status; overall: ReturnType<typeof overallLabel>; node: string }) {
  const comps = s.components ?? [];
  return (
    <div className="space-y-8">
      <section>
        <span className={`status-pill status-pill-${overall.tone}`}><span className={`status-dot status-dot-${overall.tone}`} /> {overall.tag}</span>
        <h1 className="status-hero">{overall.text}</h1>
        <p className="status-hero-sub">
          {overall.tone === "ok" ? "All systems are operating normally. No incidents reported." : "Some components require attention. See details below."}
        </p>
        <p className="status-hero-meta">node: {node} · v{s.version ?? "?"} · uptime {fmtUptime(s.uptimeSec)}</p>
      </section>

      <section className="status-card p-0">
        <div className="status-card-head"><span>SYSTEMS</span><span className="text-muted">polling every 5s</span></div>
        <div>
          {comps.map((c) => {
            const meta = META[c.name] || { slug: "service", icon: "◆" };
            const healthy = isHealthy(c.status);
            return (
              <div key={c.name} className="status-row">
                <span className="status-row-icon" aria-hidden="true">{meta.icon}</span>
                <div className="status-row-main">
                  <div className="status-row-name">{c.name}</div>
                  <div className="status-row-slug mono">{meta.slug}</div>
                </div>
                <div className="status-row-right">
                  <span className={`status-pill status-pill-${healthy ? "ok" : c.status === "degraded" ? "warn" : "danger"}`}>
                    <span className={`status-dot status-dot-${healthy ? "ok" : c.status === "degraded" ? "warn" : "danger"}`} /> {healthy ? "Operational" : c.status}
                  </span>
                  <span className="status-row-meta mono">{fmtSeen(c.updatedAt)}</span>
                </div>
              </div>
            );
          })}
          {comps.length === 0 && <div className="status-empty">Belum ada data komponen — engine belum melaporkan health check.</div>}
        </div>
      </section>

      <section className="status-card p-0">
        <div className="status-card-head"><span>LAST {WINDOW_DAYS} DAYS</span><span className="text-muted">derived from incident log</span></div>
        <div className="p-4 space-y-3">
          {/* Honesty rule: the engine does not persist uptime percentages, so
              we colour days from the incident log and mark every day as "no
              data" when no incident history exists yet. No invented bars. */}
          {comps.map((c) => {
            const healthy = isHealthy(c.status);
            const days = uptimeDays(s.incidents ?? []);
            const recorded = (s.incidents ?? []).length > 0;
            return (
              <div key={c.name} className="uptime-row">
                <span className="uptime-name">{c.name}</span>
                <div className="uptime-bars" aria-hidden="true">
                  {days.map((day, i) => (
                    <span
                      key={i}
                      className={`uptime-cell ${!recorded ? "uptime-none" : day ? (day.level === "critical" ? "uptime-danger" : "uptime-warn") : healthy ? "uptime-ok" : "uptime-danger"}`}
                    />
                  ))}
                </div>
                <span className="uptime-pct mono">{recorded ? uptimePct(days) : "no data"}</span>
              </div>
            );
          })}
          {!comps.length && <EmptyState title="Belum ada data komponen" description="Status komponen akan muncul setelah engine melaporkan health check." />}
          <div className="uptime-legend">
            <span><span className="uptime-cell uptime-ok" /> no incident</span>
            <span><span className="uptime-cell uptime-warn" /> incident</span>
            <span><span className="uptime-cell uptime-danger" /> critical / unhealthy</span>
            <span><span className="uptime-cell uptime-none" /> no incident history</span>
          </div>
        </div>
      </section>
    </div>
  );
}

function ServicesTab({ s }: { s: Status }) {
  const comps = s.components ?? [];
  return (
    <div className="status-card p-0">
      <div className="status-card-head"><span>SERVICES &amp; SITES</span><span className="text-muted">{comps.length} components</span></div>
      <div>
        {comps.map((c) => {
          const meta = META[c.name] || { slug: "service", icon: "◆" };
          const healthy = isHealthy(c.status);
          return (
            <div key={c.name} className="status-row">
              <span className="status-row-icon" aria-hidden="true">{meta.icon}</span>
              <div className="status-row-main">
                <div className="status-row-name">{c.name}</div>
                <div className="status-row-slug mono">{c.detail || meta.slug}</div>
              </div>
              <span className={`status-pill status-pill-${healthy ? "ok" : c.status === "degraded" ? "warn" : "danger"}`}>
                <span className={`status-dot status-dot-${healthy ? "ok" : c.status === "degraded" ? "warn" : "danger"}`} /> {healthy ? "Operational" : c.status}
              </span>
            </div>
          );
        })}
        {comps.length === 0 && (
          <EmptyState
            title="Belum ada data komponen"
            description="Engine belum melaporkan health check. Daftar services & sites akan terisi otomatis."
          />
        )}
      </div>
    </div>
  );
}

function HistoryTab({ s }: { s: Status }) {
  const incidents = useMemo(() => (s.incidents ?? []).slice().reverse(), [s.incidents]);
  return (
    <div className="status-card p-0">
      <div className="status-card-head"><span>INCIDENT HISTORY</span><span className="text-muted">{incidents.length} total</span></div>
      <div className="p-4 space-y-2">
        {incidents.length === 0 && <div className="status-empty">Tidak ada insiden tercatat. Semua sistem stabil.</div>}
        {incidents.map((inc, i) => (
          <div key={i} className="incident-row">
            <span className={`status-pill status-pill-${inc.level === "critical" ? "danger" : "warn"}`}>{inc.level}</span>
            <div className="incident-main">
              <div className="incident-msg">{inc.message}</div>
              <div className="incident-time mono">{new Date(inc.time).toLocaleString()}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
