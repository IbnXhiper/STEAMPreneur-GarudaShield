/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
colors: {
        /* ---- brand ----
           Navy #0A192F is the primary ink and the sidebar/navbar colour.
           Garuda Gold #D4AF37 is the CTA + active-nav accent. Crimson and
           green stay semantic (threat vs operational), never decorative. */
        navy: {
          DEFAULT: "#0A192F",
          950: "#060D1B",
          900: "#0A192F",
          800: "#12233F",
          700: "#1B3357",
          600: "#27456F",
          500: "#3A5E8C",
        },

        /* ---- brand accent ----
           Gold leads (CTA, active nav, logo, highlights). Crimson is for
           DDoS/critical/blocked/emergency only; green for operational status.
           Gradients live in globals.css but are confined to brand marks. */
        brand: {
          gold: "#D4AF37",
          goldDark: "#C29B24",
          goldInk: "#8A6D1F",
          crimson: "#DC3545",
          crimsonInk: "#B02A37",
          green: "#20C997",
          greenInk: "#0B7A57",
        },

        /* Semantic status. Meaning never changes: green healthy, gold
           warning/medium, crimson critical/blocked, navy informational,
           gray inactive. Bright fills are for dots/bars; -ink variants are
           text-safe on the white card surfaces. */
        ok: "#20C997",
        warn: "#D4AF37",
        danger: "#DC3545",
        info: "#0A192F",

        "ok-ink": "#0B7A57",
        "warn-ink": "#8A6D1F",
        "danger-ink": "#B02A37",
        "info-ink": "#0A192F",

        /* Legacy aliases kept so no existing class name breaks. */
        ink: "#FFFFFF",
        /* Surface = pure white; the app background (#F5F7FA) comes from the
            body/root so cards read as raised on the light canvas. */
        panel: "#FFFFFF",
        edge: "#E5E7EB",
        accent: "#D4AF37",
        accent2: "#C29B24",
        muted: "#475569",
        "accent-ink": "#8A6D1F",

        /* Neutral ramp: cool slate. slate-900 is primary text (navy family),
            slate-50 the page background, slate-200 the hairline border. */
        slate: {
          50: "#F5F7FA",
          100: "#EDF1F6",
          200: "#E5E7EB",
          300: "#CBD5E1",
          400: "#94A3B8",
          500: "#64748B",
          600: "#475569",
          700: "#334155",
          800: "#1E293B",
          900: "#0A192F",
        },
      },
      fontFamily: {
        /* One typeface across the product: Plus Jakarta Sans — a modern,
           corporate Indonesian face that keeps the light "cyber defense"
           identity. `display` stays as an alias for heading roles. */
        sans: ["Plus Jakarta Sans", "ui-sans-serif", "system-ui", "sans-serif"],
        display: ["Plus Jakarta Sans", "ui-sans-serif", "system-ui", "sans-serif"],
        mono: ["ui-monospace", "SFMono-Regular", "Menlo", "monospace"],
      },
      maxWidth: {
        shell: "1180px",
      },
      boxShadow: {
        /* Card elevation on the #F5F7FA canvas: a soft, low-alpha navy shadow
            so white cards lift cleanly. Spec: 0 4px 16px rgba(10,25,47,0.06). */
        card: "0 4px 16px rgba(10, 25, 47, 0.06)",
        "card-hover": "0 4px 16px rgba(10, 25, 47, 0.06), 0 8px 20px rgba(10, 25, 47, 0.09)",
        lift: "0 8px 24px rgba(10, 25, 47, 0.12), 0 2px 8px rgba(10, 25, 47, 0.06)",
        navy: "0 4px 14px rgba(10, 25, 47, 0.22)",
        glow: "0 10px 30px rgba(212, 175, 55, 0.24)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(16px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pulse-ring": {
          "0%": { boxShadow: "0 0 0 0 rgba(32, 201, 151, 0.5)" },
          "70%": { boxShadow: "0 0 0 8px rgba(32, 201, 151, 0)" },
          "100%": { boxShadow: "0 0 0 0 rgba(32, 201, 151, 0)" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.6s cubic-bezier(0.22, 1, 0.36, 1) both",
        "pulse-ring": "pulse-ring 2s infinite",
      },
    },
  },
  plugins: [],
};