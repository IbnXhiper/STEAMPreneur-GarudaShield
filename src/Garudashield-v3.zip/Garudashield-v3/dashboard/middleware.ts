import { NextRequest, NextResponse } from "next/server";

// Guard the dashboard: any /dash* request without a valid gs_key cookie is
// redirected to /login. This stops the unauthenticated 403 storm the browser
// hits when it fetches /api/gs/* (stats/mode/...) before logging in.
export function middleware(req: NextRequest) {
  const hasKey = req.cookies.get("gs_key")?.value;
  if (!hasKey) {
    // NextResponse.redirect() needs an absolute URL. Building it from
    // req.nextUrl yields Next's own bind address ("localhost:3000") because it
    // does not trust proxy headers, which sent users to the wrong origin.
    // Prefer the origin the proxy actually received, so the redirect works
    // unchanged behind Caddy and in local dev.
    const host =
      req.headers.get("x-forwarded-host") ||
      req.headers.get("host") ||
      req.nextUrl.host;
    const proto = req.headers.get("x-forwarded-proto") || req.nextUrl.protocol.replace(":", "");
    const next = encodeURIComponent(req.nextUrl.pathname + req.nextUrl.search);
    return NextResponse.redirect(new URL(`/login?next=${next}`, `${proto}://${host}`));
  }
  return NextResponse.next();
}

export const config = {
  matcher: ["/dash/:path*"],
};
