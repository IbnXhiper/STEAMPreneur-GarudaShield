declare const brain: {
  respond: (input: string) => {
    answer: string;
    chips?: string[];
    topic?: string;
    matched?: string;
    related?: string;
  };
};
export default brain;
