export async function gsGet(path: string, qs = "") {
  const r = await fetch(`/api/gs/${path}${qs}`, {
    headers: { Accept: "application/json" },
    credentials: "include",
  });
  if (r.status === 401 || r.status === 403) {
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new Error(`${r.status}`);
  }
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}

export async function gsPost(path: string, body: unknown) {
  const r = await fetch(`/api/gs/${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(body),
  });
  if (r.status === 401 || r.status === 403) {
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new Error(`${r.status}`);
  }
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}

export async function gsDelete(path: string) {
  const r = await fetch(`/api/gs/${path}`, {
    method: "DELETE",
    credentials: "include",
  });
  if (r.status === 401 || r.status === 403) {
    if (typeof window !== "undefined") window.location.href = "/login";
    throw new Error(`${r.status}`);
  }
  if (!r.ok) throw new Error(`${r.status}`);
  return r.json();
}
