package config

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDefaultHasTLSAndGeo(t *testing.T) {
	c := Default()
	if c.Server.TLS.CertFile != "" || c.Server.TLS.KeyFile != "" {
		// defaults ship disabled; enabling requires explicit cert paths
		t.Log("tls default present")
	}
	if c.Geo.CountryPath == "" || c.Geo.ASNPath == "" {
		t.Error("geo default paths should be set")
	}
	if c.Server.MaxConcurrency <= 0 {
		t.Error("maxConcurrency should default positive")
	}
}

func TestLoadMergesOverDefaults(t *testing.T) {
	dir := t.TempDir()
	p := filepath.Join(dir, "cfg.json")
	// Minimal config enabling geo + tls to prove Load merges over Default.
	cfgJSON := `{"server":{"tls":{"enabled":true,"certFile":"/x/cert.pem","keyFile":"/x/key.pem"}},"geo":{"enabled":true}}`
	if err := os.WriteFile(p, []byte(cfgJSON), 0o644); err != nil {
		t.Fatal(err)
	}
	c, err := Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if !c.Server.TLS.Enabled {
		t.Error("tls.enabled should be true from file")
	}
	if c.Server.TLS.CertFile != "/x/cert.pem" {
		t.Errorf("certFile not loaded: %q", c.Server.TLS.CertFile)
	}
	if !c.Geo.Enabled {
		t.Error("geo.enabled should be true from file")
	}
	// Untouched defaults must survive the merge.
	if c.Reputation.BlockThreshold != 80 {
		t.Errorf("reputation default overridden: %d", c.Reputation.BlockThreshold)
	}
}

func TestLoadMissingFileReturnsDefaults(t *testing.T) {
	c, err := Load(filepath.Join(t.TempDir(), "nope.json"))
	if err != nil {
		t.Fatalf("missing file should not error: %v", err)
	}
	if c.Version == "" && c.Server.HTTPPort == 0 {
		t.Error("expected defaults, got empty config")
	}
}

func TestEnvOverridesRedis(t *testing.T) {
	t.Setenv("GS_REDIS_ENABLED", "on")
	t.Setenv("GS_REDIS_ADDR", "redis:6379")
	c, err := Load(filepath.Join(t.TempDir(), "nope.json"))
	if err != nil {
		t.Fatal(err)
	}
	if !c.Cluster.Redis.Enabled {
		t.Error("GS_REDIS_ENABLED=on should enable redis")
	}
	if c.Cluster.Redis.Address != "redis:6379" {
		t.Errorf("GS_REDIS_ADDR not applied: %q", c.Cluster.Redis.Address)
	}
}

// TestDefaultTopologyIsSingleNode: the shipped baseline is one active sync node.
func TestDefaultTopologyIsSingleNode(t *testing.T) {
	c := Default()
	if got := c.Cluster.NodeCount(); got != 1 {
		t.Errorf("default node count should be 1, got %d", got)
	}
	topo := c.Cluster.Topology()
	if len(topo) != 1 || topo[0].ID != c.Cluster.NodeID {
		t.Fatalf("unexpected default topology: %+v", topo)
	}
	if len(c.Cluster.RequiredNodes()) != 0 {
		t.Errorf("no peer should be required by default")
	}
}

// TestTopologyAlwaysIncludesSelf: a nodes list without the local node still
// reports the local node so "online / expected" can never be 0/N.
func TestTopologyAlwaysIncludesSelf(t *testing.T) {
	c := Default().Cluster
	c.NodeID = "node-1"
	c.Nodes = []Node{{ID: "node-2"}, {ID: ""}} // empty id must be skipped
	topo := c.Topology()
	if len(topo) != 2 || topo[0].ID != "node-1" || topo[1].ID != "node-2" {
		t.Fatalf("unexpected topology: %+v", topo)
	}
	if topo[0].Role != c.Role || topo[0].Site != c.Site {
		t.Errorf("self should inherit cluster role/site: %+v", topo[0])
	}
	if c.NodeCount() != 2 {
		t.Errorf("node count should be 2, got %d", c.NodeCount())
	}
}

// TestSyncNodeCountEnv: SYNC_NODE_COUNT=1 is the baseline; >1 scales up without
// any code change; an explicit nodes list always wins.
func TestSyncNodeCountEnv(t *testing.T) {
	dir := t.TempDir()

	t.Setenv("SYNC_NODE_COUNT", "1")
	c, err := Load(filepath.Join(dir, "nope.json"))
	if err != nil {
		t.Fatal(err)
	}
	if c.Cluster.NodeCount() != 1 {
		t.Errorf("SYNC_NODE_COUNT=1 should stay single node, got %d", c.Cluster.NodeCount())
	}

	t.Setenv("SYNC_NODE_COUNT", "3")
	c, err = Load(filepath.Join(dir, "nope.json"))
	if err != nil {
		t.Fatal(err)
	}
	if c.Cluster.NodeCount() != 3 {
		t.Fatalf("SYNC_NODE_COUNT=3 should declare 3 nodes, got %d", c.Cluster.NodeCount())
	}
	for _, n := range c.Cluster.Topology()[1:] {
		if n.Required {
			t.Errorf("synthesized peers must stay optional: %+v", n)
		}
	}

	// GS_-prefixed variant works too.
	t.Setenv("SYNC_NODE_COUNT", "")
	t.Setenv("GS_SYNC_NODE_COUNT", "2")
	c, err = Load(filepath.Join(dir, "nope.json"))
	if err != nil {
		t.Fatal(err)
	}
	if c.Cluster.NodeCount() != 2 {
		t.Errorf("GS_SYNC_NODE_COUNT=2 should declare 2 nodes, got %d", c.Cluster.NodeCount())
	}

	// Explicit topology is authoritative: env count must not override it.
	p := filepath.Join(dir, "two.json")
	if err := os.WriteFile(p, []byte(`{"cluster":{"nodeId":"node-1","nodes":[{"id":"node-1"},{"id":"node-2"}]}}`), 0o644); err != nil {
		t.Fatal(err)
	}
	t.Setenv("SYNC_NODE_COUNT", "5")
	c, err = Load(p)
	if err != nil {
		t.Fatal(err)
	}
	if c.Cluster.NodeCount() != 2 {
		t.Errorf("explicit nodes list must win over SYNC_NODE_COUNT, got %d", c.Cluster.NodeCount())
	}
}

// TestRequiredNodesExcludesSelf: only peers can be required.
func TestRequiredNodesExcludesSelf(t *testing.T) {
	c := Default().Cluster
	c.NodeID = "node-1"
	c.Nodes = []Node{{ID: "node-1", Required: true}, {ID: "node-2"}, {ID: "node-3", Required: true}}
	got := c.RequiredNodes()
	if len(got) != 1 || got[0] != "node-3" {
		t.Fatalf("unexpected required nodes: %v", got)
	}
}
