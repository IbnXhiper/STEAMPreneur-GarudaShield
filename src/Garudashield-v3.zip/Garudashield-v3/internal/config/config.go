// Package config holds the typed runtime configuration for GarudaShield v3.
// The JSON shape intentionally mirrors v2's config/default.js so existing
// production configs remain drop-in compatible.
package config

import (
	"encoding/json"
	"fmt"
	"os"
	"strconv"
	"strings"
)

type Config struct {
	Version      string          `json:"version"`
	Name         string          `json:"name"`
	Server       Server          `json:"server"`
	Shield       Shield          `json:"shield"`
	Upstream     Upstream        `json:"upstream"`
	Sites        map[string]Site `json:"sites"`
	Defense      Defense         `json:"defense"`
	Reputation   Reputation      `json:"reputation"`
	Geo          GeoConfig       `json:"geo"`
	Anomaly      Anomaly         `json:"anomaly"`
	Detection    Detection       `json:"detection"`
	Logging      Logging         `json:"logging"`
	Alerts       Alerts          `json:"alerts"`
	Proxy        Proxy           `json:"proxy"`
	Access       Access          `json:"access"`
	AccessSecret string          `json:"accessSecret"`
	Cluster      Cluster         `json:"cluster"`
	Admin        AdminConfig     `json:"admin"`
	Offload      OffloadConfig   `json:"offload"`
	UDPGuard     UDPGuardConfig  `json:"udpGuard"`
	PyHook       PyHook          `json:"pyhook"`
	Quotas       QuotaConfig     `json:"quotas"`

	AllowedHosts []string `json:"allowedHosts"`
	Whitelist    []string `json:"whitelist"`
}

// AdminConfig controls the control-plane REST/SSE API exposed under /api/.
// Secret is the API key; when empty, only loopback callers are permitted
// (matching v2's dashboard auth). Present it via the `x-gs-key` header or
// `Authorization: Bearer <secret>`.
type AdminConfig struct {
	Enabled bool   `json:"enabled"`
	Secret  string `json:"secret"`
}

// QuotaConfig controls per-plan request budgets enforced at the edge. The
// counter lives in Postgres (usage_quota table) so limits hold across every
// engine instance sharing the same DB — Redis is not required for quota
// to be cross-instance correct. 0 in a plan limit = unlimited for that plan.
// Disabled by default so existing deployments behave exactly as before.
type QuotaConfig struct {
	Enabled bool `json:"enabled"`
	// PlanLimits maps plan name -> daily request budget (0 = unlimited).
	PlanLimits map[string]int64 `json:"planLimits"`
	// FallbackLimit applies to plans (or unknown hosts) not listed above.
	FallbackLimit int64 `json:"fallbackLimit"`
}

type Server struct {
	HTTPPort        int    `json:"httpPort"`
	DashboardPort   int    `json:"dashboardPort"`
	Host            string `json:"host"`
	Backlog         int    `json:"backlog"`
	KeepAliveMs     int    `json:"keepAliveTimeout"`
	MaxHeaderBytes  int    `json:"maxHeadersSize"`
	MaxBodySizeByte int64  `json:"maxBodySize"`
	MaxConcurrency  int    `json:"maxConcurrency"`
	// MaxConnsPerIP caps simultaneous TCP connections from a single client IP
	// at the listener. Unlike MaxConcurrency (which limits in-flight HTTP
	// requests), this bounds raw socket count so a single attacker opening
	// thousands of idle connections (classic slowloris) cannot exhaust FDs
	// before the request semaphore ever engages. 0 = unlimited.
	MaxConnsPerIP int `json:"maxConnsPerIP"`
	// MaxBytesPerSecPerIP caps total ingress bytes per client IP per second across
	// all its connections (0 = unlimited). Stops a single IP from saturating
	// bandwidth with slow big-POSTs or many uploads, independent of the conn cap.
	MaxBytesPerSecPerIP int64 `json:"maxBytesPerSecPerIP"`
	// ConnIdleTimeoutMs closes connections that stay idle (no request) longer
	// than this. Keeps slowloris-style half-open sockets from piling up.
	// 0 = use the HTTP server IdleTimeout default.
	ConnIdleTimeoutMs int `json:"connIdleTimeoutMs"`
	// HTTP2 tunes the HTTP/2 server to resist multiplexing-based slowloris
	// (many idle streams on one TCP connection) and oversized frames.
	HTTP2 HTTP2Config `json:"http2"`
	HTTP3 HTTP3Config `json:"http3"`
	// TLS enables HTTPS termination on the edge. When CertFile/KeyFile are set
	// the engine serves TLS directly; otherwise it serves plaintext HTTP and
	// relies on an upstream terminator (nginx/anycast). Do NOT run plaintext in
	// production with a real admin secret — the key travels in cleartext.
	TLS TLSConfig `json:"tls"`
	// AdminBind separates the control plane from the edge. When set (e.g.
	// "127.0.0.1:9090"), a second listener serves ONLY the /api/* admin mux —
	// the public edge never exposes admin endpoints. Empty = admin API shares
	// the edge listener (legacy single-port mode).
	AdminBind string `json:"adminBind"`
}

// HTTP2Config tunes the HTTP/2 server to resist multiplexing-based slowloris
// and oversized frames (HPACK bomb). Applied only when TLS is enabled (H2 needs
// TLS by default); ignored for plaintext.
type HTTP2Config struct {
	// MaxConcurrentStreams caps simultaneous streams per TCP connection.
	// A single attacker connection cannot open thousands of streams. 0 = Go
	// default (250).
	MaxConcurrentStreams int `json:"maxConcurrentStreams"`
	// MaxReadFrameSize caps the largest H2 frame the server will accept (bytes).
	// Small cap defeats HPACK-bomb / decompression-bomb attacks. 0 = Go default
	// (1 MiB).
	MaxReadFrameSize int `json:"maxReadFrameSize"`
}

// HTTP3Config enables an HTTP/3 (QUIC) listener alongside the TCP one. QUIC runs
// over UDP and is itself a DDoS surface (handshake floods, connection
// amplification), so MaxIncomingStreams caps streams per connection.
type HTTP3Config struct {
	Enabled            bool `json:"enabled"`
	Port               int  `json:"port"`               // UDP port; 0 => HTTPPort+1
	MaxIncomingStreams int  `json:"maxIncomingStreams"` // per-connection stream cap
	MaxIdleTimeoutMs   int  `json:"maxIdleTimeoutMs"`
}

// TLSConfig holds the certificate paths for edge TLS termination.
type TLSConfig struct {
	Enabled  bool   `json:"enabled"`
	CertFile string `json:"certFile"`
	KeyFile  string `json:"keyFile"`
	// AutoSelfSigned generates an ephemeral self-signed cert at boot when
	// enabled but no files are given. For internal/backend links and QUIC
	// tests — browsers will warn; use real certs (or Caddy) for public UI.
	AutoSelfSigned bool `json:"autoSelfSigned"`
}

// OffloadConfig controls kernel-side L3/L4 offload (XDP/eBPF). Only effective
// when the engine is built with `-tags ebpf` on Linux and run as root with the
// given interface. Ignored otherwise (the engine logs that L4 relies on an
// upstream scrubber).
type OffloadConfig struct {
	Enabled bool   `json:"enabled"`
	Iface   string `json:"interface"`
}

// UDPGuardConfig fronts one UDP service (DNS on 53, game/NTP ports) with
// the layer4 amplification heuristics. Disabled by default.
type UDPGuardConfig struct {
	Enabled     bool   `json:"enabled"`
	Listen      string `json:"listen"`
	Upstream    string `json:"upstream"`
	ServicePort int    `json:"servicePort"`
	MaxRPSPerIP int    `json:"maxRPSPerIP"`
	TimeoutMs   int64  `json:"timeoutMs"`
}

type Shield struct {
	Mode                   bool     `json:"-"`
	ModeName               string   `json:"mode"`
	AggMode                bool     `json:"aggMode"`
	LearningPeriodMs       int      `json:"learningPeriod"`
	MaxWorkers             int      `json:"maxWorkers"`
	HealthCheckIntervalMs  int      `json:"healthCheckInterval"`
	AutoScale              bool     `json:"autoScale"`
	UpstreamTimeoutMs      int      `json:"upstreamTimeout"`
	BudgetMs               int64    `json:"budgetMs"`
	FloodRpsThreshold      float64  `json:"floodRpsThreshold"`
	FloodMinMs             int64    `json:"floodMinMs"`
	AutoBlockTTL           int64    `json:"autoBlockTTL"`
	VerdictBlockTTL        int64    `json:"verdictBlockTTL"`
	VerdictChallengeTTL    int64    `json:"verdictChallengeTTL"`
	VerifyOnFirstVisit     bool     `json:"verifyOnFirstVisit"`
	VerifyOnFirstVisitHost []string `json:"verifyOnFirstVisitHosts"`
	DataDir                string   `json:"dataDir"`
}

type Upstream struct {
	Host string `json:"host"`
	Port int    `json:"port"`
}

type Site struct {
	Type     string   `json:"type"` // v3 supports "proxy"
	Upstream Upstream `json:"upstream,omitempty"`
	Root     string   `json:"root,omitempty"`
	Target   string   `json:"target,omitempty"`
	APIProxy string   `json:"apiProxy,omitempty"`
	Exempt   []string `json:"exemptPaths,omitempty"`
}

// SiteProxyTarget returns the host:port the site should proxy to. It prefers
// the structured Upstream field and falls back to the legacy Target string.
func (s Site) SiteProxyTarget() (string, bool) {
	if s.Upstream.Host != "" {
		return fmt.Sprintf("%s:%d", s.Upstream.Host, s.Upstream.Port), true
	}
	if s.Target != "" {
		return s.Target, true
	}
	return "", false
}

type Defense struct {
	Layer4      Layer4Config      `json:"layer4"`
	Layer7      Layer7Config      `json:"layer7"`
	WAF         WAFConfig         `json:"waf"`
	RateLimit   RateLimitConfig   `json:"rateLimit"`
	Fingerprint FingerprintConfig `json:"fingerprint"`
	Honeypot    Honeypot          `json:"honeypot"`
}

// Honeypot blocks requests to paths only scanners/exploit tooling touch
// (/.env, /.git/, /wp-login, /phpmyadmin, ...). A hit is definitive hostile
// intent: the source IP is blocked immediately and the request never reaches
// the upstream. Paths empty => built-in default list. BlockTTLMs/Score 0 =>
// defaults (1 h / 100).
type Honeypot struct {
	Enabled    bool     `json:"enabled"`
	Paths      []string `json:"paths"`
	BlockTTLMs int64    `json:"blockTTLMs"`
	Score      int      `json:"score"`
}

type Layer4Config struct {
	Enabled                    bool `json:"enabled"`
	SynFloodProtection         bool `json:"synFloodProtection"`
	MaxHalfOpenPerIP           int  `json:"maxHalfOpenPerIP"`
	MaxConnPerSecPerIP         int  `json:"maxConnPerSecPerIP"`
	MaxConnPerIP               int  `json:"maxConnPerIP"`
	BogonFilter                bool `json:"bogonFilter"`
	PortScanDetection          bool `json:"portScanDetection"`
	UDPAmplificationProtection bool `json:"udpAmplificationProtection"`
}

type Layer7Config struct {
	Enabled        bool  `json:"enabled"`
	Method         bool  `json:"methodValidation"`
	UserAgent      bool  `json:"userAgentValidation"`
	Headers        bool  `json:"headerValidation"`
	Referer        bool  `json:"refererValidation"`
	Origin         bool  `json:"originValidation"`
	Cookies        bool  `json:"cookieValidation"`
	Path           bool  `json:"pathValidation"`
	Query          bool  `json:"queryValidation"`
	ContentType    bool  `json:"contentTypeValidation"`
	Protocol       bool  `json:"protocolValidation"`
	MaxURILength   int   `json:"maxUriLength"`
	MaxHeaderCount int   `json:"maxHeaderCount"`
	MaxCookieLen   int   `json:"maxCookieLength"`
	MaxBodySize    int64 `json:"maxBodySize"`
}

type WAFConfig struct {
	Enabled          bool      `json:"enabled"`
	SQLi             bool      `json:"sqli"`
	XSS              bool      `json:"xss"`
	CommandInjection bool      `json:"commandInjection"`
	PathTraversal    bool      `json:"pathTraversal"`
	LFI              bool      `json:"lfi"`
	RFI              bool      `json:"rfi"`
	Shellshock       bool      `json:"shellshock"`
	Scanners         bool      `json:"scanners"`
	CustomRules      []WAFRule `json:"customRules"`
	Matcher          string    `json:"matcher"` // "auto" | "go" | "rust"
	FastFailTTL      int       `json:"fastFailTTL"`
}

type WAFRule struct {
	Name    string `json:"name"`
	Pattern string `json:"pattern"`
	Score   int    `json:"score"`
}

type RateLimitConfig struct {
	GlobalMaxRPS     float64    `json:"globalMaxRPS"`
	PerIPRPS         int        `json:"perIPRPS"`
	PerIPBurst       int        `json:"perIPBurst"`
	PerPathRPS       int        `json:"perPathRPS"`
	PathRules        []PathRule `json:"pathRules"`
	WindowMs         int        `json:"slidingWindowMs"`
	Adaptive         bool       `json:"adaptive"`
	CooldownPeriodMS int        `json:"cooldownPeriod"`
	RedEnabled       bool       `json:"red"`
	RedMinThreshold  float64    `json:"redMinThreshold"`
	RedMaxThreshold  float64    `json:"redMaxThreshold"`
	TokenBucket      bool       `json:"tokenBucket"`
	TokenBucketSize  float64    `json:"tokenBucketSize"`
	TokenRefillRate  float64    `json:"tokenRefillRate"`
	ConnLimitPerIP   int        `json:"connLimitPerIP"`
	ConnRateLimit    int        `json:"connRateLimit"`
	AutoTune         bool       `json:"autoTune"`
	MaxAdaptiveLevel int        `json:"maxAdaptiveLevel"`
}

type PathRule struct {
	Path string `json:"path"`
	RPS  *int   `json:"rps,omitempty"`
}

type FingerprintConfig struct {
	Enabled             bool `json:"enabled"`
	TLSFingerprint      bool `json:"tlsFingerprint"`
	HTTPFingerprint     bool `json:"httpFingerprint"`
	BrowserConsistency  bool `json:"browserConsistency"`
	HeadlessDetection   bool `json:"headlessDetection"`
	JSChallenge         bool `json:"jsChallenge"`
	PoWChallenge        bool `json:"powChallenge"`
	ChallengeDifficulty int  `json:"challengeDifficulty"`
	ChallengeTTLms      int  `json:"challengeTTL"`
	TokenTTLms          int  `json:"tokenTTL"`
}

type Reputation struct {
	Enabled             bool    `json:"enabled"`
	DecayIntervalMs     int     `json:"decayInterval"`
	MaxScore            int     `json:"maxScore"`
	MinScore            int     `json:"minScore"`
	SubnetScores        bool    `json:"subnetScores"`
	SubnetBlockMinScore int     `json:"subnetBlockMinScore"`
	BlockThreshold      int     `json:"blockThreshold"`
	ChallengeThreshold  int     `json:"challengeThreshold"`
	DecayRate           float64 `json:"decayRate"`
}

// GeoConfig points at optional offline MMDB files for IP enrichment. Both
// paths may be empty or missing on disk — enrichment then reports "unknown"
// and the engine keeps running. Fetch the databases with tools/fetch-geodb.ps1.
type GeoConfig struct {
	Enabled     bool   `json:"enabled"`
	CountryPath string `json:"countryDatabase"`
	ASNPath     string `json:"asnDatabase"`

	// GeoPolicy turns enrichment into enforcement (fail-open per country:
	// unknown country only blocks when the allowlist is non-empty).
	GeoPolicy GeoPolicyConfig `json:"policy"`
}

// GeoPolicyConfig gates traffic by country code (ISO 3166-1 alpha-2). With
// blocklistCountries, requests from those countries are hard-blocked. With
// allowlistCountries non-empty, ONLY those countries may pass (default-deny).
type GeoPolicyConfig struct {
	BlocklistCountries []string `json:"blocklistCountries"`
	AllowlistCountries []string `json:"allowlistCountries"`
}

// PyHook configures the external Python policy hook (internal/pyhook).
// Disabled by default. Mode "monitor" observes only (never blocks);
// "enforce" lets the script challenge/block. Script receives JSON features
// on stdin and must print {"action","score","reason"} to stdout.
// NOTE: a subprocess call costs milliseconds - enable only with a generous
// shield.budgetMs, or run monitor mode to collect labels for ML training.
type PyHook struct {
	Enabled    bool   `json:"enabled"`
	Script     string `json:"script"`
	Python     string `json:"python"`
	TimeoutMs  int64  `json:"timeoutMs"`
	Mode       string `json:"mode"`
	FailClosed bool   `json:"failClosed"`
	Worker     bool   `json:"worker"`
}

type Anomaly struct {
	Enabled               bool    `json:"enabled"`
	WindowSize            int     `json:"windowSize"`
	ZScoreThreshold       float64 `json:"zScoreThreshold"`
	MinSamples            int     `json:"minSamples"`
	EntropyThreshold      float64 `json:"entropyThreshold"`
	EnableProtocolAnomaly bool    `json:"enableProtocolAnomaly"`
	EnableRateAnomaly     bool    `json:"enableRateAnomaly"`
	EnablePayloadAnomaly  bool    `json:"enablePayloadAnomaly"`
}

type Detection struct {
	EntropyWindow       int     `json:"entropyWindow"`
	AnomalyThreshold    float64 `json:"anomalyThreshold"`
	BaselineSamples     int     `json:"baselineSamples"`
	AttackCooldownMs    int     `json:"attackCooldown"`
	RateSpikeMultiplier float64 `json:"rateSpikeMultiplier"`
	LowEntropyThreshold float64 `json:"lowEntropyThreshold"`
	UDPRatioThreshold   float64 `json:"udpRatioThreshold"`
	SYNRatioThreshold   float64 `json:"synRatioThreshold"`
}

type Logging struct {
	Level    string `json:"level"`
	Path     string `json:"path"`
	MaxFiles int    `json:"maxFiles"`
	MaxSize  int64  `json:"maxSize"`
}

type Alerts struct {
	TelegramToken string `json:"telegramToken,omitempty"`
	TelegramChat  string `json:"telegramChatId,omitempty"`
	DiscordHook   string `json:"discordWebhookUrl,omitempty"`
	SlackHook     string `json:"slackWebhookUrl,omitempty"`
	// WhatsApp delivery: a generic webhook URL (e.g. WA Business API /
	// callmebot-style gateway) posts the alert as `message`. Empty = disabled.
	WAWebhook string `json:"waWebhookUrl,omitempty"`
	// WANumber is the operator phone (E.164, no +) shown in dashboards/logs.
	WANumber    string `json:"waNumber,omitempty"`
	SMTPHost    string `json:"smtpHost,omitempty"`
	SMTPPort    int    `json:"smtpPort,omitempty"`
	SMTPUser    string `json:"smtpUser,omitempty"`
	SMTPPass    string `json:"smtpPass,omitempty"`
	SMTPFrom    string `json:"smtpFrom,omitempty"`
	MinSeverity string `json:"minSeverity"`
	CooldownMs  int    `json:"cooldown"`
}

type Proxy struct {
	TrustProxy         bool   `json:"trustProxy"`
	RealIPHeader       string `json:"realIpHeader"`
	ForwardedForHeader string `json:"forwardedForHeader"`
	// TrustedProxies is the set of proxy CIDRs/IPs allowed to set the
	// client IP headers. When TrustProxy is true but the immediate
	// connection is not in this list, the headers are ignored (the
	// connection IP is used) to prevent client IP spoofing.
	TrustedProxies []string `json:"trustedProxies"`
}

type Access struct {
	Enabled      bool            `json:"enabled"`
	ProtectAll   bool            `json:"protectAll"`
	Hosts        map[string]bool `json:"hosts"`
	LoginPath    string          `json:"loginPath"`
	LogoutPath   string          `json:"logoutPath"`
	TokenTTLMs   int             `json:"tokenTTLMs"`
	QueryParam   string          `json:"queryParam"`
	CookieName   string          `json:"cookieName"`
	CookieDomain string          `json:"cookieDomain"`
	CookieSecure bool            `json:"cookieSecure"`
	CaptchaMaxPM int             `json:"captchaMaxPerMin"`
	PrivatePaths []string        `json:"privatePaths"`
	ExemptPaths  []string        `json:"exemptPaths"`
}

// Node is one entry in the declarative sync topology. The engine always runs
// as Cluster.NodeID; every other entry is a peer that may or may not be
// online. Nothing here is a hard dependency: an optional peer that is offline
// is reported as "unavailable" and the engine keeps serving (single-node
// degradation), while Required=true only escalates the reported status.
type Node struct {
	ID string `json:"id"`
	// Address is optional metadata (host:port of the peer's admin API) used
	// for operator context. PeerSync itself talks over the shared Redis bus,
	// so an empty address is perfectly valid.
	Address string `json:"address,omitempty"`
	Role    string `json:"role,omitempty"`
	Site    string `json:"site,omitempty"`
	// Required marks a node whose absence should surface as degraded status.
	// Default false = optional, so a downed second node never breaks the
	// engine. Set true when a peer is genuinely part of the SLA.
	Required bool `json:"required,omitempty"`
}

type Cluster struct {
	Enabled bool   `json:"enabled"`
	NodeID  string `json:"nodeId"`
	// Role separates scrubbing tiers across servers: "all" (default, full
	// pipeline), "edge" (L3/L4 + rate limit only, forwards to core), or
	// "core" (full L7 behind edge tier). Site groups nodes per PoP.
	Role string `json:"role"`
	Site string `json:"site"`
	// Nodes is the declarative topology. Empty (the default) means "single
	// sync node": this engine is the only node and nothing else is expected.
	// Populating it scales 1 -> 2 -> 3+ without any code change; the local
	// node is always included, and optional peers may come and go.
	Nodes []Node `json:"nodes"`
	// Secret, Peers and TimeoutMs/UseTLS are kept for v2 config parity.
	// Deprecated: v3 coordination runs over the shared Redis bus, so there
	// is no HTTP peer link and no peer-side secret to verify.
	Secret         string   `json:"secret"`
	Peers          []string `json:"peers"`
	HeartbeatMs    int      `json:"heartbeatMs"`
	SyncIntervalMs int      `json:"syncIntervalMs"`
	TimeoutMs      int      `json:"timeoutMs"`
	UseTLS         bool     `json:"https"`

	// Redis state layer (L2)
	Redis RedisConfig `json:"redis"`
}

// NodeCount is the number of sync nodes this engine expects to be online. It
// is always >= 1: a single-node deployment is the baseline, never an error.
func (c Cluster) NodeCount() int {
	n := len(c.Topology())
	if n < 1 {
		return 1
	}
	return n
}

// Topology returns the configured node list with the local node guaranteed to
// be present (so a topology that only lists peers still reports 1/N online
// rather than 0/N). Peers without an ID are skipped instead of failing boot.
func (c Cluster) Topology() []Node {
	out := make([]Node, 0, len(c.Nodes)+1)
	seen := map[string]bool{}
	hasSelf := false
	for _, n := range c.Nodes {
		if n.ID == "" {
			continue // unusable entry: ignore rather than break the engine
		}
		if n.ID == c.NodeID {
			hasSelf = true
			if n.Role == "" {
				n.Role = c.Role
			}
			if n.Site == "" {
				n.Site = c.Site
			}
		}
		if seen[n.ID] {
			continue
		}
		seen[n.ID] = true
		out = append(out, n)
	}
	if !hasSelf {
		self := Node{ID: c.NodeID, Role: c.Role, Site: c.Site}
		if self.ID == "" {
			self.ID = "node-1"
		}
		if !seen[self.ID] {
			// A topology that lists "node-1" while nodeId is empty still has
			// exactly one node: don't report it twice.
			out = append([]Node{self}, out...)
		}
	}
	return out
}

// RequiredNodes lists the peer IDs that must be online for the cluster to be
// considered healthy. The local node is never listed.
func (c Cluster) RequiredNodes() []string {
	var out []string
	for _, n := range c.Topology() {
		if n.Required && n.ID != c.NodeID {
			out = append(out, n.ID)
		}
	}
	return out
}

type RedisConfig struct {
	Enabled   bool   `json:"enabled"`
	Address   string `json:"address"` // host:port (direct mode)
	Password  string `json:"password"`
	DB        int    `json:"db"`
	KeyPrefix string `json:"keyPrefix"`
	// Sentinel mode (HA/failover, multi-server or multi-site): when
	// Sentinels is non-empty the engine discovers the master via
	// Sentinel (MasterName, default "mymaster") and follows promotions
	// automatically. Address is ignored in this mode.
	Sentinels  []string `json:"sentinels"`
	MasterName string   `json:"masterName"`
}

// Default returns the built-in defaults, mirroring v2's config/default.js.
func Default() Config {
	return Config{
		Version: "3.0.0",
		Name:    "GarudaShield",
		Server: Server{
			HTTPPort:        8080,
			DashboardPort:   3000,
			Host:            "0.0.0.0",
			Backlog:         2048,
			KeepAliveMs:     5000,
			MaxHeaderBytes:  8192,
			MaxBodySizeByte: 1 << 20,
			MaxConcurrency:  1024,
		},
		Shield: Shield{
			ModeName:              "auto",
			LearningPeriodMs:      300000,
			HealthCheckIntervalMs: 5000,
			AutoScale:             true,
			UpstreamTimeoutMs:     10000,
			BudgetMs:              50,
			FloodRpsThreshold:     3000,
			FloodMinMs:            15000,
			AutoBlockTTL:          30000,
			VerdictBlockTTL:       30000,
			VerdictChallengeTTL:   10000,
			DataDir:               "data",
		},
		Upstream: Upstream{Host: "127.0.0.1", Port: 5000},
		Defense: Defense{
			Layer4: Layer4Config{
				Enabled: true, SynFloodProtection: true, MaxHalfOpenPerIP: 10,
				MaxConnPerSecPerIP: 50, MaxConnPerIP: 100, BogonFilter: true,
				PortScanDetection: true, UDPAmplificationProtection: true,
			},
			Layer7: Layer7Config{
				Enabled: true, Method: true, UserAgent: true, Headers: true,
				Referer: true, Origin: true, Cookies: true, Path: true,
				Query: true, ContentType: true, Protocol: true,
				MaxURILength: 2048, MaxHeaderCount: 50, MaxCookieLen: 4096,
				MaxBodySize: 1 << 20,
			},
			WAF: WAFConfig{
				Enabled: true, SQLi: true, XSS: true, CommandInjection: true,
				PathTraversal: true, LFI: true, RFI: true, Shellshock: true,
				Scanners: true, Matcher: "auto", FastFailTTL: 2000,
			},
			RateLimit: RateLimitConfig{
				GlobalMaxRPS: 50000, PerIPRPS: 100, PerIPBurst: 200, PerPathRPS: 1000,
				WindowMs: 1000, Adaptive: true, CooldownPeriodMS: 60000,
				RedEnabled: true, RedMinThreshold: 0.65, RedMaxThreshold: 0.95,
				TokenBucket: true, TokenBucketSize: 500, TokenRefillRate: 100,
				ConnLimitPerIP: 50, ConnRateLimit: 20, AutoTune: true, MaxAdaptiveLevel: 5,
			},
			Fingerprint: FingerprintConfig{
				Enabled: true, TLSFingerprint: true, HTTPFingerprint: true,
				BrowserConsistency: true, HeadlessDetection: true,
				JSChallenge: true, PoWChallenge: true,
				ChallengeDifficulty: 4, ChallengeTTLms: 30000, TokenTTLms: 600000,
			},
			Honeypot: Honeypot{Enabled: true, BlockTTLMs: 3600000, Score: 100},
		},
		Reputation: Reputation{
			Enabled: true, DecayIntervalMs: 60000, MaxScore: 100, MinScore: -100,
			SubnetScores: true, SubnetBlockMinScore: 40, BlockThreshold: 80, ChallengeThreshold: 40, DecayRate: 0.95,
		},
		Anomaly: Anomaly{
			Enabled: true, WindowSize: 60, ZScoreThreshold: 3.0, MinSamples: 10,
			EntropyThreshold: 4.5, EnableProtocolAnomaly: true,
			EnableRateAnomaly: true, EnablePayloadAnomaly: true,
		},
		Detection: Detection{
			EntropyWindow: 10, AnomalyThreshold: 3.0, BaselineSamples: 30,
			AttackCooldownMs: 30000, RateSpikeMultiplier: 4,
			LowEntropyThreshold: 0.3, UDPRatioThreshold: 0.8, SYNRatioThreshold: 0.7,
		},
		PyHook: PyHook{
			Enabled: false, Script: "", Python: "python3",
			TimeoutMs: 500, Mode: "monitor", FailClosed: true,
			Worker: false,
		},
		Quotas: QuotaConfig{
			Enabled:       false,
			PlanLimits:    map[string]int64{"free": 100000, "pro": 1000000, "enterprise": 5000000},
			FallbackLimit: 100000,
		},
		Logging: Logging{Level: "info", Path: "./logs/", MaxFiles: 30, MaxSize: 10485760},
		Alerts:  Alerts{MinSeverity: "warning", CooldownMs: 60000},
		Proxy:   Proxy{TrustProxy: true, RealIPHeader: "X-Real-IP", ForwardedForHeader: "X-Forwarded-For"},
		Access: Access{
			Enabled: true, ProtectAll: true, LoginPath: "/__gs/login",
			LogoutPath: "/__gs/logout", TokenTTLMs: 300000, QueryParam: "_gs",
			CookieName: "gs_access", CookieSecure: true, CaptchaMaxPM: 10,
		},
		Admin: AdminConfig{Enabled: true, Secret: ""},
		Cluster: Cluster{
			NodeID: "node-1", Role: "all", Site: "site-1",
			// Single sync node by default: Nodes stays empty so the engine
			// reports "1 / 1 Online" without inventing peers. Add entries to
			// cluster.nodes (or set SYNC_NODE_COUNT) to grow the cluster.
			HeartbeatMs: 10000, SyncIntervalMs: 30000, TimeoutMs: 5000,
			Redis: RedisConfig{Address: "127.0.0.1:6379", KeyPrefix: "gs"},
		},
		Whitelist: []string{"127.0.0.1", "::1"},
		Geo: GeoConfig{
			Enabled:     false,
			CountryPath: "data/GeoIP/geoip-country.mmdb",
			ASNPath:     "data/GeoIP/geoip-asn.mmdb",
		},
	}
}

// Load reads a JSON config file and merges it over the defaults. Environment
// overrides let containers (docker-compose --profile redis) enable Redis
// without editing the mounted config file:
//
//	GS_REDIS_ENABLED=on   GS_REDIS_ADDR=redis:6379   GS_REDIS_PREFIX=gs
func Load(path string) (Config, error) {
	cfg := Default()
	data, err := os.ReadFile(path)
	if err != nil {
		if os.IsNotExist(err) {
			applyEnvOverrides(&cfg)
			return cfg, nil // defaults only
		}
		return cfg, fmt.Errorf("read config: %w", err)
	}
	if err := json.Unmarshal(data, &cfg); err != nil {
		return cfg, fmt.Errorf("parse config %s: %w", path, err)
	}
	applyEnvOverrides(&cfg)
	return cfg, nil
}

// applyEnvOverrides promotes a few operational knobs to env vars so the engine
// can be rewired at deploy time (notably Redis auto-wire in docker, and secrets
// injected from the environment so they never live in a config file):
//
//	GS_REDIS_ENABLED=on   GS_REDIS_ADDR=redis:6379   GS_REDIS_PREFIX=gs
//	GS_ADMIN_SECRET=...   GS_ACCESS_SECRET=...
//	GS_NODE_ID=node-1     SYNC_NODE_COUNT=1
func applyEnvOverrides(cfg *Config) {
	if strings.EqualFold(os.Getenv("GS_REDIS_ENABLED"), "on") {
		cfg.Cluster.Redis.Enabled = true
	}
	if addr := os.Getenv("GS_REDIS_ADDR"); addr != "" {
		cfg.Cluster.Redis.Address = addr
	}
	if pfx := os.Getenv("GS_REDIS_PREFIX"); pfx != "" {
		cfg.Cluster.Redis.KeyPrefix = pfx
	}
	// Secrets from the environment take precedence over the config file so a
	// deployment can mount them via Docker/K8s secrets without editing JSON.
	if s := os.Getenv("GS_ADMIN_SECRET"); s != "" {
		cfg.Admin.Secret = s
	}
	if s := os.Getenv("GS_ACCESS_SECRET"); s != "" {
		cfg.AccessSecret = s
	}
	// Node ID for cluster identity (multi-node deployments tag each instance).
	if s := os.Getenv("GS_NODE_ID"); s != "" {
		cfg.Cluster.NodeID = s
	}
	// SYNC_NODE_COUNT declares how many sync nodes are ACTIVE right now.
	// SYNC_NODE_COUNT=1 is the single-node baseline and is a no-op when the
	// config already ships an explicit "cluster.nodes" list (the list always
	// wins so a topology edit is never silently overridden). Values > 1
	// synthesize optional peer placeholders, which makes scaling 1 -> 2 -> 3
	// a pure config/env change with no code edit.
	if s := envSyncNodeCount(); s > 0 && len(cfg.Cluster.Nodes) == 0 {
		applySyncNodeCount(&cfg.Cluster, s)
	}
}

// envSyncNodeCount reads the active sync node count from the environment,
// accepting both the bare SYNC_NODE_COUNT name and the GS_-prefixed variant.
func envSyncNodeCount() int {
	for _, key := range []string{"SYNC_NODE_COUNT", "GS_SYNC_NODE_COUNT"} {
		if v := strings.TrimSpace(os.Getenv(key)); v != "" {
			if n, err := strconv.Atoi(v); err == nil && n > 0 {
				return n
			}
		}
	}
	return 0
}

// applySyncNodeCount materialises a topology of n nodes: this engine first
// (self), then optional placeholders. Placeholders are optional on purpose --
// a downed node must never turn into an engine error.
func applySyncNodeCount(c *Cluster, n int) {
	self := Node{ID: c.NodeID, Role: c.Role, Site: c.Site}
	if self.ID == "" {
		self.ID = "node-1"
	}
	c.Nodes = []Node{self}
	for i := 2; i <= n; i++ {
		c.Nodes = append(c.Nodes, Node{ID: fmt.Sprintf("node-%d", i)})
	}
}
