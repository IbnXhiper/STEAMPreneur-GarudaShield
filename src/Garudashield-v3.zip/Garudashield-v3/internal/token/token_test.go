package token

import (
	"strings"
	"testing"
	"time"
)

func TestRoundTrip(t *testing.T) {
	sec := NewSecret()
	tok := Sign(sec, time.Minute, "1.2.3.4")
	if !Verify(sec, tok, "1.2.3.4") {
		t.Fatal("valid token rejected")
	}
	if Verify(sec, tok, "5.6.7.8") {
		t.Fatal("token must be IP-bound")
	}
}

func TestTamperAndExpiry(t *testing.T) {
	sec := NewSecret()

	tok := Sign(sec, time.Minute, "1.2.3.4")
	tampered := strings.Replace(tok, ".", ".f", 1)
	if Verify(sec, tampered, "1.2.3.4") {
		t.Fatal("tampered signature accepted")
	}

	expired := Sign(sec, -time.Second, "1.2.3.4")
	if Verify(sec, expired, "1.2.3.4") {
		t.Fatal("expired token accepted")
	}
	if Verify("wrong-secret", tok, "1.2.3.4") {
		t.Fatal("wrong secret accepted")
	}
}
