// Package token implements the gs_ok challenge-pass token from v2's shield.js:
// "<expiryMs>.<hmac_sha256(ip:expiry)>" — IP-bound, timing-safe verified.
package token

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"strconv"
	"strings"
	"time"
)

// NewSecret generates a random 32-byte secret (hex).
func NewSecret() string {
	b := make([]byte, 32)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func Sign(secret string, ttl time.Duration, ip string) string {
	expiry := time.Now().Add(ttl).UnixMilli()
	payload := ip + ":" + strconv.FormatInt(expiry, 10)
	mac := hmacSHA256(secret, payload)
	return strconv.FormatInt(expiry, 10) + "." + mac
}

func Verify(secret, tok, ip string) bool {
	parts := strings.Split(tok, ".")
	if len(parts) != 2 {
		return false
	}
	expiry, err := strconv.ParseInt(parts[0], 10, 64)
	if err != nil || expiry <= 0 || time.Now().UnixMilli() > expiry {
		return false
	}
	expected := hmacSHA256(secret, ip+":"+parts[0])
	got := parts[1]
	a, err1 := hex.DecodeString(got)
	b, err2 := hex.DecodeString(expected)
	if err1 != nil || err2 != nil || len(a) != len(b) {
		return false
	}
	return subtle.ConstantTimeCompare(a, b) == 1
}

func hmacSHA256(secret, payload string) string {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(payload))
	return hex.EncodeToString(mac.Sum(nil))
}
