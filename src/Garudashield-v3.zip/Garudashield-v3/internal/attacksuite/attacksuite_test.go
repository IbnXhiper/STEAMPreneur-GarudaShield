package attacksuite

import (
	"net/http"
	"net/http/httptest"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestCategoriesWellFormed ensures the release gate is structurally sound: every
// category has a stable ID, a title, and at least one case with a valid verdict.
func TestCategoriesWellFormed(t *testing.T) {
	seen := map[string]bool{}
	for _, cat := range Categories() {
		if cat.ID == "" || cat.Title == "" {
			t.Errorf("category missing id/title: %+v", cat)
		}
		if seen[cat.ID] {
			t.Errorf("duplicate category id: %s", cat.ID)
		}
		seen[cat.ID] = true
		if len(cat.Cases) == 0 {
			t.Errorf("category %s has no cases", cat.ID)
		}
		for _, c := range cat.Cases {
			if c.Verdict != Block && c.Verdict != Pass {
				t.Errorf("category %s case %s has bad verdict %q", cat.ID, c.Name, c.Verdict)
			}
			if c.Method == "" || c.Path == "" {
				t.Errorf("category %s case %s missing method/path", cat.ID, c.Name)
			}
		}
	}
	if len(seen) != 7 {
		t.Errorf("expected 7 gate categories, got %d", len(seen))
	}
}

// TestVerdictLogic checks the helper that classifies a status code into the
// expected verdict — the same logic the CLI runner uses against a live engine.
func verdictMatches(v Verdict, status int) bool {
	if v == Block {
		return status >= 400
	}
	return status < 400
}

func TestVerdictLogic(t *testing.T) {
	if !verdictMatches(Block, 403) {
		t.Error("403 should satisfy Block")
	}
	if verdictMatches(Block, 200) {
		t.Error("200 should NOT satisfy Block")
	}
	if !verdictMatches(Pass, 200) {
		t.Error("200 should satisfy Pass")
	}
	if verdictMatches(Pass, 403) {
		t.Error("403 should NOT satisfy Pass")
	}
}

// TestRoundTripHermetic verifies a Case runs through an injected transport
// (httptest) and that verdict classification works end-to-end without a live
// engine. The fake handler blocks any request carrying a sqlmap UA.
func TestRoundTripHermetic(t *testing.T) {
	handler := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ua := r.Header.Get("User-Agent")
		if ua == "sqlmap/1.6" || ua == "Nessus" {
			w.WriteHeader(http.StatusForbidden)
			return
		}
		w.WriteHeader(http.StatusOK)
	})
	srv := httptest.NewServer(handler)
	defer srv.Close()

	cat := Categories()
	var scanner Category
	for _, c := range cat {
		if c.ID == "scanner" {
			scanner = c
		}
	}
	if scanner.ID == "" {
		t.Fatal("scanner category not found")
	}
	for _, c := range scanner.Cases {
		status, err := c.RoundTrip(srv.Client().Transport, srv.URL)
		if err != nil {
			t.Fatalf("roundtrip: %v", err)
		}
		if !verdictMatches(c.Verdict, status) {
			t.Errorf("case %s: status %d did not satisfy verdict %s", c.Name, status, c.Verdict)
		}
	}
}

// TestArmedResolvesAllKnown ensures every category's Depends toggle resolves to
// a real config field and that the default config arms all of them (so a
// default build's gate covers all 7 families).
func TestArmedResolvesAllKnown(t *testing.T) {
	cfg := config.Default()
	for _, cat := range Categories() {
		armed, known := cat.Armed(cfg)
		if !known {
			t.Errorf("category %s: unknown dependency %q", cat.ID, cat.Depends)
			continue
		}
		if !armed {
			t.Errorf("category %s: default config should arm %q", cat.ID, cat.Depends)
		}
	}
}

// TestArmedDisabled proves a disabled defense is reported as not-armed so the
// CLI skips it rather than emitting a false failure.
func TestArmedDisabled(t *testing.T) {
	cfg := config.Default()
	cfg.Defense.WAF.Enabled = false
	for _, cat := range Categories() {
		if cat.Depends == "" || cat.ID == "l7flood" {
			continue
		}
		armed, known := cat.Armed(cfg)
		if !known {
			t.Errorf("category %s: dependency %q unexpectedly unknown", cat.ID, cat.Depends)
		}
		if armed {
			t.Errorf("category %s: WAF disabled should disarm %q", cat.ID, cat.Depends)
		}
	}
	rl := config.Default()
	rl.Defense.RateLimit.PerIPRPS = 0
	rl.Defense.RateLimit.GlobalMaxRPS = 0
	for _, cat := range Categories() {
		if cat.ID != "l7flood" {
			continue
		}
		if armed, _ := cat.Armed(rl); armed {
			t.Error("l7flood: rate limit disabled should disarm category")
		}
	}
}

// TestArmedUnknownToggle guards against a silent disarm: a Depends value the
// build does not recognize must report known=false so the CLI fails loudly.
func TestArmedUnknownToggle(t *testing.T) {
	if _, known := (Category{Depends: "defense.doesNotExist"}).Armed(config.Default()); known {
		t.Error("unknown dependency must report known=false")
	}
}

// TestDefaultUserAgentApplied ensures probes carry a browser UA (so the engine's
// blocked-ua rule does not mask real results) while an explicit case UA wins.
func TestDefaultUserAgentApplied(t *testing.T) {
	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		got = r.Header.Get("User-Agent")
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()

	if _, err := (Case{Method: "GET", Path: "/", Verdict: Pass}).RoundTrip(srv.Client().Transport, srv.URL); err != nil {
		t.Fatal(err)
	}
	if got != DefaultUserAgent {
		t.Errorf("expected default UA %q, got %q", DefaultUserAgent, got)
	}

	if _, err := (Case{Method: "GET", Path: "/", Header: map[string]string{"User-Agent": "custom/1"}}).RoundTrip(srv.Client().Transport, srv.URL); err != nil {
		t.Fatal(err)
	}
	if got != "custom/1" {
		t.Errorf("explicit UA should win, got %q", got)
	}
}

// TestRoundTripFollowsRedirect verifies a neutralizing redirect (307) is
// followed so the FINAL status is judged — the raw `..` traversal case relies
// on this (Go's ServeMux cleans the path and redirects before the WAF).
func TestRoundTripFollowsRedirect(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/old" {
			http.Redirect(w, r, "/new", http.StatusTemporaryRedirect)
			return
		}
		http.Error(w, "blocked", http.StatusForbidden)
	}))
	defer srv.Close()

	status, err := (Case{Method: "GET", Path: "/old", Verdict: Block}).RoundTrip(srv.Client().Transport, srv.URL)
	if err != nil {
		t.Fatal(err)
	}
	if !verdictMatches(Block, status) {
		t.Errorf("expected followed redirect to land on a block, got %d", status)
	}
}

// TestBaselineWellFormed checks the benign controls are valid and expected to pass.
func TestBaselineWellFormed(t *testing.T) {
	bl := Baseline()
	if len(bl) == 0 {
		t.Fatal("baseline is empty")
	}
	for _, c := range bl {
		if c.Verdict != Pass {
			t.Errorf("baseline case %s must expect Pass, got %s", c.Name, c.Verdict)
		}
		if c.Method == "" || c.Path == "" {
			t.Errorf("baseline case %s missing method/path", c.Name)
		}
	}
}
