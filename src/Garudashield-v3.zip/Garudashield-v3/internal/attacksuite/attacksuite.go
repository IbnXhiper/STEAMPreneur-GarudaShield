// Package attacksuite defines the release-gate attack battery for GarudaShield
// v3: a fixed set of 7 attack categories that MUST be mitigated (blocked or
// challenged) before a build ships to production. The categories mirror the v2
// attack surface and the WAF/L7 rules in internal/defense.
//
// The suite is defined as data so it can be (a) exercised against a live engine
// from the CLI/self-test, and (b) unit-tested here for structural integrity
// (every category has a probe vector and an expected verdict). It does NOT make
// network calls on its own — callers pass a transport (http.RoundTripper) so it
// stays hermetic in tests.
package attacksuite

import (
	"net/http"

	"github.com/ahkurdev/garudashield/internal/config"
)

// DefaultUserAgent is sent on every probe whose case does not set its own
// User-Agent. The engine blocks tool/CLI user agents (`curl`, `wget`,
// `go-http-client`, `python-requests`, ...) as `blocked-ua`; without a browser
// UA every case would be blocked for the wrong reason — attacks would "pass"
// trivially and the benign controls would fail. A browser UA makes the gate
// meaningful: a case only blocks because of its actual attack vector.
const DefaultUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

// Verdict is what the engine must do with an attack vector.
type Verdict string

const (
	// Block means the engine must return >= 400 (drop/challenge at the edge).
	Block Verdict = "block"
	// Pass means the engine must return < 400 (legitimate traffic).
	Pass Verdict = "pass"
)

// Case is one probe: a request vector and the verdict the engine must produce
// when the relevant defense is enabled.
type Case struct {
	Name    string
	Method  string
	Path    string
	Header  map[string]string
	Verdict Verdict
}

// Category groups cases under one attack family and the config toggle that
// arms it (so a skipped category can be reported, not failed).
type Category struct {
	ID      string // stable key, e.g. "sqli"
	Title   string
	Depends string // defense config field that must be enabled ("" = always on)
	Cases   []Case
}

// Categories returns the 7 release-gate attack families. Order is stable.
func Categories() []Category {
	return []Category{
		{
			ID:      "sqli",
			Title:   "SQL Injection",
			Depends: "defense.waf.sqli",
			Cases: []Case{
				{Name: "classic union", Method: "GET", Path: "/?id=1%20UNION%20SELECT%20password%20FROM%20users", Verdict: Block},
				{Name: "boolean blind", Method: "GET", Path: "/?q='%20OR%20'1'='1", Verdict: Block},
				{Name: "stacked query", Method: "GET", Path: "/?id=1;DROP%20TABLE%20users", Verdict: Block},
			},
		},
		{
			ID:      "xss",
			Title:   "Cross-Site Scripting",
			Depends: "defense.waf.xss",
			Cases: []Case{
				{Name: "script tag", Method: "GET", Path: "/?q=<script>alert(1)</script>", Verdict: Block},
				{Name: "img onerror", Method: "GET", Path: "/?q=<img%20src=x%20onerror=alert(1)>", Verdict: Block},
			},
		},
		{
			ID:      "pathtraversal",
			Title:   "Path Traversal / LFI",
			Depends: "defense.waf.pathTraversal",
			Cases: []Case{
				{Name: "dotdot", Method: "GET", Path: "/../../../../etc/passwd", Verdict: Block},
				{Name: "encoded", Method: "GET", Path: "/%2e%2e%2f%2e%2e%2fetc%2fpasswd", Verdict: Block},
			},
		},
		{
			ID:      "shellshock",
			Title:   "Shellshock (CVE-2014-6271)",
			Depends: "defense.waf.shellshock",
			Cases: []Case{
				{Name: "cgi header", Method: "GET", Path: "/", Header: map[string]string{"User-Agent": "() { :; }; /bin/cat /etc/passwd"}, Verdict: Block},
			},
		},
		{
			ID:      "cmdi",
			Title:   "Command Injection",
			Depends: "defense.waf.commandInjection",
			Cases: []Case{
				{Name: "pipe", Method: "GET", Path: "/?host=127.0.0.1;cat%20/etc/passwd", Verdict: Block},
				{Name: "backtick", Method: "GET", Path: "/?cmd=`id`", Verdict: Block},
			},
		},
		{
			ID:      "l7flood",
			Title:   "L7 HTTP Flood",
			Depends: "defense.rateLimit",
			Cases: []Case{
				// A single benign request must pass; the flood itself is rate-
				// limited over many requests, verified separately by the harness.
				{Name: "benign single", Method: "GET", Path: "/health", Verdict: Pass},
			},
		},
		{
			ID:      "scanner",
			Title:   "Scanner / Enumeration UA",
			Depends: "defense.waf.scanners",
			Cases: []Case{
				{Name: "sqlmap ua", Method: "GET", Path: "/", Header: map[string]string{"User-Agent": "sqlmap/1.6"}, Verdict: Block},
				{Name: "nessus ua", Method: "GET", Path: "/", Header: map[string]string{"User-Agent": "Nessus"}, Verdict: Block},
			},
		},
	}
}

// RoundTrip performs the probe and returns the FINAL status code. It follows
// redirects (an engine may neutralize a raw `..` traversal with a 307 to the
// cleaned path, which is then evaluated and blocked or upstreamed) and injects
// DefaultUserAgent unless the case sets its own.
func (c Case) RoundTrip(rt http.RoundTripper, base string) (int, error) {
	req, err := http.NewRequest(c.Method, base+c.Path, nil)
	if err != nil {
		return 0, err
	}
	for k, v := range c.Header {
		req.Header.Set(k, v)
	}
	if req.Header.Get("User-Agent") == "" {
		req.Header.Set("User-Agent", DefaultUserAgent)
	}
	if rt == nil {
		rt = http.DefaultTransport
	}
	resp, err := (&http.Client{Transport: rt}).Do(req)
	if err != nil {
		return 0, err
	}
	defer resp.Body.Close()
	return resp.StatusCode, nil
}

// Baseline returns benign control requests that MUST pass on a healthy,
// correctly-wired engine. They guard the gate against a false green where every
// request is blocked for an unrelated reason (bad UA, an always-on access gate,
// a global rule) and thus every attack case would "block" trivially. Only
// engine-served paths are used so the controls do not depend on an upstream.
func Baseline() []Case {
	return []Case{
		{Name: "benign health", Method: "GET", Path: "/health", Verdict: Pass},
		{Name: "benign health query", Method: "GET", Path: "/health?probe=1", Verdict: Pass},
	}
}

// Armed reports whether the category's `Depends` defense toggle is enabled in
// cfg. known is false when Depends names a field this build does not
// recognize, so a config rename cannot silently disable a gate category.
func (c Category) Armed(cfg config.Config) (armed, known bool) {
	return resolveDepends(c.Depends, cfg)
}

func resolveDepends(dep string, cfg config.Config) (armed, known bool) {
	switch dep {
	case "":
		return true, true
	case "defense.rateLimit":
		return cfg.Defense.RateLimit.PerIPRPS > 0 || cfg.Defense.RateLimit.GlobalMaxRPS > 0, true
	case "defense.waf.sqli":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.SQLi, true
	case "defense.waf.xss":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.XSS, true
	case "defense.waf.commandInjection":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.CommandInjection, true
	case "defense.waf.pathTraversal":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.PathTraversal, true
	case "defense.waf.shellshock":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.Shellshock, true
	case "defense.waf.scanners":
		return cfg.Defense.WAF.Enabled && cfg.Defense.WAF.Scanners, true
	default:
		return false, false
	}
}
