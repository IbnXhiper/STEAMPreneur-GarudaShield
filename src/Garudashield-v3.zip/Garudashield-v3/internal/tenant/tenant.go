// Package tenant resolves and isolates commercial tenants. A tenant is scoped
// by its protected domain (Host header) and carries its own plan, license, and
// per-tenant rate limits. Every query must be tenant-scoped — there is no global
// read that can leak one customer's data to another.
package tenant

import (
	"context"
	"errors"
	"fmt"
	"sync"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Tenant is the persisted commercial identity for one customer.
type Tenant struct {
	ID         string
	Name       string
	Plan       string
	Domain     string
	LicenseKey string
	LicenseExp int64
	Status     string // active | suspended | revoked
}

// Store loads and caches tenant records from PostgreSQL. The cache is a
// single-flight read-through; writes go straight to PG and invalidate the cache.
type Store struct {
	pool  *pgxpool.Pool
	mu    sync.RWMutex
	cache map[string]*Tenant // keyed by domain and by id
}

// New builds a tenant store over the given pool.
func New(pool *pgxpool.Pool) *Store {
	return &Store{pool: pool, cache: map[string]*Tenant{}}
}

// Pool exposes the backing pool to tightly scoped commercial transactions.
func (s *Store) Pool() *pgxpool.Pool { return s.pool }

// Invalidate flushes tenant reads after an operator transaction commits.
func (s *Store) Invalidate() {
	s.mu.Lock()
	s.cache = map[string]*Tenant{}
	s.mu.Unlock()
}

// ResolveByDomain returns the tenant protecting the given Host, or an error if
// none matches. Uses a read-through cache; a miss hits Postgres with a
// parameterized (injection-safe) query.
func (s *Store) ResolveByDomain(ctx context.Context, host string) (*Tenant, error) {
	host = normalizeHost(host)
	s.mu.RLock()
	t, ok := s.cache[host]
	s.mu.RUnlock()
	if ok {
		return t, nil
	}

	var tnt Tenant
	err := s.pool.QueryRow(ctx,
		`SELECT id, name, plan, COALESCE(domain,''), COALESCE(license_key,''), license_exp, COALESCE(status,'active')
		 FROM tenants WHERE domain = $1`, host).
		Scan(&tnt.ID, &tnt.Name, &tnt.Plan, &tnt.Domain, &tnt.LicenseKey, &tnt.LicenseExp, &tnt.Status)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			// Fallback: an ADDITIONAL protected domain a tenant proved ownership
			// of (protected_assets, DNS-TXT verified) resolves to the same
			// tenant. Only verified rows are honoured — an unverified asset
			// never routes traffic.
			var tid string
			aerr := s.pool.QueryRow(ctx,
				`SELECT tenant_id FROM protected_assets WHERE domain = $1 AND status = 'verified'`,
				host).Scan(&tid)
			if aerr != nil {
				return nil, ErrNoTenant
			}
			t2, gerr := s.getUncached(ctx, tid)
			if gerr != nil {
				return nil, ErrNoTenant
			}
			s.mu.Lock()
			s.cache[host] = t2
			s.cache[t2.ID] = t2
			s.mu.Unlock()
			return t2, nil
		}
		return nil, err
	}
	s.mu.Lock()
	s.cache[host] = &tnt
	s.cache[tnt.ID] = &tnt
	s.mu.Unlock()
	return &tnt, nil
}

// getUncached loads a tenant by id straight from Postgres (no cache read).
func (s *Store) getUncached(ctx context.Context, id string) (*Tenant, error) {
	var tnt Tenant
	err := s.pool.QueryRow(ctx,
		`SELECT id, name, plan, COALESCE(domain,''), COALESCE(license_key,''), license_exp, COALESCE(status,'active')
		 FROM tenants WHERE id = $1`, id).
		Scan(&tnt.ID, &tnt.Name, &tnt.Plan, &tnt.Domain, &tnt.LicenseKey, &tnt.LicenseExp, &tnt.Status)
	if err != nil {
		return nil, err
	}
	return &tnt, nil
}

// Get loads a tenant by ID (used by authenticated admin requests).
func (s *Store) Get(ctx context.Context, id string) (*Tenant, error) {
	s.mu.RLock()
	t, ok := s.cache[id]
	s.mu.RUnlock()
	if ok {
		return t, nil
	}
	var tnt Tenant
	err := s.pool.QueryRow(ctx,
		`SELECT id, name, plan, COALESCE(domain,''), COALESCE(license_key,''), license_exp, COALESCE(status,'active')
		 FROM tenants WHERE id = $1`, id).
		Scan(&tnt.ID, &tnt.Name, &tnt.Plan, &tnt.Domain, &tnt.LicenseKey, &tnt.LicenseExp, &tnt.Status)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrNoTenant
		}
		return nil, err
	}
	s.mu.Lock()
	s.cache[tnt.ID] = &tnt
	s.mu.Unlock()
	return &tnt, nil
}

// Create inserts a new tenant (plan defaults to free). Returns the new tenant.
func (s *Store) Create(ctx context.Context, id, name, domain string) (*Tenant, error) {
	_, err := s.pool.Exec(ctx,
		`INSERT INTO tenants (id, name, plan, domain) VALUES ($1,$2,'free',$3)
		 ON CONFLICT (id) DO NOTHING`, id, name, domain)
	if err != nil {
		return nil, err
	}
	return s.Get(ctx, id)
}

// SetLicense persists a license key + expiry for a tenant. The whole read cache
// is flushed: tenants are few, and a partial flush (by id only) would leave a
// stale domain-keyed entry after ResolveByDomain, so a freshly issued license
// would not take effect until restart.
func (s *Store) SetLicense(ctx context.Context, id, key string, exp int64) error {
	if _, err := s.pool.Exec(ctx,
		`UPDATE tenants SET license_key = $2, license_exp = $3, status = 'active' WHERE id = $1`,
		id, key, exp); err != nil {
		return err
	}
	s.mu.Lock()
	s.cache = map[string]*Tenant{}
	s.mu.Unlock()
	return nil
}

// SetStatus flips a tenant's commercial status (active/suspended/revoked).
// A suspended/revoked tenant fails the edge license gate (402) until
// reactivated. The cache is flushed (few tenants).
func (s *Store) SetStatus(ctx context.Context, id, status string) error {
	if status != "active" && status != "suspended" && status != "revoked" {
		return fmt.Errorf("invalid tenant status %q", status)
	}
	if _, err := s.pool.Exec(ctx,
		`UPDATE tenants SET status = $2 WHERE id = $1`, id, status); err != nil {
		return err
	}
	s.mu.Lock()
	s.cache = map[string]*Tenant{}
	s.mu.Unlock()
	return nil
}

// Renew extends a tenant's license expiry by months months (keeping the
// existing key) and marks it active again. Returns the new expiry.
func (s *Store) Renew(ctx context.Context, id string, months int) (int64, error) {
	if months <= 0 {
		months = 1
	}
	now := time.Now().Unix()
	// Extend from the later of now or the current expiry so renewals never
	// shorten an active license.
	var cur int64
	if err := s.pool.QueryRow(ctx, `SELECT COALESCE(license_exp,0) FROM tenants WHERE id = $1`, id).Scan(&cur); err != nil {
		return 0, err
	}
	base := now
	if cur > now {
		base = cur
	}
	exp := base + int64(months)*30*24*3600
	if _, err := s.pool.Exec(ctx,
		`UPDATE tenants SET license_exp = $2, status = 'active' WHERE id = $1`, id, exp); err != nil {
		return 0, err
	}
	s.mu.Lock()
	s.cache = map[string]*Tenant{}
	s.mu.Unlock()
	return exp, nil
}

// Audit writes a commercial audit row (tenant-scoped). Best-effort: a failure
// to record never breaks the primary action.
func (s *Store) Audit(ctx context.Context, tenantID, actor, action, detail, ip string) {
	_, _ = s.pool.Exec(ctx,
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip) VALUES ($1,$2,$3,$4,$5)`,
		tenantID, actor, action, detail, ip)
}

// ErrNoTenant is returned when no tenant protects the given host/id.
var ErrNoTenant = errors.New("no tenant for host")

func normalizeHost(h string) string {
	for i := len(h) - 1; i >= 0; i-- {
		if h[i] == ':' {
			return h[:i]
		}
	}
	return h
}
