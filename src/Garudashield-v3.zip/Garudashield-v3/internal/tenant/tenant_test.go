package tenant

import (
	"context"
	"os"
	"testing"

	"github.com/ahkurdev/garudashield/internal/db"
)

// TestTenantStorePG exercises the Postgres-backed tenant store end-to-end.
// It is skipped when GS_DATABASE_URL is not set (CI without a DB).
func TestTenantStorePG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set; skipping PG integration test")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Fatalf("connect: %v", err)
	}
	defer pool.Close()

	ctx := context.Background()
	if err := db.Migrate(ctx, pool); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	store := New(pool)
	id := "test-tenant-pg"
	// Clean slate.
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, id)

	created, err := store.Create(ctx, id, "PT Maju", "maju.example.com")
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if created.Plan != "free" {
		t.Fatalf("expected free plan, got %s", created.Plan)
	}

	// Resolve by domain (parameterized query — injection-safe).
	got, err := store.ResolveByDomain(ctx, "maju.example.com")
	if err != nil {
		t.Fatalf("resolve: %v", err)
	}
	if got.ID != id {
		t.Fatalf("resolved wrong tenant: %s", got.ID)
	}

	// Injection attempt in Host must NOT break or leak.
	_, err = store.ResolveByDomain(ctx, "maju.example.com' OR '1'='1")
	if err == nil {
		t.Fatal("sql injection in host not rejected")
	}

	// SetLicense persists.
	if err := store.SetLicense(ctx, id, "key:pro:0:sig", 0); err != nil {
		t.Fatalf("setlicense: %v", err)
	}
	got2, _ := store.Get(ctx, id)
	if got2.LicenseKey != "key:pro:0:sig" {
		t.Fatalf("license not persisted: %q", got2.LicenseKey)
	}

	// Cleanup.
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, id)
}
