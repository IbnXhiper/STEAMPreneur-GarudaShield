package storage

import (
	"sync"
	"time"
)

// SlidingWindow is a bucketed sliding window counter — port of v2's
// SlidingWindowCounter (default: 1000 ms window / 200 ms buckets).
// Increment(key) adds one to the current slot and returns the count across
// the whole window for that key.
type SlidingWindow struct {
	mu         sync.Mutex
	windowMS   int64
	bucketMS   int64
	numBuckets int
	keys       map[string]*swKeyState
	lastTouch  map[string]int64
}

type swKeyState struct {
	slots []swSlot
	cur   int
}

type swSlot struct {
	start int64 // unix ms of slot start
	count int64
}

func NewSlidingWindow(windowMS, bucketMS int64) *SlidingWindow {
	if windowMS <= 0 {
		windowMS = 1000
	}
	if bucketMS <= 0 {
		bucketMS = 200
	}
	n := windowMS / bucketMS
	if n < 1 {
		n = 1
	}
	return &SlidingWindow{
		windowMS:   windowMS,
		bucketMS:   bucketMS,
		numBuckets: int(n),
		keys:       make(map[string]*swKeyState),
		lastTouch:  make(map[string]int64),
	}
}

func slotStartFor(now, bucketMS int64) int64 { return now - now%bucketMS }

// Increment bumps the current slot for key and returns the window total.
func (w *SlidingWindow) Increment(key string) int64 {
	now := time.Now().UnixMilli()
	w.mu.Lock()
	defer w.mu.Unlock()
	st := w.keys[key]
	if st == nil {
		st = &swKeyState{slots: make([]swSlot, w.numBuckets)}
		w.keys[key] = st
	}
	start := slotStartFor(now, w.bucketMS)
	cur := &st.slots[st.cur]
	if cur.start != start {
		st.cur = (st.cur + 1) % w.numBuckets
		st.slots[st.cur] = swSlot{start: start}
		cur = &st.slots[st.cur]
	}
	cur.count++
	w.lastTouch[key] = now
	return w.sumLocked(st, now)
}

// Count returns the current window total without incrementing.
func (w *SlidingWindow) Count(key string) int64 {
	now := time.Now().UnixMilli()
	w.mu.Lock()
	defer w.mu.Unlock()
	st, ok := w.keys[key]
	if !ok {
		return 0
	}
	return w.sumLocked(st, now)
}

func (w *SlidingWindow) sumLocked(st *swKeyState, now int64) int64 {
	cutoff := now - w.windowMS + 1
	var total int64
	for i := range st.slots {
		if s := st.slots[i]; s.start >= cutoff && s.start <= now {
			total += s.count
		}
	}
	return total
}

// Prune drops keys idle longer than the window (memory guard; improvement over v2).
func (w *SlidingWindow) Prune() int {
	now := time.Now().UnixMilli()
	w.mu.Lock()
	defer w.mu.Unlock()
	n := 0
	for k, t := range w.lastTouch {
		if now-t > w.windowMS*2 {
			delete(w.keys, k)
			delete(w.lastTouch, k)
			n++
		}
	}
	return n
}

// KeyCount reports how many distinct keys are tracked.
func (w *SlidingWindow) KeyCount() int {
	w.mu.Lock()
	defer w.mu.Unlock()
	return len(w.keys)
}

// Clear resets all keys.
func (w *SlidingWindow) Clear() {
	w.mu.Lock()
	w.keys = make(map[string]*swKeyState)
	w.lastTouch = make(map[string]int64)
	w.mu.Unlock()
}
