// Package storage provides the in-process L1 data primitives used across the
// engine: TTL key-value store, sliding-window counters, and a ring buffer.
// These are Go ports of v2's src/storage/store.js with identical semantics.
package storage

import (
	"sync"
	"time"
)

// ---------- TTL KV Store (port of MemoryStore) ----------

type entry struct {
	value    any
	expireAt int64 // unix ms; 0 = no expiry
}

// Store is a mutex-guarded KV store with per-key TTL and lazy expiry,
// plus a periodic janitor. Port of v2 MemoryStore.
type Store struct {
	mu        sync.RWMutex
	data      map[string]entry
	janitor   *time.Ticker
	done      chan struct{}
	onceClose sync.Once
	hits      atomicCounter
	misses    atomicCounter
}

// NewStore creates a store whose janitor sweeps every 30s (v2 default).
func NewStore() *Store {
	s := &Store{
		data: make(map[string]entry),
		done: make(chan struct{}),
	}
	s.janitor = time.NewTicker(30 * time.Second)
	go func() {
		for {
			select {
			case <-s.janitor.C:
				s.Cleanup()
			case <-s.done:
				return
			}
		}
	}()
	return s
}

func (s *Store) Set(key string, value any, ttlMs int64) {
	var exp int64
	if ttlMs > 0 {
		exp = time.Now().UnixMilli() + ttlMs
	}
	s.mu.Lock()
	s.data[key] = entry{value: value, expireAt: exp}
	s.mu.Unlock()
}

func (s *Store) Get(key string) (any, bool) {
	s.mu.RLock()
	e, ok := s.data[key]
	s.mu.RUnlock()
	if !ok {
		s.misses.add(1)
		return nil, false
	}
	if e.expireAt > 0 && time.Now().UnixMilli() >= e.expireAt {
		s.mu.Lock()
		delete(s.data, key)
		s.mu.Unlock()
		s.misses.add(1)
		return nil, false
	}
	s.hits.add(1)
	return e.value, true
}

// GetInt returns the stored value as int64 (0 if missing or wrong type).
func (s *Store) GetInt(key string) int64 {
	v, ok := s.Get(key)
	if !ok {
		return 0
	}
	switch n := v.(type) {
	case int64:
		return n
	case int:
		return int64(n)
	default:
		return 0
	}
}

func (s *Store) Delete(key string) {
	s.mu.Lock()
	delete(s.data, key)
	s.mu.Unlock()
}

// Incr atomically increments a numeric value; ttlMs refreshes expiry.
func (s *Store) Incr(key string, delta int64, ttlMs int64) int64 {
	s.mu.Lock()
	defer s.mu.Unlock()
	e, ok := s.data[key]
	now := time.Now().UnixMilli()
	if ok && e.expireAt > 0 && now >= e.expireAt {
		ok = false
	}
	var cur int64
	if ok {
		if n, isNum := e.value.(int64); isNum {
			cur = n
		}
	}
	cur += delta
	var exp int64
	if ttlMs > 0 {
		exp = now + ttlMs
	}
	s.data[key] = entry{value: cur, expireAt: exp}
	return cur
}

// ForEach iterates live (non-expired) entries; return false to stop.
func (s *Store) ForEach(fn func(key string, val any) bool) {
	now := time.Now().UnixMilli()
	s.mu.RLock()
	snapshot := make(map[string]entry, len(s.data))
	for k, e := range s.data {
		if e.expireAt == 0 || now < e.expireAt {
			snapshot[k] = e
		}
	}
	s.mu.RUnlock()
	for k, e := range snapshot {
		if !fn(k, e.value) {
			return
		}
	}
}

// Cleanup removes expired entries. Returns number removed.
func (s *Store) Cleanup() int {
	now := time.Now().UnixMilli()
	s.mu.Lock()
	defer s.mu.Unlock()
	n := 0
	for k, e := range s.data {
		if e.expireAt > 0 && now >= e.expireAt {
			delete(s.data, k)
			n++
		}
	}
	return n
}

// Size reports the number of entries including not-yet-swept expired ones.
func (s *Store) Size() int {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return len(s.data)
}

// Stats mirrors v2 hit/miss accounting.
func (s *Store) Stats() (hits, misses uint64) { return s.hits.get(), s.misses.get() }

// Close stops the janitor goroutine.
func (s *Store) Close() {
	s.onceClose.Do(func() {
		close(s.done)
		s.janitor.Stop()
	})
}

// ---------- tiny atomic counters ----------

type atomicCounter struct {
	mu sync.Mutex
	v  uint64
}

func (c *atomicCounter) add(d uint64) {
	c.mu.Lock()
	c.v += d
	c.mu.Unlock()
}

func (c *atomicCounter) get() uint64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.v
}
