package storage

import "sync"

// Ring is a fixed-capacity circular buffer — port of v2's RingBuffer.
// Push overwrites the oldest element when full. Iteration helpers go
// newest-first so callers can implement cutoff semantics cheaply.
type Ring[T any] struct {
	mu   sync.Mutex
	buf  []T
	next int // index where next push goes
	size int
}

func NewRing[T any](capacity int) *Ring[T] {
	if capacity < 1 {
		capacity = 1
	}
	return &Ring[T]{buf: make([]T, capacity)}
}

// Push appends an element, evicting the oldest when at capacity.
func (r *Ring[T]) Push(v T) {
	r.mu.Lock()
	r.buf[r.next] = v
	r.next = (r.next + 1) % len(r.buf)
	if r.size < len(r.buf) {
		r.size++
	}
	r.mu.Unlock()
}

// Len returns the number of live elements.
func (r *Ring[T]) Len() int {
	r.mu.Lock()
	defer r.mu.Unlock()
	return r.size
}

// ForEachNewest iterates newest → oldest; return false from fn to stop early.
func (r *Ring[T]) ForEachNewest(fn func(T) bool) {
	r.mu.Lock()
	// copy indices under lock; fn runs unlocked to avoid re-entrancy deadlock
	type item struct {
		idx int
	}
	items := make([]item, 0, r.size)
	for i := 0; i < r.size; i++ {
		idx := (r.next - 1 - i + len(r.buf)) % len(r.buf)
		items = append(items, item{idx: idx})
	}
	buf := r.buf
	r.mu.Unlock()

	for _, it := range items {
		if !fn(buf[it.idx]) {
			return
		}
	}
}

// Snapshot copies elements oldest → newest.
func (r *Ring[T]) Snapshot() []T {
	r.mu.Lock()
	out := make([]T, 0, r.size)
	for i := r.size; i > 0; i-- {
		idx := (r.next - i + len(r.buf)) % len(r.buf)
		out = append(out, r.buf[idx])
	}
	r.mu.Unlock()
	return out
}

// Clear empties the ring.
func (r *Ring[T]) Clear() {
	r.mu.Lock()
	r.next = 0
	r.size = 0
	r.mu.Unlock()
}
