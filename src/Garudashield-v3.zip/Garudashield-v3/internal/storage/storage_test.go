package storage

import (
	"sync"
	"testing"
	"time"
)

func TestStoreTTLExpiry(t *testing.T) {
	s := NewStore()
	defer s.Close()
	s.Set("k", "v", 50)
	if _, ok := s.Get("k"); !ok {
		t.Fatal("expected value right after set")
	}
	time.Sleep(60 * time.Millisecond)
	if _, ok := s.Get("k"); ok {
		t.Fatal("expected value to expire")
	}
}

func TestStoreIncrAtomic(t *testing.T) {
	s := NewStore()
	defer s.Close()
	var wg sync.WaitGroup
	for i := 0; i < 100; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			s.Incr("n", 1, 60000)
		}()
	}
	wg.Wait()
	if got := s.GetInt("n"); got != 100 {
		t.Fatalf("want 100, got %d", got)
	}
}

func TestSlidingWindowCounts(t *testing.T) {
	w := NewSlidingWindow(300, 100) // 3 buckets of 100ms
	w.Increment("ip1")
	w.Increment("ip1")
	w.Increment("ip1")
	if c := w.Count("ip1"); c != 3 {
		t.Fatalf("count should be 3, got %d", c)
	}
	if c := w.Count("other"); c != 0 {
		t.Fatalf("other key should be 0, got %d", c)
	}
}

func TestSlidingWindowDecay(t *testing.T) {
	w := NewSlidingWindow(200, 100)
	w.Increment("k")
	time.Sleep(250 * time.Millisecond) // window fully elapsed
	if c := w.Count("k"); c != 0 {
		t.Fatalf("window should have decayed to 0, got %d", c)
	}
}

func TestRingOverwrite(t *testing.T) {
	r := NewRing[int](3)
	for i := 0; i < 5; i++ {
		r.Push(i)
	}
	if r.Len() != 3 {
		t.Fatalf("cap exceeded: len=%d", r.Len())
	}
	got := r.Snapshot()
	want := []int{2, 3, 4}
	for i := range want {
		if got[i] != want[i] {
			t.Fatalf("snapshot=%v want %v", got, want)
		}
	}
}
