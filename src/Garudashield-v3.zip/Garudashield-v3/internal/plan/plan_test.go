package plan

import "testing"

// TestMaxDomains pins the tier caps the portal and the asset API rely on. The
// free tier must be exactly 1; paid tiers are unlimited (0); anything unknown
// or empty must fall back to the free cap so a misconfigured plan can never
// grant more than the entry tier.
func TestMaxDomains(t *testing.T) {
	cases := []struct {
		plan string
		want int
	}{
		{"free", 1},
		{"FREE", 1},
		{" free ", 1},
		{"pro", 0},
		{"enterprise", 0},
		{"", 1},       // empty -> free (deny-by-default)
		{"trial", 1},  // unknown -> free
		{"FREE\n", 1}, // whitespace trimmed
		{"Pro", 0},    // case-insensitive
	}
	for _, c := range cases {
		if got := MaxDomains(c.plan); got != c.want {
			t.Errorf("MaxDomains(%q) = %d, want %d", c.plan, got, c.want)
		}
	}
}

func TestDomainLimitReached(t *testing.T) {
	// Free: 0 domains ok, 1 domain = at the cap (reached), 2 = over.
	if DomainLimitReached("free", 0) {
		t.Error("free with 0 domains must not be reached")
	}
	if !DomainLimitReached("free", 1) {
		t.Error("free with 1 domain must be reached")
	}
	if !DomainLimitReached("free", 2) {
		t.Error("free with 2 domains must be reached")
	}
	// Pro is unlimited: never reached regardless of count.
	if DomainLimitReached("pro", 1000) {
		t.Error("pro is unlimited and must never be reached")
	}
	// Unknown plan behaves like free.
	if !DomainLimitReached("weird", 1) {
		t.Error("unknown plan must behave like free (reached at 1)")
	}
}
