// Package plan defines the per-tier limits the control plane enforces on the
// customer-facing control plane (currently the number of protected domains a
// tenant may hold). Limits are keyed by the tenant's plan name
// (license.Plan: free | pro | enterprise). A limit of 0 means "unlimited".
//
// An empty or unknown plan name falls back to the FREE tier on purpose: a
// typo'd or unconfigured plan must never grant more than the entry tier. This
// mirrors the engine's fail-closed posture — an unrecognized plan is treated as
// the most restrictive one, not the most permissive.
package plan

import "strings"

// Plan names recognised by the commercial control plane (mirrors
// license.Plan). Kept as plain strings so callers that already store the plan
// name (tenant.Tenant.Plan) need no import cycle.
const (
	Free       = "free"
	Pro        = "pro"
	Enterprise = "enterprise"
)

// domainLimits maps a plan name -> the maximum number of protected domains it
// may hold (0 = unlimited). The free tier is intentionally capped so the portal
// can prompt an upgrade; paid tiers are uncapped until product sets a number.
var domainLimits = map[string]int{
	Free:       1,
	Pro:        0,
	Enterprise: 0,
}

// MaxDomains returns the maximum number of protected domains a tenant on the
// given plan may hold. 0 means unlimited. An empty or unknown plan is treated
// as the free tier (deny-by-default).
func MaxDomains(plan string) int {
	p := strings.ToLower(strings.TrimSpace(plan))
	if p == "" {
		p = Free
	}
	if n, ok := domainLimits[p]; ok {
		return n
	}
	return domainLimits[Free]
}

// DomainLimitReached reports whether the tenant is already at (or over) its
// plan's domain cap given how many domains it currently holds. A limit of 0
// (unlimited) is never reached.
func DomainLimitReached(plan string, current int) bool {
	max := MaxDomains(plan)
	return max > 0 && current >= max
}
