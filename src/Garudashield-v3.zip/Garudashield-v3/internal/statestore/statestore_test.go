package statestore

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

func TestMemoryStore(t *testing.T) {
	s := newMemory()
	defer s.Close()
	ctx := context.Background()
	s.Set(ctx, "k", "v", 0)
	if v, ok := s.Get(ctx, "k"); !ok || v != "v" {
		t.Fatalf("get = %q,%v want v,true", v, ok)
	}
	s.Set(ctx, "exp", "x", 1)
	time.Sleep(15 * time.Millisecond)
	if _, ok := s.Get(ctx, "exp"); ok {
		t.Fatalf("expected expired key to be gone")
	}
	s.Delete(ctx, "k")
	if _, ok := s.Get(ctx, "k"); ok {
		t.Fatalf("expected deleted key gone")
	}
	// ForEach
	s.Set(ctx, "p:1", "a", 0)
	s.Set(ctx, "p:2", "b", 0)
	got := map[string]string{}
	s.ForEach("p:", func(k, v string) bool { got[k] = v; return true })
	if got["p:1"] != "a" || got["p:2"] != "b" {
		t.Fatalf("foreach = %v", got)
	}
	if n := s.Incr(ctx, "c", 5, 0); n != 5 {
		t.Fatalf("incr = %d want 5", n)
	}
}

func TestHybridLocal(t *testing.T) {
	h := New(config.RedisConfig{Enabled: false})
	defer h.Close()
	if h.Mode() != "local" {
		t.Fatalf("mode = %q want local", h.Mode())
	}
	ctx := context.Background()
	h.Set(ctx, "blk:1.2.3.4", `{"e":1,"r":"t","s":50}`, 60000)
	if v, ok := h.Get(ctx, "blk:1.2.3.4"); !ok || v == "" {
		t.Fatalf("get = %q,%v", v, ok)
	}
	// snapshot merges prefix
	out := map[string]string{}
	h.ForEach("blk:", func(k, v string) bool { out[k] = v; return true })
	if _, ok := out["blk:1.2.3.4"]; !ok {
		t.Fatalf("foreach missing key: %v", out)
	}
}

func TestHybridRedisLive(t *testing.T) {
	// Only exercise real L2 when a Redis is actually reachable. Honour
	// GS_TEST_REDIS=1 to force-run even if a quick ping fails (used in the
	// local verification stack where gs-redis is up).
	cfg := config.RedisConfig{Enabled: true, Address: "127.0.0.1:6379", KeyPrefix: "gstest:"}
	h := New(cfg)
	if h.Mode() != "redis" || h.l2 == nil {
		if os.Getenv("GS_TEST_REDIS") != "1" {
			t.Skip("redis L2 not active (unreachable); skipping live L2 test")
		}
		t.Fatalf("redis configured but L2 not active: mode=%s l2=%v", h.Mode(), h.l2)
	}
	defer h.Close()
	ctx := context.Background()
	key := "blk:9.9.9.9"
	val := `{"e":9999999999999,"r":"live","s":50}`
	h.Set(ctx, key, val, 60000)
	// read back (L1 hydrates)
	if v, ok := h.Get(ctx, key); !ok || v != val {
		t.Fatalf("get = %q,%v want %q,true", v, ok, val)
	}
	// L2 should also hold it
	if v, ok := h.l2.Get(ctx, key); !ok || v != val {
		t.Fatalf("l2 get = %q,%v", v, ok)
	}
	h.Delete(ctx, key)
	if _, ok := h.Get(ctx, key); ok {
		t.Fatalf("expected key gone after delete")
	}
	if _, ok := h.l2.Get(ctx, key); ok {
		t.Fatalf("expected l2 key gone after delete")
	}
}

// TestHybridFailoverRedisDown proves the engine keeps serving from L1 when L2
// dies mid-flight: no panic, no fail-open, decisions still observable locally.
func TestHybridFailoverRedisDown(t *testing.T) {
	cfg := config.RedisConfig{Enabled: true, Address: "127.0.0.1:6379", KeyPrefix: "gstest:"}
	h := New(cfg)
	if h.Mode() != "redis" || h.l2 == nil {
		if os.Getenv("GS_TEST_REDIS") != "1" {
			t.Skip("redis L2 not active (unreachable); skipping failover test")
		}
		t.Fatalf("redis configured but L2 not active: mode=%s l2=%v", h.Mode(), h.l2)
	}
	ctx := context.Background()

	// Seed state with Redis up.
	h.Set(ctx, "blk:1.2.3.4", "v1", 60000)
	if v, ok := h.Get(ctx, "blk:1.2.3.4"); !ok || v != "v1" {
		t.Fatalf("pre-failover get = %q,%v", v, ok)
	}

	// Simulate L2 death: close the underlying redis client directly.
	if rc, ok := h.l2.(*redisStore); ok {
		_ = rc.c.Close()
	} else {
		t.Fatalf("l2 is not *redisStore: %T", h.l2)
	}

	// L1 must still answer (hydrated value survives), and Mode() must report
	// local so the operator/health sees the degradation.
	if v, ok := h.Get(ctx, "blk:1.2.3.4"); !ok || v != "v1" {
		t.Fatalf("post-failover L1 get = %q,%v; local state lost", v, ok)
	}
	if h.Mode() != "local" {
		t.Fatalf("expected mode local after L2 death, got %s", h.Mode())
	}
	// Mutations must not panic after L2 death (L1-only write path).
	h.Set(ctx, "blk:5.6.7.8", "v2", 60000)
	if v, ok := h.Get(ctx, "blk:5.6.7.8"); !ok || v != "v2" {
		t.Fatalf("post-failover write/read = %q,%v", v, ok)
	}
	// Incr on a dead L2 must not panic and must still return a usable L1 count.
	n := h.Incr(ctx, "rate:9.9.9.9", 1, 60000)
	if n <= 0 {
		t.Fatalf("post-failover Incr returned %d; expected positive L1 count", n)
	}
	h.Close()
}

// Dial builds a client in both modes without connecting.
func TestDialSelection(t *testing.T) {
	direct := Dial(config.RedisConfig{Enabled: true, Address: "127.0.0.1:6379"})
	if direct == nil {
		t.Fatal("direct dial must build")
	}
	_ = direct.Close()
	fo := Dial(config.RedisConfig{Enabled: true, Sentinels: []string{"127.0.0.1:26379"}})
	if fo == nil {
		t.Fatal("sentinel dial must build")
	}
	_ = fo.Close()
	if UsingSentinel(config.RedisConfig{Enabled: true}) {
		t.Fatal("no sentinels must not be sentinel mode")
	}
	if !UsingSentinel(config.RedisConfig{Enabled: true, Sentinels: []string{"x:1"}}) {
		t.Fatal("sentinels must select sentinel mode")
	}
}

// Sentinel live phases (needs GS_TEST_SENTINEL="host:port,...").
// Phase 1 writes through Sentinel; the harness then kills the master and
// waits for promotion; phase 2 must read the old key and write a new one
// via the promoted master — proving the client followed the failover.
func sentinelAddrs(t *testing.T) []string {
	t.Helper()
	raw := os.Getenv("GS_TEST_SENTINEL")
	if raw == "" {
		t.Skip("GS_TEST_SENTINEL not set")
	}
	return splitCSV(raw)
}

func splitCSV(s string) []string {
	var out []string
	cur := ""
	for _, r := range s {
		if r == ',' {
			if cur != "" {
				out = append(out, cur)
				cur = ""
			}
			continue
		}
		cur += string(r)
	}
	if cur != "" {
		out = append(out, cur)
	}
	return out
}

func TestSentinelPhase1Write(t *testing.T) {
	addrs := sentinelAddrs(t)
	h := New(config.RedisConfig{Enabled: true, Sentinels: addrs, MasterName: "gsmaster", KeyPrefix: "t1:"})
	defer h.Close()
	if h.Mode() != "redis" {
		t.Fatalf("mode = %q, want redis (sentinel unreachable?)", h.Mode())
	}
	ctx := context.Background()
	h.Set(ctx, "fail:key", "before", 60000)
	if v, ok := h.Get(ctx, "fail:key"); !ok || v != "before" {
		t.Fatalf("sentinel write/read = %q,%v", v, ok)
	}
}

func TestSentinelPhase2AfterKill(t *testing.T) {
	addrs := sentinelAddrs(t)
	h := New(config.RedisConfig{Enabled: true, Sentinels: addrs, MasterName: "gsmaster", KeyPrefix: "t1:"})
	defer h.Close()
	if h.Mode() != "redis" {
		t.Fatalf("mode = %q, want hybrid (failover incomplete?)", h.Mode())
	}
	ctx := context.Background()
	if v, ok := h.Get(ctx, "fail:key"); !ok || v != "before" {
		t.Fatalf("post-kill read = %q,%v (replica lost the write?)", v, ok)
	}
	h.Set(ctx, "fail:key2", "after", 60000)
	if v, ok := h.Get(ctx, "fail:key2"); !ok || v != "after" {
		t.Fatalf("post-kill write/read = %q,%v", v, ok)
	}
}
