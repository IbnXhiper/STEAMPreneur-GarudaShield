// Package statestore provides the hybrid L1/L2 state layer for GarudaShield.
//
// Principle (DESIGN.md): in-process memory (L1) is the hot-path source of
// truth for every decision; Redis (L2) is the persistent + cross-node source
// of truth. When Redis is unavailable the engine keeps running in "local"
// mode on L1 alone — fail-closed, never fail-open.
package statestore

import (
	"context"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/storage"
	"github.com/redis/go-redis/v9"
)

// StateStore is the hybrid interface used across the engine. Implementations
// must be safe for concurrent use. Get returns (value, true) only for live,
// non-expired keys.
type StateStore interface {
	Get(ctx context.Context, key string) (string, bool)
	Set(ctx context.Context, key, value string, ttlMs int64)
	Delete(ctx context.Context, key string)
	ForEach(prefix string, fn func(key, value string) bool)
	Incr(ctx context.Context, key string, delta int64, ttlMs int64) int64
	Healthy() bool
	Mode() string // "redis" when L2 connected, "local" otherwise
	Close() error
}

// ---------- Memory L1 ----------

type memoryStore struct{ s *storage.Store }

func newMemory() *memoryStore { return &memoryStore{s: storage.NewStore()} }

func (m *memoryStore) Get(_ context.Context, key string) (string, bool) {
	v, ok := m.s.Get(key)
	if !ok {
		return "", false
	}
	s, ok := v.(string)
	if !ok {
		return "", false
	}
	return s, true
}

func (m *memoryStore) Set(_ context.Context, key, value string, ttlMs int64) {
	m.s.Set(key, value, ttlMs)
}

func (m *memoryStore) Delete(_ context.Context, key string) { m.s.Delete(key) }

func (m *memoryStore) ForEach(prefix string, fn func(key, value string) bool) {
	m.s.ForEach(func(k string, v any) bool {
		s, ok := v.(string)
		if !ok {
			return true
		}
		if prefix == "" || strings.HasPrefix(k, prefix) {
			return fn(k, s)
		}
		return true
	})
}

func (m *memoryStore) Incr(_ context.Context, key string, delta int64, ttlMs int64) int64 {
	return m.s.Incr(key, delta, ttlMs)
}

func (m *memoryStore) Healthy() bool { return true }
func (m *memoryStore) Mode() string  { return "local" }
func (m *memoryStore) Close() error  { m.s.Close(); return nil }

// ---------- Redis L2 ----------

type redisStore struct {
	c      redis.UniversalClient
	prefix string
}

func (r *redisStore) key(k string) string { return r.prefix + k }

func (r *redisStore) Get(ctx context.Context, key string) (string, bool) {
	v, err := r.c.Get(ctx, r.key(key)).Result()
	if err != nil {
		return "", false
	}
	return v, true
}

func (r *redisStore) Set(ctx context.Context, key, value string, ttlMs int64) {
	var ex time.Duration
	if ttlMs > 0 {
		ex = time.Duration(ttlMs) * time.Millisecond
	}
	_ = r.c.Set(ctx, r.key(key), value, ex).Err()
}

func (r *redisStore) Delete(ctx context.Context, key string) {
	_ = r.c.Del(ctx, r.key(key)).Err()
}

func (r *redisStore) ForEach(prefix string, fn func(key, value string) bool) {
	ctx := context.Background()
	iter := r.c.Scan(ctx, 0, r.key(prefix)+"*", 0).Iterator()
	for iter.Next(ctx) {
		full := iter.Val()
		k := strings.TrimPrefix(full, r.prefix)
		v, err := r.c.Get(ctx, full).Result()
		if err != nil {
			continue
		}
		if !fn(k, v) {
			return
		}
	}
}

func (r *redisStore) Incr(ctx context.Context, key string, delta int64, ttlMs int64) int64 {
	n, err := r.c.IncrBy(ctx, r.key(key), delta).Result()
	if err == nil && ttlMs > 0 {
		_ = r.c.Expire(ctx, r.key(key), time.Duration(ttlMs)*time.Millisecond).Err()
	}
	if err != nil {
		return 0
	}
	return n
}

func (r *redisStore) Healthy() bool {
	return r.c.Ping(context.Background()).Err() == nil
}

func (r *redisStore) Mode() string {
	if r.Healthy() {
		return "redis"
	}
	return "local"
}

func (r *redisStore) Close() error { return r.c.Close() }

// ---------- Hybrid (L1 + optional L2) ----------

type Hybrid struct {
	l1 StateStore
	l2 StateStore // nil when Redis disabled or unreachable
}

// New builds a Hybrid store. When Redis is disabled (or the address is empty)
// only L1 is used ("local" mode). If Redis is enabled but unreachable at
// startup, L2 is dropped and the engine runs locally rather than failing.
func New(cfg config.RedisConfig) *Hybrid {
	l1 := newMemory()
	if !cfg.Enabled || (cfg.Address == "" && len(cfg.Sentinels) == 0) {
		return &Hybrid{l1: l1}
	}
	prefix := cfg.KeyPrefix
	if prefix == "" {
		prefix = "gs"
	}
	rc := Dial(cfg)
	l2 := &redisStore{c: rc, prefix: prefix}
	if !l2.Healthy() {
		_ = l2.Close()
		return &Hybrid{l1: l1}
	}
	return &Hybrid{l1: l1, l2: l2}
}

// Get checks L1 first (hot path), then hydrates from L2 on a miss so state
// survives restarts. A dead L2 simply falls through to L1.
func (h *Hybrid) Get(ctx context.Context, key string) (string, bool) {
	if v, ok := h.l1.Get(ctx, key); ok {
		return v, true
	}
	if h.l2 != nil {
		if v, ok := h.l2.Get(ctx, key); ok {
			h.l1.Set(ctx, key, v, 0) // hydrate (no TTL; value carries its own expiry)
			return v, true
		}
	}
	return "", false
}

func (h *Hybrid) Set(ctx context.Context, key, value string, ttlMs int64) {
	h.l1.Set(ctx, key, value, ttlMs)
	if h.l2 != nil {
		h.l2.Set(ctx, key, value, ttlMs)
	}
}

func (h *Hybrid) Delete(ctx context.Context, key string) {
	h.l1.Delete(ctx, key)
	if h.l2 != nil {
		h.l2.Delete(ctx, key)
	}
}

// ForEach merges L1 and L2, de-duplicating by key (L2 wins on conflict).
func (h *Hybrid) ForEach(prefix string, fn func(key, value string) bool) {
	seen := make(map[string]bool)
	if h.l2 != nil && h.l2.Healthy() {
		h.l2.ForEach(prefix, func(k, v string) bool {
			seen[k] = true
			return fn(k, v)
		})
	}
	h.l1.ForEach(prefix, func(k, v string) bool {
		if seen[k] {
			return true
		}
		return fn(k, v)
	})
}

func (h *Hybrid) Incr(ctx context.Context, key string, delta int64, ttlMs int64) int64 {
	n := h.l1.Incr(ctx, key, delta, ttlMs)
	if h.l2 != nil {
		h.l2.Incr(ctx, key, delta, ttlMs)
	}
	return n
}

func (h *Hybrid) Healthy() bool {
	if h.l2 != nil {
		return h.l2.Healthy()
	}
	return true
}

func (h *Hybrid) Mode() string {
	if h.l2 != nil && h.l2.Healthy() {
		return "redis"
	}
	return "local"
}

func (h *Hybrid) Close() error {
	if h.l2 != nil {
		_ = h.l2.Close()
	}
	return h.l1.Close()
}
