package statestore

import (
	"github.com/redis/go-redis/v9"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Dial builds the Redis client for the L2 store and the PeerSync bus.
// With Sentinels set it returns a Sentinel-managed failover client
// (automatic master promotion within/across sites); otherwise a direct
// client. Construction never dials — callers probe with Healthy/Ping.
func Dial(cfg config.RedisConfig) redis.UniversalClient {
	if len(cfg.Sentinels) > 0 {
		master := cfg.MasterName
		if master == "" {
			master = "mymaster"
		}
		return redis.NewFailoverClient(&redis.FailoverOptions{
			MasterName:    master,
			SentinelAddrs: cfg.Sentinels,
			Password:      cfg.Password,
			DB:            cfg.DB,
		})
	}
	return redis.NewClient(&redis.Options{
		Addr:     cfg.Address,
		Password: cfg.Password,
		DB:       cfg.DB,
	})
}

// UsingSentinel reports whether cfg selects failover mode.
func UsingSentinel(cfg config.RedisConfig) bool {
	return cfg.Enabled && len(cfg.Sentinels) > 0
}
