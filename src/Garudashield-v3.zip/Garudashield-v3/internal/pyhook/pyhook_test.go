package pyhook

import (
	"context"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"
)

// pythonOK locates a Python interpreter that actually runs. It deliberately
// verifies the binary executes: on Windows "python3"/"python" are frequently
// App Execution Alias stubs pointing at the Microsoft Store that LookPath
// resolves happily but that only print an install prompt and exit non-zero.
// Treating such a stub as present makes the hook fail with "pyhook-exec"
// instead of skipping, so a functional interpreter is required.
// Set GARUDASHIELD_PYTHON to point at an interpreter not on PATH.
func pythonOK(t *testing.T) string {
	t.Helper()
	if p := findPython(); p != "" {
		return p
	}
	t.Skip("no working python3 interpreter available, skipping pyhook tests")
	return ""
}

func findPython() string {
	candidates := []string{}
	if env := os.Getenv("GARUDASHIELD_PYTHON"); env != "" {
		candidates = append(candidates, env)
	}
	candidates = append(candidates, "python3", "python")
	for _, name := range candidates {
		p, err := exec.LookPath(name)
		if err != nil {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		cmd := exec.CommandContext(ctx, p, "-c", "import sys")
		cmd.Stdout = io.Discard
		cmd.Stderr = io.Discard
		err = cmd.Run()
		cancel()
		if err == nil {
			return p
		}
	}
	return ""
}

func writeScript(t *testing.T, body string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "hook.py")
	if err := os.WriteFile(p, []byte(body), 0600); err != nil {
		t.Fatal(err)
	}
	return p
}

func TestDisabledNil(t *testing.T) {
	if New(Config{Enabled: false, Script: "x.py"}) != nil {
		t.Fatal("disabled hook must be nil")
	}
	if New(Config{Enabled: true, Script: ""}) != nil {
		t.Fatal("empty script must be nil")
	}
}

func TestPassScript(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import json,sys\nf=json.load(sys.stdin)\nprint(json.dumps({'action':'pass','score':5,'reason':'ml-ok'}))\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true})
	v := h.Evaluate(Features{IP: "1.2.3.4", Method: "GET", Path: "/", Score: 10})
	if v.Action != "pass" || v.Score != 5 || v.Reason != "ml-ok" {
		t.Fatalf("got %+v", v)
	}
}

func TestBlockScript(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "print('{\"action\":\"block\",\"reason\":\"ml-evil\"}')\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true})
	if v := h.Evaluate(Features{}); v.Action != "block" || v.Reason != "ml-evil" {
		t.Fatalf("got %+v", v)
	}
}

func TestTimeoutFailClosed(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import time\ntime.sleep(30)\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 200, Mode: "enforce", FailClosed: true})
	if v := h.Evaluate(Features{}); v.Action != "block" || v.Reason != "pyhook-timeout" {
		t.Fatalf("got %+v", v)
	}
}

func TestBadOutputFailClosed(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "print('not json at all')\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true})
	if v := h.Evaluate(Features{}); v.Action != "block" || v.Reason != "pyhook-bad-output" {
		t.Fatalf("got %+v", v)
	}
}

func TestBadActionFailClosed(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "print('{\"action\":\"nuke\",\"reason\":\"x\"}')\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true})
	if v := h.Evaluate(Features{}); v.Action != "block" || v.Reason != "pyhook-bad-action" {
		t.Fatalf("got %+v", v)
	}
}

func TestFailOpenMode(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import time\ntime.sleep(30)\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 200, Mode: "enforce", FailClosed: false})
	if v := h.Evaluate(Features{}); v.Action != "pass" {
		t.Fatalf("fail-open must pass, got %+v", v)
	}
}

// Worker mode: one process serves many evaluations (echo script).
func TestWorkerEcho(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import json,sys\nfor line in sys.stdin:\n\tline=line.strip()\n\tif not line: continue\n\tf=json.loads(line)\n\tprint(json.dumps({'action':'pass','score':f.get('score',0),'reason':'w-ok'}),flush=True)\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true, Worker: true})
	defer h.Close()
	for i := 0; i < 5; i++ {
		v := h.Evaluate(Features{IP: "1.2.3.4", Path: "/"})
		if v.Action != "pass" || v.Reason != "w-ok" {
			t.Fatalf("eval %d got %+v", i, v)
		}
	}
}

// Worker crash fails closed and the next call respawns.
func TestWorkerCrashRespawn(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import json,sys\nprint(json.dumps({'action':'pass','score':0,'reason':'once'}),flush=True)\nsys.exit(1)\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 20000, Mode: "enforce", FailClosed: true, Worker: true})
	defer h.Close()
	if v := h.Evaluate(Features{}); v.Action != "pass" {
		t.Fatalf("first eval got %+v", v)
	}
	if v := h.Evaluate(Features{}); v.Action != "block" {
		t.Fatalf("dead worker must fail closed, got %+v", v)
	}
	// Respawned worker serves again.
	if v := h.Evaluate(Features{}); v.Action != "pass" {
		t.Fatalf("respawned eval got %+v", v)
	}
}

// Worker timeout kills the slow process (fail-closed).
func TestWorkerTimeout(t *testing.T) {
	py := pythonOK(t)
	p := writeScript(t, "import sys,time\nfor line in sys.stdin:\n\ttime.sleep(30)\n")
	h := New(Config{Enabled: true, Script: p, Python: py, TimeoutMs: 300, Mode: "enforce", FailClosed: true, Worker: true})
	defer h.Close()
	if v := h.Evaluate(Features{}); v.Action != "block" || v.Reason != "pyhook-timeout" {
		t.Fatalf("got %+v", v)
	}
}
