// Package pyhook embeds a Python policy hook into the Go engine: per request,
// the engine pipes a small JSON feature object to an external Python script's
// stdin and reads a JSON verdict from its stdout. This lets operators add
// ML models or custom heuristics (Python ecosystem) without recompiling Go.
//
// Fail-closed: timeout, exec error, oversize or malformed output yields a
// block verdict when FailClosed is set (default), otherwise pass.
// Disabled by default (zero hook cost on the hot path).
package pyhook

import (
	"bytes"
	"context"
	"encoding/json"
	"os/exec"
	"time"
)

// Config mirrors config.PyHook without importing the config package
// (keeps the dependency direction shield -> pyhook clean).
type Config struct {
	Enabled    bool
	Script     string
	Python     string
	TimeoutMs  int64
	Mode       string // "enforce" or "monitor" (observe-only)
	FailClosed bool
	// Worker keeps one Python process alive (NDJSON over stdin/stdout,
	// argv "--worker") instead of forking per request. The script must
	// implement the worker loop; otherwise keep false (one-shot).
	Worker bool
}

// Features is the JSON object piped to the script's stdin.
type Features struct {
	IP        string `json:"ip"`
	Method    string `json:"method"`
	Path      string `json:"path"`
	UserAgent string `json:"user_agent"`
	Score     int    `json:"score"`
	WireBytes int64  `json:"wire_bytes"`
}

// Verdict is the JSON object the script must print to stdout.
type Verdict struct {
	Action string `json:"action"` // "pass", "challenge", or "block"
	Score  int    `json:"score"`  // extra risk points (added when action=pass)
	Reason string `json:"reason"`
}

const maxOutput = 64 * 1024 // cap script stdout (memory guard)

// Hook runs the configured Python script per evaluation.
type Hook struct {
	cfg Config
	w   *worker // non-nil only in Worker mode
}

// New validates the config. New returns nil when disabled so callers can
// keep a nil *Hook as "no hook" without extra flags.
func New(c Config) *Hook {
	if !c.Enabled || c.Script == "" {
		return nil
	}
	if c.Python == "" {
		c.Python = "python3"
	}
	if c.TimeoutMs <= 0 {
		c.TimeoutMs = 500
	}
	if c.Mode != "enforce" && c.Mode != "monitor" {
		c.Mode = "monitor"
	}
	h := &Hook{cfg: c}
	if c.Worker {
		h.w = newWorker(c.Python, c.Script)
	}
	return h
}

// Mode reports enforce vs monitor.
func (h *Hook) Mode() string { return h.cfg.Mode }

// Evaluate runs the script and parses its verdict. Never returns an error:
// failures degrade to the fail-closed verdict (block) or pass.
func (h *Hook) Evaluate(f Features) Verdict {
	if h.w != nil {
		v, reason := h.w.call(f, time.Duration(h.cfg.TimeoutMs)*time.Millisecond)
		if reason != "" {
			return h.fail(reason)
		}
		return v
	}
	return h.oneShot(f)
}

// Close stops the worker process, if any. Safe on nil Hook.
func (h *Hook) Close() {
	if h == nil {
		return
	}
	if h.w != nil {
		h.w.Close()
	}
}

func (h *Hook) oneShot(f Features) Verdict {
	in, err := json.Marshal(f)
	if err != nil {
		return h.fail("pyhook-encode")
	}
	ctx, cancel := context.WithTimeout(context.Background(),
		time.Duration(h.cfg.TimeoutMs)*time.Millisecond)
	defer cancel()
	cmd := exec.CommandContext(ctx, h.cfg.Python, h.cfg.Script)
	cmd.Stdin = bytes.NewReader(in)
	var out, errBuf bytes.Buffer
	cmd.Stdout = &limitedWriter{w: &out, n: maxOutput}
	cmd.Stderr = &limitedWriter{w: &errBuf, n: 4096}
	if err := cmd.Run(); err != nil {
		reason := "pyhook-exec"
		if ctx.Err() == context.DeadlineExceeded {
			reason = "pyhook-timeout"
		}
		return h.fail(reason)
	}
	var v Verdict
	dec := json.NewDecoder(bytes.NewReader(out.Bytes()))
	if err := dec.Decode(&v); err != nil {
		return h.fail("pyhook-bad-output")
	}
	switch v.Action {
	case "pass", "challenge", "block":
		if v.Reason == "" {
			v.Reason = "pyhook"
		}
		return v
	default:
		return h.fail("pyhook-bad-action")
	}
}

func (h *Hook) fail(reason string) Verdict {
	if h.cfg.FailClosed {
		return Verdict{Action: "block", Reason: reason}
	}
	return Verdict{Action: "pass", Reason: reason}
}

// limitedWriter caps captured output (defense against chatty scripts).
type limitedWriter struct {
	w *bytes.Buffer
	n int
}

func (l *limitedWriter) Write(p []byte) (int, error) {
	room := l.n - l.w.Len()
	if room <= 0 {
		return len(p), nil // discard, report success
	}
	if len(p) > room {
		p = p[:room]
	}
	return l.w.Write(p)
}
