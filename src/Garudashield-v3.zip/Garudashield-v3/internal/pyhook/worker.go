package pyhook

import (
	"bufio"
	"bytes"
	"encoding/json"
	"io"
	"os/exec"
	"sync"
	"time"
)

// worker is a persistent Python subprocess speaking NDJSON: the engine
// writes one Features line per evaluation and reads one Verdict line back.
// This removes the fork+interpreter-startup cost of one-shot mode
// (cold start on Windows regularly exceeds 500ms).
//
// Protocol: argv gets "--worker". Scripts must loop stdin line-by-line,
// print exactly one JSON verdict per line, and flush stdout.
type worker struct {
	python string
	script string

	mu     sync.Mutex
	cmd    *exec.Cmd
	stdin  io.WriteCloser
	stdout *bufio.Reader
}

func newWorker(python, script string) *worker {
	return &worker{python: python, script: script}
}

// call sends one evaluation. It spawns (or respawns) the process on demand.
// A dead/slow worker fails the evaluation but never the engine: the process
// is killed and the next call tries a fresh spawn.
func (w *worker) call(f Features, timeout time.Duration) (Verdict, string) {
	in, err := json.Marshal(f)
	if err != nil {
		return Verdict{}, "pyhook-encode"
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	if w.cmd == nil {
		if err := w.spawn(); err != nil {
			return Verdict{}, "pyhook-exec"
		}
	}
	// Serialized request/response on the pipes.
	if _, err := w.stdin.Write(append(in, '\n')); err != nil {
		w.kill()
		return Verdict{}, "pyhook-exec"
	}
	lineCh := make(chan []byte, 1)
	errCh := make(chan error, 1)
	go func() {
		line, err := w.stdout.ReadBytes('\n')
		if err != nil {
			errCh <- err
			return
		}
		lineCh <- line
	}()
	timer := time.NewTimer(timeout)
	defer timer.Stop()
	select {
	case line := <-lineCh:
		if len(line) > maxOutput {
			w.kill()
			return Verdict{}, "pyhook-bad-output"
		}
		var v Verdict
		if err := json.Unmarshal(bytes.TrimSpace(line), &v); err != nil {
			w.kill()
			return Verdict{}, "pyhook-bad-output"
		}
		switch v.Action {
		case "pass", "challenge", "block":
			if v.Reason == "" {
				v.Reason = "pyhook"
			}
			return v, ""
		default:
			w.kill()
			return Verdict{}, "pyhook-bad-action"
		}
	case err := <-errCh:
		_ = err
		w.kill()
		return Verdict{}, "pyhook-exec"
	case <-timer.C:
		w.kill()
		return Verdict{}, "pyhook-timeout"
	}
}

func (w *worker) spawn() error {
	cmd := exec.Command(w.python, w.script, "--worker")
	stdin, err := cmd.StdinPipe()
	if err != nil {
		return err
	}
	stdout, err := cmd.StdoutPipe()
	if err != nil {
		return err
	}
	var errBuf bytes.Buffer
	cmd.Stderr = &limitedWriter{w: &errBuf, n: 4096}
	if err := cmd.Start(); err != nil {
		return err
	}
	w.cmd = cmd
	w.stdin = stdin
	w.stdout = bufio.NewReaderSize(stdout, maxOutput+1024)
	return nil
}

func (w *worker) kill() {
	if w.cmd != nil && w.cmd.Process != nil {
		_ = w.cmd.Process.Kill()
		_, _ = w.cmd.Process.Wait()
	}
	w.cmd = nil
	w.stdin = nil
	w.stdout = nil
}

// Close stops the worker process. Safe on zero value.
func (w *worker) Close() {
	if w == nil {
		return
	}
	w.mu.Lock()
	defer w.mu.Unlock()
	w.kill()
}
