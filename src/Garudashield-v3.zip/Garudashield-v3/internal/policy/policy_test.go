package policy

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func ptrStr(s string) *string { return &s }
func ptrI64(i int64) *int64   { return &i }

func TestApplyInheritsAndOverrides(t *testing.T) {
	g := config.Default()
	g.Shield.BudgetMs = 50
	g.Defense.WAF.SQLi = true

	// Nil policy = pure inherit.
	eff := (*Policy)(nil).Apply(g)
	if eff.Shield.BudgetMs != 50 || !eff.Defense.WAF.SQLi {
		t.Fatalf("nil policy must inherit global, got %+v", eff.Shield)
	}

	// Override a scalar and a subtree; everything else inherits.
	p := &Policy{
		BudgetMs: ptrI64(5),
		WAF:      &config.WAFConfig{Enabled: true, SQLi: false, XSS: true},
	}
	eff = p.Apply(g)
	if eff.Shield.BudgetMs != 5 {
		t.Fatalf("budget override not applied: %d", eff.Shield.BudgetMs)
	}
	if eff.Defense.WAF.SQLi || !eff.Defense.WAF.XSS {
		t.Fatalf("waf subtree not replaced: %+v", eff.Defense.WAF)
	}
	// Untouched subtree keeps the global value.
	if eff.Defense.Layer7.Enabled != g.Defense.Layer7.Enabled {
		t.Fatalf("unrelated subtree changed")
	}
}

func TestModeParsing(t *testing.T) {
	if !(&Policy{Mode: ptrStr("emergency")}).Emergency() {
		t.Fatal("emergency not detected")
	}
	if (&Policy{Mode: ptrStr("auto")}).Emergency() {
		t.Fatal("auto must not be emergency")
	}
	if !(&Policy{Mode: ptrStr("aggressive")}).Aggressive(false) {
		t.Fatal("aggressive not detected")
	}
	if (&Policy{Mode: ptrStr("normal")}).Aggressive(true) {
		t.Fatal("normal must override global aggressive")
	}
	if !(&Policy{}).Aggressive(true) {
		t.Fatal("empty policy must inherit global aggressive")
	}
}

func TestValidate(t *testing.T) {
	if err := (&Policy{Mode: ptrStr("bogus")}).Validate(); err == nil {
		t.Fatal("unknown mode must fail validation")
	}
	bad := &Policy{WAF: &config.WAFConfig{CustomRules: []config.WAFRule{{Name: "x"}}}}
	if err := bad.Validate(); err == nil {
		t.Fatal("empty rule pattern must fail validation")
	}
	if err := (&Policy{Mode: ptrStr("emergency")}).Validate(); err != nil {
		t.Fatalf("valid policy rejected: %v", err)
	}
}

func TestNormalizeDomain(t *testing.T) {
	cases := map[string]string{
		"Example.COM:443": "example.com",
		" example.com.":   "example.com",
		"":                "",
	}
	for in, want := range cases {
		if got := NormalizeDomain(in); got != want {
			t.Fatalf("NormalizeDomain(%q)=%q want %q", in, got, want)
		}
	}
}
