// Package policy defines a per-domain (per protected website) override of the
// engine's protection configuration and its durable Postgres store.
//
// A Policy mirrors the knobs an operator can change live from the admin
// dashboard, scoped to a single Host: the request mode, the evaluation budget,
// browser verification on first visit, the L7 protocol validators, the WAF
// module set + custom rules, the rate-limit policy, and the country policy.
// Every field is optional (a nil subtree inherits the global config), so a
// tenant can tune one knob without forking the whole configuration.
//
// Enforcement is deliberately fail-closed: the resolved effective config is a
// copy of the global config with the policy overlaid, so an empty or corrupt
// policy can never weaken a domain below the global baseline.
package policy

import (
	"fmt"
	"strings"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Policy is the per-domain override. Nil fields inherit the global config.
type Policy struct {
	// Mode is the protection posture for this domain: "auto" (default),
	// "aggressive" or "emergency". Empty = inherit the global mode.
	Mode *string `json:"mode,omitempty"`
	// BudgetMs overrides the per-request evaluation budget. <= 0 keeps the
	// fail-closed instant-abort contract.
	BudgetMs *int64 `json:"budgetMs,omitempty"`
	// VerifyOnFirstVisit forces the human-verification gate for this domain
	// (browser challenge on the first request from an unknown IP).
	VerifyOnFirstVisit *bool `json:"verifyOnFirstVisit,omitempty"`

	Layer7    *config.Layer7Config    `json:"layer7,omitempty"`
	WAF       *config.WAFConfig       `json:"waf,omitempty"`
	RateLimit *config.RateLimitConfig `json:"rateLimit,omitempty"`
	Geo       *config.GeoPolicyConfig `json:"geo,omitempty"`
}

// Apply returns the effective config for a domain: the global config with the
// policy overlaid. Slice/struct subtrees are replaced wholesale (the editor
// always sends a complete subtree), scalars are copied field by field.
func (p *Policy) Apply(global config.Config) config.Config {
	eff := global
	if p == nil {
		return eff
	}
	if p.BudgetMs != nil {
		eff.Shield.BudgetMs = *p.BudgetMs
	}
	if p.VerifyOnFirstVisit != nil {
		eff.Shield.VerifyOnFirstVisit = *p.VerifyOnFirstVisit
	}
	if p.Layer7 != nil {
		eff.Defense.Layer7 = *p.Layer7
	}
	if p.WAF != nil {
		eff.Defense.WAF = *p.WAF
	}
	if p.RateLimit != nil {
		eff.Defense.RateLimit = *p.RateLimit
	}
	if p.Geo != nil {
		eff.Geo.GeoPolicy = *p.Geo
	}
	return eff
}

// Active reports whether the policy carries any override at all.
func (p *Policy) Active() bool {
	if p == nil {
		return false
	}
	return p.Mode != nil || p.BudgetMs != nil || p.VerifyOnFirstVisit != nil ||
		p.Layer7 != nil || p.WAF != nil || p.RateLimit != nil || p.Geo != nil
}

// Aggressive reports whether the effective mode is aggressive for this policy,
// given the global fallback. Emergency is enforced separately (hard block).
func (p *Policy) Aggressive(globalAgg bool) bool {
	if p == nil || p.Mode == nil {
		return globalAgg
	}
	switch strings.ToLower(strings.TrimSpace(*p.Mode)) {
	case "aggressive", "agg", "on", "true":
		return true
	case "auto", "normal", "off", "false":
		return false
	}
	return globalAgg
}

// Emergency reports whether this policy forces emergency mode for the domain.
func (p *Policy) Emergency() bool {
	if p == nil || p.Mode == nil {
		return false
	}
	switch strings.ToLower(strings.TrimSpace(*p.Mode)) {
	case "emergency", "panic", "lockdown":
		return true
	}
	return false
}

// Validate performs cheap sanity checks. It never relaxes enforcement — the
// engine is fail-closed regardless — but rejects values that would obviously
// break a domain (negative budgets, unknown modes, empty WAF rule patterns).
func (p *Policy) Validate() error {
	if p == nil {
		return nil
	}
	if p.Mode != nil {
		switch strings.ToLower(strings.TrimSpace(*p.Mode)) {
		case "", "auto", "normal", "aggressive", "agg", "emergency", "on", "off", "true", "false", "panic", "lockdown":
		default:
			return fmt.Errorf("policy: unknown mode %q", *p.Mode)
		}
	}
	if p.WAF != nil {
		for i, r := range p.WAF.CustomRules {
			if strings.TrimSpace(r.Pattern) == "" {
				return fmt.Errorf("policy: waf.customRules[%d] has empty pattern", i)
			}
			if r.Score < 0 || r.Score > 100 {
				return fmt.Errorf("policy: waf.customRules[%d].score must be 0..100", i)
			}
		}
	}
	if p.RateLimit != nil {
		rl := p.RateLimit
		if rl.PerIPRPS < 0 || rl.PerIPBurst < 0 || rl.PerPathRPS < 0 || rl.GlobalMaxRPS < 0 {
			return fmt.Errorf("policy: rateLimit values must be non-negative")
		}
	}
	return nil
}
