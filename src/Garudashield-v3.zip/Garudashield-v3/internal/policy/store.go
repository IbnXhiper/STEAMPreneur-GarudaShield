package policy

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

// ErrNotFound is returned when no policy row exists for a domain.
var ErrNotFound = errors.New("policy: not found")

// Store is the durable Postgres system of record for per-domain policies. The
// engine keeps a hot in-memory copy; this store survives restarts and is the
// source of truth for boot-time rehydration.
type Store struct {
	pool *pgxpool.Pool
}

// New wraps a connection pool. A nil pool yields a store whose reads return
// ErrNotFound and whose writes error, so the caller can treat "no commercial
// store" identically to "no policy".
func New(pool *pgxpool.Pool) *Store {
	return &Store{pool: pool}
}

// Entry is one stored policy plus its tenancy + audit metadata.
type Entry struct {
	Domain    string `json:"domain"`
	TenantID  string `json:"tenantId"`
	Policy    Policy `json:"policy"`
	UpdatedAt int64  `json:"updatedAt"`
	UpdatedBy string `json:"updatedBy"`
}

// NormalizeDomain lowercases and strips a port from a Host header so lookups
// are stable regardless of the client's casing or ":443" suffix.
func NormalizeDomain(host string) string {
	h := strings.ToLower(strings.TrimSpace(host))
	if i := strings.IndexByte(h, ':'); i >= 0 {
		h = h[:i]
	}
	return strings.TrimSuffix(h, ".")
}

// Get loads the policy for a domain (parameterized query, injection-safe).
func (s *Store) Get(ctx context.Context, domain string) (Entry, error) {
	if s == nil || s.pool == nil {
		return Entry{}, ErrNotFound
	}
	domain = NormalizeDomain(domain)
	var (
		raw       []byte
		tenantID  string
		updatedAt int64
		updatedBy string
	)
	err := s.pool.QueryRow(ctx,
		`SELECT tenant_id, config, updated_at, COALESCE(updated_by,'')
		 FROM domain_policies WHERE domain = $1`, domain).
		Scan(&tenantID, &raw, &updatedAt, &updatedBy)
	if errors.Is(err, pgx.ErrNoRows) {
		return Entry{}, ErrNotFound
	}
	if err != nil {
		return Entry{}, fmt.Errorf("policy get: %w", err)
	}
	e := Entry{Domain: domain, TenantID: tenantID, UpdatedAt: updatedAt, UpdatedBy: updatedBy}
	if len(raw) > 0 {
		if err := json.Unmarshal(raw, &e.Policy); err != nil {
			return Entry{}, fmt.Errorf("policy decode: %w", err)
		}
	}
	return e, nil
}

// Upsert writes (or replaces) the policy for a domain.
func (s *Store) Upsert(ctx context.Context, domain, tenantID, actor string, p Policy) error {
	if s == nil || s.pool == nil {
		return fmt.Errorf("policy: no store")
	}
	domain = NormalizeDomain(domain)
	if domain == "" {
		return fmt.Errorf("policy: empty domain")
	}
	raw, err := json.Marshal(p)
	if err != nil {
		return fmt.Errorf("policy encode: %w", err)
	}
	_, err = s.pool.Exec(ctx,
		`INSERT INTO domain_policies (domain, tenant_id, config, updated_at, updated_by)
		 VALUES ($1, $2, $3, $4, $5)
		 ON CONFLICT (domain) DO UPDATE
		   SET tenant_id = EXCLUDED.tenant_id,
		       config = EXCLUDED.config,
		       updated_at = EXCLUDED.updated_at,
		       updated_by = EXCLUDED.updated_by`,
		domain, tenantID, raw, time.Now().UnixMilli(), actor)
	if err != nil {
		return fmt.Errorf("policy upsert: %w", err)
	}
	return nil
}

// Delete removes the policy for a domain (it then falls back to global).
func (s *Store) Delete(ctx context.Context, domain string) error {
	if s == nil || s.pool == nil {
		return fmt.Errorf("policy: no store")
	}
	_, err := s.pool.Exec(ctx, `DELETE FROM domain_policies WHERE domain = $1`, NormalizeDomain(domain))
	if err != nil {
		return fmt.Errorf("policy delete: %w", err)
	}
	return nil
}

// List loads every stored policy, keyed by normalized domain. Used once at
// engine boot to warm the in-memory registry.
func (s *Store) List(ctx context.Context) (map[string]Entry, error) {
	out := map[string]Entry{}
	if s == nil || s.pool == nil {
		return out, nil
	}
	rows, err := s.pool.Query(ctx,
		`SELECT domain, tenant_id, config, updated_at, COALESCE(updated_by,'') FROM domain_policies`)
	if err != nil {
		return nil, fmt.Errorf("policy list: %w", err)
	}
	defer rows.Close()
	for rows.Next() {
		var (
			domain, tenantID, updatedBy string
			raw                         []byte
			updatedAt                   int64
		)
		if err := rows.Scan(&domain, &tenantID, &raw, &updatedAt, &updatedBy); err != nil {
			return nil, fmt.Errorf("policy list scan: %w", err)
		}
		e := Entry{Domain: domain, TenantID: tenantID, UpdatedAt: updatedAt, UpdatedBy: updatedBy}
		if len(raw) > 0 {
			_ = json.Unmarshal(raw, &e.Policy)
		}
		out[domain] = e
	}
	return out, rows.Err()
}
