package access

import (
	"crypto/sha256"
	"encoding/hex"
	"fmt"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

func newGate() *Gate {
	return New(config.Access{
		Enabled:      true,
		ProtectAll:   true,
		CookieName:   "gs_access",
		QueryParam:   "gsat",
		TokenTTLMs:   600000,
		CaptchaMaxPM: 3,
		ExemptPaths:  []string{"/health", "/static/"},
		PrivatePaths: []string{"/admin"},
	}, "test-secret")
}

func TestTokenRoundTrip(t *testing.T) {
	g := newGate()
	tok := g.Token("session-42")
	if !g.Check(tok, "session-42") {
		t.Fatal("valid token should verify")
	}
	if g.Check(tok, "session-99") {
		t.Fatal("token must be payload-bound")
	}
	if g.Check("1*deadbeef*session-42*bad", "session-42") {
		t.Fatal("tampered signature must fail")
	}
}

func TestCaptchaRoundTrip(t *testing.T) {
	g := newGate()
	svg, tok, code := g.GenerateCaptcha()
	if svg == "" || tok == "" || code == "" {
		t.Fatal("captcha must produce svg/token/code")
	}
	if !g.VerifyCaptcha(tok, code) {
		t.Fatal("correct code must verify")
	}
	if g.VerifyCaptcha(tok, "WRONG") {
		t.Fatal("wrong code must fail")
	}
}

func TestShouldGate(t *testing.T) {
	g := newGate()
	if !g.ShouldGate("example.com", "/") {
		t.Fatal("protectAll must gate root")
	}
	if g.ShouldGate("example.com", "/health") {
		t.Fatal("/health is exempt")
	}
	if !g.ShouldGate("example.com", "/admin/login") {
		t.Fatal("/admin is private")
	}

	// host-scoped mode
	scoped := New(config.Access{Enabled: true, Hosts: map[string]bool{"admin.example.com": true}, PrivatePaths: []string{"/admin"}}, "s")
	if !scoped.ShouldGate("admin.example.com", "/admin") {
		t.Fatal("private path under listed host must gate")
	}
	if scoped.ShouldGate("public.example.com", "/admin") {
		t.Fatal("other host must not gate private path")
	}
	if scoped.ShouldGate("admin.example.com", "/blog") {
		t.Fatal("non-private path under host scope must not gate")
	}
}

func TestLatencyHoldGrows(t *testing.T) {
	g := newGate()
	d0 := g.Hold("1.2.3.4")
	d1 := g.Hold("1.2.3.4")
	if d1 <= d0 {
		t.Fatalf("hold must grow: %v then %v", d0, d1)
	}
	g.ResetHold("1.2.3.4")
	d2 := g.Hold("1.2.3.4")
	if d2 != d0 {
		t.Fatalf("reset must restore base hold: %v vs %v", d2, d0)
	}
}

func TestCaptchaRateLimit(t *testing.T) {
	g := newGate() // CaptchaMaxPM = 3
	ip := "9.9.9.9"
	for i := 0; i < 3; i++ {
		if !g.CaptchaAllowed(ip) {
			t.Fatalf("request %d should be allowed", i)
		}
		g.RecordCaptcha(ip)
	}
	if g.CaptchaAllowed(ip) {
		t.Fatal("4th captcha within minute must be denied")
	}
}

// VerifyCaptcha is single-use: first verify passes, replay fails.
func TestCaptchaSingleUse(t *testing.T) {
	g := New(config.Access{}, "test-secret")
	_, token, code := g.GenerateCaptcha()
	if !g.VerifyCaptcha(token, code) {
		t.Fatal("first verify must pass")
	}
	if g.VerifyCaptcha(token, code) {
		t.Fatal("replay must be rejected")
	}
}

func TestCaptchaWrongCode(t *testing.T) {
	g := New(config.Access{}, "test-secret")
	_, token, code := g.GenerateCaptcha()
	if g.VerifyCaptcha(token, code+"X") {
		t.Fatal("wrong code must be rejected")
	}
	// Correct code still works once (failed attempt must not burn it).
	if !g.VerifyCaptcha(token, code) {
		t.Fatal("correct code after failed attempt must pass")
	}
}

func TestCaptchaUnknownToken(t *testing.T) {
	g := New(config.Access{}, "test-secret")
	other := New(config.Access{}, "other-secret")
	_, token, code := other.GenerateCaptcha()
	if g.VerifyCaptcha(token, code) {
		t.Fatal("foreign token must be rejected")
	}
}

// ---------- browser (JS) challenge ----------

// solveChallenge brute-forces a nonce satisfying sha256(id+"."+nonce) with the
// requested number of leading hex zeros.
func solveChallenge(id string, diff int) string {
	target := strings.Repeat("0", diff)
	for n := 0; n < 5_000_000; n++ {
		sum := sha256.Sum256([]byte(id + "." + strconv.Itoa(n)))
		if strings.HasPrefix(hex.EncodeToString(sum[:]), target) {
			return strconv.Itoa(n)
		}
	}
	return ""
}

// badNonce returns a nonce that does NOT satisfy the challenge.
func badNonce(id string, diff int) string {
	target := strings.Repeat("0", diff)
	for n := 0; n < 1_000_000; n++ {
		sum := sha256.Sum256([]byte(id + "." + strconv.Itoa(n)))
		if !strings.HasPrefix(hex.EncodeToString(sum[:]), target) {
			return strconv.Itoa(n)
		}
	}
	return ""
}

func TestChallengeRoundTrip(t *testing.T) {
	g := newGate()
	ip := "203.0.113.7"
	id := g.IssueChallenge(ip)
	nonce := solveChallenge(id, ChallengeDifficulty)
	if nonce == "" {
		t.Fatal("test solver failed to find a nonce")
	}
	if !g.VerifyChallenge(id, nonce, ip) {
		t.Fatal("valid solution must verify")
	}
	if g.VerifyChallenge(id, badNonce(id, ChallengeDifficulty), ip) {
		t.Fatal("wrong nonce must fail")
	}
	if g.VerifyChallenge(id, "", ip) {
		t.Fatal("empty nonce must fail")
	}
	if g.VerifyChallenge(id, nonce, "198.51.100.9") {
		t.Fatal("solution must be bound to the issuing IP")
	}
	if g.VerifyChallenge(id+"x", nonce, ip) {
		t.Fatal("tampered challenge id must fail")
	}
}

func TestChallengeIPv6(t *testing.T) {
	g := newGate()
	ip := "2001:db8::1"
	id := g.IssueChallenge(ip)
	if !g.VerifyChallenge(id, solveChallenge(id, ChallengeDifficulty), ip) {
		t.Fatal("IPv6-bound challenge must verify")
	}
}

func TestChallengeExpired(t *testing.T) {
	g := newGate()
	ip := "203.0.113.7"
	old := time.Now().Add(-10 * time.Minute).Unix()
	id := g.Token(fmt.Sprintf("c|%s|%d|%d", ip, old, ChallengeDifficulty))
	if g.VerifyChallenge(id, solveChallenge(id, ChallengeDifficulty), ip) {
		t.Fatal("expired challenge must fail")
	}
}

func TestChallengeForeignSecret(t *testing.T) {
	g := New(config.Access{}, "secret-a")
	other := New(config.Access{}, "secret-b")
	ip := "1.2.3.4"
	id := other.IssueChallenge(ip)
	if g.VerifyChallenge(id, solveChallenge(id, ChallengeDifficulty), ip) {
		t.Fatal("challenge signed by another node must fail")
	}
}
