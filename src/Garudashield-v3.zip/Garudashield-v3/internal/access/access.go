// Package access ports v2's src/access/ AccessGate: CAPTCHA SVG generation
// with a signed code token, HMAC access tokens (format 1*rand*payload*sig22),
// exponential latency-hold for private paths, and per-IP CAPTCHA rate limiting.
package access

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"fmt"
	"math/big"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

const (
	holdBaseMs = 800
	holdMaxMs  = 20000
	holdMaxExp = 4 // 800 * 2^4 = 12800ms cap
)

// Gate is the v2 AccessGate port.
type Gate struct {
	cfg    config.Access
	secret string

	mu        sync.Mutex
	holds     map[string]int
	captchaTs map[string][]time.Time
	// issued tracks live CAPTCHA tokens (token -> verify deadline).
	// redeemed tracks spent tokens until they age out (anti-replay).
	issued   map[string]time.Time
	redeemed map[string]time.Time
}

// New builds a Gate. secret should be a stable per-node value (config.AccessSecret).
func New(cfg config.Access, secret string) *Gate {
	if secret == "" {
		secret = "garudashield-insecure-default"
	}
	if cfg.TokenTTLMs <= 0 {
		cfg.TokenTTLMs = 3_600_000
	}
	if cfg.CaptchaMaxPM <= 0 {
		cfg.CaptchaMaxPM = 10
	}
	if cfg.CookieName == "" {
		cfg.CookieName = "gs_access"
	}
	if cfg.QueryParam == "" {
		cfg.QueryParam = "gsat"
	}
	return &Gate{
		cfg:       cfg,
		secret:    secret,
		holds:     map[string]int{},
		captchaTs: map[string][]time.Time{},
		issued:    map[string]time.Time{},
		redeemed:  map[string]time.Time{},
	}
}

// ---------- token (format: 1*rand*payload*sig22) ----------

func (g *Gate) sign(randTok, payload string) string {
	mac := hmac.New(sha256.New, []byte(g.secret))
	mac.Write([]byte("1" + randTok + payload))
	return hex.EncodeToString(mac.Sum(nil))[:22]
}

// Token issues a signed access token binding an arbitrary payload
// (e.g. the CAPTCHA code or a session id).
func (g *Gate) Token(payload string) string {
	rb := make([]byte, 8)
	rand.Read(rb)
	randTok := hex.EncodeToString(rb)
	return "1*" + randTok + "*" + payload + "*" + g.sign(randTok, payload)
}

// Check validates a token and (optionally) that its payload matches expected.
func (g *Gate) Check(token, expectedPayload string) bool {
	parts := strings.Split(token, "*")
	if len(parts) != 4 || parts[0] != "1" {
		return false
	}
	_, randTok, payload, sig := parts[0], parts[1], parts[2], parts[3]
	if subtle.ConstantTimeCompare([]byte(g.sign(randTok, payload)), []byte(sig)) != 1 {
		return false
	}
	if expectedPayload != "" && payload != expectedPayload {
		return false
	}
	return true
}

// CaptchaWindow bounds CAPTCHA token validity (issue -> verify).
const captchaWindow = 5 * time.Minute

const capCharset = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"

// GenerateCaptcha returns the SVG markup, the signed token (binds the code),
// and the plain code (only for tests / server render). The token is
// registered with a short validity window (captchaWindow).
func (g *Gate) GenerateCaptcha() (svg, token, code string) {
	code = g.randomCode(5)
	token = g.Token(code)
	svg = g.svgFor(code)
	g.mu.Lock()
	g.issued[token] = time.Now().Add(captchaWindow)
	g.mu.Unlock()
	return
}

// VerifyCaptcha checks a submitted code against a previously issued token.
// Each token is single-use inside its validity window: unknown, expired,
// or already-redeemed tokens are rejected.
func (g *Gate) VerifyCaptcha(token, code string) bool {
	if token == "" || code == "" {
		return false
	}
	if !g.Check(token, code) {
		return false
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	now := time.Now()
	for t, exp := range g.issued {
		if now.After(exp) {
			delete(g.issued, t)
		}
	}
	for t, exp := range g.redeemed {
		if now.After(exp) {
			delete(g.redeemed, t)
		}
	}
	deadline, ok := g.issued[token]
	if !ok || now.After(deadline) {
		return false // never issued, expired, or already spent
	}
	if _, spent := g.redeemed[token]; spent {
		return false
	}
	delete(g.issued, token)
	g.redeemed[token] = now.Add(captchaWindow)
	return true
}

func (g *Gate) randomCode(n int) string {
	b := make([]byte, n)
	for i := range b {
		idx, _ := rand.Int(rand.Reader, big.NewInt(int64(len(capCharset))))
		b[i] = capCharset[idx.Int64()]
	}
	return string(b)
}

func (g *Gate) svgFor(code string) string {
	var sb strings.Builder
	sb.WriteString(`<svg xmlns="http://www.w3.org/2000/svg" width="160" height="48" viewBox="0 0 160 48">`)
	sb.WriteString(`<rect width="160" height="48" fill="#0b1020"/>`)
	for i, c := range code {
		x := 16 + i*28
		y := 34
		rot := (int(c) % 20) - 10
		sb.WriteString(fmt.Sprintf(
			`<text x="%d" y="%d" font-family="monospace" font-size="28" fill="#7ee787" transform="rotate(%d %d %d)">%c</text>`,
			x, y, rot, x, y, c))
	}
	// noise lines
	sb.WriteString(`<line x1="0" y1="10" x2="160" y2="38" stroke="#30363d" stroke-width="1"/>`)
	sb.WriteString(`<line x1="0" y1="40" x2="160" y2="8" stroke="#30363d" stroke-width="1"/>`)
	sb.WriteString(`</svg>`)
	return sb.String()
}

// ---------- browser (JS) challenge ----------

// ChallengeDifficulty is the number of leading hex zeros required in the
// SHA-256 proof-of-work solution (4 hex digits = 16 bits). It forces a real
// per-request cost on automation while a browser solves it in well under a
// second on modern hardware.
const ChallengeDifficulty = 4

// challengeWindow bounds how long an issued challenge stays valid.
const challengeWindow = 5 * time.Minute

// IssueChallenge returns a signed, stateless challenge id bound to ip. The id
// encodes the client IP, issue time and difficulty (payload "c:ip:ts:diff")
// and is safe to hand to an untrusted browser: tampering breaks the HMAC.
func (g *Gate) IssueChallenge(ip string) string {
	payload := fmt.Sprintf("c|%s|%d|%d", ip, time.Now().Unix(), ChallengeDifficulty)
	return g.Token(payload)
}

// VerifyChallenge validates a browser's proof-of-work solution for a signed
// challenge id. It requires a valid HMAC, an unexpired token, the same client
// IP that issued it, and sha256(id + "." + nonce) starting with
// ChallengeDifficulty hex zeros.
func (g *Gate) VerifyChallenge(id, nonce, ip string) bool {
	if id == "" || nonce == "" || len(nonce) > 20 {
		return false
	}
	parts := strings.Split(id, "*")
	if len(parts) != 4 {
		return false
	}
	if !g.Check(id, "") { // HMAC over rand+payload
		return false
	}
	fields := strings.Split(parts[2], "|")
	if len(fields) != 4 || fields[0] != "c" {
		return false
	}
	if fields[1] != ip { // bound to the issuing client IP
		return false
	}
	ts, err := strconv.ParseInt(fields[2], 10, 64)
	if err != nil {
		return false
	}
	if time.Since(time.Unix(ts, 0)) > challengeWindow {
		return false
	}
	diff, err := strconv.Atoi(fields[3])
	if err != nil || diff < 1 || diff > 6 {
		return false
	}
	sum := sha256.Sum256([]byte(id + "." + nonce))
	return strings.HasPrefix(hex.EncodeToString(sum[:]), strings.Repeat("0", diff))
}

// ---------- gating decision ----------

// ShouldGate reports whether the request must clear a CAPTCHA/access token
// before reaching the upstream.
func (g *Gate) ShouldGate(host, path string) bool {
	if !g.cfg.Enabled {
		return false
	}
	host = strings.ToLower(host)
	gated := g.cfg.ProtectAll
	if !gated && g.cfg.Hosts != nil {
		gated = g.cfg.Hosts[host]
	}
	if !gated {
		return false
	}
	if g.matchAny(path, g.cfg.ExemptPaths) {
		return false
	}
	if len(g.cfg.PrivatePaths) > 0 && g.matchAny(path, g.cfg.PrivatePaths) {
		return true
	}
	return g.cfg.ProtectAll
}

func (g *Gate) matchAny(path string, patterns []string) bool {
	if len(patterns) == 0 {
		return false
	}
	path = strings.ToLower(path)
	for _, p := range patterns {
		p = strings.ToLower(p)
		if p == "" {
			continue
		}
		if strings.HasPrefix(path, p) {
			return true
		}
	}
	return false
}

// ---------- latency hold ----------

// Hold returns the delay to apply before responding to a gated request and
// records the attempt (exponential backoff, capped).
func (g *Gate) Hold(ip string) time.Duration {
	g.mu.Lock()
	defer g.mu.Unlock()
	n := g.holds[ip]
	d := time.Duration(holdBaseMs*intPow(2, minInt(n, holdMaxExp))) * time.Millisecond
	if d > holdMaxMs*time.Millisecond {
		d = holdMaxMs * time.Millisecond
	}
	g.holds[ip] = n + 1
	return d
}

// ResetHold clears the backoff for an IP after a successful pass.
func (g *Gate) ResetHold(ip string) {
	g.mu.Lock()
	delete(g.holds, ip)
	g.mu.Unlock()
}

// ---------- CAPTCHA rate limit ----------

// CaptchaAllowed reports whether the IP may request another CAPTCHA this minute.
func (g *Gate) CaptchaAllowed(ip string) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	now := time.Now()
	ts := g.captchaTs[ip]
	cut := now.Add(-time.Minute)
	kept := ts[:0]
	for _, t := range ts {
		if t.After(cut) {
			kept = append(kept, t)
		}
	}
	g.captchaTs[ip] = kept
	return len(kept) < g.cfg.CaptchaMaxPM
}

// RecordCaptcha notes a CAPTCHA issuance for the per-IP minute limit.
func (g *Gate) RecordCaptcha(ip string) {
	g.mu.Lock()
	g.captchaTs[ip] = append(g.captchaTs[ip], time.Now())
	g.mu.Unlock()
}

// ---------- cookie helpers ----------

// SetCookie writes the access token cookie (caller supplies the token).
func (g *Gate) SetCookie(w http.ResponseWriter, token string) {
	http.SetCookie(w, &http.Cookie{
		Name:     g.cfg.CookieName,
		Value:    token,
		Path:     "/",
		Domain:   g.cfg.CookieDomain,
		MaxAge:   int(g.cfg.TokenTTLMs / 1000),
		Secure:   g.cfg.CookieSecure,
		HttpOnly: true,
		SameSite: http.SameSiteLaxMode,
	})
}

// CookieName returns the configured cookie name.
func (g *Gate) CookieName() string { return g.cfg.CookieName }

// QueryParam returns the configured query-param name for token passthrough.
func (g *Gate) QueryParam() string { return g.cfg.QueryParam }

// ---------- small math ----------

func intPow(base, exp int) int {
	r := 1
	for i := 0; i < exp; i++ {
		r *= base
	}
	return r
}

func minInt(a, b int) int {
	if a < b {
		return a
	}
	return b
}

// Hosts returns a copy of the per-host gating map.
func (g *Gate) Hosts() map[string]bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	out := make(map[string]bool, len(g.cfg.Hosts))
	for k, v := range g.cfg.Hosts {
		out[k] = v
	}
	return out
}

// ProtectAll reports whether gating applies to every host.
func (g *Gate) ProtectAll() bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.cfg.ProtectAll
}

// SetProtectAll toggles global gating.
func (g *Gate) SetProtectAll(v bool) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.cfg.ProtectAll = v
}

// SetHost enables or disables gating for a specific host.
func (g *Gate) SetHost(host string, enabled bool) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.cfg.Hosts == nil {
		g.cfg.Hosts = map[string]bool{}
	}
	g.cfg.Hosts[host] = enabled
}

// RemoveHost drops a host from the gating map entirely. This differs from
// SetHost(host, false), which keeps the entry as an explicit "not gated"
// record — removal is what the dashboard needs so an operator can clear a
// subdomain they added by mistake.
func (g *Gate) RemoveHost(host string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	delete(g.cfg.Hosts, host)
}

// CookieSecure reports the Secure flag configured for access cookies.
func (g *Gate) CookieSecure() bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.cfg.CookieSecure
}

// CookieDomain returns the Domain configured for access cookies.
func (g *Gate) CookieDomain() string {
	g.mu.Lock()
	defer g.mu.Unlock()
	return g.cfg.CookieDomain
}
