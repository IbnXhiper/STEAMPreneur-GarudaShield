// Package alerts delivers notifications over Discord / Telegram / Slack / SMTP
// webhooks, honoring a minimum-severity gate and per-title cooldown. It
// implements shield.Notifier so the engine can emit incidents without coupling
// to any transport.
package alerts

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"net/smtp"
	"net/url"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Manager is the alert sink used by the engine.
type Manager struct {
	cfg     config.Alerts
	mu      sync.Mutex
	history []Entry
	last    map[string]int64
	client  *http.Client
}

// Entry is a single emitted alert (for /api/alerts/log).
type Entry struct {
	Time     int64  `json:"time"`
	Severity string `json:"severity"`
	Title    string `json:"title"`
	Detail   string `json:"detail"`
}

func New(cfg config.Alerts) *Manager {
	return &Manager{
		cfg:     cfg,
		history: make([]Entry, 0, 64),
		last:    make(map[string]int64),
		client:  &http.Client{Timeout: 8 * time.Second},
	}
}

func rank(s string) int {
	switch strings.ToLower(s) {
	case "critical", "error":
		return 2
	case "warning":
		return 1
	default:
		return 0
	}
}

// Send implements shield.Notifier.
func (m *Manager) Send(severity, title string, fields map[string]string) {
	if rank(severity) < rank(m.cfg.MinSeverity) {
		return
	}
	detail := flatten(fields)
	m.mu.Lock()
	now := time.Now().UnixMilli()
	if m.cfg.CooldownMs > 0 {
		if last, ok := m.last[title]; ok && now-last < int64(m.cfg.CooldownMs) {
			m.mu.Unlock()
			return
		}
		m.last[title] = now
	}
	m.history = append(m.history, Entry{Time: now, Severity: severity, Title: title, Detail: detail})
	if len(m.history) > 200 {
		m.history = m.history[len(m.history)-200:]
	}
	m.mu.Unlock()

	msg := fmt.Sprintf("[%s] %s\n%s", strings.ToUpper(severity), title, detail)
	if m.cfg.WAWebhook != "" {
		go m.postJSON(m.cfg.WAWebhook, map[string]any{"message": msg})
	}
	if m.cfg.DiscordHook != "" {
		go m.postJSON(m.cfg.DiscordHook, map[string]any{"content": msg})
	}
	if m.cfg.SlackHook != "" {
		go m.postJSON(m.cfg.SlackHook, map[string]any{"text": msg})
	}
	if m.cfg.TelegramToken != "" && m.cfg.TelegramChat != "" {
		go m.telegram(msg)
	}
	if m.cfg.SMTPHost != "" {
		go m.email(title, msg)
	}
}

func (m *Manager) postJSON(u string, payload any) error {
	b, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	req, err := http.NewRequestWithContext(context.Background(), http.MethodPost, u, strings.NewReader(string(b)))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")
	resp, err := m.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

func (m *Manager) telegram(msg string) error {
	endpoint := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", m.cfg.TelegramToken)
	q := url.Values{}
	q.Set("chat_id", m.cfg.TelegramChat)
	q.Set("text", msg)
	req, err := http.NewRequestWithContext(context.Background(), http.MethodGet, endpoint+"?"+q.Encode(), nil)
	if err != nil {
		return err
	}
	resp, err := m.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()
	return nil
}

func (m *Manager) email(subject, body string) error {
	addr := fmt.Sprintf("%s:%d", m.cfg.SMTPHost, m.cfg.SMTPPort)
	var auth smtp.Auth
	if m.cfg.SMTPUser != "" {
		auth = smtp.PlainAuth("", m.cfg.SMTPUser, m.cfg.SMTPPass, m.cfg.SMTPHost)
	}
	msg := strings.Builder{}
	msg.WriteString("From: " + m.cfg.SMTPFrom + "\r\n")
	msg.WriteString("To: " + m.cfg.SMTPFrom + "\r\n")
	msg.WriteString("Subject: " + subject + "\r\n")
	msg.WriteString("MIME-Version: 1.0\r\n")
	msg.WriteString("Content-Type: text/plain; charset=UTF-8\r\n\r\n")
	msg.WriteString(body + "\r\n")
	return smtp.SendMail(addr, auth, m.cfg.SMTPFrom, []string{m.cfg.SMTPFrom}, []byte(msg.String()))
}

// History returns up to n recent alerts.
func (m *Manager) History(n int) []Entry {
	m.mu.Lock()
	defer m.mu.Unlock()
	if n <= 0 || n > len(m.history) {
		n = len(m.history)
	}
	out := make([]Entry, n)
	copy(out, m.history[len(m.history)-n:])
	return out
}

// Status reports per-channel availability (without sending).
func (m *Manager) Status() map[string]any {
	return map[string]any{
		"minSeverity": m.cfg.MinSeverity,
		"cooldownMs":  m.cfg.CooldownMs,
		"channels": map[string]bool{
			"discord":  m.cfg.DiscordHook != "",
			"slack":    m.cfg.SlackHook != "",
			"telegram": m.cfg.TelegramToken != "" && m.cfg.TelegramChat != "",
			"email":    m.cfg.SMTPHost != "",
		},
	}
}

// Test sends a probe alert to every configured channel.
func (m *Manager) Test() map[string]any {
	m.Send("info", "GarudaShield self-test", map[string]string{"note": "alert channel test"})
	return m.Status()
}

// Configure merges overrides into the live config (best-effort).
func (m *Manager) Configure(data map[string]any) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if v, ok := data["minSeverity"].(string); ok {
		m.cfg.MinSeverity = v
	}
	if v, ok := data["cooldown"].(float64); ok {
		m.cfg.CooldownMs = int(v)
	}
	if v, ok := data["discordWebhookUrl"].(string); ok {
		m.cfg.DiscordHook = v
	}
	if v, ok := data["slackWebhookUrl"].(string); ok {
		m.cfg.SlackHook = v
	}
	if v, ok := data["telegramToken"].(string); ok {
		m.cfg.TelegramToken = v
	}
	if v, ok := data["telegramChatId"].(string); ok {
		m.cfg.TelegramChat = v
	}
}

func flatten(fields map[string]string) string {
	if len(fields) == 0 {
		return ""
	}
	parts := make([]string, 0, len(fields))
	for k, v := range fields {
		parts = append(parts, k+": "+v)
	}
	return strings.Join(parts, "\n")
}
