package alerts

import (
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

func TestSeverityGate(t *testing.T) {
	m := New(config.Alerts{MinSeverity: "info", CooldownMs: 0})
	m.Send("info", "low", nil)
	m.Send("warning", "mid", nil)
	m.Send("critical", "high", nil)
	if len(m.History(10)) != 3 {
		t.Fatalf("expected 3 in history, got %d", len(m.History(10)))
	}
}

func TestSeverityGateFilters(t *testing.T) {
	m := New(config.Alerts{MinSeverity: "warning", CooldownMs: 0})
	m.Send("info", "ignored", nil)
	if len(m.History(10)) != 0 {
		t.Fatalf("info should be filtered under warning min; got %d", len(m.History(10)))
	}
	m.Send("critical", "kept", nil)
	if len(m.History(10)) != 1 {
		t.Fatalf("critical should pass; got %d", len(m.History(10)))
	}
}

func TestCooldown(t *testing.T) {
	m := New(config.Alerts{MinSeverity: "info", CooldownMs: 1000})
	m.Send("info", "dup", nil)
	m.Send("info", "dup", nil) // within cooldown
	if len(m.History(10)) != 1 {
		t.Fatalf("cooldown should suppress duplicate; got %d", len(m.History(10)))
	}
	time.Sleep(1100 * time.Millisecond)
	m.Send("info", "dup", nil)
	if len(m.History(10)) != 2 {
		t.Fatalf("after cooldown should send again; got %d", len(m.History(10)))
	}
}

func TestStatusChannels(t *testing.T) {
	m := New(config.Alerts{MinSeverity: "info", DiscordHook: "https://x/y", TelegramToken: "t", TelegramChat: "c"})
	s := m.Status()
	ch := s["channels"].(map[string]bool)
	if !ch["discord"] || !ch["telegram"] || ch["slack"] || ch["email"] {
		t.Fatalf("channel detection wrong: %+v", ch)
	}
}

func TestWADelivery(t *testing.T) {
	var got string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		b, _ := io.ReadAll(r.Body)
		got = string(b)
		w.WriteHeader(http.StatusOK)
	}))
	defer srv.Close()
	m := New(config.Alerts{MinSeverity: "info", WAWebhook: srv.URL + "/wa"})
	m.Send("warning", "Serangan L7", map[string]string{"ip": "1.2.3.4", "rps": "9000"})
	// WA delivery is async (go m.postJSON). Poll instead of a fixed sleep so
	// the test stays reliable under load (CI) without a long dead wait.
	deadline := time.Now().Add(2 * time.Second)
	for time.Now().Before(deadline) && got == "" {
		time.Sleep(20 * time.Millisecond)
	}
	if got == "" {
		t.Fatal("WhatsApp webhook was not called")
	}
	if !strings.Contains(got, "Serangan L7") || !strings.Contains(got, "1.2.3.4") {
		t.Fatalf("WA payload wrong: %q", got)
	}
}
