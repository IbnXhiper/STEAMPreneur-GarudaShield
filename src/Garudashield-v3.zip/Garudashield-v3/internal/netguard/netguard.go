// Package netguard provides listener-level defenses that operate before any
// HTTP parsing happens: per-client-IP connection caps and idle-connection
// reaping. These close the classic slowloris / connection-exhaustion gap that a
// request-concurrency semaphore (http.Server.MaxConcurrency) cannot, because an
// attacker can hold thousands of idle sockets open without ever sending a full
// request.
package netguard

import (
	"net"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/metrics"
)

// Guard wraps a net.Listener and enforces limits on accepted connections.
type Guard struct {
	under            net.Listener
	maxPerIP         int
	idle             time.Duration
	bytesPerSecPerIP int64 // 0 = unlimited; total ingress bytes/IP/sec across all its conns

	mu      sync.Mutex
	count   map[string]int
	bytesAt map[string]int64
	window  time.Time
}

// New wraps l. maxPerIP <= 0 disables the per-IP cap. idle <= 0 disables the
// idle timeout (callers should then rely on http.Server.IdleTimeout).
func New(l net.Listener, maxPerIP int, idle time.Duration, bytesPerSecPerIP int64) *Guard {
	return &Guard{
		under:            l,
		maxPerIP:         maxPerIP,
		idle:             idle,
		bytesPerSecPerIP: bytesPerSecPerIP,
		count:            make(map[string]int),
		bytesAt:          make(map[string]int64),
		window:           time.Now(),
	}
}

// ipOf extracts the client IP from a connection's remote address, ignoring any
// port. IPv4-mapped IPv6 is normalized to the IPv4 form.
func ipOf(addr net.Addr) string {
	if addr == nil {
		return ""
	}
	host, _, err := net.SplitHostPort(addr.String())
	if err != nil {
		host = addr.String()
	}
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			return v4.String()
		}
	}
	return host
}

// Accept enforces the per-IP cap. When the cap is reached for a client, the
// freshly accepted connection is closed immediately (fail-closed: a client
// past its limit gets nothing, not a slot someone else could have used).
func (g *Guard) Accept() (net.Conn, error) {
	for {
		c, err := g.under.Accept()
		if err != nil {
			return nil, err
		}
		ip := ipOf(c.RemoteAddr())
		if g.maxPerIP > 0 {
			g.mu.Lock()
			n := g.count[ip]
			if n >= g.maxPerIP {
				g.mu.Unlock()
				c.Close() // over limit: drop silently
				continue
			}
			g.count[ip] = n + 1
			g.mu.Unlock()
			metrics.ActiveConns.Inc()
		}
		return &TrackedConn{Conn: c, guard: g, ip: ip, idle: g.idle}, nil
	}
}

// Close closes the underlying listener.
func (g *Guard) Close() error { return g.under.Close() }

// Addr returns the underlying listener's address.
func (g *Guard) Addr() net.Addr { return g.under.Addr() }

// trackedConn decrements the per-IP counter on close and applies the idle
// timeout (no read/write activity beyond idle) when configured.
type TrackedConn struct {
	net.Conn
	guard *Guard
	ip    string
	idle  time.Duration
	once  sync.Once
}

func (t *TrackedConn) Close() error {
	t.once.Do(func() {
		metrics.ActiveConns.Dec()
		if t.guard.maxPerIP > 0 {
			t.guard.mu.Lock()
			if t.guard.count[t.ip] > 0 {
				t.guard.count[t.ip]--
			}
			t.guard.mu.Unlock()
		}
	})
	if t.idle > 0 {
		_ = t.Conn.SetDeadline(time.Now().Add(t.idle))
	}
	return t.Conn.Close()
}

// SetIdleTimeout applies the idle deadline to future reads/writes. Called by the
// server after accept; we also set it on Close as a fallback for idle sockets.
func (t *TrackedConn) SetIdleTimeout() {
	if t.idle > 0 {
		_ = t.Conn.SetDeadline(time.Now().Add(t.idle))
	}
}

// Read enforces the per-IP bandwidth cap. Bytes read on this connection are
// charged to the connection's IP; if the IP exceeds bytesPerSecPerIP within the
// sliding 1-second window, the connection is closed (fail-closed). This stops a
// single IP from saturating ingress bandwidth with a slow big-POST or many
// concurrent uploads, independent of the connection-count cap.
func (t *TrackedConn) Read(b []byte) (int, error) {
	n, err := t.Conn.Read(b)
	if n > 0 {
		metrics.BytesIngested.Add(float64(n))
	}
	if n > 0 && t.guard != nil && t.guard.bytesPerSecPerIP > 0 {
		if t.guard.charge(t.ip, int64(n)) {
			_ = t.Close()
			return n, err
		}
	}
	return n, err
}

// charge adds n bytes to ip's window, rolling the window every second. Returns
// true if the IP is now over its per-second budget (caller should drop).
func (g *Guard) charge(ip string, n int64) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	now := time.Now()
	if now.Sub(g.window) >= time.Second {
		g.window = now
		g.bytesAt = make(map[string]int64)
	}
	g.bytesAt[ip] += n
	return g.bytesAt[ip] > g.bytesPerSecPerIP
}

var _ net.Listener = (*Guard)(nil)
