package netguard

import (
	"net"
	"sync"
	"testing"
	"time"
)

func TestPerIPCapEnforced(t *testing.T) {
	under, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer under.Close()
	g := New(under, 2, 0, 0) // max 2 conns per IP
	defer g.Close()

	var wg sync.WaitGroup
	var accepted int
	var mu sync.Mutex
	go func() {
		for {
			c, err := g.Accept()
			if err != nil {
				return
			}
			mu.Lock()
			accepted++
			mu.Unlock()
			wg.Add(1)
			go func() {
				defer wg.Done()
				// hold the connection open
				buf := make([]byte, 8)
				_, _ = c.Read(buf)
				c.Close()
			}()
		}
	}()

	// Open 2 connections from the same IP — both should be accepted.
	a, err := net.Dial("tcp", under.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	b, err := net.Dial("tcp", under.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	// Third from same IP must be refused (listener accepts then Guard closes it).
	time.Sleep(50 * time.Millisecond)
	c, err := net.Dial("tcp", under.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	// Give the Guard time to accept+close c.
	time.Sleep(100 * time.Millisecond)
	c.Close()
	a.Close()
	b.Close()

	time.Sleep(100 * time.Millisecond)
	mu.Lock()
	got := accepted
	mu.Unlock()
	if got != 2 {
		t.Fatalf("expected exactly 2 accepted connections, got %d", got)
	}
	wg.Wait()
}

func TestIdleTimeoutClosesStaleConn(t *testing.T) {
	under, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer under.Close()
	g := New(under, 0, 80*time.Millisecond, 0) // 80ms idle cap
	defer g.Close()

	type res struct {
		c   net.Conn
		err error
	}
	rc := make(chan res, 1)
	go func() {
		c, e := g.Accept()
		rc <- res{c, e}
	}()

	cli, err := net.Dial("tcp", under.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer cli.Close()

	select {
	case r := <-rc:
		if r.err != nil {
			t.Fatalf("accept failed: %v", r.err)
		}
		tc := r.c.(*TrackedConn)
		tc.SetIdleTimeout()
		// The server side should hit its idle deadline and close.
		buf := make([]byte, 8)
		_ = r.c.(*TrackedConn).Conn.SetReadDeadline(time.Now().Add(500 * time.Millisecond))
		_, rerr := r.c.Read(buf)
		if rerr == nil {
			t.Fatal("expected idle timeout to close the connection")
		}
	case <-time.After(500 * time.Millisecond):
		t.Fatal("accept timed out")
	}
}

func TestPerIPBandwidthCap(t *testing.T) {
	under, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer under.Close()
	// 100 bytes/sec/IP cap. Client sends 500 bytes in one shot.
	g := New(under, 0, 0, 100)
	defer g.Close()

	type res struct {
		c   net.Conn
		err error
	}
	rc := make(chan res, 1)
	go func() {
		c, e := g.Accept()
		rc <- res{c, e}
	}()

	cli, err := net.Dial("tcp", under.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer cli.Close()

	select {
	case r := <-rc:
		if r.err != nil {
			t.Fatalf("accept failed: %v", r.err)
		}
		conn := r.c.(*TrackedConn)
		// Send a big chunk; Guard should close the conn once the IP exceeds 100 B/s.
		payload := make([]byte, 500)
		_, werr := cli.Write(payload)
		if werr != nil {
			t.Fatalf("write failed: %v", werr)
		}
		// Drain reads on the server side. Each Read charges bytes to the IP; once
		// the 1s window passes 100 bytes the Guard closes the conn, so the next
		// Read must fail.
		buf := make([]byte, 16)
		conn.SetReadDeadline(time.Now().Add(1 * time.Second))
		for {
			_, rerr := conn.Read(buf)
			if rerr != nil {
				return // closed by bandwidth cap — expected
			}
		}
	case <-time.After(500 * time.Millisecond):
		t.Fatal("accept timed out")
	}
}

func TestIPNormalization(t *testing.T) {
	if got := ipOf(&net.TCPAddr{IP: net.ParseIP("::ffff:1.2.3.4"), Port: 1234}); got != "1.2.3.4" {
		t.Fatalf("IPv4-mapped not normalized: %q", got)
	}
	if got := ipOf(&net.TCPAddr{IP: net.ParseIP("2001:db8::1"), Port: 1234}); got != "2001:db8::1" {
		t.Fatalf("IPv6 changed: %q", got)
	}
}
