// Package audit exposes a read-only, tenant-scoped view over the commercial
// audit_log table (login, account, key, asset, member, license, and operator
// actions).
//
// Writes happen elsewhere (tenant.Store.Audit and the commercial transactions);
// this package only queries. Every query is parameterized and filtered by
// tenant_id, so one customer can never read another tenant's history — there is
// no global listing exposed to a customer session.
package audit

import (
	"context"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Pagination bounds. A client-supplied limit is always clamped into this range.
const (
	DefaultLimit = 50
	MaxLimit     = 200
	maxOffset    = 1_000_000
)

// Entry is one audit record as surfaced to the owning tenant.
type Entry struct {
	ID       int64  `json:"id"`
	TenantID string `json:"tenant"`
	Actor    string `json:"actor"`
	Action   string `json:"action"`
	Detail   string `json:"detail"`
	IP       string `json:"ip"`
	At       int64  `json:"at"`
	Time     string `json:"time"`
}

// Filter narrows a listing. Zero values mean "no filter".
type Filter struct {
	Action string
	Actor  string
	Limit  int
	Offset int
}

// Normalize clamps untrusted values into safe bounds.
func (f Filter) Normalize() Filter {
	f.Action = clip(strings.TrimSpace(f.Action), 64)
	f.Actor = clip(strings.TrimSpace(f.Actor), 128)
	if f.Limit <= 0 {
		f.Limit = DefaultLimit
	}
	if f.Limit > MaxLimit {
		f.Limit = MaxLimit
	}
	if f.Offset < 0 {
		f.Offset = 0
	}
	if f.Offset > maxOffset {
		f.Offset = maxOffset
	}
	return f
}

// Store reads audit rows from PostgreSQL.
type Store struct {
	pool *pgxpool.Pool
}

// New builds an audit store over the given pool.
func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// List returns the tenant's audit entries, newest first, honoring the filter.
// All values are bound as parameters; only placeholder numbers are formatted.
func (s *Store) List(ctx context.Context, tenantID string, f Filter) ([]Entry, error) {
	f = f.Normalize()
	q := `SELECT id, COALESCE(tenant_id,''), COALESCE(actor,''), action,
	             COALESCE(detail,''), COALESCE(ip,''), created_at
	      FROM audit_log WHERE tenant_id = $1`
	args := []any{tenantID}
	if f.Action != "" {
		args = append(args, f.Action)
		q += fmt.Sprintf(" AND action = $%d", len(args))
	}
	if f.Actor != "" {
		args = append(args, f.Actor)
		q += fmt.Sprintf(" AND actor = $%d", len(args))
	}
	args = append(args, f.Limit, f.Offset)
	q += fmt.Sprintf(" ORDER BY id DESC LIMIT $%d OFFSET $%d", len(args)-1, len(args))

	rows, err := s.pool.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	out := make([]Entry, 0, f.Limit)
	for rows.Next() {
		var (
			e  Entry
			ts time.Time
		)
		if err := rows.Scan(&e.ID, &e.TenantID, &e.Actor, &e.Action, &e.Detail, &e.IP, &ts); err != nil {
			return nil, err
		}
		e.At = ts.Unix()
		e.Time = ts.UTC().Format(time.RFC3339)
		out = append(out, e)
	}
	return out, rows.Err()
}

// Count returns the total number of matching rows (for pagination).
func (s *Store) Count(ctx context.Context, tenantID string, f Filter) (int64, error) {
	f = f.Normalize()
	q := `SELECT count(*) FROM audit_log WHERE tenant_id = $1`
	args := []any{tenantID}
	if f.Action != "" {
		args = append(args, f.Action)
		q += fmt.Sprintf(" AND action = $%d", len(args))
	}
	if f.Actor != "" {
		args = append(args, f.Actor)
		q += fmt.Sprintf(" AND actor = $%d", len(args))
	}
	var n int64
	err := s.pool.QueryRow(ctx, q, args...).Scan(&n)
	return n, err
}

func clip(s string, max int) string {
	if len(s) > max {
		return s[:max]
	}
	return s
}
