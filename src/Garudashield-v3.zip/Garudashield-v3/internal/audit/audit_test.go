package audit

import (
	"context"
	"os"
	"testing"

	"github.com/ahkurdev/garudashield/internal/db"
)

func TestFilterNormalize(t *testing.T) {
	// Defaults.
	f := Filter{}.Normalize()
	if f.Limit != DefaultLimit || f.Offset != 0 {
		t.Fatalf("defaults: limit=%d offset=%d", f.Limit, f.Offset)
	}
	// Clamp high limit and negative offset.
	f = Filter{Limit: 100000, Offset: -5}.Normalize()
	if f.Limit != MaxLimit || f.Offset != 0 {
		t.Fatalf("clamp: limit=%d offset=%d", f.Limit, f.Offset)
	}
	// Trimming + length clipping.
	f = Filter{Action: "  x  ", Actor: string(make([]byte, 300))}.Normalize()
	if f.Action != "x" {
		t.Fatalf("action trim = %q", f.Action)
	}
	if len(f.Actor) != 128 {
		t.Fatalf("actor clip = %d want 128", len(f.Actor))
	}
}

// TestAuditListIsTenantScopedPG proves the read API can never leak across
// tenants: rows for another tenant are invisible and excluded from counts.
func TestAuditListIsTenantScopedPG(t *testing.T) {
	if os.Getenv("GS_DATABASE_URL") == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	const a, b = "audit-t1", "audit-t2"
	cleanup := func() {
		_, _ = pool.Exec(ctx, `DELETE FROM audit_log WHERE tenant_id IN ($1,$2)`, a, b)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id IN ($1,$2)`, a, b)
	}
	cleanup()
	defer cleanup()
	for _, id := range []string{a, b} {
		if _, err := pool.Exec(ctx,
			`INSERT INTO tenants (id,name,plan) VALUES ($1,$1,'free')`, id); err != nil {
			t.Fatal(err)
		}
	}
	ins := func(tenant, action, actor string) {
		if _, err := pool.Exec(ctx,
			`INSERT INTO audit_log (tenant_id,actor,action,detail,ip) VALUES ($1,$2,$3,'', '')`,
			tenant, actor, action); err != nil {
			t.Fatal(err)
		}
	}
	ins(a, "account.login", "u1")
	ins(a, "apikey.create", "u1")
	ins(b, "account.login", "u2")

	s := New(pool)
	got, err := s.List(ctx, a, Filter{})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 {
		t.Fatalf("tenant %s rows = %d want 2", a, len(got))
	}
	for _, e := range got {
		if e.TenantID != a {
			t.Fatalf("leak: got tenant %q for listing %q", e.TenantID, a)
		}
	}

	// Action filter.
	filtered, err := s.List(ctx, a, Filter{Action: "apikey.create"})
	if err != nil {
		t.Fatal(err)
	}
	if len(filtered) != 1 || filtered[0].Action != "apikey.create" {
		t.Fatalf("action filter = %+v", filtered)
	}

	n, err := s.Count(ctx, a, Filter{})
	if err != nil {
		t.Fatal(err)
	}
	if n != 2 {
		t.Fatalf("count(%s) = %d want 2", a, n)
	}
	// b must not bleed in.
	nb, err := s.Count(ctx, b, Filter{})
	if err != nil {
		t.Fatal(err)
	}
	if nb != 1 {
		t.Fatalf("count(%s) = %d want 1", b, nb)
	}
}
