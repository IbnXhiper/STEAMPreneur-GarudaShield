// Package transport provides the HTTP/3 (QUIC) listener for GarudaShield v3.
//
// QUIC runs over UDP and is itself a DDoS surface (handshake floods, connection
// amplification, stream exhaustion), so StartH3 bounds per-connection streams.
// The handler is shared with the TCP (H1/H2) listener so the same edge defenses
// apply.
package transport

import (
	"crypto/tls"
	"net"
	"net/http"
	"time"

	"github.com/quic-go/quic-go"
	"github.com/quic-go/quic-go/http3"
)

// StartH3 binds a UDP socket on addr and serves handler over HTTP/3. It returns
// the underlying packet conn so the caller can close it on shutdown. maxStreams
// caps streams per QUIC connection (0 => 100); idle tunes MaxIdleTimeout.
func StartH3(addr string, handler http.Handler, tlsCfg *tls.Config, maxStreams int, idle time.Duration) (net.PacketConn, error) {
	if maxStreams <= 0 {
		maxStreams = 100
	}
	if idle <= 0 {
		idle = 30 * time.Second
	}
	udpAddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		return nil, err
	}
	pc, err := net.ListenUDP("udp", udpAddr)
	if err != nil {
		return nil, err
	}
	cfg := tlsCfg.Clone()
	cfg.NextProtos = []string{"h3"}
	h3 := &http3.Server{
		Handler:   handler,
		TLSConfig: cfg,
		QUICConfig: &quic.Config{
			MaxIncomingStreams: int64(maxStreams),
			MaxIdleTimeout:     idle,
		},
	}
	go func() {
		_ = h3.Serve(pc)
	}()
	return pc, nil
}
