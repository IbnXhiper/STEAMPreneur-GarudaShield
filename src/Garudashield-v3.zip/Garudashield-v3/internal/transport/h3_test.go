package transport

import (
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"fmt"
	"io"
	"math/big"
	"net/http"
	"strings"
	"testing"
	"time"

	"github.com/quic-go/quic-go/http3"
)

func selfSigned(t *testing.T) (cert tls.Certificate, serverName string) {
	priv, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		t.Fatal(err)
	}
	tmpl := x509.Certificate{
		SerialNumber: big.NewInt(1),
		Subject:      pkix.Name{CommonName: "localhost"},
		NotBefore:    time.Now().Add(-time.Hour),
		NotAfter:     time.Now().Add(time.Hour),
		DNSNames:     []string{"localhost"},
		IPAddresses:  nil,
		KeyUsage:     x509.KeyUsageDigitalSignature,
		ExtKeyUsage:  []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth},
	}
	der, err := x509.CreateCertificate(rand.Reader, &tmpl, &tmpl, &priv.PublicKey, priv)
	if err != nil {
		t.Fatal(err)
	}
	c, err := tls.X509KeyPair(pemEncode("CERTIFICATE", der), pemEncode("EC PRIVATE KEY", mustMarshalEC(priv)))
	if err != nil {
		t.Fatal(err)
	}
	return c, "localhost"
}

func mustMarshalEC(priv *ecdsa.PrivateKey) []byte {
	b, err := x509.MarshalECPrivateKey(priv)
	if err != nil {
		panic(err)
	}
	return b
}

func pemEncode(typ string, der []byte) []byte {
	return pem.EncodeToMemory(&pem.Block{Type: typ, Bytes: der})
}

func TestH3EndToEnd(t *testing.T) {
	cert, name := selfSigned(t)
	mux := http.NewServeMux()
	mux.HandleFunc("/ping", func(w http.ResponseWriter, r *http.Request) {
		_, _ = w.Write([]byte("pong-over-quic"))
	})
	pc, err := StartH3("127.0.0.1:18443", mux, &tls.Config{
		Certificates: []tls.Certificate{cert},
	}, 50, 10*time.Second)
	if err != nil {
		t.Fatalf("StartH3: %v", err)
	}
	defer pc.Close()

	// Give the listener a moment to bind.
	time.Sleep(200 * time.Millisecond)

	rt := &http3.Transport{
		TLSClientConfig: &tls.Config{
			InsecureSkipVerify: true,
			ServerName:         name,
		},
	}
	defer rt.Close()
	client := &http.Client{Transport: rt, Timeout: 5 * time.Second}

	resp, err := client.Get("https://127.0.0.1:18443/ping")
	if err != nil {
		t.Fatalf("h3 GET: %v", err)
	}
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	if resp.StatusCode != 200 {
		t.Fatalf("status %d", resp.StatusCode)
	}
	if !strings.Contains(string(body), "pong-over-quic") {
		t.Fatalf("unexpected body: %q", string(body))
	}
	fmt.Println("H3 e2e OK:", strings.TrimSpace(string(body)))
}

func TestH3StreamCap(t *testing.T) {
	// Smoke: StartH3 with a tiny stream cap must still serve (cap is enforced by
	// quic-go at the connection level, not by blocking startup).
	cert, _ := selfSigned(t)
	pc, err := StartH3("127.0.0.1:18444", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {}),
		&tls.Config{Certificates: []tls.Certificate{cert}}, 2, time.Second)
	if err != nil {
		t.Fatalf("StartH3 cap: %v", err)
	}
	defer pc.Close()
	time.Sleep(100 * time.Millisecond)
}
