package license

import (
	"crypto/sha256"
	"encoding/hex"
	"net"
	"os"
	"os/exec"
	"runtime"
	"strings"
)

// HostFingerprint returns a stable, hardware-derived identifier for the machine
// running the engine. It is used to bind a self-hosted license to one server so
// the same license key cannot be copied to a second box.
//
// The value is a hex SHA-256 of stable host attributes (machine-id + primary MAC
// + hostname). It is never placed in a license in raw form — callers should pass
// FingerprintHash() so the license only carries a one-way digest, not the real
// host identity.
func HostFingerprint() string {
	parts := []string{
		machineID(),
		primaryMAC(),
		hostname(),
	}
	raw := strings.Join(parts, "|")
	sum := sha256.Sum256([]byte(raw))
	return hex.EncodeToString(sum[:])
}

// FingerprintHash returns the digest form suitable for embedding in a license.
func FingerprintHash() string {
	return HostFingerprint()
}

func hostname() string {
	h, err := os.Hostname()
	if err != nil || h == "" {
		return "unknown"
	}
	return h
}

// machineID reads the OS-native stable machine identifier.
func machineID() string {
	switch runtime.GOOS {
	case "windows":
		return regMachineGuid()
	case "linux":
		if b, err := os.ReadFile("/etc/machine-id"); err == nil {
			s := strings.TrimSpace(string(b))
			if s != "" {
				return s
			}
		}
		if b, err := os.ReadFile("/var/lib/dbus/machine-id"); err == nil {
			return strings.TrimSpace(string(b))
		}
	case "darwin":
		out, err := exec.Command("ioreg", "-rd1", "-c", "IOPlatformExpertDevice",
			"-d", "1").Output()
		if err == nil {
			for _, line := range strings.Split(string(out), "\n") {
				if strings.Contains(line, "IOPlatformUUID") {
					if i := strings.Index(line, "\""); i >= 0 {
						rest := line[i+1:]
						if j := strings.Index(rest, "\""); j >= 0 {
							return rest[:j]
						}
					}
				}
			}
		}
	}
	// Fallback: best-effort, never empty (empty would make the binding useless).
	if b, err := os.ReadFile("/etc/hostid"); err == nil {
		return strings.TrimSpace(string(b))
	}
	return "no-machine-id"
}

// primaryMAC returns the first non-loopback, non-zero MAC address.
func primaryMAC() string {
	ifaces, err := net.Interfaces()
	if err != nil {
		return "no-mac"
	}
	for _, ifc := range ifaces {
		if ifc.Flags&net.FlagLoopback != 0 {
			continue
		}
		mac := ifc.HardwareAddr
		if len(mac) == 0 || isZeroMAC(mac.String()) {
			continue
		}
		return mac.String()
	}
	return "no-mac"
}

func isZeroMAC(mac string) bool {
	return mac == "00:00:00:00:00:00" || mac == "00-00-00-00-00-00"
}
