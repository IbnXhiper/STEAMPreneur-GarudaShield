package license

import (
	"errors"
	"testing"
	"time"
)

func TestFingerprintStableAndNonEmpty(t *testing.T) {
	a := FingerprintHash()
	b := FingerprintHash()
	if a == "" {
		t.Fatal("fingerprint empty")
	}
	if a != b {
		t.Fatalf("fingerprint not stable: %s != %s", a, b)
	}
}

func TestHostBindingEnforced(t *testing.T) {
	secret := "test-secret"
	now := time.Unix(1700000000, 0)

	// license bound to THIS host -> valid
	bound := Sign(License{
		TenantID: "t1",
		Plan:     PlanPro,
		Expiry:   0,
		Issued:   now.Unix(),
		Host:     FingerprintHash(),
	}, secret)
	if err := Validate(bound, secret, now); err != nil {
		t.Fatalf("expected valid on matching host, got %v", err)
	}

	// license bound to a DIFFERENT host -> ErrHostMismatch (fail-closed)
	wrong := Sign(License{
		TenantID: "t1",
		Plan:     PlanPro,
		Expiry:   0,
		Issued:   now.Unix(),
		Host:     "deadbeefdeadbeefdeadbeefdeadbeef",
	}, secret)
	if err := Validate(wrong, secret, now); err == nil {
		t.Fatal("expected ErrHostMismatch for foreign host")
	} else if !errors.Is(err, ErrHostMismatch) {
		t.Fatalf("expected ErrHostMismatch, got %v", err)
	}

	// host-less license (managed/SaaS) -> unaffected by binding
	unbound := Sign(License{
		TenantID: "t2",
		Plan:     PlanEnterprise,
		Expiry:   0,
		Issued:   now.Unix(),
	}, secret)
	if err := Validate(unbound, secret, now); err != nil {
		t.Fatalf("unbound license should validate, got %v", err)
	}
}

func TestKeyRoundTripWithHost(t *testing.T) {
	secret := "k"
	l := Sign(License{
		TenantID: "tenant-x",
		Plan:     PlanPro,
		Expiry:   1700000000,
		Issued:   1699990000,
		Features: []string{"waf", "cluster"},
		Host:     FingerprintHash(),
	}, secret)
	key := l.Key()
	parsed, err := ParseKey(key, secret)
	if err != nil {
		t.Fatalf("parse failed: %v", err)
	}
	if parsed.Host != l.Host {
		t.Fatalf("host lost in round-trip: %q != %q", parsed.Host, l.Host)
	}
	if parsed.Signature != l.Signature {
		t.Fatal("signature lost in round-trip")
	}
	// tamper: change host segment and re-sign must differ
	if err := Validate(parsed, secret, time.Unix(1699995000, 0)); err != nil {
		t.Fatalf("valid license rejected: %v", err)
	}
}
