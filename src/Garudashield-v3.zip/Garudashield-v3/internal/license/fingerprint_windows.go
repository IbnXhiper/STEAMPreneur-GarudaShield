//go:build windows

package license

import (
	"syscall"
	"unsafe"
)

// regMachineGuid reads HKLM\SOFTWARE\Microsoft\Cryptography\MachineGuid.
func regMachineGuid() string {
	var h syscall.Handle
	key := syscall.StringToUTF16Ptr(`SOFTWARE\Microsoft\Cryptography`)
	if err := syscall.RegOpenKeyEx(syscall.HKEY_LOCAL_MACHINE, key, 0,
		syscall.KEY_READ, &h); err != nil {
		return "no-guid"
	}
	defer syscall.RegCloseKey(h)
	var buf [256]uint16
	dw := uint32(len(buf) * 2)
	sub := syscall.StringToUTF16Ptr("MachineGuid")
	if err := syscall.RegQueryValueEx(h, sub, nil, nil, (*byte)(unsafe.Pointer(&buf[0])), &dw); err != nil {
		return "no-guid"
	}
	return syscall.UTF16ToString(buf[:])
}
