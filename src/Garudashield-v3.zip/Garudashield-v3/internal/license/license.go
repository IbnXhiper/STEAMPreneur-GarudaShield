// Package license implements signed license-key validation for GarudaShield
// commercial deployments (self-hosted + managed tiers).
//
// A license is a JSON payload (tenant id, plan, expiry, features) HMAC-signed
// with a server-side secret (GS_LICENSE_SECRET). The engine validates it at
// boot and on a periodic re-check; an invalid/expired license degrades the
// engine to a read-only / throttled state rather than failing open.
//
// This is deliberately minimal: no phone-home, no DRM cruft. The signature is
// checked locally so air-gapped self-hosted nodes work. Revocation happens by
// shipping a new signed license with an earlier expiry (or the operator flipping
// GS_LICENSE_REQUIRED=false for internal/free use).
package license

import (
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"strconv"
	"strings"
	"time"
)

// Plan identifies a commercial tier.
type Plan string

const (
	PlanFree       Plan = "free"
	PlanPro        Plan = "pro"
	PlanEnterprise Plan = "enterprise"
)

// License is the signed payload.
type License struct {
	TenantID  string   `json:"tid"`            // customer / tenant identifier
	Plan      Plan     `json:"plan"`           // free | pro | enterprise
	Expiry    int64    `json:"exp"`            // unix seconds; 0 = no expiry
	Issued    int64    `json:"iat"`            // unix seconds
	Features  []string `json:"feat"`           // optional capability gates
	Host      string   `json:"host,omitempty"` // one-way host bind (self-host only)
	Signature string   `json:"sig"`            // HMAC over the canonical payload
}

// Claims returns the unsigned, canonical payload string used for signing.
func (l License) canonical() string {
	feat := strings.Join(l.Features, ",")
	host := l.Host
	if host == "" {
		host = "-"
	}
	return strings.Join([]string{l.TenantID, string(l.Plan), strconv.FormatInt(l.Expiry, 10), strconv.FormatInt(l.Issued, 10), feat, host}, "|")
}

// Sign produces a License with Signature set, using the given secret.
func Sign(l License, secret string) License {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(l.canonical()))
	l.Signature = hex.EncodeToString(mac.Sum(nil))
	return l
}

// Key returns the single-string ("<tid>:<plan>:<exp>:<iat>:<feat>:<sig>") encoding
// used to hand a license to a customer (env var / file).
func (l License) Key() string {
	feat := strings.Join(l.Features, ",")
	host := l.Host
	if host == "" {
		host = "-"
	}
	return strings.Join([]string{l.TenantID, string(l.Plan), strconv.FormatInt(l.Expiry, 10), strconv.FormatInt(l.Issued, 10), feat, host, l.Signature}, ":")
}

// ParseKey decodes a license key string back into a License (signature included).
func ParseKey(key, secret string) (License, error) {
	parts := strings.Split(key, ":")
	if len(parts) != 7 {
		return License{}, errors.New("malformed license key")
	}
	exp, err := strconv.ParseInt(parts[2], 10, 64)
	if err != nil {
		return License{}, errors.New("invalid expiry in license key")
	}
	iat, err := strconv.ParseInt(parts[3], 10, 64)
	if err != nil {
		return License{}, errors.New("invalid issued in license key")
	}
	var feats []string
	if parts[4] != "" {
		feats = strings.Split(parts[4], ",")
	}
	host := parts[5]
	if host == "-" {
		host = ""
	}
	l := License{
		TenantID:  parts[0],
		Plan:      Plan(parts[1]),
		Expiry:    exp,
		Issued:    iat,
		Features:  feats,
		Host:      host,
		Signature: parts[6],
	}
	if !validSignature(l, secret) {
		return License{}, errors.New("invalid license signature")
	}
	return l, nil
}

func validSignature(l License, secret string) bool {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(l.canonical()))
	expected := hex.EncodeToString(mac.Sum(nil))
	return hmac.Equal([]byte(expected), []byte(l.Signature))
}

// ErrHostMismatch is returned when a license bound to one host is used on another.
var ErrHostMismatch = errors.New("license host mismatch")

// Validate checks signature + expiry + optional host binding. now is injectable
// for testing. When l.Host is non-empty it must equal HostFingerprint() of the
// current machine, otherwise ErrHostMismatch is returned (fail-closed).
func Validate(l License, secret string, now time.Time) error {
	if !validSignature(l, secret) {
		return errors.New("invalid license signature")
	}
	if l.Expiry != 0 && now.Unix() > l.Expiry {
		return errors.New("license expired")
	}
	if l.Host != "" && l.Host != FingerprintHash() {
		return ErrHostMismatch
	}
	return nil
}

// HasFeature reports whether a feature gate is present.
func (l License) HasFeature(f string) bool {
	for _, x := range l.Features {
		if x == f {
			return true
		}
	}
	return false
}

// Marshal round-trips a license to JSON (used for the customer portal API).
func (l License) Marshal() ([]byte, error) { return json.Marshal(l) }
