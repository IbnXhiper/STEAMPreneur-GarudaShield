//go:build !windows

package license

// regMachineGuid is Windows-only; non-Windows hosts use /etc/machine-id.
func regMachineGuid() string {
	return "no-guid"
}
