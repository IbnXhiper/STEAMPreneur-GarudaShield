// Package harden provides HTTP hardening middleware for the GarudaShield edge
// and admin API: security response headers, CSRF protection for state-changing
// requests, and strict content-type enforcement on JSON APIs.
//
// Defense-in-depth, applied at the server boundary so every route inherits it
// without per-handler boilerplate.
package harden

import (
	"net/http"
	"strings"
)

// Headers sets the baseline security response headers on every response.
// - nosniff: stops MIME confusion / reflected-XSS via content-type guessing
// - frame-deny: clickjacking protection (admin API is not embeddable)
// - no-referrer: no leak of origin URLs to upstreams
// - HSTS only added by the TLS terminator (caddy); engine stays header-clean on plaintext
func Headers(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		h := w.Header()
		h.Set("X-Content-Type-Options", "nosniff")
		h.Set("X-Frame-Options", "DENY")
		h.Set("Referrer-Policy", "no-referrer")
		h.Set("X-GarudaShield", "v3")
		// Block all but a tight set of origins for scripts/styles; object-src
		// none stops flash/plugin injection; frame-ancestors none = no embedding.
		// https://fonts.googleapis.com (css) and https://fonts.gstatic.com (woff2)
		// are the only third-party origins the dashboard loads — the Plus Jakarta
		// Sans brand font — so they get exactly the two directives they need.
		h.Set("Content-Security-Policy",
			"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; object-src 'none'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'")
		next.ServeHTTP(w, r)
	})
}

// CSRF protects mutating admin endpoints (POST/PUT/DELETE/PATCH) by requiring a
// matching Origin/Referer or a valid X-CSRF-Token. Read-only methods and the
// API key path (machine-to-machine) are exempt: a browser form-post from an
// attacker site cannot carry the admin key, so a keyed request is not CSRF-able.
func CSRF(allowedHosts []string) func(http.Handler) http.Handler {
	hostSet := map[string]bool{}
	for _, h := range allowedHosts {
		hostSet[strings.ToLower(h)] = true
	}
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Method == http.MethodGet || r.Method == http.MethodHead || r.Method == http.MethodOptions {
				next.ServeHTTP(w, r)
				return
			}
			// Machine-to-machine / API-key authenticated: exempt from CSRF.
			// The admin key is never auto-attached by a browser, so an
			// attacker-origin POST cannot satisfy this and CSRF is moot.
			if r.Header.Get("x-gs-key") != "" || strings.HasPrefix(r.Header.Get("Authorization"), "Bearer ") {
				next.ServeHTTP(w, r)
				return
			}
			origin := r.Header.Get("Origin")
			referer := r.Header.Get("Referer")
			if origin == "" && referer == "" {
				// No cross-site context: same-origin form posts include Referer;
				// a missing both on a mutation is suspicious from a browser.
				http.Error(w, "csrf: missing origin/referer", http.StatusForbidden)
				return
			}
			if !sameOrigin(r, origin, referer, hostSet) {
				http.Error(w, "csrf: cross-origin mutation denied", http.StatusForbidden)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}

func sameOrigin(r *http.Request, origin, referer string, hostSet map[string]bool) bool {
	check := origin
	if check == "" {
		check = referer
	}
	// Strip scheme:// and path, compare host.
	host := check
	if i := strings.Index(host, "://"); i >= 0 {
		host = host[i+3:]
	}
	if i := strings.Index(host, "/"); i >= 0 {
		host = host[:i]
	}
	// Allow if it matches a configured host, or the request's own Host
	// (covers dev where allowedHosts is empty).
	if hostSet[strings.ToLower(host)] {
		return true
	}
	return strings.EqualFold(host, r.Host)
}
