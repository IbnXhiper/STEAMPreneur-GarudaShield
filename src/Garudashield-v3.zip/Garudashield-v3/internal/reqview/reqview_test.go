package reqview

import (
	"crypto/tls"
	"net/http"
	"testing"
)

func TestNewSplitsPathAndURL(t *testing.T) {
	r, _ := http.NewRequest(http.MethodGet, "/search?q=hello", nil)
	r.Host = "EXAMPLE.com"
	v := New(r, nil)
	if v.Path != "/search" {
		t.Errorf("Path = %q, want /search", v.Path)
	}
	if v.URL != "/search?q=hello" {
		t.Errorf("URL = %q", v.URL)
	}
	if v.HostLower() != "example.com" {
		t.Errorf("HostLower = %q", v.HostLower())
	}
}

func TestNewCapturesTLSAndBody(t *testing.T) {
	r, _ := http.NewRequest(http.MethodPost, "/x", nil)
	r.TLS = &tls.ConnectionState{}
	v := New(r, []byte("payload"))
	if !v.HasTLS {
		t.Error("HasTLS should be true when r.TLS != nil")
	}
	if v.WireBytes() <= 0 {
		t.Error("WireBytes should count body + headers")
	}
}
