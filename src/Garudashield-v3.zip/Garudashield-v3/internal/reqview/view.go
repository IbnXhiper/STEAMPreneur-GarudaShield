// Package reqview defines the normalized request view passed through the
// defense pipeline, decoupling defense packages from net/http specifics.
package reqview

import (
	"net/http"
	"strings"
)

// View is the normalized request inspected by all defense layers.
type View struct {
	Method     string
	URL        string // origin-form, e.g. "/path?x=1"
	Path       string // URL path portion (before '?')
	Proto      string // e.g. "1.1" (without "HTTP/" prefix)
	Header     http.Header
	Body       []byte // already capped by the reader
	RemoteAddr string
	Host       string // Host header / authority (lowercased on read)
	HasTLS     bool   // request arrived over TLS
	LocalPort  int    // server-side port (for Layer-4 port-scan context)
}

// New builds a View from an incoming request and its (capped) body.
func New(r *http.Request, body []byte) *View {
	v := &View{
		Method:     r.Method,
		URL:        r.URL.RequestURI(),
		Proto:      r.Proto,
		Header:     r.Header,
		Body:       body,
		RemoteAddr: r.RemoteAddr,
		Host:       r.Host,
		HasTLS:     r.TLS != nil,
	}
	if i := strings.IndexByte(v.URL, '?'); i >= 0 {
		v.Path = v.URL[:i]
	} else {
		v.Path = v.URL
	}
	return v
}

// WireBytes estimates the on-the-wire size of the request so ingress volume
// reflects real traffic, not just body length. Most floods are header-heavy
// GET requests with empty bodies, so counting only Body would report ~0.
// This approximates: request line + Host + each header ("Name: value\r\n") + body.
func (v *View) WireBytes() int64 {
	// request line: "METHOD URL HTTP/x.y\r\n"
	n := len(v.Method) + 1 + len(v.URL) + 1 + len("HTTP/") + len(v.Proto) + 2
	n += len("Host: ") + len(v.Host) + 2
	for name, values := range v.Header {
		for _, val := range values {
			n += len(name) + 2 + len(val) + 2 // "Name: value\r\n"
		}
	}
	n += 2 // blank line terminating headers
	n += len(v.Body)
	return int64(n)
}

// Get returns a header lower-cased lookup (http.Header keys are canonical).
func (v *View) Get(name string) string { return v.Header.Get(name) }

// HostLower returns the Host header lowercased, for host-allowlist checks.
func (v *View) HostLower() string { return strings.ToLower(v.Host) }

// HeaderValues concatenates all header values space-separated (≤2048 bytes),
// mirroring v2 _headerValues for WAF inspection input.
func (v *View) HeaderValues() string {
	var b strings.Builder
	for _, values := range v.Header {
		for _, val := range values {
			b.WriteString(val)
			b.WriteByte(' ')
		}
	}
	out := b.String()
	if len(out) > 2048 {
		out = out[:2048]
	}
	return out
}
