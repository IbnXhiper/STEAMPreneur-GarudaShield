// Package cluster provides multi-node coordination for GarudaShield. When a
// shared Redis backend (config.Cluster.Redis) is enabled, PeerSync broadcasts
// blocklist mutations over a Redis Pub/Sub channel so peer nodes can warm
// their local L1 caches, keeping the edge consistent without polling.
//
// Topology is configuration-driven: config.Cluster.Nodes lists the sync nodes
// that are ACTIVE. The baseline is a single node (the engine itself) and every
// peer is optional by default, so a downed second node degrades the reported
// status without ever breaking protection. Growing back to 2 or 3+ nodes is a
// config change, never a code change.
package cluster

import (
	"context"
	"encoding/json"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/statestore"
	"github.com/redis/go-redis/v9"
)

const syncChannel = "garuda:sync"

// Reconnect backoff bounds for the sync subscription.
const (
	minBackoff = 1 * time.Second
	maxBackoff = 30 * time.Second
)

type syncMsg struct {
	Node string `json:"node"`
	Op   string `json:"op"`
	IP   string `json:"ip"`
	Rec  string `json:"rec"`
	TTL  int64  `json:"ttl"`
}

// PeerSync broadcasts and applies blocklist changes across nodes, and tracks
// which configured nodes are actually online via presence heartbeats.
type PeerSync struct {
	store    statestore.StateStore
	nodeID   string
	topology config.Cluster
	cfg      config.RedisConfig

	// rdb is created in Start before any goroutine exists, so it is safe to
	// read afterwards. It is deliberately never set back to nil: a closed
	// client reports errors instead of panicking on a nil dereference.
	rdb redis.UniversalClient

	// subMu guards the live subscription and the supervisor cancel func so
	// Stop never races with a resubscribe.
	subMu      sync.Mutex
	sub        *redis.PubSub
	rootCancel context.CancelFunc

	// subscribed is 1 while a live subscription is attached to the bus.
	subscribed atomic.Int32
	// reconnects counts reattach attempts after a dropped channel.
	reconnects atomic.Int64
	// lastErr holds the most recent transport error for operator display.
	lastErr atomic.Value // string

	// mu guards the sync activity counters below.
	mu         sync.Mutex
	lastSent   int64 // last broadcast we emitted
	lastSync   int64 // last peer mutation we applied
	lastSeen   int64 // last presence write by this node
	appliedOps int64
}

// New constructs a PeerSync from the full cluster config. It is inert unless
// Redis is configured, so a single-node deployment pays one bool check per
// broadcast and nothing else.
func New(store statestore.StateStore, cc config.Cluster) *PeerSync {
	id := cc.NodeID
	if id == "" {
		id = "node-1"
	}
	return &PeerSync{store: store, nodeID: id, topology: cc, cfg: cc.Redis}
}

// Enabled reports whether cross-node sync is possible (Redis configured,
// direct or Sentinel mode).
func (p *PeerSync) Enabled() bool {
	return p.cfg.Enabled && (p.cfg.Address != "" || len(p.cfg.Sentinels) > 0)
}

// Start dials the state layer and hands the sync subscription to a supervisor
// goroutine. No-op when Redis is disabled: a single-node engine does not need
// a bus, and must never block boot waiting for one.
func (p *PeerSync) Start() {
	if !p.Enabled() {
		return
	}
	p.rdb = statestore.Dial(p.cfg)
	ctx, cancel := context.WithCancel(context.Background())
	p.subMu.Lock()
	p.rootCancel = cancel
	p.subMu.Unlock()
	go p.supervise(ctx)
	go p.heartbeatLoop(ctx)
}

// heartbeatLoop refreshes this node's presence key on the configured interval
// (default 10s). Peers flip to offline after three missed heartbeats, which is
// what makes a downed node visible instead of silently trusted.
func (p *PeerSync) heartbeatLoop(ctx context.Context) {
	t := time.NewTicker(heartbeatInterval(p.topology))
	defer t.Stop()
	for {
		select {
		case <-ctx.Done():
			return
		case <-t.C:
			p.heartbeat()
		}
	}
}

// supervise owns the subscription lifecycle: attach, pump messages, and
// reattach with capped backoff whenever the channel drops. Without this a
// Redis blip left the node permanently deaf until process restart.
func (p *PeerSync) supervise(root context.Context) {
	backoff := minBackoff
	for {
		if root.Err() != nil {
			return
		}
		sub, err := p.attach(root)
		if err != nil {
			// Bus unavailable: keep retrying quietly instead of erroring out.
			p.setErr(err.Error())
			p.reconnects.Add(1)
			if !sleepCtx(root, backoff) {
				return
			}
			backoff = nextBackoff(backoff)
			continue
		}
		p.setErr("")
		p.subscribed.Store(1)
		p.heartbeat()

		p.pump(root, sub)

		p.subscribed.Store(0)
		p.subMu.Lock()
		if p.sub == sub {
			p.sub = nil
		}
		p.subMu.Unlock()
		_ = sub.Close()
		if root.Err() != nil {
			return // shutting down
		}
		p.reconnects.Add(1)
		if !sleepCtx(root, backoff) {
			return
		}
		backoff = nextBackoff(backoff)
	}
}

// attach subscribes and waits for the Pub/Sub confirmation so a "subscribed"
// state really means the bus acknowledged us.
func (p *PeerSync) attach(root context.Context) (*redis.PubSub, error) {
	sub := p.rdb.Subscribe(root, syncChannel)
	if _, err := sub.Receive(root); err != nil {
		_ = sub.Close()
		return nil, err
	}
	p.subMu.Lock()
	p.sub = sub
	p.subMu.Unlock()
	return sub, nil
}

// pump applies inbound messages until the channel closes or we shut down.
func (p *PeerSync) pump(root context.Context, sub *redis.PubSub) {
	ch := sub.Channel()
	for {
		select {
		case <-root.Done():
			return
		case msg, ok := <-ch:
			if !ok {
				return
			}
			p.apply(msg.Payload)
		}
	}
}

func nextBackoff(cur time.Duration) time.Duration {
	next := cur * 2
	if next > maxBackoff {
		return maxBackoff
	}
	return next
}

// sleepCtx waits for d or ctx cancellation; false means cancelled.
func sleepCtx(ctx context.Context, d time.Duration) bool {
	t := time.NewTimer(d)
	defer t.Stop()
	select {
	case <-ctx.Done():
		return false
	case <-t.C:
		return true
	}
}

func (p *PeerSync) setErr(s string) { p.lastErr.Store(s) }

func (p *PeerSync) lastError() string {
	if v, ok := p.lastErr.Load().(string); ok {
		return v
	}
	return ""
}

func (p *PeerSync) apply(payload string) {
	var m syncMsg
	if err := json.Unmarshal([]byte(payload), &m); err != nil {
		return
	}
	if m.Node == p.nodeID {
		return // ignore our own broadcasts
	}
	key := "block:" + m.IP
	ctx := context.Background()
	switch m.Op {
	case "block":
		p.store.Set(ctx, key, m.Rec, m.TTL)
	case "unblock":
		p.store.Delete(ctx, key)
	case "wl-add":
		// Whitelist mutations keep L2 consistent; each node's Shield
		// rehydrates its L1 map from the store (loadWhitelistFromStore
		// runs at boot, and IsWhitelisted checks the shared store via
		// the local map refreshed below).
		p.store.Set(ctx, "wl:"+m.IP, "1", 0)
	case "wl-del":
		p.store.Delete(ctx, "wl:"+m.IP)
	case "presence":
		// A peer's heartbeat is recorded in the shared store so the whole
		// topology can be evaluated from either side of the bus.
		if _, ok := presenceTime(m.Rec); ok {
			p.store.Set(ctx, presenceKey(m.Node), m.Rec, presenceTTL(p.topology).Milliseconds())
		}
	default:
		return
	}
	p.mu.Lock()
	p.lastSync = time.Now().UnixMilli()
	p.appliedOps++
	p.mu.Unlock()
}

// Broadcast publishes a blocklist mutation to peer nodes. Safe to call from
// any goroutine; no-op when sync is disabled.
func (p *PeerSync) Broadcast(op, ip, rec string, ttlMs int64) {
	if !p.Enabled() || p.rdb == nil {
		return
	}
	m := syncMsg{Node: p.nodeID, Op: op, IP: ip, Rec: rec, TTL: ttlMs}
	b, err := json.Marshal(m)
	if err != nil {
		return
	}
	ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
	defer cancel()
	if err := p.rdb.Publish(ctx, syncChannel, string(b)).Err(); err != nil {
		p.setErr(err.Error())
		return
	}
	p.mu.Lock()
	p.lastSent = time.Now().UnixMilli()
	p.mu.Unlock()
}

// Stop tears down the subscription and client. Safe to call when never started.
func (p *PeerSync) Stop() {
	p.subMu.Lock()
	sub, cancel := p.sub, p.rootCancel
	p.sub, p.rootCancel = nil, nil
	p.subMu.Unlock()
	if cancel != nil {
		cancel()
	}
	if sub != nil {
		_ = sub.Close()
	}
	p.subscribed.Store(0)
	if p.rdb != nil {
		_ = p.rdb.Close()
	}
}

// Status reports cluster sync state for the admin API. The first three keys
// are the original v2-compatible contract (enabled/nodeId/connected); the rest
// is additive so older dashboards keep working.
func (p *PeerSync) Status() map[string]any {
	nodes := p.Nodes()
	online, expected, reqOff := nodeCounts(nodes)
	connected := false
	if p.Enabled() && p.rdb != nil {
		// Bounded probe: the admin API must answer even when the bus is a black
		// hole, otherwise the dashboard tab would hang instead of reporting it.
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		connected = p.rdb.Ping(ctx).Err() == nil
		cancel()
	}

	p.mu.Lock()
	lastSent, lastSync, lastSeen, applied := p.lastSent, p.lastSync, p.lastSeen, p.appliedOps
	p.mu.Unlock()

	subscribed := p.subscribed.Load() == 1
	state := "online"
	switch {
	case !p.Enabled():
		// Bus off: this node is healthy on its own, single-node mode.
	case !connected || !subscribed || reqOff > 0:
		state = "degraded"
	case online < expected:
		state = "partial"
	}

	mode := "single"
	if expected > 1 {
		mode = "cluster"
	}
	return map[string]any{
		// v2-compatible core fields.
		"enabled":   p.Enabled(),
		"nodeId":    p.nodeID,
		"connected": connected,
		// Node topology.
		"mode":            mode,
		"role":            p.topology.Role,
		"site":            p.topology.Site,
		"expectedNodes":   expected,
		"onlineNodes":     online,
		"requiredOffline": reqOff,
		"state":           state,
		"degraded":        degraded(nodes) || (p.Enabled() && !connected),
		// Sync engine activity.
		"subscribed":  subscribed,
		"reconnects":  p.reconnects.Load(),
		"heartbeatMs": p.topology.HeartbeatMs,
		"lastSentMs":  lastSent,
		"lastSyncMs":  lastSync,
		"lastSeenMs":  lastSeen,
		"appliedOps":  applied,
		"lastError":   p.lastError(),
		"nodes":       nodes,
	}
}
