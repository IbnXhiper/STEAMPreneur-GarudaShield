package cluster

import (
	"context"
	"encoding/json"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Node state values reported to the dashboard. Kept as plain strings so the
// admin API contract is stable and easy to consume from the web app.
const (
	NodeOnline  = "online"  // node is up and its presence key is fresh
	NodeOffline = "offline" // node is known but its presence key expired
	NodeUnknown = "unknown" // node state cannot be observed (sync disabled)
)

// NodeStatus is the per-node view returned by Status().
type NodeStatus struct {
	ID       string `json:"id"`
	Address  string `json:"address,omitempty"`
	Role     string `json:"role,omitempty"`
	Site     string `json:"site,omitempty"`
	Required bool   `json:"required"`
	Self     bool   `json:"self"`
	State    string `json:"state"`
	// AgeMs is how long ago the node was last seen. 0 for self (always fresh)
	// or when the state is unknown.
	AgeMs int64 `json:"ageMs"`
	// Note explains a non-healthy state in operator language.
	Note string `json:"note,omitempty"`
}

// presenceKey is the L2 key each node refreshes on its heartbeat. Presence is
// stored in the shared state store (not in local memory) so every node can
// evaluate the whole topology without any peer-to-peer connection.
func presenceKey(nodeID string) string { return "node:" + nodeID + ":seen" }

// heartbeatInterval resolves the configured heartbeat period, defaulting to 10s
// and never dropping below 1s (a too-small period would hammer Redis).
func heartbeatInterval(cc config.Cluster) time.Duration {
	ms := cc.HeartbeatMs
	if ms <= 0 {
		ms = 10000
	}
	if ms < 1000 {
		ms = 1000
	}
	return time.Duration(ms) * time.Millisecond
}

// presenceTTL is how long a node stays "online" without a heartbeat. Three
// missed heartbeats flip the node to offline, which is what makes a downed
// peer visible instead of silently trusted.
func presenceTTL(cc config.Cluster) time.Duration {
	return 3 * heartbeatInterval(cc)
}

// heartbeat writes this node's presence key and announces it on the sync bus.
// Failures are non-fatal: a node that cannot reach Redis keeps serving (local
// mode), it just reports itself as not connected.
func (p *PeerSync) heartbeat() {
	if !p.Enabled() || p.store == nil {
		return
	}
	seen := time.Now().UnixMilli()
	p.store.Set(context.Background(), presenceKey(p.nodeID), presenceBytes(seen), presenceTTL(p.topology).Milliseconds())
	p.Broadcast("presence", "", presenceBytes(seen), 0)
	p.mu.Lock()
	p.lastSeen = seen
	p.mu.Unlock()
}

// presenceBytes is the tiny payload stored under a presence key: the unix
// millisecond timestamp the node last checked in.
func presenceBytes(seen int64) string {
	b, err := json.Marshal(map[string]int64{"ts": seen})
	if err != nil {
		return `{"ts":0}`
	}
	return string(b)
}

func presenceTime(raw string) (int64, bool) {
	var m map[string]int64
	if err := json.Unmarshal([]byte(raw), &m); err != nil {
		return 0, false
	}
	return m["ts"], true
}

// Nodes evaluates the configured topology against the shared state store. The
// local node is always reported online (the engine is answering the request),
// peers are online only while their presence key is fresh, and peers are
// "unknown" when cross-node sync is disabled because their state simply
// cannot be observed from here.
func (p *PeerSync) Nodes() []NodeStatus {
	topo := p.topology.Topology()
	now := time.Now().UnixMilli()
	obs := p.Enabled() && p.store != nil

	out := make([]NodeStatus, 0, len(topo))
	for _, n := range topo {
		st := NodeStatus{
			ID:       n.ID,
			Address:  n.Address,
			Role:     n.Role,
			Site:     n.Site,
			Required: n.Required,
			Self:     n.ID == p.nodeID,
		}
		switch {
		case st.Self:
			st.State = NodeOnline
			st.Note = selfNote(p)
		case !obs:
			st.State = NodeUnknown
			st.Note = "cross-node sync disabled; peer state not observable"
		default:
			raw, _ := p.store.Get(context.Background(), presenceKey(n.ID))
			seen, valid := presenceTime(raw)
			if !valid {
				// Presence key missing or corrupt: treat as never seen. Age stays 0
				// so the dashboard shows "never" instead of a bogus timestamp.
				st.State = NodeOffline
				st.Note = offlineNote(n.Required)
				break
			}
			st.AgeMs = now - seen
			if now-seen <= presenceTTL(p.topology).Milliseconds() {
				st.State = NodeOnline
				break
			}
			st.State = NodeOffline
			st.Note = offlineNote(n.Required)
		}
		out = append(out, st)
	}
	return out
}

// selfNote keeps the local node's status honest: the node itself is up (it is
// serving this very request), but whether its sync bus and state layer are
// healthy is reported separately so operators can tell the two apart.
func selfNote(p *PeerSync) string {
	switch {
	case !p.Enabled():
		return "local node serving; sync bus disabled (single-node mode)"
	case p.store != nil && !p.store.Healthy():
		return "local node serving; L2 state layer unreachable"
	case p.subscribed.Load() == 0:
		return "local node serving; sync subscription not active yet"
	default:
		return "local node serving; sync bus active"
	}
}

func offlineNote(required bool) string {
	if required {
		return "required node offline"
	}
	return "optional node unavailable"
}

// nodeCounts summarises the topology for the dashboard headline
// ("Sync Nodes 1 / 1 Online").
func nodeCounts(nodes []NodeStatus) (online, expected, requiredOffline int) {
	expected = len(nodes)
	for _, n := range nodes {
		if n.State == NodeOnline {
			online++
		}
		if n.Required && !n.Self && n.State != NodeOnline {
			requiredOffline++
		}
	}
	if expected < 1 {
		expected = 1
	}
	return online, expected, requiredOffline
}

// degraded reports whether a REQUIRED node is missing. Optional peers never
// mark the cluster degraded -- that is the whole point of running one node
// while the second VPS is down.
func degraded(nodes []NodeStatus) bool {
	_, _, reqOff := nodeCounts(nodes)
	return reqOff > 0
}

// Label is a compact human summary of the sync topology, used in boot logs.
func Label(cc config.Cluster) string {
	topo := cc.Topology()
	roles := make([]string, 0, len(topo))
	for _, n := range topo {
		if n.Role != "" && n.Role != "all" {
			roles = append(roles, n.ID+"="+n.Role)
		}
	}
	mode := "single-node"
	if len(topo) > 1 {
		mode = "multi-node"
	}
	out := mode + " nodes=" + strconv.Itoa(len(topo))
	if len(roles) > 0 {
		out += " roles=[" + strings.Join(roles, ",") + "]"
	}
	return out
}
