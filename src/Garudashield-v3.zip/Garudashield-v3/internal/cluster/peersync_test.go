package cluster

import (
	"context"
	"encoding/json"
	"os"
	"strconv"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/statestore"
)

func envOr(key, def string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return def
}

func envIntOr(key string, def int) int {
	v := os.Getenv(key)
	if v == "" {
		return def
	}
	n, err := strconv.Atoi(v)
	if err != nil {
		return def
	}
	return n
}

func TestApplyPropagatesBlock(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	p := &PeerSync{store: store, nodeID: "self", cfg: config.RedisConfig{Enabled: false}}

	// a peer broadcasts a block for 1.2.3.4
	msg, _ := json.Marshal(syncMsg{Node: "peer", Op: "block", IP: "1.2.3.4", Rec: `{"e":9999999999999,"r":"x","s":50}`, TTL: 60000})
	p.apply(string(msg))

	v, ok := store.Get(context.Background(), "block:1.2.3.4")
	if !ok || v != `{"e":9999999999999,"r":"x","s":50}` {
		t.Fatalf("peer block not applied: %q,%v", v, ok)
	}

	// unblock from peer
	msg2, _ := json.Marshal(syncMsg{Node: "peer", Op: "unblock", IP: "1.2.3.4"})
	p.apply(string(msg2))
	if _, ok := store.Get(context.Background(), "block:1.2.3.4"); ok {
		t.Fatalf("peer unblock not applied")
	}
}

func TestApplyIgnoresSelf(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	p := &PeerSync{store: store, nodeID: "self", cfg: config.RedisConfig{Enabled: false}}
	msg, _ := json.Marshal(syncMsg{Node: "self", Op: "block", IP: "5.5.5.5", Rec: "{}", TTL: 0})
	p.apply(string(msg))
	if _, ok := store.Get(context.Background(), "block:5.5.5.5"); ok {
		t.Fatalf("own broadcast should be ignored")
	}
}

// TestSingleNodeStatus: the baseline deployment has exactly one active sync
// node and no bus. It must report 1 / 1 online, not an error and not 1 / 2.
func TestSingleNodeStatus(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	defer store.Close()
	cc := config.Default().Cluster
	p := New(store, cc)
	if p.Enabled() {
		t.Fatalf("peer sync should be inert without redis")
	}
	// Inert objects are still safe to drive.
	p.Start()
	p.Broadcast("block", "10.0.0.1", "{}", 1000)
	p.heartbeat()
	p.Stop()

	st := p.Status()
	if st["enabled"] != false {
		t.Fatalf("enabled should be false: %v", st)
	}
	if st["expectedNodes"] != 1 || st["onlineNodes"] != 1 {
		t.Fatalf("single node should report 1/1 online: %v", st)
	}
	if st["mode"] != "single" || st["state"] != "online" {
		t.Fatalf("unexpected mode/state: %v", st)
	}
	nodes, _ := st["nodes"].([]NodeStatus)
	if len(nodes) != 1 || !nodes[0].Self || nodes[0].State != NodeOnline {
		t.Fatalf("unexpected node list: %+v", nodes)
	}
}

// TestOptionalPeerOfflineIsNotDegraded: a downed second node must degrade the
// reported state at most, never the engine.
func TestOptionalPeerOfflineIsNotDegraded(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	defer store.Close()
	cc := config.Default().Cluster
	cc.NodeID = "node-1"
	cc.Nodes = []config.Node{
		{ID: "node-1"},
		{ID: "node-2"}, // optional: the VPS is currently down
	}
	p := New(store, cc)

	nodes := p.Nodes()
	if len(nodes) != 2 {
		t.Fatalf("expected 2 configured nodes: %+v", nodes)
	}
	online, expected, reqOff := nodeCounts(nodes)
	if expected != 2 || online != 1 || reqOff != 0 {
		t.Fatalf("unexpected counts online=%d expected=%d required=%d", online, expected, reqOff)
	}
	if degraded(nodes) {
		t.Fatalf("optional offline peer must not mark cluster degraded")
	}
}

// TestRequiredPeerOfflineDegrades: an explicitly required node DOES escalate
// the reported status (but still never errors).
func TestRequiredPeerOfflineDegrades(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	defer store.Close()
	cc := config.Default().Cluster
	cc.NodeID = "node-1"
	cc.Nodes = []config.Node{{ID: "node-1"}, {ID: "node-2", Required: true}}
	p := New(store, cc)

	if !degraded(p.Nodes()) {
		t.Fatalf("required offline peer should mark cluster degraded")
	}
	if got := p.Status()["requiredOffline"]; got != 1 {
		t.Fatalf("requiredOffline should be 1: %v", got)
	}
}

// TestPresenceMarksPeerOnline: a fresh presence key from a peer flips it online.
func TestPresenceMarksPeerOnline(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	defer store.Close()
	cc := config.Default().Cluster
	cc.NodeID = "node-1"
	cc.Nodes = []config.Node{{ID: "node-1"}, {ID: "node-2"}}
	p := New(store, cc)

	if got := p.Nodes()[1].State; got != NodeUnknown {
		t.Fatalf("peer state without bus should be unknown, got %q", got)
	}

	// Pretend Redis-backed L2: write the peer presence key directly.
	store.Set(context.Background(), presenceKey("node-2"), presenceBytes(time.Now().UnixMilli()), 60000)
	p.cfg.Enabled = true
	p.cfg.Address = "127.0.0.1:6379"
	n := p.Nodes()[1]
	if n.State != NodeOnline {
		t.Fatalf("fresh presence should mark peer online, got %q", n.State)
	}
	if n.AgeMs < 0 {
		t.Fatalf("presence age should not be negative: %d", n.AgeMs)
	}

	// Stale presence -> offline again.
	store.Set(context.Background(), presenceKey("node-2"), presenceBytes(time.Now().Add(-10*time.Minute).UnixMilli()), 60000)
	if got := p.Nodes()[1].State; got != NodeOffline {
		t.Fatalf("stale presence should mark peer offline, got %q", got)
	}
}

// TestPresenceBroadcastIsApplied: peers record each other's heartbeats.
func TestPresenceBroadcastIsApplied(t *testing.T) {
	store := statestore.New(config.RedisConfig{Enabled: false})
	defer store.Close()
	p := &PeerSync{store: store, nodeID: "self", cfg: config.RedisConfig{Enabled: false}}
	msg, _ := json.Marshal(syncMsg{Node: "peer-1", Op: "presence", Rec: presenceBytes(time.Now().UnixMilli())})
	p.apply(string(msg))
	if _, ok := store.Get(context.Background(), presenceKey("peer-1")); !ok {
		t.Fatalf("peer presence not recorded")
	}
}

// TestPeerSyncCrossNode proves two engine nodes sharing a Redis backend stay
// consistent: a block broadcast on node A is applied to node B's local store
// via the Pub/Sub channel. Guarded by GS_TEST_REDIS=1 (needs a live Redis).
//
// GS_TEST_REDIS_ADDR / GS_TEST_REDIS_PASSWORD / GS_TEST_REDIS_DB point the test
// at a Redis instance that is not the local one (CI, or verifying on the real
// deployment host). Without them it uses 127.0.0.1:6379.
func TestPeerSyncCrossNode(t *testing.T) {
	addr := envOr("GS_TEST_REDIS_ADDR", "127.0.0.1:6379")
	rcfg := config.RedisConfig{
		Enabled:   true,
		Address:   addr,
		Password:  os.Getenv("GS_TEST_REDIS_PASSWORD"),
		DB:        envIntOr("GS_TEST_REDIS_DB", 0),
		KeyPrefix: "gsynctest:",
	}
	probe := statestore.New(rcfg)
	if probe.Mode() != "redis" {
		if os.Getenv("GS_TEST_REDIS") != "1" {
			t.Skip("redis not reachable; skipping cross-node sync test")
		}
		t.Fatalf("redis configured but unreachable: mode=%s", probe.Mode())
	}
	probe.Close()

	storeA := statestore.New(rcfg)
	storeB := statestore.New(rcfg)
	defer storeA.Close()
	defer storeB.Close()

	cfgA := config.Default().Cluster
	cfgA.NodeID = "node-A"
	cfgA.Redis = rcfg
	cfgA.HeartbeatMs = 1000
	// Both nodes must be part of the configured topology, otherwise each node
	// would only ever evaluate itself.
	cfgA.Nodes = []config.Node{{ID: "node-A"}, {ID: "node-B", Address: "127.0.0.1:8080"}}
	cfgB := cfgA
	cfgB.NodeID = "node-B"

	nodeA := New(storeA, cfgA)
	nodeB := New(storeB, cfgB)
	nodeA.Start()
	nodeB.Start()
	defer nodeA.Stop()
	defer nodeB.Stop()

	// ensure subscriptions are ready before publishing
	time.Sleep(500 * time.Millisecond)

	// Each node sees the other online via presence heartbeats.
	if st := nodeA.Status()["onlineNodes"]; st != 2 {
		t.Fatalf("node A should see 2 nodes online, got %v (%v)", st, nodeA.Status())
	}

	// Node A blocks an IP; node B must learn it.
	nodeA.Broadcast("block", "203.0.113.9", `{"e":9999999999999,"r":"xsync","s":50}`, 60000)

	deadline := time.Now().Add(3 * time.Second)
	for {
		if v, ok := storeB.Get(context.Background(), "block:203.0.113.9"); ok && v != "" {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("node B did not receive block broadcast from node A")
		}
		time.Sleep(50 * time.Millisecond)
	}

	// Node A unblocks; node B must drop it.
	nodeA.Broadcast("unblock", "203.0.113.9", "", 0)
	deadline = time.Now().Add(3 * time.Second)
	for {
		if _, ok := storeB.Get(context.Background(), "block:203.0.113.9"); !ok {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("node B did not receive unblock broadcast from node A")
		}
		time.Sleep(50 * time.Millisecond)
	}
}
