// Package totp implements RFC 6238 time-based one-time passwords (and RFC 4226
// HOTP at its core) using only the standard library. No external dependency is
// pulled in for second-factor auth, matching the repo's "stdlib-first" stance.
//
// Security notes:
//   - SHA-1, 6 digits, 30-second step (the interoperable default every
//     authenticator app — Google Authenticator, Authy, 1Password — expects).
//   - Validate accepts a +/-1 step skew so a code typed just before/after the
//     boundary is not rejected.
//   - Comparison is constant-time to avoid a timing oracle on the digit string.
package totp

import (
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha1"
	"crypto/subtle"
	"encoding/base32"
	"encoding/binary"
	"fmt"
	"net/url"
	"strings"
	"time"
)

const (
	step    = 30 // seconds per code
	digits  = 6
	skew    = 1 // accept current step +/- 1
	secretB = 20
)

var b32 = base32.StdEncoding.WithPadding(base32.NoPadding)

// GenerateSecret returns a fresh base32-encoded shared secret (160-bit).
func GenerateSecret() (string, error) {
	b := make([]byte, secretB)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return b32.EncodeToString(b), nil
}

// Code returns the 6-digit TOTP for the secret at time t.
func Code(secret string, t time.Time) (string, error) {
	key, err := decode(secret)
	if err != nil {
		return "", err
	}
	counter := uint64(t.Unix() / step)
	return hotp(key, counter), nil
}

// Validate reports whether code is a valid TOTP for secret within the allowed
// skew window. It is constant-time per candidate code.
func Validate(secret, code string, t time.Time) bool {
	code = strings.TrimSpace(code)
	if len(code) != digits {
		return false
	}
	key, err := decode(secret)
	if err != nil {
		return false
	}
	base := t.Unix() / step
	for d := int64(-skew); d <= skew; d++ {
		want := hotp(key, uint64(base+d))
		if subtle.ConstantTimeCompare([]byte(want), []byte(code)) == 1 {
			return true
		}
	}
	return false
}

// ProvisioningURL builds the otpauth:// URI an authenticator app scans.
func ProvisioningURL(issuer, account, secret string) string {
	q := url.Values{}
	q.Set("secret", secret)
	q.Set("issuer", issuer)
	q.Set("algorithm", "SHA1")
	q.Set("digits", fmt.Sprintf("%d", digits))
	q.Set("period", fmt.Sprintf("%d", step))
	return "otpauth://totp/" + url.PathEscape(issuer+":"+account) + "?" + q.Encode()
}

func hotp(key []byte, counter uint64) string {
	var buf [8]byte
	binary.BigEndian.PutUint64(buf[:], counter)
	mac := hmac.New(sha1.New, key)
	mac.Write(buf[:])
	sum := mac.Sum(nil)
	off := sum[len(sum)-1] & 0x0f
	bin := (uint32(sum[off]&0x7f) << 24) |
		(uint32(sum[off+1]) << 16) |
		(uint32(sum[off+2]) << 8) |
		uint32(sum[off+3])
	mod := bin % 1_000_000
	return fmt.Sprintf("%06d", mod)
}

func decode(secret string) ([]byte, error) {
	s := strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(secret), " ", ""))
	key, err := b32.DecodeString(s)
	if err != nil {
		return nil, fmt.Errorf("totp: invalid secret: %w", err)
	}
	return key, nil
}
