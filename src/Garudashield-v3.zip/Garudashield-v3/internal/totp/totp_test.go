package totp

import (
	"testing"
	"time"
)

// RFC 6238 Appendix B test vectors (SHA-1, secret "12345678901234567890").
// The 8-digit reference values are truncated to 6 digits here.
func TestRFC6238Vectors(t *testing.T) {
	secret := b32.EncodeToString([]byte("12345678901234567890"))
	cases := []struct {
		unix int64
		want string
	}{
		{59, "287082"},
		{1111111109, "081804"},
		{1111111111, "050471"},
		{1234567890, "005924"},
		{2000000000, "279037"},
	}
	for _, c := range cases {
		got, err := Code(secret, time.Unix(c.unix, 0))
		if err != nil {
			t.Fatalf("Code(%d): %v", c.unix, err)
		}
		if got != c.want {
			t.Errorf("T=%d got %s want %s", c.unix, got, c.want)
		}
	}
}

func TestValidateSkewAndReject(t *testing.T) {
	secret, err := GenerateSecret()
	if err != nil {
		t.Fatal(err)
	}
	now := time.Unix(1234567890, 0)
	code, _ := Code(secret, now)
	if !Validate(secret, code, now) {
		t.Fatal("current-step code rejected")
	}
	if !Validate(secret, code, now.Add(29*time.Second)) {
		t.Fatal("code should be valid within the same step")
	}
	// Previous step still accepted (skew=1), two steps back is not.
	prev, _ := Code(secret, now.Add(-30*time.Second))
	if !Validate(secret, prev, now) {
		t.Fatal("previous-step code should be within skew")
	}
	old, _ := Code(secret, now.Add(-90*time.Second))
	if Validate(secret, old, now) {
		t.Fatal("code two steps back must be rejected")
	}
	if Validate(secret, "000000", now) && code != "000000" {
		t.Fatal("garbage code accepted")
	}
	if Validate("!!!notbase32!!!", code, now) {
		t.Fatal("invalid secret accepted")
	}
}

func TestProvisioningURL(t *testing.T) {
	u := ProvisioningURL("GarudaShield", "owner@acme.id", "ABC234")
	if u[:15] != "otpauth://totp/" {
		t.Fatalf("bad scheme: %s", u)
	}
	for _, want := range []string{"secret=ABC234", "issuer=GarudaShield", "digits=6", "period=30"} {
		if !contains(u, want) {
			t.Errorf("missing %q in %s", want, u)
		}
	}
}

func contains(s, sub string) bool {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}
