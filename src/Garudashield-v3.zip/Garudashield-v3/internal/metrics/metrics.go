// Package metrics exposes Prometheus-compatible counters for the edge engine so
// operators can graph DDoS pressure (requests, blocks, challenged, blocked-IP
// count, active conns, bytes) in Grafana. Metrics are process-local; in a
// cluster each node scrapes its own /metrics endpoint.
package metrics

import (
	"net/http"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promhttp"
)

var (
	// RequestsTotal counts evaluated requests by action (pass/block/challenge).
	RequestsTotal = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: "garudashield",
		Name:      "requests_total",
		Help:      "Total requests evaluated by final action.",
	}, []string{"action"})

	// BlocksTotal counts admin/engine IP blocks by reason.
	BlocksTotal = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: "garudashield",
		Name:      "blocks_total",
		Help:      "Total IP blocks issued by reason.",
	}, []string{"reason"})

	// ActiveConns reports current accepted connections (gauge).
	ActiveConns = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: "garudashield",
		Name:      "active_conns",
		Help:      "Currently accepted TCP connections.",
	})

	// BytesIngested counts ingress bytes (bandwidth pressure).
	BytesIngested = prometheus.NewCounter(prometheus.CounterOpts{
		Namespace: "garudashield",
		Name:      "bytes_ingested_total",
		Help:      "Total ingress bytes seen by the edge.",
	})

	// BlocklistSize reports current blocklist entries.
	BlocklistSize = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: "garudashield",
		Name:      "blocklist_size",
		Help:      "Number of IPs currently in the blocklist.",
	})

	// RustWAFRulesActive reports how many rules the Rust matcher actually
	// compiled. When > 0 and != the expected count, patterns were silently
	// skipped (fail-loud signal for operators).
	RustWAFRulesActive = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: "garudashield",
		Name:      "rust_waf_rules_active",
		Help:      "Rules compiled into the Rust WAF matcher (-1 when Rust is off).",
	})

	// QuotaRejected counts edge requests refused because the tenant exceeded
	// its configured daily request budget (business guardrail, not DDoS block).
	QuotaRejected = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: "garudashield",
		Name:      "quota_rejected_total",
		Help:      "Requests refused by per-plan usage quota.",
	}, []string{"plan"})

	// HoneypotHits counts requests blocked by the scanner/exploit path trap.
	HoneypotHits = prometheus.NewCounterVec(prometheus.CounterOpts{
		Namespace: "garudashield",
		Name:      "honeypot_hits_total",
		Help:      "Requests blocked by the honeypot probe-path trap, by pattern.",
	}, []string{"pattern"})

	// FloodMode is 1 while the engine is in flood fast-path mode, else 0.
	FloodMode = prometheus.NewGauge(prometheus.GaugeOpts{
		Namespace: "garudashield",
		Name:      "flood_mode",
		Help:      "1 when the engine is in flood mode, 0 otherwise.",
	})
)

// Registry is the engine's metric registry.
var Registry = prometheus.NewRegistry()

func init() {
	Registry.MustRegister(
		RequestsTotal,
		BlocksTotal,
		ActiveConns,
		BytesIngested,
		BlocklistSize,
		RustWAFRulesActive,
		QuotaRejected,
		HoneypotHits,
		FloodMode,
	)
}

// Handler returns the /metrics HTTP handler (Prometheus text format).
func Handler() http.Handler {
	return promhttp.HandlerFor(Registry, promhttp.HandlerOpts{})
}
