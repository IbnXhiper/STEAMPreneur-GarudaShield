package metrics

import (
	"net/http"
	"net/http/httptest"
	"testing"
)

func TestMetricsEndpoint(t *testing.T) {
	// Exercise the counters so the output is non-empty.
	RequestsTotal.WithLabelValues("pass").Inc()
	BlocksTotal.WithLabelValues("waf").Inc()
	ActiveConns.Set(3)
	BytesIngested.Add(1024)
	BlocklistSize.Set(7)

	req := httptest.NewRequest(http.MethodGet, "/metrics", nil)
	rec := httptest.NewRecorder()
	Handler().ServeHTTP(rec, req)

	if rec.Code != http.StatusOK {
		t.Fatalf("expected 200, got %d", rec.Code)
	}
	body := rec.Body.String()
	for _, want := range []string{
		"garudashield_requests_total",
		"garudashield_blocks_total",
		"garudashield_active_conns",
		"garudashield_bytes_ingested_total",
		"garudashield_blocklist_size",
	} {
		if !contains(body, want) {
			t.Fatalf("metric %q missing from /metrics output", want)
		}
	}
}

func contains(haystack, needle string) bool {
	return len(haystack) >= len(needle) && indexOf(haystack, needle) >= 0
}

func indexOf(s, sub string) int {
	for i := 0; i+len(sub) <= len(s); i++ {
		if s[i:i+len(sub)] == sub {
			return i
		}
	}
	return -1
}
