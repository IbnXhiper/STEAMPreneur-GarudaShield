package quicguard

import (
	"errors"
	"net"
	"testing"
	"time"
)

func TestChargeByteBudget(t *testing.T) {
	g := New(100)
	if !g.take("1.2.3.4", 60) {
		t.Fatal("60B under 100B budget must pass")
	}
	if !g.take("1.2.3.4", 40) {
		t.Fatal("cumulative 100B == budget must pass")
	}
	if g.take("1.2.3.4", 1) {
		t.Fatal("101B must exceed budget (fail-closed)")
	}
	if !g.Blocked("1.2.3.4") {
		t.Fatal("over-budget IP must be blocked")
	}
	if g.take("1.2.3.4", 1) {
		t.Fatal("blocked IP packets must be dropped")
	}
}

func TestIndependentIPs(t *testing.T) {
	g := New(100)
	g.take("1.1.1.1", 100)
	if !g.take("2.2.2.2", 50) {
		t.Fatal("budget is per-IP, not global")
	}
	if g.take("1.1.1.1", 1) {
		t.Fatal("exhausted IP must be denied")
	}
}

func TestDisabledGuard(t *testing.T) {
	g := New(0)
	for i := 0; i < 1000; i++ {
		if !g.take("x", 1<<20) {
			t.Fatal("disabled guard must always pass")
		}
	}
}

func TestBlockExpires(t *testing.T) {
	g := New(100)
	if g.take("1.1.1.1", 200) {
		t.Fatal("200B against 100B budget must be denied")
	}
	if !g.Blocked("1.1.1.1") {
		t.Fatal("over budget must block")
	}
	// Sticky 30s penalty: packets keep dropping even inside a fresh window.
	if g.take("1.1.1.1", 1) {
		t.Fatal("blocked IP must stay denied for blockFor")
	}
	// Expire the penalty: block clears AND budget resets (penalty served).
	g.mu.Lock()
	g.blockedAt["1.1.1.1"] = time.Now().Add(-time.Hour)
	g.mu.Unlock()
	if !g.take("1.1.1.1", 1) {
		t.Fatal("after penalty served, packet must flow")
	}
}

func TestWrapDropsOverBudgetPackets(t *testing.T) {
	g := New(10)
	ua, err := net.ResolveUDPAddr("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	pc, err := net.ListenUDP("udp", ua)
	if err != nil {
		t.Fatal(err)
	}
	defer pc.Close()
	guarded := g.Wrap(pc)

	// Sender: aaaaa (5B) + bbbbb (5B) fill the 10B/s budget; cccc (4B) goes
	// over and must be dropped by the guard.
	sender, err := net.DialUDP("udp", nil, pc.LocalAddr().(*net.UDPAddr))
	if err != nil {
		t.Fatal(err)
	}
	for _, pkt := range []string{"aaaaa", "bbbbb", "cccc"} {
		if _, err := sender.Write([]byte(pkt)); err != nil {
			t.Fatal(err)
		}
	}

	buf := make([]byte, 1500)
	n, _, err := guarded.ReadFrom(buf)
	if err != nil {
		t.Fatal(err)
	}
	if string(buf[:n]) != "aaaaa" {
		t.Fatalf("first packet must pass, got %q", buf[:n])
	}
	n, _, err = guarded.ReadFrom(buf)
	if err != nil {
		t.Fatal(err)
	}
	if string(buf[:n]) != "bbbbb" {
		t.Fatalf("second packet is exactly at budget, must pass, got %q", buf[:n])
	}
	// cccc is over budget: dropped inside the guard. The next read must time
	// out, proving the over-budget packet never surfaces.
	guarded.SetReadDeadline(time.Now().Add(300 * time.Millisecond))
	_, _, err = guarded.ReadFrom(buf)
	var ne net.Error
	if !errors.As(err, &ne) || !ne.Timeout() {
		t.Fatalf("over-budget packet must be silently dropped (want timeout), got: %v", err)
	}
}
