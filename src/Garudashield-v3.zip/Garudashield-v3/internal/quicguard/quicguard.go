// Package quicguard provides UDP packet-level defense for the QUIC/HTTP-3
// listener, mirroring netguard's TCP protections. QUIC has no accept() step a
// net.Listener can wrap, so without a guard a QUIC client can saturate
// bandwidth (and trigger amplification) while netguard never sees the traffic.
//
// Mechanism: a net.PacketConn wrapper that charges every ingress packet to a
// per-client-IP byte budget (1s sliding window). Over budget -> the IP is
// blocked for blockFor and its packets are silently dropped (fail-closed).
package quicguard

import (
	"net"
	"sync"
	"time"
)

// Guard enforces a per-client-IP ingress byte budget on a UDP packet conn.
type Guard struct {
	bytesPerSecPerIP int64 // > 0 required; 0 disables the guard entirely
	blockFor         time.Duration

	mu        sync.Mutex
	bytesAt   map[string]int64
	window    time.Time
	blockedAt map[string]time.Time
}

// New creates a Guard. bytesPerSecPerIP <= 0 means unlimited (guard still
// constructed but passthrough).
func New(bytesPerSecPerIP int64) *Guard {
	return &Guard{
		bytesPerSecPerIP: bytesPerSecPerIP,
		blockFor:         30 * time.Second,
		bytesAt:          make(map[string]int64),
		blockedAt:        make(map[string]time.Time),
		window:           time.Now(),
	}
}

// Wrap returns a guarded PacketConn. When the byte budget is disabled the
// original conn is returned untouched.
func (g *Guard) Wrap(pc net.PacketConn) net.PacketConn {
	if g.bytesPerSecPerIP <= 0 {
		return pc
	}
	return &guardedConn{Guard: g, under: pc}
}

// take admits one packet of n bytes from ip: false when the IP is blocked or
// the packet exceeds the remaining budget (fail-closed: the packet is lost).
func (g *Guard) take(ip string, n int64) bool {
	if g.bytesPerSecPerIP <= 0 {
		return true
	}
	g.mu.Lock()
	defer g.mu.Unlock()
	now := time.Now()
	if now.Sub(g.window) >= time.Second {
		g.window = now
		g.bytesAt = make(map[string]int64)
	}
	if t, ok := g.blockedAt[ip]; ok {
		if now.Sub(t) < g.blockFor {
			return false
		}
		// Penalty served: clear the block and give the IP a fresh budget.
		delete(g.blockedAt, ip)
		g.bytesAt[ip] = 0
	}
	g.bytesAt[ip] += n
	if g.bytesAt[ip] > g.bytesPerSecPerIP {
		g.blockedAt[ip] = now
		return false
	}
	return true
}

// Blocked reports whether ip is currently blocked (over budget recently).
func (g *Guard) Blocked(ip string) bool {
	g.mu.Lock()
	defer g.mu.Unlock()
	t, ok := g.blockedAt[ip]
	return ok && time.Since(t) < g.blockFor
}

type guardedConn struct {
	*Guard
	under net.PacketConn
}

func (c *guardedConn) ReadFrom(p []byte) (int, net.Addr, error) {
	for {
		n, addr, err := c.under.ReadFrom(p)
		if err != nil {
			return n, addr, err
		}
		if c.take(ipFrom(addr), int64(n)) {
			return n, addr, nil
		}
		// Packet dropped (fail-closed); read the next one.
	}
}

func (c *guardedConn) WriteTo(p []byte, addr net.Addr) (int, error) {
	return c.under.WriteTo(p, addr)
}

func (c *guardedConn) Close() error                       { return c.under.Close() }
func (c *guardedConn) LocalAddr() net.Addr                { return c.under.LocalAddr() }
func (c *guardedConn) SetDeadline(t time.Time) error      { return c.under.SetDeadline(t) }
func (c *guardedConn) SetReadDeadline(t time.Time) error  { return c.under.SetReadDeadline(t) }
func (c *guardedConn) SetWriteDeadline(t time.Time) error { return c.under.SetWriteDeadline(t) }

// ipFrom extracts the client IP from a UDP packet address, normalizing
// IPv4-mapped IPv6 the same way netguard does.
func ipFrom(addr net.Addr) string {
	if addr == nil {
		return ""
	}
	host, _, err := net.SplitHostPort(addr.String())
	if err != nil {
		host = addr.String()
	}
	if ip := net.ParseIP(host); ip != nil {
		if v4 := ip.To4(); v4 != nil {
			return v4.String()
		}
	}
	return host
}
