package status

import (
	"testing"
	"time"
)

func TestMonitorBasics(t *testing.T) {
	m := New("3.0.0", "host1")
	m.Register("Shield", nil)
	m.Register("Redis", func() (ComponentStatus, string) {
		return Degraded, "slow"
	})
	m.Start(10 * time.Millisecond)
	defer m.Close()
	m.runChecks() // deterministic: force one pass instead of racing the ticker

	st := m.GetStatus()
	if st.Overall != string(Degraded) {
		t.Fatalf("overall = %q want degraded (Redis checker)", st.Overall)
	}
	if st.UptimeSec < 0 {
		t.Fatalf("uptime negative")
	}
	found := false
	for _, c := range st.Components {
		if c.Name == "Redis" && c.Status == Degraded {
			found = true
		}
	}
	if !found {
		t.Fatalf("redis component not degraded: %+v", st.Components)
	}
	if len(st.Incidents) == 0 {
		t.Fatalf("expected an incident recorded on degradation")
	}
}

func TestMonitorSetTransition(t *testing.T) {
	m := New("3.0.0", "h")
	m.Register("Up", nil)
	m.Set("Up", Down, "boom")
	if len(m.GetStatus().Incidents) == 0 {
		t.Fatalf("expected incident on down transition")
	}
	// no new incident for same status
	m.Set("Up", Down, "boom")
	if len(m.GetStatus().Incidents) != 1 {
		t.Fatalf("expected no duplicate incident for same status")
	}
}
