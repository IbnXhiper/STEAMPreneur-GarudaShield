// Package status implements the 5-component health monitor with uptime
// tracking and an incident ring, surfaced via /api/status. Mirrors v2's
// src/status/monitor.js intent.
package status

import (
	"sync"
	"time"
)

type ComponentStatus string

const (
	OK       ComponentStatus = "ok"
	Degraded ComponentStatus = "degraded"
	Down     ComponentStatus = "down"
)

type Component struct {
	Name      string          `json:"name"`
	Status    ComponentStatus `json:"status"`
	Detail    string          `json:"detail,omitempty"`
	UpdatedAt int64           `json:"updatedAt"`
}

type Incident struct {
	Time    int64  `json:"time"`
	Level   string `json:"level"`
	Message string `json:"message"`
}

// Status is the /api/status payload.
type Status struct {
	Page       string         `json:"page"`
	Brand      string         `json:"brand"`
	Version    string         `json:"version"`
	Generated  int64          `json:"generated"`
	Overall    string         `json:"overall"`
	UptimeSec  int64          `json:"uptimeSec"`
	Components []Component    `json:"components"`
	Incidents  []Incident     `json:"incidents"`
	System     map[string]any `json:"system"`
}

// Monitor tracks component health, uptime and incidents.
type Monitor struct {
	mu         sync.RWMutex
	start      time.Time
	version    string
	hostname   string
	components map[string]Component
	incidents  []Incident
	checkers   map[string]func() (ComponentStatus, string)
	stop       chan struct{}
	once       sync.Once
}

// New creates a Monitor. checkInterval drives auto-refresh of registered
// checkers (0 = no background loop).
func New(version, hostname string) *Monitor {
	return &Monitor{
		start:      time.Now(),
		version:    version,
		hostname:   hostname,
		components: map[string]Component{},
		incidents:  []Incident{},
		checkers:   map[string]func() (ComponentStatus, string){},
		stop:       make(chan struct{}),
	}
}

// Register adds a component with an optional health checker that runs on the
// background tick.
func (m *Monitor) Register(name string, check func() (ComponentStatus, string)) {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.components[name] = Component{Name: name, Status: OK, UpdatedAt: time.Now().UnixMilli()}
	if check != nil {
		m.checkers[name] = check
	}
}

// Set updates a component's status and records an incident on a worsening
// transition (ok->degraded/down or degraded->down).
func (m *Monitor) Set(name string, st ComponentStatus, detail string) {
	m.mu.Lock()
	defer m.mu.Unlock()
	prev, ok := m.components[name]
	if !ok {
		prev = Component{Status: OK}
	}
	changed := !ok || prev.Status != st
	m.components[name] = Component{Name: name, Status: st, Detail: detail, UpdatedAt: time.Now().UnixMilli()}
	if changed && (st == Degraded || st == Down) {
		m.recordLocked(incidentLevel(st), name+": "+detail)
	}
}

func incidentLevel(st ComponentStatus) string {
	if st == Down {
		return "critical"
	}
	return "warning"
}

func (m *Monitor) recordLocked(level, msg string) {
	m.incidents = append(m.incidents, Incident{Time: time.Now().UnixMilli(), Level: level, Message: msg})
	if len(m.incidents) > 100 {
		m.incidents = m.incidents[len(m.incidents)-100:]
	}
}

// Start launches the background health-check loop (noop if no checkers).
func (m *Monitor) Start(interval time.Duration) {
	if interval <= 0 {
		return
	}
	go func() {
		t := time.NewTicker(interval)
		defer t.Stop()
		for {
			select {
			case <-m.stop:
				return
			case <-t.C:
				m.runChecks()
			}
		}
	}()
}

func (m *Monitor) runChecks() {
	m.mu.RLock()
	checkers := make(map[string]func() (ComponentStatus, string), len(m.checkers))
	for k, v := range m.checkers {
		checkers[k] = v
	}
	m.mu.RUnlock()
	for name, fn := range checkers {
		st, detail := fn()
		m.Set(name, st, detail)
	}
}

// Close stops the background loop.
func (m *Monitor) Close() {
	m.once.Do(func() { close(m.stop) })
}

// GetStatus snapshots current state.
func (m *Monitor) GetStatus() Status {
	m.mu.RLock()
	defer m.mu.RUnlock()
	comps := make([]Component, 0, len(m.components))
	overall := OK
	for _, c := range m.components {
		comps = append(comps, c)
		if c.Status == Down {
			overall = Down
		} else if c.Status == Degraded && overall != Down {
			overall = Degraded
		}
	}
	inc := make([]Incident, len(m.incidents))
	copy(inc, m.incidents)
	return Status{
		Page:       "GarudaShield Status",
		Brand:      "GarudaShield",
		Version:    m.version,
		Generated:  time.Now().UnixMilli(),
		Overall:    string(overall),
		UptimeSec:  int64(time.Since(m.start).Seconds()),
		Components: comps,
		Incidents:  inc,
		// No hostname or internals: this endpoint is public. The dashboard
		// falls back to "edge" when system is absent.
		System: map[string]any{},
	}
}
