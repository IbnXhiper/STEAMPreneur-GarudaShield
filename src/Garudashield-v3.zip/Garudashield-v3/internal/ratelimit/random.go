package ratelimit

import "math/rand/v2"

// randFloat is isolated for deterministic testing.
var randFloat = rand.Float64
