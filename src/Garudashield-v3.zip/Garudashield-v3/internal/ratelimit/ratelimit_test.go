package ratelimit

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func testConfig() config.RateLimitConfig {
	return config.RateLimitConfig{
		GlobalMaxRPS:     100000,
		PerIPRPS:         5,
		PerIPBurst:       10,
		PerPathRPS:       1000,
		WindowMs:         1000,
		Adaptive:         false, // deterministic in tests
		CooldownPeriodMS: 500,
		RedEnabled:       false, // isolate hard limits
		TokenBucket:      false,
		ConnLimitPerIP:   100,
		AutoTune:         false,
		MaxAdaptiveLevel: 5,
	}
}

func TestPerIPLimit(t *testing.T) {
	l := New(testConfig())
	defer l.Close()

	// v2 chain for limit 5/burst 10/cooldown 500ms:
	// reqs 1–5 pass · 6–15 rate-exceeded · 16 burst-exceeded (+throttle)
	// · 17–20 throttled outright.
	reasons := map[string]int{}
	denied := 0
	for i := 0; i < 20; i++ {
		d := l.Check("1.2.3.4", "/x")
		if !d.Allowed {
			denied++
			reasons[d.Reason]++
		}
	}
	want := map[string]int{"rate-exceeded": 10, "burst-exceeded": 1, "throttled": 4}
	if denied != 15 {
		t.Fatalf("want 15 denials, got %d (%v)", denied, reasons)
	}
	for k, v := range want {
		if reasons[k] != v {
			t.Fatalf("reason %s: want %d got %d (%v)", k, v, reasons[k], reasons)
		}
	}
	// different IP unaffected
	if d := l.Check("5.6.7.8", "/x"); !d.Allowed {
		t.Fatalf("fresh IP should pass, got %+v", d)
	}
}

func TestThrottleAfterBurstExceeded(t *testing.T) {
	cfg := testConfig()
	l := New(cfg)
	defer l.Close()

	// exhaust per-IP then burst window
	for i := 0; i < 40; i++ {
		l.Check("9.9.9.9", "/flood")
	}
	d := l.Check("9.9.9.9", "/flood")
	if d.Allowed {
		t.Fatal("expected denial after flood")
	}
	// after burst-exceeded the IP must now be throttled outright
	reason := ""
	for i := 0; i < 10 && reason != "throttled"; i++ {
		d = l.Check("9.9.9.9", "/flood")
		reason = d.Reason
	}
	if reason != "throttled" {
		t.Fatalf("expected throttled, got %s", reason)
	}
}

func TestTokenBucket(t *testing.T) {
	cfg := testConfig()
	cfg.TokenBucket = true
	cfg.TokenBucketSize = 3
	cfg.TokenRefillRate = 100 // full refill in 30ms
	l := New(cfg)
	defer l.Close()

	for i := 0; i < 10; i++ {
		l.Check("7.7.7.7", "/") // also drains via per-IP? disabled RED; per-IP limit 5 denies first
	}
	// direct bucket semantics check via Stats counters
	if l.tokenDropped == 0 {
		t.Log("tokenDropped=0 — acceptable if per-IP denied before bucket")
	}
}

func TestREDQuadraticCurve(t *testing.T) {
	cfg := testConfig()
	cfg.RedEnabled = true
	cfg.RedMinThreshold = 0.65
	cfg.RedMaxThreshold = 0.95
	l := New(cfg)
	defer l.Close()

	if p := l.redDropProb(0.65); p != 0 {
		t.Fatalf("at min threshold prob must be 0, got %v", p)
	}
	if p := l.redDropProb(0.95); p != 1 {
		t.Fatalf("at max threshold prob must be 1, got %v", p)
	}
	mid := l.redDropProb(0.80) // p=(0.8-0.65)/0.3=0.5 → 0.25
	if mid < 0.249 || mid > 0.251 {
		t.Fatalf("quadratic midpoint wrong: %v", mid)
	}
}

func TestPathRulePrefix(t *testing.T) {
	cfg := testConfig()
	rps := 2
	cfg.PathRules = []config.PathRule{{Path: "/api/*", RPS: &rps}}
	l := New(cfg)
	defer l.Close()

	// requests 1–2 pass, request 3 hits custom rule (per-IP limit is 5)
	var third Decision
	for i := 0; i < 3; i++ {
		third = l.Check("4.4.4.4", "/api/users")
	}
	if third.Allowed || third.Reason != "path-rule-limit" {
		t.Fatalf("request 3: want path-rule-limit, got %+v", third)
	}
	// different IP + non-matching path follows the default limit
	if d := l.Check("6.6.6.6", "/other"); !d.Allowed {
		t.Fatalf("/other should follow default limit, got %+v", d)
	}
}

func TestEffectiveIPRPSTable(t *testing.T) {
	cfg := testConfig()
	cfg.PerIPRPS = 100
	cfg.Adaptive = true
	l := New(cfg)
	defer l.Close()

	want := [6]float64{100, 80, 60, 40, 25, 15}
	for lvl := 0; lvl <= 5; lvl++ {
		l.level = lvl
		if got := l.EffectiveIPRPS(); got != want[lvl] {
			t.Fatalf("level %d: got %v want %v", lvl, got, want[lvl])
		}
	}
}

// TestConnLimitIsConcurrentNotCumulative guards the DDoS-time false positive
// where an ordinary browser (many sequential asset requests) was hard-blocked
// because the connection check counted cumulative requests in a sliding window.
func TestConnLimitIsConcurrentNotCumulative(t *testing.T) {
	cfg := testConfig()
	cfg.PerIPRPS = 1000000
	cfg.PerIPBurst = 1000000
	cfg.ConnLimitPerIP = 3
	l := New(cfg)
	defer l.Close()

	ip := "10.1.2.3"

	// 200 sequential open→check→close cycles must never trip conn-limit.
	for i := 0; i < 200; i++ {
		l.ConnOpen(ip)
		if d := l.Check(ip, "/asset.js"); !d.Allowed && d.Reason == "conn-limit" {
			t.Fatalf("sequential request %d wrongly conn-limited", i)
		}
		l.ConnClose(ip)
	}

	// Concurrency up to the cap is fine; the first request over the line is
	// rejected (the caller registers itself via Open before Check).
	for i := 0; i < 3; i++ {
		l.ConnOpen(ip)
	}
	if d := l.Check(ip, "/x"); !d.Allowed && d.Reason == "conn-limit" {
		t.Fatalf("3 concurrent (== cap) should be allowed, got %+v", d)
	}
	l.ConnOpen(ip) // 4 concurrent > cap
	if d := l.Check(ip, "/x"); d.Allowed || d.Reason != "conn-limit" {
		t.Fatalf("4th concurrent should be conn-limited, got %+v", d)
	}
}
