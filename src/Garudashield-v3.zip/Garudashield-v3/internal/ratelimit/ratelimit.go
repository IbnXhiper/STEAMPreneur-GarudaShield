// Package ratelimit is a faithful Go port of v2's src/engine/ratelimiter.js:
// global/per-IP/per-path sliding windows, quadratic RED early-drop,
// token buckets, connection limits, burst throttling, an adaptive ladder and
// periodic auto-tuning.
package ratelimit

import (
	"math"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/storage"
)

// Decision mirrors v2's {allowed, reason, retryAfter}.
type Decision struct {
	Allowed      bool
	Reason       string
	RetryAfterMS int64
}

var allow = Decision{Allowed: true}

type throttleEntry struct {
	at  time.Time
	dur time.Duration
}

type Limiter struct {
	mu sync.RWMutex // guards cfg fields mutated by auto-tune / dashboard

	cfg config.RateLimitConfig

	global    *storage.SlidingWindow
	perIP     *storage.SlidingWindow
	perPath   *storage.SlidingWindow
	burst     *storage.SlidingWindow
	buckets   *storage.Store // token buckets: tb:<ip> -> []float64{tokens, lastRefillMs}
	conns     *storage.Store // in-flight counters: inflight:<ip> (see Open/Close)
	throttled sync.Map       // ip -> throttleEntry

	dropped      uint64
	redDropped   uint64
	connDropped  uint64
	tokenDropped uint64

	level     int // adaptive level 0..max
	tick      *time.Ticker
	tuner     *time.Ticker
	done      chan struct{}
	closeOnce sync.Once
}

func New(cfg config.RateLimitConfig) *Limiter {
	if cfg.GlobalMaxRPS <= 0 {
		cfg.GlobalMaxRPS = 50000
	}
	if cfg.PerIPRPS <= 0 {
		cfg.PerIPRPS = 100
	}
	if cfg.PerIPBurst <= 0 {
		cfg.PerIPBurst = 200
	}
	if cfg.PerPathRPS <= 0 {
		cfg.PerPathRPS = 1000
	}
	if cfg.WindowMs <= 0 {
		cfg.WindowMs = 1000
	}
	if cfg.CooldownPeriodMS <= 0 {
		cfg.CooldownPeriodMS = 60000
	}
	if cfg.RedMinThreshold <= 0 {
		cfg.RedMinThreshold = 0.65
	}
	if cfg.RedMaxThreshold <= cfg.RedMinThreshold {
		cfg.RedMaxThreshold = 0.95
	}
	if cfg.TokenBucketSize <= 0 {
		cfg.TokenBucketSize = 500
	}
	if cfg.TokenRefillRate <= 0 {
		cfg.TokenRefillRate = 100
	}
	if cfg.ConnLimitPerIP <= 0 {
		cfg.ConnLimitPerIP = 50
	}
	if cfg.MaxAdaptiveLevel <= 0 || cfg.MaxAdaptiveLevel > 5 {
		cfg.MaxAdaptiveLevel = 5
	}

	l := &Limiter{
		cfg:     cfg,
		global:  storage.NewSlidingWindow(int64(cfg.WindowMs), 200),
		perIP:   storage.NewSlidingWindow(int64(cfg.WindowMs), 200),
		perPath: storage.NewSlidingWindow(int64(cfg.WindowMs), 200),
		burst:   storage.NewSlidingWindow(100, 20),
		buckets: storage.NewStore(),
		conns:   storage.NewStore(),
		done:    make(chan struct{}),
	}

	if cfg.Adaptive {
		l.tick = time.NewTicker(2 * time.Second)
		go l.adaptiveLoop()
	}
	if cfg.AutoTune {
		interval := 10 * time.Second
		l.tuner = time.NewTicker(interval)
		go l.autoTuneLoop()
	}
	return l
}

// ---------- adaptive ladder ----------

var ladderFactors = [6]float64{1, 0.8, 0.6, 0.4, 0.25, 0.15}

func (l *Limiter) snapshot() config.RateLimitConfig {
	l.mu.RLock()
	defer l.mu.RUnlock()
	return l.cfg
}

// EffectiveIPRPS applies the adaptive ladder to the configured per-IP limit.
func (l *Limiter) EffectiveIPRPS() float64 {
	cfg := l.snapshot()
	if !cfg.Adaptive {
		return float64(cfg.PerIPRPS)
	}
	f := ladderFactors[l.level]
	return math.Floor(float64(cfg.PerIPRPS) * f)
}

func (l *Limiter) adaptiveLoop() {
	for {
		select {
		case <-l.done:
			return
		case <-l.tick.C:
			g := l.global.Count("__global__")
			cfg := l.snapshot()
			ratio := float64(g) / cfg.GlobalMaxRPS
			switch {
			case ratio > 0.8 && l.level < cfg.MaxAdaptiveLevel:
				l.level++
			case ratio < 0.3 && l.level > 0:
				l.level--
			}
		}
	}
}

func (l *Limiter) autoTuneLoop() {
	for {
		select {
		case <-l.done:
			return
		case <-l.tuner.C:
			g := l.global.Count("__global__")
			l.mu.Lock()
			cfg := &l.cfg
			ratio := float64(g) / cfg.GlobalMaxRPS
			if ratio > 0.9 {
				cfg.RedMinThreshold = math.Max(0.4, cfg.RedMinThreshold-0.05)
				cfg.PerIPRPS = int(math.Max(10, math.Floor(float64(cfg.PerIPRPS)*0.9)))
			} else if ratio < 0.3 && cfg.RedMinThreshold < 0.65 {
				cfg.RedMinThreshold = math.Min(0.65, cfg.RedMinThreshold+0.05)
			}
			l.mu.Unlock()
		}
	}
}

// redDropProb reproduces v2's quadratic probability curve.
func (l *Limiter) redDropProb(ratio float64) float64 {
	cfg := l.snapshot()
	if !cfg.RedEnabled {
		return 0
	}
	if ratio <= cfg.RedMinThreshold {
		return 0
	}
	if ratio >= cfg.RedMaxThreshold {
		return 1
	}
	p := (ratio - cfg.RedMinThreshold) / (cfg.RedMaxThreshold - cfg.RedMinThreshold)
	return p * p
}

// ---------- token bucket ----------

func (l *Limiter) checkTokenBucket(ip string) bool {
	cfg := l.snapshot()
	if !cfg.TokenBucket {
		return true
	}
	now := time.Now().UnixMilli()
	key := "tb:" + ip
	cur, ok := l.buckets.Get(key)
	if !ok {
		l.buckets.Set(key, []float64{cfg.TokenBucketSize - 1, float64(now)}, 60000)
		return true
	}
	st, _ := cur.([]float64)
	if len(st) != 2 {
		l.buckets.Set(key, []float64{cfg.TokenBucketSize - 1, float64(now)}, 60000)
		return true
	}
	refillPerMS := cfg.TokenRefillRate / 1000
	elapsed := now - int64(st[1])
	if elapsed < 0 {
		elapsed = 0
	}
	st[0] = math.Min(cfg.TokenBucketSize, st[0]+float64(elapsed)*refillPerMS)
	st[1] = float64(now)
	if st[0] < 1 {
		l.tokenDropped++
		l.buckets.Set(key, st, 60000)
		return false
	}
	st[0]--
	l.buckets.Set(key, st, 60000)
	return true
}

// ---------- connection limit ----------

// Open registers the start of an in-flight request for ip. Pair it with a
// matching Close when the request finishes. The counter approximates concurrent
// connections per client IP; using a TTL means a lost Close self-heals after a
// minute instead of leaking a permanently elevated count.
func (l *Limiter) ConnOpen(ip string) { l.conns.Incr("inflight:"+ip, 1, 60000) }

// Close releases an in-flight request for ip, deleting the key at zero so the
// store does not accumulate dead entries.
func (l *Limiter) ConnClose(ip string) {
	if n := l.conns.Incr("inflight:"+ip, -1, 60000); n <= 0 {
		l.conns.Delete("inflight:" + ip)
	}
}

// checkConnLimit enforces a cap on CONCURRENT in-flight requests per IP rather
// than cumulative requests. The earlier cumulative form counted every request in
// a sliding 30s window, so an ordinary browser page load (>20 asset requests)
// blew through the limit and hard-blocked legitimate users; counting concurrent
// requests keeps the flood guard while never tripping on normal browsing.
func (l *Limiter) checkConnLimit(ip string) bool {
	cfg := l.snapshot()
	if cfg.ConnLimitPerIP <= 0 {
		return true
	}
	// The caller has already registered itself via Open, so a count strictly
	// greater than the cap is the first request over the line.
	if l.conns.GetInt("inflight:"+ip) > int64(cfg.ConnLimitPerIP) {
		l.connDropped++
		return false
	}
	return true
}

// ---------- throttle list ----------

func (l *Limiter) throttle(ip string, dur time.Duration) {
	l.throttled.Store(ip, throttleEntry{at: time.Now(), dur: dur})
	if l.countThrottled() > 50000 { // v2 cap: sweep expired until ≤30000
		now := time.Now()
		removed := 0
		l.throttled.Range(func(k, v any) bool {
			e, ok := v.(throttleEntry)
			if ok && now.Sub(e.at) > e.dur {
				l.throttled.Delete(k)
				removed++
			}
			return 50000-removed > 30000 // continue while still oversized
		})
	}
}

func (l *Limiter) countThrottled() int {
	n := 0
	l.throttled.Range(func(_, _ any) bool { n++; return true })
	return n
}

// Check runs the full v2 decision chain for one request.
func (l *Limiter) Check(ip, path string) Decision {
	now := time.Now()

	// 1. active throttle window
	if v, ok := l.throttled.Load(ip); ok {
		e := v.(throttleEntry)
		if now.Sub(e.at) < e.dur {
			l.dropped++
			return Decision{Allowed: false, Reason: "throttled", RetryAfterMS: int64((e.dur - now.Sub(e.at)).Milliseconds())}
		}
		l.throttled.Delete(ip)
	}

	cfg := l.snapshot()

	// 2. global RPS + RED + hard global limit
	g := l.global.Increment("__global__")
	ratio := float64(g) / cfg.GlobalMaxRPS
	if ratio > cfg.RedMinThreshold {
		p := l.redDropProb(ratio)
		if p > 0 && randFloat() < p {
			l.redDropped++
			l.dropped++
			return Decision{Allowed: false, Reason: "red-drop", RetryAfterMS: ceilF(100 + p*400)}
		}
	}
	if float64(g) > cfg.GlobalMaxRPS {
		l.dropped++
		return Decision{Allowed: false, Reason: "global-limit", RetryAfterMS: 100}
	}

	// 3. per-IP RPS + RED + over-limit/burst handling
	ipRPS := l.perIP.Increment(ip)
	ipLimit := l.EffectiveIPRPS()
	ipRatio := float64(ipRPS) / math.Max(ipLimit, 1)

	if ipRatio > cfg.RedMinThreshold {
		p := l.redDropProb(math.Min(ipRatio, 1))
		if p > 0 && randFloat() < p {
			l.redDropped++
			l.dropped++
			return Decision{Allowed: false, Reason: "red-ip-drop", RetryAfterMS: ceilF(100 + p*400)}
		}
	}
	if float64(ipRPS) > ipLimit {
		burstCount := l.burst.Increment("b:" + ip)
		if burstCount > int64(cfg.PerIPBurst) {
			l.throttle(ip, time.Duration(cfg.CooldownPeriodMS)*time.Millisecond)
			l.dropped++
			return Decision{Allowed: false, Reason: "burst-exceeded", RetryAfterMS: int64(cfg.CooldownPeriodMS)}
		}
		if cfg.Adaptive && float64(ipRPS) > ipLimit*1.5 {
			d := time.Duration(cfg.CooldownPeriodMS) * time.Millisecond
			if d > 5000*time.Millisecond {
				d = 5000 * time.Millisecond
			}
			l.throttle(ip, d)
		}
		l.dropped++
		return Decision{Allowed: false, Reason: "rate-exceeded", RetryAfterMS: 1000}
	}

	// 4. connection limit
	if !l.checkConnLimit(ip) {
		l.dropped++
		return Decision{Allowed: false, Reason: "conn-limit", RetryAfterMS: 500}
	}

	// 5. token bucket
	if !l.checkTokenBucket(ip) {
		l.dropped++
		return Decision{Allowed: false, Reason: "token-bucket", RetryAfterMS: 200}
	}

	// 6. per-path limit with optional path rules (prefix `x*` or exact match)
	p := l.perPath.Increment(path)
	pathLimit := int64(cfg.PerPathRPS)
	reason := "path-limit"
	for _, pr := range cfg.PathRules {
		if pr.Path == "" {
			continue
		}
		match := false
		if len(pr.Path) > 0 && pr.Path[len(pr.Path)-1] == '*' {
			prefix := pr.Path[:len(pr.Path)-1]
			match = len(path) >= len(prefix) && path[:len(prefix)] == prefix
		} else {
			match = pr.Path == path
		}
		if match && pr.RPS != nil {
			pathLimit = int64(*pr.RPS)
			reason = "path-rule-limit"
			break
		}
	}
	if p > pathLimit {
		l.dropped++
		return Decision{Allowed: false, Reason: reason, RetryAfterMS: 500}
	}

	return allow
}

// GetIPRPS returns the current per-IP window count.
func (l *Limiter) GetIPRPS(ip string) int64 { return l.perIP.Count(ip) }

// Reset clears all state (v2 /api/reset).
func (l *Limiter) Reset() {
	l.global.Clear()
	l.perIP.Clear()
	l.perPath.Clear()
	l.burst.Clear()
	l.throttled = sync.Map{}
	l.buckets.Close()
	l.conns.Close()
	l.buckets = storage.NewStore()
	l.conns = storage.NewStore()
	l.dropped, l.redDropped, l.connDropped, l.tokenDropped = 0, 0, 0, 0
	l.level = 0
}

// UpdateConfig merges dashboard-side changes into live config.
// Config returns a copy of the live rate-limit configuration.
func (l *Limiter) Config() config.RateLimitConfig {
	l.mu.RLock()
	defer l.mu.RUnlock()
	return l.cfg
}

func (l *Limiter) UpdateConfig(patch config.RateLimitConfig) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if patch.GlobalMaxRPS > 0 {
		l.cfg.GlobalMaxRPS = patch.GlobalMaxRPS
	}
	if patch.PerIPRPS > 0 {
		l.cfg.PerIPRPS = patch.PerIPRPS
	}
	if patch.PerIPBurst > 0 {
		l.cfg.PerIPBurst = patch.PerIPBurst
	}
	if patch.TokenBucketSize > 0 {
		l.cfg.TokenBucketSize = patch.TokenBucketSize
	}
	if patch.ConnLimitPerIP > 0 {
		l.cfg.ConnLimitPerIP = patch.ConnLimitPerIP
	}
	if patch.RedMinThreshold > 0 {
		l.cfg.RedMinThreshold = patch.RedMinThreshold
	}
}

type Stats struct {
	GlobalRPS        int64   `json:"globalRPS"`
	ThrottledIPs     int     `json:"throttledIPs"`
	DroppedCount     uint64  `json:"droppedCount"`
	RedDropped       uint64  `json:"redDropped"`
	ConnDropped      uint64  `json:"connDropped"`
	TokenDropped     uint64  `json:"tokenDropped"`
	AdaptiveLevel    int     `json:"adaptiveLevel"`
	MaxAdaptiveLevel int     `json:"maxAdaptiveLevel"`
	EffectiveIPRPS   float64 `json:"effectiveIPRPS"`
	GlobalLimit      float64 `json:"globalLimit"`
	PerIPLimit       int     `json:"perIPLimit"`
	TokenBucketSize  float64 `json:"tokenBucketSize"`
	ConnLimitPerIP   int     `json:"connLimitPerIP"`
	RedThreshold     float64 `json:"redThreshold"`
}

func (l *Limiter) Stats() Stats {
	cfg := l.snapshot()
	return Stats{
		GlobalRPS:        l.global.Count("__global__"),
		ThrottledIPs:     l.countThrottled(),
		DroppedCount:     l.dropped,
		RedDropped:       l.redDropped,
		ConnDropped:      l.connDropped,
		TokenDropped:     l.tokenDropped,
		AdaptiveLevel:    l.level,
		MaxAdaptiveLevel: cfg.MaxAdaptiveLevel,
		EffectiveIPRPS:   l.EffectiveIPRPS(),
		GlobalLimit:      cfg.GlobalMaxRPS,
		PerIPLimit:       cfg.PerIPRPS,
		TokenBucketSize:  cfg.TokenBucketSize,
		ConnLimitPerIP:   cfg.ConnLimitPerIP,
		RedThreshold:     cfg.RedMinThreshold,
	}
}

// Close stops background loops and stores.
func (l *Limiter) Close() {
	l.closeOnce.Do(func() {
		close(l.done)
		if l.tick != nil {
			l.tick.Stop()
		}
		if l.tuner != nil {
			l.tuner.Stop()
		}
		l.buckets.Close()
		l.conns.Close()
	})
}

// ceilF mirrors Math.ceil on the RED retry-after computation.
func ceilF(f float64) int64 { return int64(math.Ceil(f)) }
