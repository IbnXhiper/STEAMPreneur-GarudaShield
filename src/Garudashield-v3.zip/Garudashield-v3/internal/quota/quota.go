// Package quota enforces per-plan request budgets at the edge. Counters live in
// PostgreSQL (usage_quota table) using a single atomic upsert, so the budget
// is shared across every engine instance on the same database — enforcement is
// cross-instance without Redis. A pool outage fails the increment, which the
// edge treats as "allow and degrade" (quota is a business guardrail, not a
// security gate; the DDoS pipeline already runs before this).
package quota

import (
	"context"
	"fmt"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Store is the quota counter over Postgres.
type Store struct {
	pool *pgxpool.Pool
}

// New builds a Store over the given pool. A nil pool is allowed but every
// method fails closed (returns an error) so the edge can skip enforcement.
func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// PeriodKey returns the daily window key for now (UTC). The ceiling rolls at
// midnight UTC; period keys are opaque to callers.
func PeriodKey(now time.Time) string {
	return "d:" + now.UTC().Format("2006-01-02")
}

// Incr atomically increments the tenant counter for the period and returns the
// running total. The increment and the read happen in one statement, so two
// nodes can never overshoot by more than one request.
func (s *Store) Incr(ctx context.Context, tenantID, period string) (int64, error) {
	if s.pool == nil {
		return 0, fmt.Errorf("usage_quota store not connected")
	}
	var n int64
	err := s.pool.QueryRow(ctx,
		`INSERT INTO usage_quota (tenant_id, period, requests) VALUES ($1,$2,1)
		 ON CONFLICT (tenant_id, period)
		 DO UPDATE SET requests = usage_quota.requests + 1
		 RETURNING requests`, tenantID, period).Scan(&n)
	if err != nil {
		return 0, err
	}
	return n, nil
}

// Usage returns the tenant counter for one or more period windows. Empty key
// set returns the whole history (bounded server-side to the last 366 rows).
func (s *Store) Usage(ctx context.Context, tenantID string, periods ...string) (map[string]int64, error) {
	out := map[string]int64{}
	if s.pool == nil {
		return out, fmt.Errorf("usage_quota store not connected")
	}
	if len(periods) == 0 {
		rows, err := s.pool.Query(ctx,
			`SELECT period, requests FROM usage_quota WHERE tenant_id = $1
			 ORDER BY period DESC LIMIT 366`, tenantID)
		if err != nil {
			return out, err
		}
		defer rows.Close()
		for rows.Next() {
			var p string
			var n int64
			if err := rows.Scan(&p, &n); err != nil {
				return out, err
			}
			out[p] = n
		}
		return out, rows.Err()
	}
	rows, err := s.pool.Query(ctx,
		`SELECT period, requests FROM usage_quota WHERE tenant_id = $1 AND period = ANY($2)`,
		tenantID, periods)
	if err != nil {
		return out, err
	}
	defer rows.Close()
	for rows.Next() {
		var p string
		var n int64
		if err := rows.Scan(&p, &n); err != nil {
			return out, err
		}
		out[p] = n
	}
	return out, rows.Err()
}

// LimitFor resolves the daily budget for a plan from the configured map,
// falling back to the configured default. 0 means unlimited.
func LimitFor(plan string, planLimits map[string]int64, fallback int64) int64 {
	if v, ok := planLimits[plan]; ok {
		return v
	}
	return fallback
}

// Enforcer sits at the edge: it increments the tenant's daily counter and
// reports whether the request is still within budget. It is nil-safe in the
// sense that callers pass nil to disable quota entirely (no CPU or I/O cost).
type Enforcer struct {
	store      *Store
	planLimits map[string]int64
	fallback   int64
}

// NewEnforcer wires a store + the configured plan limits into an Enforcer.
// A nil store still allows unlimited traffic: quota never bricks the edge on
// its own outage (the DDoS pipeline already ran; quota is a billing rail).
func NewEnforcer(s *Store, planLimits map[string]int64, fallback int64) *Enforcer {
	return &Enforcer{store: s, planLimits: planLimits, fallback: fallback}
}

// Check consumes one unit of the tenant's daily budget and returns whether the
// request is allowed. Plans with a limit of 0 (unlimited) short-circuit.
// On a counter error the request is ALLOWED (fail-open): a quota accounting
// blip must not take a paying tenant offline; abuse is still caught by the
// DDoS defense layers that run before this point.
func (e *Enforcer) Check(ctx context.Context, tenantID, plan string) (bool, error) {
	if e == nil || e.store == nil {
		return true, nil
	}
	limit := LimitFor(plan, e.planLimits, e.fallback)
	if limit <= 0 {
		return true, nil
	}
	n, err := e.store.Incr(ctx, tenantID, PeriodKey(time.Now()))
	if err != nil {
		return true, err
	}
	return n <= limit, nil
}
