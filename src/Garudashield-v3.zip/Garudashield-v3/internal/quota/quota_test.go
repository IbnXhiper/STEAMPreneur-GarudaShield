package quota

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/db"
)

func TestPeriodKeyUTC(t *testing.T) {
	now := time.Date(2026, 10, 11, 1, 30, 0, 0, time.FixedZone("WIB", 7*3600))
	if got := PeriodKey(now); got != "d:2026-10-10" {
		t.Fatalf("PeriodKey should roll in UTC: got %q", got)
	}
	if got := PeriodKey(now.UTC()); got != "d:2026-10-10" {
		t.Fatalf("PeriodKey(UTC) = %q", got)
	}
}

func TestLimitForFallback(t *testing.T) {
	m := map[string]int64{"free": 100, "pro": 0}
	if v := LimitFor("free", m, 7); v != 100 {
		t.Fatalf("free = %d", v)
	}
	if v := LimitFor("pro", m, 7); v != 0 {
		t.Fatalf("pro should be unlimited, got %d", v)
	}
	if v := LimitFor("enterprise", m, 7); v != 7 {
		t.Fatalf("unknown plan should fall back, got %d", v)
	}
}

func TestEnforcerNilSafeAndUnlimited(t *testing.T) {
	if ok, err := (*Enforcer)(nil).Check(context.Background(), "t1", "pro"); !ok || err != nil {
		t.Fatalf("nil enforcer must allow: ok=%v err=%v", ok, err)
	}
	e := NewEnforcer(nil, map[string]int64{"free": 100}, 50)
	if ok, _ := e.Check(context.Background(), "t1", "free"); !ok {
		t.Fatal("nil store must fail open (allow)")
	}
	if ok, _ := e.Check(context.Background(), "t1", "pro"); !ok {
		t.Fatal("unlimited plan must never consume or deny")
	}
}

// TestQuotaLifecyclePG covers the real upsert counter on Postgres: increments
// persist across calls, periods are isolated, and the enforcer turns 429 once
// the budget is exceeded. Skips without GS_DATABASE_URL.
func TestQuotaLifecyclePG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM usage_quota WHERE tenant_id='quota-test'`)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan) VALUES ('quota-test','Quota','free') ON CONFLICT (id) DO NOTHING`)
	defer func() { _, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='quota-test'`) }()

	s := New(pool)
	p1 := PeriodKey(time.Now())
	p2 := "d:1999-01-01"

	for i := 0; i < 3; i++ {
		if _, err := s.Incr(ctx, "quota-test", p1); err != nil {
			t.Fatalf("incr %d: %v", i, err)
		}
	}
	n, err := s.Incr(ctx, "quota-test", p2)
	if err != nil || n != 1 {
		t.Fatalf("cross-period incr = %d err=%v", n, err)
	}

	usage, err := s.Usage(ctx, "quota-test", p1)
	if err != nil || usage[p1] != 3 {
		t.Fatalf("usage[p1] = %d err=%v", usage[p1], err)
	}
	all, _ := s.Usage(ctx, "quota-test")
	if len(all) == 0 || all[p1] != 3 || all[p2] != 1 {
		t.Fatalf("full usage = %#v", all)
	}

	// Enforcer: budget of 2 for this tenant's plan -> 2x allow, then deny.
	// Start from a clean counter so the earlier 3+1 increments don't leak in.
	_, _ = pool.Exec(ctx, `DELETE FROM usage_quota WHERE tenant_id='quota-test'`)
	e := NewEnforcer(s, map[string]int64{"free": 2}, 50)
	var results []bool
	for i := 0; i < 3; i++ {
		ok, err := e.Check(ctx, "quota-test", "free")
		if err != nil {
			t.Fatalf("check: %v", err)
		}
		results = append(results, ok)
	}
	if !results[0] || !results[1] || results[2] {
		t.Fatalf("expected allow,allow,deny got %v", results)
	}
}
