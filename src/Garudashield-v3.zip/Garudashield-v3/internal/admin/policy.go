package admin

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/asset"
	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/policy"
	"github.com/ahkurdev/garudashield/internal/shield"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// policyHandler exposes per-domain protection policies (the "site settings" a
// customer tunes for their own protected website, mirroring the operator
// dashboard's WAF / rate-limit / mode controls). Every tenant endpoint resolves
// the tenant from the signed session and the domain from the tenant's own asset
// — neither is ever taken from the request body.
//
//	GET    /api/v1/policies               — list the tenant's domains + policies
//	GET    /api/v1/assets/{id}/policy     — read one domain's policy
//	POST   /api/v1/assets/{id}/policy     — write one domain's policy
//	DELETE /api/v1/assets/{id}/policy     — clear it (fall back to global)
//	GET    /api/admin/policy?domain=      — operator read
//	POST   /api/admin/policy              — operator write {domain,tenantId,policy}
//	DELETE /api/admin/policy?domain=      — operator clear
//
// Writes are persisted to Postgres (source of truth) and pushed into the local
// engine registry immediately; peer nodes reconcile from Postgres on a short
// interval, so both edge nodes converge without a dedicated message bus.
type policyHandler struct {
	ps *policy.Store
	as *asset.Store
	ts *tenant.Store
	sh *shield.Shield
}

// RegisterPolicies wires the per-domain policy API. Only meaningful when the
// commercial Postgres store is present.
func RegisterPolicies(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler, sh *shield.Shield) {
	h := &policyHandler{
		ps: policy.New(ts.Pool()),
		as: asset.New(ts.Pool()),
		ts: ts,
		sh: sh,
	}
	mux.HandleFunc("GET /api/v1/policies", roleShim(auth.RoleViewer, ah, h.list))
	mux.HandleFunc("GET /api/v1/assets/{id}/policy", roleShim(auth.RoleViewer, ah, h.getAsset))
	mux.HandleFunc("POST /api/v1/assets/{id}/policy", roleShim(auth.RoleAdmin, ah, h.putAsset))
	mux.HandleFunc("DELETE /api/v1/assets/{id}/policy", roleShim(auth.RoleAdmin, ah, h.deleteAsset))

	mux.HandleFunc("GET /api/admin/policy", h.operatorGet)
	mux.HandleFunc("POST /api/admin/policy", h.operatorPut)
	mux.HandleFunc("DELETE /api/admin/policy", h.operatorDelete)
}

// list returns every domain the tenant owns, with its policy (empty if unset)
// and whether it is currently enforced (verified).
func (h *policyHandler) list(w http.ResponseWriter, r *http.Request, tid string) {
	assets, err := h.as.List(r.Context(), tid)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	out := make([]map[string]any, 0, len(assets))
	for _, a := range assets {
		cfg := policy.Policy{}
		updatedAt := int64(0)
		if e, err := h.ps.Get(r.Context(), a.Domain); err == nil {
			cfg, updatedAt = e.Policy, e.UpdatedAt
		}
		out = append(out, map[string]any{
			"domain":    a.Domain,
			"assetId":   a.ID,
			"status":    a.Status,
			"policy":    cfg,
			"updatedAt": updatedAt,
		})
	}
	writeJSON(w, http.StatusOK, map[string]any{"domains": out})
}

// resolveAsset loads an asset owned by tid and returns its normalized domain.
func (h *policyHandler) resolveAsset(r *http.Request, tid string) (string, bool, error) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		return "", false, asset.ErrNotFound
	}
	a, err := h.as.Get(r.Context(), tid, id)
	if err != nil {
		return "", false, err
	}
	return policy.NormalizeDomain(a.Domain), a.Status == asset.StatusVerified, nil
}

func (h *policyHandler) getAsset(w http.ResponseWriter, r *http.Request, tid string) {
	domain, verified, err := h.resolveAsset(r, tid)
	if err != nil {
		if errors.Is(err, asset.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	cfg := policy.Policy{}
	updatedAt := int64(0)
	if e, err := h.ps.Get(r.Context(), domain); err == nil {
		cfg, updatedAt = e.Policy, e.UpdatedAt
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"domain": domain, "enforced": verified,
		"policy": cfg, "updatedAt": updatedAt,
	})
}

func (h *policyHandler) putAsset(w http.ResponseWriter, r *http.Request, tid string) {
	domain, _, err := h.resolveAsset(r, tid)
	if err != nil {
		if errors.Is(err, asset.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	var p policy.Policy
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(&p); err != nil {
		writeJSONError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := p.Validate(); err != nil {
		writeJSONError(w, http.StatusBadRequest, err.Error())
		return
	}
	now := time.Now().UnixMilli()
	if err := h.ps.Upsert(r.Context(), domain, tid, "tenant", p); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.sh.SetDomainPolicy(domain, p, tid, now)
	h.ts.Audit(r.Context(), tid, "tenant", "policy.set", "domain="+domain, r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "domain": domain, "policy": p, "updatedAt": now})
}

func (h *policyHandler) deleteAsset(w http.ResponseWriter, r *http.Request, tid string) {
	domain, _, err := h.resolveAsset(r, tid)
	if err != nil {
		if errors.Is(err, asset.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	if err := h.ps.Delete(r.Context(), domain); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.sh.DeleteDomainPolicy(domain)
	h.ts.Audit(r.Context(), tid, "tenant", "policy.clear", "domain="+domain, r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "domain": domain})
}

// ---------- operator endpoints (GS_ADMIN_SECRET) ----------

func (h *policyHandler) operatorGet(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		writeJSONError(w, http.StatusForbidden, "forbidden")
		return
	}
	domain := policy.NormalizeDomain(r.URL.Query().Get("domain"))
	if domain == "" {
		writeJSONError(w, http.StatusBadRequest, "domain required")
		return
	}
	e, err := h.ps.Get(r.Context(), domain)
	if errors.Is(err, policy.ErrNotFound) {
		writeJSON(w, http.StatusOK, map[string]any{"domain": domain, "policy": policy.Policy{}})
		return
	}
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"domain": domain, "tenantId": e.TenantID, "policy": e.Policy, "updatedAt": e.UpdatedAt})
}

func (h *policyHandler) operatorPut(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		writeJSONError(w, http.StatusForbidden, "forbidden")
		return
	}
	var req struct {
		Domain   string        `json:"domain"`
		TenantID string        `json:"tenantId"`
		Policy   policy.Policy `json:"policy"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 64<<10)).Decode(&req); err != nil {
		writeJSONError(w, http.StatusBadRequest, "bad request")
		return
	}
	domain := policy.NormalizeDomain(req.Domain)
	if domain == "" || strings.TrimSpace(req.TenantID) == "" {
		writeJSONError(w, http.StatusBadRequest, "domain and tenantId are required")
		return
	}
	if err := req.Policy.Validate(); err != nil {
		writeJSONError(w, http.StatusBadRequest, err.Error())
		return
	}
	now := time.Now().UnixMilli()
	if err := h.ps.Upsert(r.Context(), domain, req.TenantID, "operator", req.Policy); err != nil {
		writeJSONError(w, http.StatusBadRequest, "store rejected the policy (unknown tenant?)")
		return
	}
	h.sh.SetDomainPolicy(domain, req.Policy, req.TenantID, now)
	h.ts.Audit(r.Context(), req.TenantID, "operator", "policy.set", "domain="+domain, r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "domain": domain, "updatedAt": now})
}

func (h *policyHandler) operatorDelete(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		writeJSONError(w, http.StatusForbidden, "forbidden")
		return
	}
	domain := policy.NormalizeDomain(r.URL.Query().Get("domain"))
	if domain == "" {
		writeJSONError(w, http.StatusBadRequest, "domain is required")
		return
	}
	if err := h.ps.Delete(r.Context(), domain); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.sh.DeleteDomainPolicy(domain)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "domain": domain})
}
