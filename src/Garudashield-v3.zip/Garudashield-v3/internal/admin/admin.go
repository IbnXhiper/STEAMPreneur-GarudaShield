// Package admin exposes GarudaShield's control-plane API: a v2-compatible
// REST surface under /api/ (identical paths) plus an SSE stream of live
// stats at /api/stats/stream. State stays in-memory (Fase 3, pre-Redis).
package admin

import (
	"crypto/subtle"
	"encoding/json"
	"net"
	"net/http"
	"os"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/access"
	"github.com/ahkurdev/garudashield/internal/alerts"
	"github.com/ahkurdev/garudashield/internal/cluster"
	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/shield"
	"github.com/ahkurdev/garudashield/internal/status"
)

// publicEndpoints are reachable without an API key (mirrors v2 PUBLIC_ENDPOINTS).
var publicEndpoints = map[string]bool{
	"/api/status": true,
	"/api/whoami": true,
}

type api struct {
	shield  *shield.Shield
	cfg     config.AdminConfig
	mon     *status.Monitor
	al      *alerts.Manager
	gate    *access.Gate
	ps      *cluster.PeerSync
	fullCfg *config.Config
	// failed tracks per-client-IP auth failures for brute-force protection.
	failed *sync.Map
	// pubLimiter caps unauthenticated endpoints (/api/status, /api/whoami).
	pubLimiter *publicRateLimiter
}

// Register mounts the admin API onto mux. Safe to call once after the shield
// is constructed. mon, al, gate and ps may be nil (their endpoints fall back
// gracefully). fullCfg is used by /api/config (read-only snapshot).
func Register(mux *http.ServeMux, s *shield.Shield, mon *status.Monitor, al *alerts.Manager, cfg config.AdminConfig, gate *access.Gate, ps *cluster.PeerSync, fullCfg *config.Config) {
	a := &api{shield: s, cfg: cfg, mon: mon, al: al, gate: gate, ps: ps, fullCfg: fullCfg, pubLimiter: newPublicRateLimiter(60)}

	// GET (auth)
	mux.HandleFunc("GET /api/stats", a.auth(a.handleStats))
	mux.HandleFunc("GET /api/stats/stream", a.auth(a.handleStream))
	mux.HandleFunc("GET /api/blocklist", a.auth(a.handleBlocklist))
	mux.HandleFunc("GET /api/whitelist", a.auth(a.handleWhitelist))
	mux.HandleFunc("GET /api/whitelist/detailed", a.auth(a.handleWhitelistDetailed))
	mux.HandleFunc("GET /api/top", a.auth(a.handleTop))
	mux.HandleFunc("GET /api/geo", a.auth(a.handleGeo))
	mux.HandleFunc("GET /api/logs", a.auth(a.handleLogs))
	mux.HandleFunc("GET /api/reputation", a.auth(a.handleReputation))
	mux.HandleFunc("GET /api/mode", a.auth(a.handleMode))

	// POST (auth)
	mux.HandleFunc("POST /api/block", a.auth(a.handleBlock))
	mux.HandleFunc("POST /api/unblock", a.auth(a.handleUnblock))
	mux.HandleFunc("POST /api/whitelist", a.auth(a.handleWhitelistAdd))
	mux.HandleFunc("POST /api/unwhitelist", a.auth(a.handleWhitelistRemove))
	mux.HandleFunc("POST /api/mode", a.auth(a.handleModeSet))
	mux.HandleFunc("POST /api/emergency", a.auth(a.handleEmergency))
	mux.HandleFunc("POST /api/reputation/reset", a.auth(a.handleReputationReset))

	// alerts (auth)
	mux.HandleFunc("GET /api/alerts/config", a.auth(a.handleAlertsConfig))
	mux.HandleFunc("GET /api/alerts/log", a.auth(a.handleAlertsLog))
	mux.HandleFunc("POST /api/alerts/test", a.auth(a.handleAlertsTest))

	// v2-parity management endpoints (auth)
	mux.HandleFunc("GET /api/waf", a.auth(a.handleWAFGet))
	mux.HandleFunc("POST /api/waf", a.auth(a.handleWAFSet))
	mux.HandleFunc("GET /api/ratelimit", a.auth(a.handleRatelimitGet))
	mux.HandleFunc("POST /api/ratelimit", a.auth(a.handleRatelimitSet))
	mux.HandleFunc("GET /api/rules", a.auth(a.handleRulesGet))
	mux.HandleFunc("POST /api/rules", a.auth(a.handleRulesAdd))
	mux.HandleFunc("DELETE /api/rules", a.auth(a.handleRulesClear))
	mux.HandleFunc("GET /api/cluster", a.auth(a.handleCluster))
	mux.HandleFunc("GET /api/backup", a.auth(a.handleBackup))
	mux.HandleFunc("POST /api/backup/restore", a.auth(a.handleBackupRestore))
	mux.HandleFunc("GET /api/config", a.auth(a.handleConfigGet))
	mux.HandleFunc("POST /api/config", a.auth(a.handleConfigSet))
	mux.HandleFunc("POST /api/reset", a.auth(a.handleReset))
	mux.HandleFunc("GET /api/notifications", a.auth(a.handleAlertsConfig))
	mux.HandleFunc("POST /api/notifications/test", a.auth(a.handleAlertsTest))

	// access gate management (auth)
	mux.HandleFunc("GET /api/access/hosts", a.auth(a.handleAccessHosts))
	mux.HandleFunc("POST /api/access/hosts", a.auth(a.handleAccessHostsSet))
	mux.HandleFunc("POST /api/access/hosts/remove", a.auth(a.handleAccessHostsRemove))
	mux.HandleFunc("GET /api/access/protectall", a.auth(a.handleAccessProtectAll))
	mux.HandleFunc("POST /api/access/protectall", a.auth(a.handleAccessProtectAllSet))
	mux.HandleFunc("GET /api/access/cookietokens", a.auth(a.handleAccessCookies))
	mux.HandleFunc("POST /api/access/toggle", a.auth(a.handleAccessToggle))

	// GET (public) — status is intentionally not behind auth, but it IS rate
	// limited per IP (enumeration/amplification guard).
	mux.HandleFunc("GET /api/status", a.wrapPublic(a.handleStatus))
	mux.HandleFunc("GET /api/whoami", a.wrapPublic(a.handleWhoami))
}

// ---------- auth & headers (port of v2 dashboard api.js) ----------

func (a *api) setHeaders(w http.ResponseWriter) {
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.Header().Set("X-Frame-Options", "SAMEORIGIN")
	w.Header().Set("Referrer-Policy", "no-referrer")
	w.Header().Set("Cache-Control", "no-store")
	// No CORS wildcard: the dashboard talks to the engine through the
	// same-origin BFF proxy (/api/gs), so browsers never need cross-origin
	// access to key-authenticated endpoints.
}

func (a *api) auth(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		a.setHeaders(w)
		if r.Method == "OPTIONS" {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if publicEndpoints[r.URL.Path] {
			next(w, r)
			return
		}
		// Brute-force protection: throttle repeated auth failures per client IP.
		if a.authLocked(r) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusTooManyRequests)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "too many failed attempts; try again later"})
			return
		}
		if a.hasKey(r) || (a.cfg.Secret == "" && a.fromLoopback(r)) {
			a.authReset(r)
			next(w, r)
			return
		}
		a.authFail(r)
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusForbidden)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
	}
}

// --- brute-force limiter (per-client-IP) ---
//
// A client that fails auth repeatedly is locked out for authLockWindow to stop
// key guessing. The limiter is in-memory only (resets on restart), which is
// acceptable: it raises the cost of an online brute-force without becoming a
// DoS surface itself (an attacker who already holds a valid key is unaffected).

const (
	authMaxFails      = 5
	authLockWindowSec = 300
)

type authAttempt struct {
	fails       int
	lockedUntil time.Time
	mu          sync.Mutex
}

func (a *api) clientIPOf(r *http.Request) string {
	host := r.RemoteAddr
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	// Proxy headers are only honored when TrustProxy is set AND the immediate
	// connection comes from a trusted proxy (same rule as the edge clientIP in
	// cmd/garudashield). Otherwise a client could spoof X-Forwarded-For to
	// rotate its apparent IP and walk around the brute-force lockout and the
	// public rate limiter.
	if xff := r.Header.Get("X-Forwarded-For"); xff != "" && a.fullCfg != nil && a.fullCfg.Proxy.TrustProxy &&
		isTrustedProxyAddr(host, a.fullCfg.Proxy.TrustedProxies) {
		host = strings.TrimSpace(strings.SplitN(xff, ",", 2)[0])
	}
	return host
}

// isTrustedProxyAddr reports whether ip belongs to the trusted proxy set
// (plain IP or CIDR). An empty set means nothing is trusted.
func isTrustedProxyAddr(ip string, trusted []string) bool {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	for _, c := range trusted {
		if c == "" {
			continue
		}
		if ip == c {
			return true
		}
		if _, network, err := net.ParseCIDR(c); err == nil && network.Contains(parsed) {
			return true
		}
	}
	return false
}

func (a *api) authFail(r *http.Request) {
	if a.failed == nil {
		a.failed = &sync.Map{}
	}
	ip := a.clientIPOf(r)
	v, _ := a.failed.LoadOrStore(ip, &authAttempt{})
	at := v.(*authAttempt)
	at.mu.Lock()
	at.fails++
	if at.fails >= authMaxFails {
		at.lockedUntil = time.Now().Add(authLockWindowSec * time.Second)
	}
	at.mu.Unlock()
}

func (a *api) authLocked(r *http.Request) bool {
	if a.failed == nil {
		return false
	}
	ip := a.clientIPOf(r)
	v, ok := a.failed.Load(ip)
	if !ok {
		return false
	}
	at := v.(*authAttempt)
	at.mu.Lock()
	defer at.mu.Unlock()
	if time.Now().Before(at.lockedUntil) {
		return true
	}
	if at.fails >= authMaxFails && time.Now().After(at.lockedUntil) {
		// window expired; reset the slate
		at.fails = 0
		at.lockedUntil = time.Time{}
	}
	return false
}

func (a *api) authReset(r *http.Request) {
	if a.failed == nil {
		return
	}
	ip := a.clientIPOf(r)
	a.failed.Delete(ip)
}

func (a *api) hasKey(r *http.Request) bool {
	if a.cfg.Secret == "" {
		return false
	}
	expect := []byte(a.cfg.Secret)
	if h := r.Header.Get("x-gs-key"); h != "" {
		if subtle.ConstantTimeCompare([]byte(h), expect) == 1 {
			return true
		}
	}
	if a := r.Header.Get("Authorization"); strings.HasPrefix(a, "Bearer ") {
		if subtle.ConstantTimeCompare([]byte(a[7:]), expect) == 1 {
			return true
		}
	}
	return false
}

func (a *api) fromLoopback(r *http.Request) bool {
	// Only the real connection IP counts, unless it comes from a trusted
	// proxy (same rule as clientIPOf). Reading XFF unconditionally lets a
	// remote client claim 127.0.0.1 and walk past the empty-secret
	// loopback allowance.
	ra := r.RemoteAddr
	if h, _, err := net.SplitHostPort(ra); err == nil {
		ra = h
	}
	if a.fullCfg != nil && a.fullCfg.Proxy.TrustProxy &&
		isTrustedProxyAddr(ra, a.fullCfg.Proxy.TrustedProxies) {
		if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
			ra = strings.TrimSpace(strings.SplitN(xff, ",", 2)[0])
		} else if xri := r.Header.Get("X-Real-IP"); xri != "" {
			ra = strings.TrimSpace(xri)
		}
	}
	host := ra
	if h, _, err := net.SplitHostPort(ra); err == nil {
		host = h
	}
	return host == "127.0.0.1" || host == "::1"
}

func (a *api) writeJSON(w http.ResponseWriter, status int, v any) {
	a.setHeaders(w)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

// ---------- GET handlers ----------

func (a *api) handleStats(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, a.shield.GetStats())
}

func (a *api) handleBlocklist(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, a.shield.BlocklistSnapshot())
}

func (a *api) handleWhitelist(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, a.shield.WhitelistSnapshot())
}

func (a *api) handleWhitelistDetailed(w http.ResponseWriter, _ *http.Request) {
	out := make([]map[string]any, 0)
	for _, ip := range a.shield.WhitelistSnapshot() {
		out = append(out, map[string]any{"ip": ip, "source": "manual"})
	}
	a.writeJSON(w, http.StatusOK, out)
}

func (a *api) handleTop(w http.ResponseWriter, _ *http.Request) {
	st := a.shield.GetStats()
	a.writeJSON(w, http.StatusOK, map[string]any{
		"ips":   st.TopIPs,
		"paths": st.TopPaths,
	})
}

// handleGeo returns traffic sources enriched with country/ASN.
//
// Enrichment happens here, at read time, rather than in the request pipeline:
// the hot path has a sub-millisecond budget and would gain nothing, while this
// endpoint only ever resolves the ~10-100 entries in the top-talkers window.
func (a *api) handleGeo(w http.ResponseWriter, _ *http.Request) {
	stats := a.shield.GetStats()

	type source struct {
		IP          string `json:"ip"`
		Requests    int64  `json:"requests"`
		CountryCode string `json:"countryCode,omitempty"`
		Country     string `json:"country,omitempty"`
		ASN         string `json:"asn,omitempty"`
		Org         string `json:"org,omitempty"`
	}
	type country struct {
		Code     string `json:"code"`
		Country  string `json:"country,omitempty"`
		Requests int64  `json:"requests"`
		Sources  int    `json:"sources"`
	}

	sources := make([]source, 0, len(stats.TopIPs))
	byCountry := map[string]*country{}

	for _, item := range stats.TopIPs {
		ip, ok := item[0].(string)
		if !ok || ip == "" {
			continue
		}
		requests := toInt64(item[1])
		loc := a.shield.GeoLookup(ip)
		sources = append(sources, source{
			IP: ip, Requests: requests,
			CountryCode: loc.CountryCode, Country: loc.Country,
			ASN: loc.ASN, Org: loc.Org,
		})
		if loc.CountryCode == "" {
			continue
		}
		agg := byCountry[loc.CountryCode]
		if agg == nil {
			agg = &country{Code: loc.CountryCode, Country: loc.Country}
			byCountry[loc.CountryCode] = agg
		}
		agg.Requests += requests
		agg.Sources++
	}

	countries := make([]country, 0, len(byCountry))
	for _, c := range byCountry {
		countries = append(countries, *c)
	}
	sort.Slice(countries, func(i, j int) bool { return countries[i].Requests > countries[j].Requests })

	a.writeJSON(w, http.StatusOK, map[string]any{
		"available": a.shield.GeoAvailable(),
		"sources":   sources,
		"countries": countries,
	})
}

// handleWhoami echoes the IP the engine resolved for the caller, and which
// source it came from. This is the fastest way to verify a trustProxy
// misconfiguration: if ipSource is "remoteAddr" behind a real proxy, the
// forwarded headers are being (correctly) ignored because the proxy is not in
// trustedProxies — and every per-IP decision is keyed on the proxy instead of
// the visitor.
//
// Only an allowlist of fields is returned. Request headers are never echoed
// wholesale: Authorization, Cookie and x-gs-key must not be reflected back.
func (a *api) handleWhoami(w http.ResponseWriter, r *http.Request) {
	var proxyCfg config.Proxy
	if a.fullCfg != nil {
		proxyCfg = a.fullCfg.Proxy
	}
	ip, source := resolveClientIP(r, proxyCfg)

	a.writeJSON(w, http.StatusOK, map[string]any{
		"ip":        ip,
		"ipSource":  source,
		"tls":       r.TLS != nil,
		"host":      r.Host,
		"userAgent": r.Header.Get("User-Agent"),
		// No trustProxy flag or geo lookup: both aid fingerprinting and
		// no dashboard surface consumes them.
	})
}

// resolveClientIP mirrors the engine's own client-IP resolution and reports
// which source won. Forwarded headers are honored only when TrustProxy is set
// AND the connection itself comes from a trusted proxy; otherwise a client
// could spoof its own IP with a header.
func resolveClientIP(r *http.Request, p config.Proxy) (ip, source string) {
	conn := r.RemoteAddr
	if host, _, err := net.SplitHostPort(conn); err == nil {
		conn = host
	}
	if !p.TrustProxy || !isTrustedProxy(conn, p.TrustedProxies) {
		return conn, "remoteAddr"
	}
	if p.RealIPHeader != "" {
		if v := strings.TrimSpace(r.Header.Get(p.RealIPHeader)); v != "" {
			return v, p.RealIPHeader
		}
	}
	if p.ForwardedForHeader != "" {
		if v := r.Header.Get(p.ForwardedForHeader); v != "" {
			if i := strings.IndexByte(v, ','); i >= 0 {
				v = v[:i]
			}
			if v = strings.TrimSpace(v); v != "" {
				return v, p.ForwardedForHeader
			}
		}
	}
	return conn, "remoteAddr"
}

func isTrustedProxy(ip string, trusted []string) bool {
	parsed := net.ParseIP(ip)
	if parsed == nil {
		return false
	}
	for _, entry := range trusted {
		if entry == "" {
			continue
		}
		if entry == ip {
			return true
		}
		if _, network, err := net.ParseCIDR(entry); err == nil && network.Contains(parsed) {
			return true
		}
	}
	return false
}

func toInt64(v any) int64 {
	switch n := v.(type) {
	case int:
		return int64(n)
	case int64:
		return n
	case float64:
		return int64(n)
	}
	return 0
}

func (a *api) handleLogs(w http.ResponseWriter, r *http.Request) {
	limit := atoiDefault(r.URL.Query().Get("limit"), 200)
	if limit <= 0 || limit > 1000 {
		limit = 200
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"logs": a.shield.Events(limit)})
}

func (a *api) handleReputation(w http.ResponseWriter, r *http.Request) {
	limit := atoiDefault(r.URL.Query().Get("limit"), 50)
	if limit <= 0 || limit > 500 {
		limit = 50
	}
	entries := a.shield.Rep.Top(limit)
	out := make([]map[string]any, 0, len(entries))
	for _, e := range entries {
		reason, _ := a.shield.Rep.GetReason(e.IP)
		out = append(out, map[string]any{"ip": e.IP, "score": e.Score, "reason": reason})
	}
	a.writeJSON(w, http.StatusOK, out)
}

func (a *api) handleMode(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, map[string]any{
		"aggressive": a.shield.AggressiveOn(),
		"emergency":  a.shield.EmergencyOn(),
		"flood":      a.shield.FloodOn(),
	})
}

func (a *api) handleStatus(w http.ResponseWriter, _ *http.Request) {
	a.setHeaders(w)
	w.Header().Set("Content-Type", "application/json")
	if a.mon != nil {
		_ = json.NewEncoder(w).Encode(a.mon.GetStatus())
		return
	}
	st := a.shield.GetStats()
	// Public counters only: blocklist/whitelist/top-talkers would hand
	// attackers evasion intel (what is blocked, what is trusted).
	_ = json.NewEncoder(w).Encode(map[string]any{
		"page":      "GarudaShield Status",
		"brand":     "GarudaShield",
		"version":   "3.0.0",
		"generated": time.Now().UTC().Format(time.RFC3339),
		"overall":   overallStatus(st),
		"components": []map[string]any{
			{"name": "Shield", "status": "ok"},
			{"name": "Proxy", "status": "ok"},
		},
		"incidents": []any{},
		"stats": map[string]any{
			"processed":    st.Processed,
			"blocked":      st.Blocked,
			"challenged":   st.Challenged,
			"passed":       st.Passed,
			"currentRps":   st.CurrentRPS,
			"attackActive": st.AttackActive,
		},
	})
}

func overallStatus(st shield.Stats) string {
	if st.AttackActive {
		return "degraded"
	}
	return "operational"
}

// ---------- POST handlers ----------

func (a *api) handleBlock(w http.ResponseWriter, r *http.Request) {
	var body struct {
		IP       string `json:"ip"`
		Duration int64  `json:"duration"`
		Reason   string `json:"reason"`
	}
	if !decodeJSON(w, r, &body) || body.IP == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	dur := body.Duration
	if dur <= 0 {
		dur = 3600000
	}
	reason := body.Reason
	if reason == "" {
		reason = "api"
	}
	a.shield.BlockIP(body.IP, dur, reason)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleUnblock(w http.ResponseWriter, r *http.Request) {
	var body struct {
		IP string `json:"ip"`
	}
	if !decodeJSON(w, r, &body) || body.IP == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.UnblockIP(body.IP)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleWhitelistAdd(w http.ResponseWriter, r *http.Request) {
	var body struct {
		IP string `json:"ip"`
	}
	if !decodeJSON(w, r, &body) || body.IP == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.WhitelistIP(body.IP)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleWhitelistRemove(w http.ResponseWriter, r *http.Request) {
	var body struct {
		IP string `json:"ip"`
	}
	if !decodeJSON(w, r, &body) || body.IP == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.UnwhitelistIP(body.IP)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleModeSet(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Mode string `json:"mode"`
	}
	if !decodeJSON(w, r, &body) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	switch body.Mode {
	case "aggressive":
		a.shield.SetAggressive(true)
	case "normal", "calm":
		a.shield.SetAggressive(false)
	case "emergency":
		a.shield.SetEmergency(true)
	default:
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-mode"})
		return
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "mode": body.Mode})
}

func (a *api) handleEmergency(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Enabled bool `json:"enabled"`
	}
	if !decodeJSON(w, r, &body) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.SetEmergency(body.Enabled)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "emergency": body.Enabled})
}

func (a *api) handleReputationReset(w http.ResponseWriter, r *http.Request) {
	var body struct {
		IP string `json:"ip"`
	}
	if !decodeJSON(w, r, &body) || body.IP == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.Rep.Reset(body.IP)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleAlertsConfig(w http.ResponseWriter, _ *http.Request) {
	if a.al == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{"enabled": false})
		return
	}
	a.writeJSON(w, http.StatusOK, a.al.Status())
}

func (a *api) handleAlertsLog(w http.ResponseWriter, r *http.Request) {
	if a.al == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{"log": []any{}, "totalSent": 0})
		return
	}
	n := atoiDefault(r.URL.Query().Get("limit"), 200)
	a.writeJSON(w, http.StatusOK, map[string]any{"log": a.al.History(n)})
}

func (a *api) handleAlertsTest(w http.ResponseWriter, _ *http.Request) {
	if a.al == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{"ok": false, "error": "alerts-unavailable"})
		return
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "result": a.al.Test()})
}

// ---------- v2-parity management endpoints ----------

func (a *api) handleWAFGet(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, map[string]any{
		"config": a.shield.WAF.Config(),
		"rules":  a.shield.WAF.Rules(),
		"stats":  a.shield.WAF.Stats(),
	})
}

func (a *api) handleWAFSet(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Modules map[string]bool  `json:"modules"`
		Rules   []config.WAFRule `json:"rules"`
	}
	if !decodeJSON(w, r, &body) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	for name, on := range body.Modules {
		a.shield.WAF.SetModule(name, on)
	}
	for _, rule := range body.Rules {
		a.shield.WAF.AddCustomRule(rule)
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleRatelimitGet(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, map[string]any{
		"config": a.shield.Rate.Config(),
		"stats":  a.shield.Rate.Stats(),
	})
}

func (a *api) handleRatelimitSet(w http.ResponseWriter, r *http.Request) {
	var patch config.RateLimitConfig
	if !decodeJSON(w, r, &patch) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.Rate.UpdateConfig(patch)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "config": a.shield.Rate.Config()})
}

func (a *api) handleRulesGet(w http.ResponseWriter, _ *http.Request) {
	a.writeJSON(w, http.StatusOK, map[string]any{"rules": a.shield.WAF.Rules()})
}

func (a *api) handleRulesAdd(w http.ResponseWriter, r *http.Request) {
	var rule config.WAFRule
	if !decodeJSON(w, r, &rule) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.shield.WAF.AddCustomRule(rule)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleRulesClear(w http.ResponseWriter, _ *http.Request) {
	a.shield.WAF.ClearCustomRules()
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

// handleCluster reports sync-node status. It never fails because a peer is
// missing: with one active node it answers "1 / 1 Online", and an unreachable
// optional node is reported as unavailable rather than as an error.
func (a *api) handleCluster(w http.ResponseWriter, _ *http.Request) {
	if a.ps != nil {
		a.writeJSON(w, http.StatusOK, a.ps.Status())
		return
	}
	// No PeerSync wired (embedded/unit use): fall back to the config so the
	// dashboard still gets a consistent, single-node shape.
	a.writeJSON(w, http.StatusOK, staticClusterStatus(a.fullCfg))
}

// staticClusterStatus mirrors PeerSync.Status for the no-sync path so the API
// contract stays identical regardless of how the engine was wired.
func staticClusterStatus(cc *config.Config) map[string]any {
	var nodes []cluster.NodeStatus
	id, role, site := "", "", ""
	if cc != nil {
		id, role, site = cc.Cluster.NodeID, cc.Cluster.Role, cc.Cluster.Site
	}
	if id == "" {
		// Resolve the local identity before evaluating the topology: otherwise a
		// config without an explicit nodeId would report its own node as a peer.
		id = "node-1"
	}
	if cc != nil {
		for _, n := range cc.Cluster.Topology() {
			state := cluster.NodeOnline
			note := "local node serving; sync bus disabled (single-node mode)"
			if n.ID != id {
				state = cluster.NodeUnknown
				note = "cross-node sync disabled; peer state not observable"
			}
			nodes = append(nodes, cluster.NodeStatus{
				ID: n.ID, Address: n.Address, Role: n.Role, Site: n.Site,
				Required: n.Required, Self: n.ID == id, State: state, Note: note,
			})
		}
	}
	if len(nodes) == 0 {
		nodes = []cluster.NodeStatus{{ID: id, Self: true, State: cluster.NodeOnline,
			Note: "local node serving; sync bus disabled (single-node mode)"}}
	}
	online := 0
	for _, n := range nodes {
		if n.State == cluster.NodeOnline {
			online++
		}
	}
	mode := "single"
	if len(nodes) > 1 {
		mode = "cluster"
	}
	return map[string]any{
		"enabled":         false,
		"nodeId":          id,
		"connected":       false,
		"mode":            mode,
		"role":            role,
		"site":            site,
		"expectedNodes":   len(nodes),
		"onlineNodes":     online,
		"requiredOffline": 0,
		"state":           "online",
		"degraded":        false,
		"subscribed":      false,
		"reconnects":      0,
		"heartbeatMs":     0,
		"lastSentMs":      int64(0),
		"lastSyncMs":      int64(0),
		"lastSeenMs":      int64(0),
		"appliedOps":      int64(0),
		"lastError":       "",
		"nodes":           nodes,
	}
}

func (a *api) handleBackup(w http.ResponseWriter, _ *http.Request) {
	snap := map[string]any{
		"blocklist":  a.shield.BlocklistSnapshot(),
		"whitelist":  a.shield.WhitelistSnapshot(),
		"waf":        a.shield.WAF.Config(),
		"ratelimit":  a.shield.Rate.Config(),
		"reputation": a.shield.Rep.Top(500),
		"access": func() map[string]any {
			if a.gate == nil {
				return map[string]any{}
			}
			return map[string]any{"protectAll": a.gate.ProtectAll(), "hosts": a.gate.Hosts()}
		}(),
	}
	a.writeJSON(w, http.StatusOK, snap)
}

func (a *api) handleBackupRestore(w http.ResponseWriter, r *http.Request) {
	var snap struct {
		Blocklist []string               `json:"blocklist"`
		Whitelist []string               `json:"whitelist"`
		WAF       config.WAFConfig       `json:"waf"`
		Ratelimit config.RateLimitConfig `json:"ratelimit"`
		Access    *config.Access         `json:"access"`
	}
	if !decodeJSON(w, r, &snap) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	for _, ip := range snap.Blocklist {
		a.shield.BlockIP(ip, 3600000, "restore")
	}
	for _, ip := range snap.Whitelist {
		a.shield.WhitelistIP(ip)
	}
	a.shield.Rate.UpdateConfig(snap.Ratelimit)
	wc := snap.WAF
	a.shield.WAF.SetModule("sqli", wc.SQLi)
	a.shield.WAF.SetModule("xss", wc.XSS)
	a.shield.WAF.SetModule("cmdi", wc.CommandInjection)
	a.shield.WAF.SetModule("ptrav", wc.PathTraversal)
	a.shield.WAF.SetModule("lfi", wc.LFI)
	a.shield.WAF.SetModule("rfi", wc.RFI)
	if snap.Access != nil && a.gate != nil {
		a.gate.SetProtectAll(snap.Access.ProtectAll)
		for h, en := range snap.Access.Hosts {
			a.gate.SetHost(h, en)
		}
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleConfigGet(w http.ResponseWriter, _ *http.Request) {
	if a.fullCfg == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{})
		return
	}
	// Never dump live secrets to any key holder: return a redacted copy.
	b, err := json.Marshal(a.fullCfg)
	if err != nil {
		a.writeJSON(w, http.StatusOK, map[string]any{})
		return
	}
	var m map[string]any
	if err := json.Unmarshal(b, &m); err != nil {
		a.writeJSON(w, http.StatusOK, map[string]any{})
		return
	}
	redactSecrets(m)
	a.writeJSON(w, http.StatusOK, m)
}

// redactSecrets masks credential-shaped values in place (key contains
// secret, password, token, or webhook/hook url). Operates on the
// JSON-marshalled copy so the live config is untouched.
func redactSecrets(m map[string]any) {
	for k, v := range m {
		switch t := v.(type) {
		case map[string]any:
			redactSecrets(t)
		case string:
			lk := strings.ToLower(k)
			if strings.Contains(lk, "secret") || strings.Contains(lk, "password") ||
				strings.Contains(lk, "token") || strings.Contains(lk, "webhook") ||
				strings.Contains(lk, "hookurl") || strings.Contains(lk, "smtpPass") {
				if t != "" {
					m[k] = "***"
				}
			}
		}
	}
}

func (a *api) handleConfigSet(w http.ResponseWriter, r *http.Request) {
	var body config.Config
	if !decodeJSON(w, r, &body) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	wc := body.Defense.WAF
	a.shield.WAF.SetModule("sqli", wc.SQLi)
	a.shield.WAF.SetModule("xss", wc.XSS)
	a.shield.WAF.SetModule("cmdi", wc.CommandInjection)
	a.shield.WAF.SetModule("ptrav", wc.PathTraversal)
	a.shield.WAF.SetModule("lfi", wc.LFI)
	a.shield.WAF.SetModule("rfi", wc.RFI)
	if body.Defense.RateLimit.PerIPRPS > 0 || body.Defense.RateLimit.GlobalMaxRPS > 0 {
		a.shield.Rate.UpdateConfig(body.Defense.RateLimit)
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleReset(w http.ResponseWriter, _ *http.Request) {
	a.shield.Reset()
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true})
}

func (a *api) handleAccessHosts(w http.ResponseWriter, _ *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{"hosts": map[string]bool{}, "protectAll": false})
		return
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"hosts": a.gate.Hosts(), "protectAll": a.gate.ProtectAll()})
}

func (a *api) handleAccessHostsSet(w http.ResponseWriter, r *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusServiceUnavailable, map[string]string{"error": "access-unavailable"})
		return
	}
	var body struct {
		Host    string `json:"host"`
		Enabled bool   `json:"enabled"`
	}
	if !decodeJSON(w, r, &body) || body.Host == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.gate.SetHost(body.Host, body.Enabled)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "hosts": a.gate.Hosts()})
}

func (a *api) handleAccessHostsRemove(w http.ResponseWriter, r *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusServiceUnavailable, map[string]string{"error": "access-unavailable"})
		return
	}
	var body struct {
		Host string `json:"host"`
	}
	if !decodeJSON(w, r, &body) || body.Host == "" {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.gate.RemoveHost(strings.ToLower(strings.TrimSpace(body.Host)))
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "hosts": a.gate.Hosts()})
}

func (a *api) handleAccessProtectAll(w http.ResponseWriter, _ *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{"protectAll": false})
		return
	}
	a.writeJSON(w, http.StatusOK, map[string]any{"protectAll": a.gate.ProtectAll()})
}

func (a *api) handleAccessProtectAllSet(w http.ResponseWriter, r *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusServiceUnavailable, map[string]string{"error": "access-unavailable"})
		return
	}
	var body struct {
		Enabled bool `json:"enabled"`
	}
	if !decodeJSON(w, r, &body) {
		a.writeJSON(w, http.StatusBadRequest, map[string]string{"error": "invalid-request"})
		return
	}
	a.gate.SetProtectAll(body.Enabled)
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "protectAll": a.gate.ProtectAll()})
}

func (a *api) handleAccessCookies(w http.ResponseWriter, _ *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusOK, map[string]any{})
		return
	}
	a.writeJSON(w, http.StatusOK, map[string]any{
		"cookieName":   a.gate.CookieName(),
		"queryParam":   a.gate.QueryParam(),
		"cookieSecure": a.gate.CookieSecure(),
		"cookieDomain": a.gate.CookieDomain(),
	})
}

func (a *api) handleAccessToggle(w http.ResponseWriter, r *http.Request) {
	if a.gate == nil {
		a.writeJSON(w, http.StatusServiceUnavailable, map[string]string{"error": "access-unavailable"})
		return
	}
	a.gate.SetProtectAll(!a.gate.ProtectAll())
	a.writeJSON(w, http.StatusOK, map[string]any{"ok": true, "protectAll": a.gate.ProtectAll()})
}

// ---------- SSE ----------

func (a *api) handleStream(w http.ResponseWriter, r *http.Request) {
	a.setHeaders(w)
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Connection", "keep-alive")
	flusher, ok := w.(http.Flusher)
	if !ok {
		a.writeJSON(w, http.StatusInternalServerError, map[string]string{"error": "streaming-unsupported"})
		return
	}
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()
	// initial frame
	a.streamFrame(w, flusher)
	for {
		select {
		case <-r.Context().Done():
			return
		case <-ticker.C:
			a.streamFrame(w, flusher)
		}
	}
}

func (a *api) streamFrame(w http.ResponseWriter, flusher http.Flusher) {
	data, err := json.Marshal(a.shield.GetStats())
	if err != nil {
		return
	}
	_, _ = w.Write([]byte("data: "))
	_, _ = w.Write(data)
	_, _ = w.Write([]byte("\n\n"))
	flusher.Flush()
}

// ---------- helpers ----------

func decodeJSON(w http.ResponseWriter, r *http.Request, v any) bool {
	if r.Body == nil {
		return false
	}
	defer r.Body.Close()
	// Cap admin bodies: unauthenticated size games must not reach json.Decode.
	r.Body = http.MaxBytesReader(w, r.Body, 1<<20)
	if err := json.NewDecoder(r.Body).Decode(v); err != nil {
		return false
	}
	return true
}

func atoiDefault(s string, def int) int {
	if s == "" {
		return def
	}
	n, err := strconv.Atoi(s)
	if err != nil {
		return def
	}
	return n
}

func hostname() string {
	h, err := os.Hostname()
	if err != nil || h == "" {
		return "unknown"
	}
	return h
}
