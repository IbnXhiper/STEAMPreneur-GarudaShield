package admin

import (
	"net/http"

	"github.com/ahkurdev/garudashield/internal/auth"
)

// requireRole authenticates the signed session cookie and enforces a minimum
// role. The tenant/user/role are resolved server-side (never from the request),
// and a role below the minimum gets 403. Deny-by-default.
func requireRole(ah *auth.Handler, min string, next func(http.ResponseWriter, *http.Request, auth.Principal)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		p, err := ah.PrincipalFromRequest(r)
		if err != nil {
			writeJSONError(w, http.StatusUnauthorized, "unauthorized")
			return
		}
		if !auth.RoleAtLeast(p.Role, min) {
			writeJSONError(w, http.StatusForbidden, "insufficient role")
			return
		}
		next(w, r, p)
	}
}

// roleShim adapts a tenant-id handler to the requireRole principal handler.
func roleShim(min string, ah *auth.Handler, next func(http.ResponseWriter, *http.Request, string)) http.HandlerFunc {
	return requireRole(ah, min, func(w http.ResponseWriter, r *http.Request, p auth.Principal) {
		next(w, r, p.TenantID)
	})
}
