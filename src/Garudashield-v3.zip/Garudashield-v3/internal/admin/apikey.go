package admin

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/apikey"
	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// apiKeyHandler serves tenant-scoped API key management. Every endpoint is
// authenticated by the signed session cookie (auth.Handler) and acts only on
// the caller's own tenant — there is no path parameter that selects a tenant.
type apiKeyHandler struct {
	store *apikey.Store
	ts    *tenant.Store
	ah    *auth.Handler
}

// registerAPIKeys mounts the versioned API key surface:
//
//	GET    /api/v1/keys       — list the tenant's keys (masked)
//	POST   /api/v1/keys       — mint a key (raw secret returned exactly once)
//	DELETE /api/v1/keys/{id}  — revoke one of the tenant's keys
//
// The endpoints are additive to the v2-compatible /api/* surface and reuse the
// same session authentication (no separate credential store).
func registerAPIKeys(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler) {
	h := &apiKeyHandler{store: apikey.New(ts.Pool()), ts: ts, ah: ah}
	mux.HandleFunc("GET /api/v1/keys", h.requireSession(h.list))
	// Minting/revoking credentials is a privileged (admin+) action.
	mux.HandleFunc("POST /api/v1/keys", roleShim(auth.RoleAdmin, ah, h.create))
	mux.HandleFunc("DELETE /api/v1/keys/{id}", roleShim(auth.RoleAdmin, ah, h.revoke))
}

func (h *apiKeyHandler) requireSession(next func(http.ResponseWriter, *http.Request, string)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tid, err := h.ah.TenantFromRequest(r)
		if err != nil {
			writeJSONError(w, http.StatusUnauthorized, "unauthorized")
			return
		}
		next(w, r, tid)
	}
}

func (h *apiKeyHandler) list(w http.ResponseWriter, r *http.Request, tid string) {
	keys, err := h.store.List(r.Context(), tid)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	// Return the masked view only; the raw secret is never retrievable.
	type row struct {
		apikey.Key
		Masked string `json:"masked"`
	}
	out := make([]row, 0, len(keys))
	for _, k := range keys {
		out = append(out, row{Key: k, Masked: k.Masked()})
	}
	writeJSON(w, http.StatusOK, map[string]any{"keys": out})
}

func (h *apiKeyHandler) create(w http.ResponseWriter, r *http.Request, tid string) {
	var req struct {
		Name    string   `json:"name"`
		Scopes  []string `json:"scopes"`
		TTLDays int      `json:"ttlDays"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil {
		writeJSONError(w, http.StatusBadRequest, "bad request")
		return
	}
	req.Name = strings.TrimSpace(req.Name)
	if req.Name == "" || len(req.Name) > 64 {
		writeJSONError(w, http.StatusBadRequest, "name required (<=64 chars)")
		return
	}
	if req.TTLDays < 0 || req.TTLDays > 3650 {
		writeJSONError(w, http.StatusBadRequest, "ttlDays out of range (0-3650)")
		return
	}
	ttl := time.Duration(req.TTLDays) * 24 * time.Hour
	raw, k, err := h.store.Create(r.Context(), tid, req.Name, req.Scopes, ttl)
	if err != nil {
		// normalizeScopes rejects unknown scopes; treat that as a client error.
		if strings.Contains(err.Error(), "scope") {
			writeJSONError(w, http.StatusBadRequest, err.Error())
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.ts.Audit(r.Context(), tid, "tenant", "apikey.create",
		"name="+k.Name+" prefix="+k.Prefix+" scopes="+strings.Join(req.Scopes, ","), r.RemoteAddr)
	// raw is returned exactly once and never persisted anywhere else.
	writeJSON(w, http.StatusCreated, map[string]any{
		"key":    raw,
		"meta":   k,
		"notice": "Simpan key ini sekarang; tidak akan ditampilkan lagi.",
	})
}

func (h *apiKeyHandler) revoke(w http.ResponseWriter, r *http.Request, tid string) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		writeJSONError(w, http.StatusBadRequest, "invalid id")
		return
	}
	if err := h.store.Revoke(r.Context(), tid, id); err != nil {
		if errors.Is(err, apikey.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.ts.Audit(r.Context(), tid, "tenant", "apikey.revoke",
		"id="+strconv.FormatInt(id, 10), r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "id": id})
}

// ---------- shared JSON helpers ----------

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Cache-Control", "no-store")
	w.Header().Set("X-Content-Type-Options", "nosniff")
	w.WriteHeader(status)
	_ = json.NewEncoder(w).Encode(v)
}

func writeJSONError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}
