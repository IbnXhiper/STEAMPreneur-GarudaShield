package admin

import (
	"bufio"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"net/http/httptest"
	"strings"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/cluster"
	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/shield"
)

func newTestServer(t *testing.T, secret string) (*httptest.Server, *shield.Shield) {
	t.Helper()
	cfg := config.Default()
	cfg.Admin = config.AdminConfig{Enabled: true, Secret: secret}
	sh := shield.New(cfg)
	mux := http.NewServeMux()
	Register(mux, sh, nil, nil, cfg.Admin, nil, nil, &cfg)
	srv := httptest.NewServer(mux)
	t.Cleanup(func() {
		srv.Close()
		sh.Close()
	})
	return srv, sh
}

// newTestServerWithSync is newTestServer with a real PeerSync attached, so the
// node-topology endpoints are exercised end to end (no Redis needed: a
// single-node topology must report itself as online).
func newTestServerWithSync(t *testing.T, secret string, cc config.Cluster) *httptest.Server {
	t.Helper()
	cfg := config.Default()
	cfg.Admin = config.AdminConfig{Enabled: true, Secret: secret}
	cfg.Cluster = cc
	sh := shield.New(cfg)
	ps := cluster.New(sh.Store(), cfg.Cluster)
	ps.Start()
	mux := http.NewServeMux()
	Register(mux, sh, nil, nil, cfg.Admin, nil, ps, &cfg)
	srv := httptest.NewServer(mux)
	t.Cleanup(func() {
		srv.Close()
		ps.Stop()
		sh.Close()
	})
	return srv
}

func TestStatusPublic(t *testing.T) {
	srv, _ := newTestServer(t, "key")
	resp, err := http.Get(srv.URL + "/api/status")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("status = %d, want 200", resp.StatusCode)
	}
	var body map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		t.Fatal(err)
	}
	if body["brand"] != "GarudaShield" {
		t.Fatalf("brand = %v", body["brand"])
	}
}

func TestAuthRequired(t *testing.T) {
	srv, _ := newTestServer(t, "secret123")
	// without key -> forbidden
	resp, err := http.Get(srv.URL + "/api/stats")
	if err != nil {
		t.Fatal(err)
	}
	resp.Body.Close()
	if resp.StatusCode != http.StatusForbidden {
		t.Fatalf("no-key status = %d, want 403", resp.StatusCode)
	}
	// with correct key -> ok
	req, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/stats", nil)
	req.Header.Set("x-gs-key", "secret123")
	resp2, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != http.StatusOK {
		t.Fatalf("key status = %d, want 200", resp2.StatusCode)
	}
	// wrong key -> forbidden
	req3, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/stats", nil)
	req3.Header.Set("x-gs-key", "wrong")
	resp3, err := http.DefaultClient.Do(req3)
	if err != nil {
		t.Fatal(err)
	}
	resp3.Body.Close()
	if resp3.StatusCode != http.StatusForbidden {
		t.Fatalf("wrong-key status = %d, want 403", resp3.StatusCode)
	}
}

func TestLoopbackAllowedWhenNoSecret(t *testing.T) {
	srv, _ := newTestServer(t, "") // secret empty -> loopback allowed
	resp, err := http.Get(srv.URL + "/api/stats")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("loopback status = %d, want 200", resp.StatusCode)
	}
}

func TestBlockWhitelistFlow(t *testing.T) {
	srv, _ := newTestServer(t, "")
	// block
	postOK(t, srv, "/api/block", `{"ip":"203.0.113.5","duration":60000,"reason":"test"}`)
	// verify in blocklist
	resp, _ := http.Get(srv.URL + "/api/blocklist")
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if !strings.Contains(string(body), "203.0.113.5") {
		t.Fatalf("blocklist missing ip: %s", body)
	}
	// whitelist
	postOK(t, srv, "/api/whitelist", `{"ip":"198.51.100.9"}`)
	resp2, _ := http.Get(srv.URL + "/api/whitelist")
	body2, _ := io.ReadAll(resp2.Body)
	resp2.Body.Close()
	if !strings.Contains(string(body2), "198.51.100.9") {
		t.Fatalf("whitelist missing ip: %s", body2)
	}
	// unblock
	postOK(t, srv, "/api/unblock", `{"ip":"203.0.113.5"}`)
}

func TestModeFlow(t *testing.T) {
	srv, _ := newTestServer(t, "")
	postOK(t, srv, "/api/mode", `{"mode":"aggressive"}`)
	resp, _ := http.Get(srv.URL + "/api/mode")
	body, _ := io.ReadAll(resp.Body)
	resp.Body.Close()
	if !strings.Contains(string(body), `"aggressive":true`) {
		t.Fatalf("mode not aggressive: %s", body)
	}
	postOK(t, srv, "/api/emergency", `{"enabled":true}`)
	resp2, _ := http.Get(srv.URL + "/api/mode")
	body2, _ := io.ReadAll(resp2.Body)
	resp2.Body.Close()
	if !strings.Contains(string(body2), `"emergency":true`) {
		t.Fatalf("emergency not on: %s", body2)
	}
}

func TestReputationReset(t *testing.T) {
	srv, _ := newTestServer(t, "")
	postOK(t, srv, "/api/reputation/reset", `{"ip":"192.0.2.4"}`)
	// just assert ok path works (200)
}

func TestSSEStream(t *testing.T) {
	srv, _ := newTestServer(t, "")
	req, _ := http.NewRequest(http.MethodGet, srv.URL+"/api/stats/stream", nil)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if ct := resp.Header.Get("Content-Type"); ct != "text/event-stream" {
		t.Fatalf("content-type = %q, want text/event-stream", ct)
	}
	// read first frame within 2s
	done := make(chan string, 1)
	go func() {
		sc := bufio.NewScanner(resp.Body)
		if sc.Scan() {
			done <- sc.Text()
		}
		close(done)
	}()
	select {
	case line := <-done:
		if !strings.HasPrefix(line, "data: ") {
			t.Fatalf("frame = %q, want prefix 'data: '", line)
		}
	case <-time.After(3 * time.Second):
		t.Fatal("no SSE frame within 3s")
	}
}

func postOK(t *testing.T, srv *httptest.Server, path, payload string) {
	t.Helper()
	req, _ := http.NewRequest("POST", srv.URL+path, strings.NewReader(payload))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-gs-key", "key")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		t.Fatalf("POST %s status = %d, body=%s", path, resp.StatusCode, b)
	}
	var body map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		t.Fatal(err)
	}
	if body["ok"] != true {
		t.Fatalf("POST %s ok != true: %v", path, body)
	}
}

// authGet issues an authed GET and fails the test on a non-200.
func authGet(t *testing.T, srv *httptest.Server, path string) map[string]any {
	t.Helper()
	req, _ := http.NewRequest("GET", srv.URL+path, nil)
	req.Header.Set("x-gs-key", "key")
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		b, _ := io.ReadAll(resp.Body)
		t.Fatalf("GET %s status = %d, body=%s", path, resp.StatusCode, b)
	}
	var body map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&body); err != nil {
		t.Fatal(err)
	}
	return body
}

// TestManagementEndpoints covers the v2-parity endpoints added in P1.
func TestManagementEndpoints(t *testing.T) {
	srv, _ := newTestServer(t, "key")

	// WAF: GET has config; POST toggles a module and is accepted.
	if got := authGet(t, srv, "/api/waf"); got["config"] == nil {
		t.Fatalf("/api/waf missing config: %v", got)
	}
	postOK(t, srv, "/api/waf", `{"modules":{"sqli":false}}`)
	if got := authGet(t, srv, "/api/waf"); got["config"] == nil {
		t.Fatalf("/api/waf config missing after set: %v", got)
	}

	// Ratelimit GET/POST.
	if got := authGet(t, srv, "/api/ratelimit"); got["config"] == nil {
		t.Fatalf("/api/ratelimit missing config: %v", got)
	}
	postOK(t, srv, "/api/ratelimit", `{"perIPRPS":100}`)

	// Cluster: a missing peer sync must still answer with a consistent
	// single-node shape (never an error, never "1 / 2").
	if got := authGet(t, srv, "/api/cluster"); got["enabled"] != false {
		t.Fatalf("/api/cluster enabled should be false: %v", got)
	}

	// Backup returns the snapshot envelope.
	if got := authGet(t, srv, "/api/backup"); got["blocklist"] == nil || got["waf"] == nil {
		t.Fatalf("/api/backup missing fields: %v", got)
	}

	// Access endpoints degrade gracefully (gate nil in test server).
	if got := authGet(t, srv, "/api/access/hosts"); got["hosts"] == nil {
		t.Fatalf("/api/access/hosts missing: %v", got)
	}

	// Reset is accepted.
	postOK(t, srv, "/api/reset", `{}`)

	// Notifications alias returns alerts config shape.
	if got := authGet(t, srv, "/api/notifications"); got["enabled"] == nil {
		t.Fatalf("/api/notifications missing enabled: %v", got)
	}
}

// numField reads a JSON number from a decoded body. encoding/json decodes into
// float64, so comparing got["x"] != 1 (an int) would always fail.
func numField(t *testing.T, body map[string]any, key string) float64 {
	t.Helper()
	v, ok := body[key].(float64)
	if !ok {
		t.Fatalf("%s missing or not a number in %v", key, body)
	}
	return v
}

// TestClusterSingleNodeShape: /api/cluster reports the node topology the
// dashboard renders ("1 / 1 Online" for a single active node).
func TestClusterSingleNodeShape(t *testing.T) {
	srv := newTestServerWithSync(t, "key", config.Default().Cluster)
	got := authGet(t, srv, "/api/cluster")

	if got["nodeId"] != "node-1" {
		t.Errorf("nodeId should default to node-1: %v", got)
	}
	if n := numField(t, got, "expectedNodes"); n != 1 {
		t.Errorf("expectedNodes should be 1 for a single-node deployment, got %v: %v", n, got)
	}
	if n := numField(t, got, "onlineNodes"); n != 1 {
		t.Errorf("onlineNodes should be 1 (the local node is always online), got %v: %v", n, got)
	}
	if got["mode"] != "single" {
		t.Errorf("mode should be single: %v", got)
	}
	if got["state"] != "online" {
		t.Errorf("state should be online: %v", got)
	}
	nodes, _ := got["nodes"].([]any)
	if len(nodes) != 1 {
		t.Fatalf("expected exactly one node entry: %v", got)
	}
	first, _ := nodes[0].(map[string]any)
	if first["self"] != true || first["state"] != "online" || first["id"] != "node-1" {
		t.Errorf("unexpected node entry: %v", first)
	}
}

// TestClusterOptionalPeerStaysSingleServing: with a second node configured but
// unreachable, the API must stay 200 and report the peer as unavailable.
func TestClusterOptionalPeerStaysSingleServing(t *testing.T) {
	cc := config.Default().Cluster
	cc.NodeID = "node-1"
	cc.Nodes = []config.Node{{ID: "node-1"}, {ID: "node-2", Address: "10.0.0.9:8080"}}
	srv := newTestServerWithSync(t, "key", cc)

	got := authGet(t, srv, "/api/cluster")
	if n := numField(t, got, "expectedNodes"); n != 2 {
		t.Errorf("expectedNodes should follow the config, got %v: %v", n, got)
	}
	if n := numField(t, got, "onlineNodes"); n != 1 {
		t.Errorf("only the local node can be online without a bus, got %v: %v", n, got)
	}
	if got["degraded"] != false {
		t.Errorf("an optional peer must not degrade the cluster: %v", got)
	}
	nodes, _ := got["nodes"].([]any)
	if len(nodes) != 2 {
		t.Fatalf("expected two node entries: %v", got)
	}
	peer, _ := nodes[1].(map[string]any)
	if peer["state"] != "unknown" {
		t.Errorf("peer state should be unknown when sync is off: %v", peer)
	}
}

// TestAuthBruteForceLockout: 5 wrong keys from one IP -> 6th gets 429.
func TestAuthBruteForceLockout(t *testing.T) {
	srv, _ := newTestServer(t, "key")
	try := func() int {
		req, _ := http.NewRequest("GET", srv.URL+"/api/stats", nil)
		req.Header.Set("x-gs-key", "SALAH")
		resp, err := srv.Client().Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		return resp.StatusCode
	}
	for i := 0; i < 5; i++ {
		if got := try(); got != http.StatusForbidden {
			t.Fatalf("attempt %d = %d, want 403", i+1, got)
		}
	}
	if got := try(); got != http.StatusTooManyRequests {
		t.Fatalf("attempt 6 = %d, want 429", got)
	}
}

// TestAuthLockoutIgnoresSpoofedXFF: with TrustProxy on but no trusted proxies
// configured (default), rotating X-Forwarded-For must NOT reset the per-IP
// failure counter — all failures count against the connection IP.
func TestAuthLockoutIgnoresSpoofedXFF(t *testing.T) {
	srv, _ := newTestServer(t, "key")
	try := func(xff string) int {
		req, _ := http.NewRequest("GET", srv.URL+"/api/stats", nil)
		req.Header.Set("x-gs-key", "SALAH")
		if xff != "" {
			req.Header.Set("X-Forwarded-For", xff)
		}
		resp, err := srv.Client().Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		return resp.StatusCode
	}
	for i := 0; i < 5; i++ {
		if got := try(fmt.Sprintf("9.9.9.%d", i+1)); got != http.StatusForbidden {
			t.Fatalf("spoofed attempt %d = %d, want 403", i+1, got)
		}
	}
	if got := try(""); got != http.StatusTooManyRequests {
		t.Fatalf("6th attempt after XFF rotation = %d, want 429", got)
	}
}

// TestAuthLockoutPerXFFBehindTrustedProxy: when the connection comes from a
// configured trusted proxy, XFF selects the identity — distinct XFFs get
// distinct failure budgets, and exhausting one XFF locks only that identity.
func TestAuthLockoutPerXFFBehindTrustedProxy(t *testing.T) {
	cfg := config.Default()
	cfg.Admin = config.AdminConfig{Enabled: true, Secret: "key"}
	cfg.Proxy.TrustedProxies = []string{"127.0.0.1"}
	sh := shield.New(cfg)
	mux := http.NewServeMux()
	Register(mux, sh, nil, nil, cfg.Admin, nil, nil, &cfg)
	srv := httptest.NewServer(mux)
	t.Cleanup(func() {
		srv.Close()
		sh.Close()
	})
	try := func(xff string) int {
		req, _ := http.NewRequest("GET", srv.URL+"/api/stats", nil)
		req.Header.Set("x-gs-key", "SALAH")
		req.Header.Set("X-Forwarded-For", xff)
		resp, err := srv.Client().Do(req)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		io.Copy(io.Discard, resp.Body)
		return resp.StatusCode
	}
	// 5 distinct identities: none may trip the lockout alone.
	for i := 0; i < 5; i++ {
		if got := try(fmt.Sprintf("10.0.0.%d", i+1)); got != http.StatusForbidden {
			t.Fatalf("distinct XFF %d = %d, want 403", i+1, got)
		}
	}
	// Exhaust one identity: 5 more fails on 10.9.9.9 then locked.
	for i := 0; i < 5; i++ {
		if got := try("10.9.9.9"); got != http.StatusForbidden {
			t.Fatalf("repeat XFF attempt %d = %d, want 403", i+1, got)
		}
	}
	if got := try("10.9.9.9"); got != http.StatusTooManyRequests {
		t.Fatalf("exhausted XFF = %d, want 429", got)
	}
	// A fresh identity still passes through to 403 (not globally locked).
	if got := try("10.9.9.10"); got != http.StatusForbidden {
		t.Fatalf("fresh XFF = %d, want 403", got)
	}
}

// TestLoopbackSpoofDenied: fromLoopback must ignore forged X-Forwarded-For
// from untrusted connections (only real RemoteAddr counts).
func TestLoopbackSpoofDenied(t *testing.T) {
	cfg := config.Default()
	a := &api{cfg: config.AdminConfig{}, fullCfg: &cfg}
	mk := func(remote, xff string) *http.Request {
		req := httptest.NewRequest("GET", "/api/stats", nil)
		req.RemoteAddr = remote
		if xff != "" {
			req.Header.Set("X-Forwarded-For", xff)
		}
		return req
	}
	if !a.fromLoopback(mk("127.0.0.1:1234", "")) {
		t.Fatal("real loopback must pass")
	}
	if a.fromLoopback(mk("203.0.113.9:1234", "127.0.0.1")) {
		t.Fatal("spoofed XFF loopback bypassed auth")
	}
	if a.fromLoopback(mk("203.0.113.9:1234", "")) {
		t.Fatal("remote must not be loopback")
	}
}

// TestConfigRedacted: /api/config must not leak live secrets.
func TestConfigRedacted(t *testing.T) {
	srv, _ := newTestServer(t, "sup3r-key")
	req, _ := http.NewRequest("GET", srv.URL+"/api/config", nil)
	req.Header.Set("x-gs-key", "sup3r-key")
	resp, err := srv.Client().Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	var m map[string]any
	if err := json.NewDecoder(resp.Body).Decode(&m); err != nil {
		t.Fatal(err)
	}
	raw, _ := json.Marshal(m)
	for _, leak := range []string{"sup3r-key"} {
		if strings.Contains(string(raw), leak) {
			t.Fatalf("/api/config leaks secret %q", leak)
		}
	}
}

// TestNoWildcardCORS: admin responses must not carry ACAO *.
func TestNoWildcardCORS(t *testing.T) {
	srv, _ := newTestServer(t, "key")
	resp, err := http.Get(srv.URL + "/api/status")
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	io.Copy(io.Discard, resp.Body)
	if resp.Header.Get("Access-Control-Allow-Origin") == "*" {
		t.Fatal("admin API still sends CORS wildcard")
	}
}

// TestPublicSurfaceTrimmed: public endpoints must not leak internals.
func TestPublicSurfaceTrimmed(t *testing.T) {
	srv, _ := newTestServer(t, "key")
	get := func(path string) map[string]any {
		resp, err := http.Get(srv.URL + path)
		if err != nil {
			t.Fatal(err)
		}
		defer resp.Body.Close()
		var m map[string]any
		if err := json.NewDecoder(resp.Body).Decode(&m); err != nil {
			t.Fatal(err)
		}
		return m
	}
	raw := func(m map[string]any) string {
		b, _ := json.Marshal(m)
		return string(b)
	}
	st := get("/api/status")
	for _, leak := range []string{"hostname", "blocklist", "whitelist", "topIps", "topPaths"} {
		if strings.Contains(raw(st), `"`+leak+`"`) {
			t.Fatalf("/api/status leaks %q", leak)
		}
	}
	if st["brand"] != "GarudaShield" || st["overall"] == nil {
		t.Fatalf("public status lost dashboard fields: %v", raw(st))
	}
	who := get("/api/whoami")
	for _, leak := range []string{"trustProxy", "geo"} {
		if strings.Contains(raw(who), `"`+leak+`"`) {
			t.Fatalf("/api/whoami leaks %q", leak)
		}
	}
	if who["ip"] == nil {
		t.Fatalf("whoami lost ip echo: %v", raw(who))
	}
}
