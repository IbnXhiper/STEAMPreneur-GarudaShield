package admin

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"strconv"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/db"
	"github.com/ahkurdev/garudashield/internal/tenant"
	"golang.org/x/crypto/bcrypt"
)

// TestRoleBasedAccessPG exercises the real Postgres path for RBAC + member
// management: a viewer cannot mutate, an admin can manage keys/assets but not
// teammates, and only the owner can add/remove members. Sessions are minted
// through the real auth.Login.
func TestRoleBasedAccessPG(t *testing.T) {
	if os.Getenv("GS_DATABASE_URL") == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	const tid = "rbac-test"
	cleanup := func() {
		_, _ = pool.Exec(ctx, `DELETE FROM audit_log WHERE tenant_id = $1`, tid)
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id = $1`, tid)
		_, _ = pool.Exec(ctx, `DELETE FROM subscriptions WHERE tenant_id = $1`, tid)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id = $1`, tid)
	}
	cleanup()
	defer cleanup()

	if _, err := pool.Exec(ctx,
		`INSERT INTO tenants (id,name,plan) VALUES ($1,'RBAC Test','free')`, tid); err != nil {
		t.Fatal(err)
	}
	const pw = "rbac-secret-123!"
	hash, _ := bcrypt.GenerateFromPassword([]byte(pw), bcrypt.MinCost)
	mkUser := func(email, role string) int64 {
		var id int64
		if err := pool.QueryRow(ctx,
			`INSERT INTO users (tenant_id,email,password_hash,role) VALUES ($1,$2,$3,$4) RETURNING id`,
			tid, email, string(hash), role).Scan(&id); err != nil {
			t.Fatal(err)
		}
		return id
	}
	ownerID := mkUser("owner@rbac.test", auth.RoleOwner)
	mkUser("admin@rbac.test", auth.RoleAdmin)
	mkUser("viewer@rbac.test", auth.RoleViewer)

	ah := auth.New(pool, "test-session-secret-32bytes-minimum!!")
	ts := tenant.New(pool)
	mux := http.NewServeMux()
	RegisterTenant(mux, ts, ah)

	login := func(email string) *http.Cookie {
		rr := httptest.NewRecorder()
		req := httptest.NewRequest("POST", "/api/auth/login",
			strings.NewReader(`{"email":"`+email+`","password":"`+pw+`"}`))
		ah.Login(rr, req)
		if rr.Code != http.StatusOK {
			t.Fatalf("login %s: status %d body=%s", email, rr.Code, rr.Body.String())
		}
		for _, c := range rr.Result().Cookies() {
			if c.Name == auth.SessionCookieName {
				return c
			}
		}
		t.Fatalf("login %s: no session cookie", email)
		return nil
	}
	do := func(method, path string, cookie *http.Cookie, body string) *httptest.ResponseRecorder {
		rr := httptest.NewRecorder()
		req := httptest.NewRequest(method, path, strings.NewReader(body))
		if cookie != nil {
			req.AddCookie(cookie)
		}
		mux.ServeHTTP(rr, req)
		return rr
	}

	// Viewer can read members, but cannot add them.
	if rr := do("GET", "/api/v1/members", login("viewer@rbac.test"), ""); rr.Code != http.StatusOK {
		t.Fatalf("viewer list members = %d body=%s", rr.Code, rr.Body.String())
	}
	if rr := do("POST", "/api/v1/members", login("viewer@rbac.test"),
		`{"email":"x@rbac.test","password":"long-enough-pw","role":"viewer"}`); rr.Code != http.StatusForbidden {
		t.Fatalf("viewer add member = %d want 403", rr.Code)
	}
	// Admin cannot add members (owner-only).
	if rr := do("POST", "/api/v1/members", login("admin@rbac.test"),
		`{"email":"y@rbac.test","password":"long-enough-pw","role":"viewer"}`); rr.Code != http.StatusForbidden {
		t.Fatalf("admin add member = %d want 403", rr.Code)
	}
	// Viewer cannot mint API keys (admin+); admin passes the guard (400 on empty
	// body, proving the request reached the handler rather than being 401/403).
	if rr := do("POST", "/api/v1/keys", login("viewer@rbac.test"), `{}`); rr.Code != http.StatusForbidden {
		t.Fatalf("viewer create key = %d want 403", rr.Code)
	}
	if rr := do("POST", "/api/v1/keys", login("admin@rbac.test"), `{}`); rr.Code == http.StatusForbidden || rr.Code == http.StatusUnauthorized {
		t.Fatalf("admin create key blocked = %d", rr.Code)
	}
	// Viewer cannot register assets (admin+).
	if rr := do("POST", "/api/v1/assets", login("viewer@rbac.test"), `{"domain":"a.example.com"}`); rr.Code != http.StatusForbidden {
		t.Fatalf("viewer create asset = %d want 403", rr.Code)
	}

	// Owner adds a member: success, then duplicate (409), weak (400), bad role (400).
	cookie := login("owner@rbac.test")
	if rr := do("POST", "/api/v1/members", cookie,
		`{"email":"newbie@rbac.test","password":"newbie-secret-01","role":"admin"}`); rr.Code != http.StatusCreated {
		t.Fatalf("owner add member = %d body=%s", rr.Code, rr.Body.String())
	}
	if rr := do("POST", "/api/v1/members", cookie,
		`{"email":"newbie@rbac.test","password":"newbie-secret-01","role":"admin"}`); rr.Code != http.StatusConflict {
		t.Fatalf("duplicate member = %d want 409", rr.Code)
	}
	if rr := do("POST", "/api/v1/members", cookie,
		`{"email":"weak@rbac.test","password":"short","role":"admin"}`); rr.Code != http.StatusBadRequest {
		t.Fatalf("weak member password = %d want 400", rr.Code)
	}
	if rr := do("POST", "/api/v1/members", cookie,
		`{"email":"oops@rbac.test","password":"long-enough-pw","role":"owner"}`); rr.Code != http.StatusBadRequest {
		t.Fatalf("owner role assignment = %d want 400", rr.Code)
	}

	// Owner cannot remove themselves.
	if rr := do("DELETE", "/api/v1/members/"+strconv.FormatInt(ownerID, 10), cookie, ""); rr.Code != http.StatusConflict {
		t.Fatalf("remove self = %d want 409", rr.Code)
	}

	// Remove the newly added member.
	var newbieID int64
	if err := pool.QueryRow(ctx,
		`SELECT id FROM users WHERE tenant_id=$1 AND email='newbie@rbac.test'`, tid).Scan(&newbieID); err != nil {
		t.Fatal(err)
	}
	if rr := do("DELETE", "/api/v1/members/"+strconv.FormatInt(newbieID, 10), cookie, ""); rr.Code != http.StatusOK {
		t.Fatalf("remove member = %d body=%s", rr.Code, rr.Body.String())
	}

	// Audit history reflects the mutations and is tenant-scoped.
	rr := do("GET", "/api/v1/audit?limit=10", cookie, "")
	if rr.Code != http.StatusOK {
		t.Fatalf("audit list = %d body=%s", rr.Code, rr.Body.String())
	}
	body := rr.Body.String()
	if !strings.Contains(body, "member.add") || !strings.Contains(body, "member.remove") {
		t.Fatalf("audit body missing member actions: %s", body)
	}
}
