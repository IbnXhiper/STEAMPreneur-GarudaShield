package admin

import (
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

func TestPublicRateLimiter(t *testing.T) {
	p := newPublicRateLimiter(3)
	for i := 0; i < 3; i++ {
		if !p.allow("1.2.3.4") {
			t.Fatalf("request %d under limit must pass", i+1)
		}
	}
	if p.allow("1.2.3.4") {
		t.Fatal("4th request must be denied (fail-closed)")
	}
	// Other IPs are unaffected (per-IP budget).
	if !p.allow("5.6.7.8") {
		t.Fatal("budget is per-IP")
	}
	// Window roll resets the budget.
	p.mu.Lock()
	p.window = p.window.Add(-2 * time.Minute)
	p.mu.Unlock()
	if !p.allow("1.2.3.4") {
		t.Fatal("after window roll the budget resets")
	}
}

func TestWrapPublicReturns429(t *testing.T) {
	a := &api{pubLimiter: newPublicRateLimiter(1)}
	h := a.wrapPublic(func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
	})
	req := httptest.NewRequest("GET", "/api/status", nil)
	req.RemoteAddr = "9.9.9.9:1111"
	rec := httptest.NewRecorder()
	h(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("first request must pass, got %d", rec.Code)
	}
	rec2 := httptest.NewRecorder()
	h(rec2, req)
	if rec2.Code != http.StatusTooManyRequests {
		t.Fatalf("second request must be 429, got %d", rec2.Code)
	}
}
