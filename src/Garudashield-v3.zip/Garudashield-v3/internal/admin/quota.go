// Quota read API (commercial /api/v1). Session-authenticated tenant views its
// own daily usage budget. The limit values mirror what the edge enforces
// (configured via config file); a plan may be unlimited (0).
package admin

import (
	"encoding/json"
	"net/http"
	"time"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/quota"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// RegisterQuotaV1 mounts GET /api/v1/quota for the authenticated tenant.
func RegisterQuotaV1(mux *http.ServeMux, qs *quota.Store, ts *tenant.Store, ah *auth.Handler, planLimits map[string]int64, fallback int64) {
	h := &quotaHandler{qs: qs, ts: ts, ah: ah, planLimits: planLimits, fallback: fallback}
	mux.HandleFunc("GET /api/v1/quota", h.requireSession(h.usage))
}

type quotaHandler struct {
	qs         *quota.Store
	ts         *tenant.Store
	ah         *auth.Handler
	planLimits map[string]int64
	fallback   int64
}

func (h *quotaHandler) requireSession(next func(http.ResponseWriter, *http.Request, string)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tid, err := h.ah.TenantFromRequest(r)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "unauthorized"})
			return
		}
		next(w, r, tid)
	}
}

// usage reports today's consumed requests vs the plan budget. A tenant on an
// unlimited plan still sees a 0 limit (not over-quota). Unknown tenant returns
// 404 rather than leaking anything.
func (h *quotaHandler) usage(w http.ResponseWriter, r *http.Request, tid string) {
	t, err := h.ts.Get(r.Context(), tid)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusNotFound)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "tenant not found"})
		return
	}
	period := quota.PeriodKey(time.Now())
	used := int64(0)
	usage, err := h.qs.Usage(r.Context(), tid, period)
	if err == nil {
		used = usage[period]
	}
	limit := quota.LimitFor(t.Plan, h.planLimits, h.fallback)
	remaining := int64(0)
	if limit > used {
		remaining = limit - used
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"tenant":    tid,
		"plan":      t.Plan,
		"period":    period,
		"limit":     limit,
		"used":      used,
		"remaining": remaining,
	})
}
