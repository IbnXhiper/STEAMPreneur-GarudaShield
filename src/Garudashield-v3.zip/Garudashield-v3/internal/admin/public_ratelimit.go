package admin

import (
	"encoding/json"
	"net/http"
	"sync"
	"time"
)

// publicRateLimiter is a lightweight fixed-window per-IP rate limiter for the
// public (unauthenticated) admin endpoints (/api/status, /api/whoami). These
// endpoints are reachable without a key, so without a cap they are an
// enumeration/amplification vector. Window: 60 req/min/IP default.
type publicRateLimiter struct {
	mu     sync.Mutex
	hits   map[string]int
	window time.Time
	limit  int
	perWin time.Duration
}

func newPublicRateLimiter(limit int) *publicRateLimiter {
	if limit <= 0 {
		limit = 60
	}
	return &publicRateLimiter{
		hits:   make(map[string]int),
		window: time.Now(),
		limit:  limit,
		perWin: time.Minute,
	}
}

// allow admits one request from ip. Over-limit requests are denied (fail-closed).
func (p *publicRateLimiter) allow(ip string) bool {
	p.mu.Lock()
	defer p.mu.Unlock()
	now := time.Now()
	if now.Sub(p.window) >= p.perWin {
		p.window = now
		p.hits = make(map[string]int)
	}
	p.hits[ip]++
	return p.hits[ip] <= p.limit
}

// NewPublicRateLimiter creates a limiter admitting `limit` requests per
// minute per IP (exported for the edge server's /health, /stats, /metrics).
func NewPublicRateLimiter(limit int) *publicRateLimiter {
	return newPublicRateLimiter(limit)
}

// Allow admits one request from ip (exported wrapper).
func (p *publicRateLimiter) Allow(ip string) bool { return p.allow(ip) }

// wrapPublic applies public rate limiting to an unauthenticated handler.
func (a *api) wrapPublic(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		a.setHeaders(w)
		if r.Method == http.MethodOptions {
			w.WriteHeader(http.StatusNoContent)
			return
		}
		if !a.pubLimiter.allow(a.clientIPOf(r)) {
			w.Header().Set("Content-Type", "application/json")
			w.Header().Set("Retry-After", "60")
			w.WriteHeader(http.StatusTooManyRequests)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "rate limited"})
			return
		}
		next(w, r)
	}
}
