package admin

import (
	"crypto/subtle"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"regexp"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/license"
	"github.com/ahkurdev/garudashield/internal/tenant"
	"github.com/jackc/pgx/v5/pgconn"
	"golang.org/x/crypto/bcrypt"
)

// RegisterTenant mounts the commercial tenant API:
//   - POST /api/admin/tenant/onboard  — operator creates a tenant + owner atomically
//   - POST /api/admin/license/issue   — operator issues a signed license (paid)
//   - POST /api/admin/license/renew   — operator extends an existing license
//   - POST /api/admin/license/revoke  — operator revokes (tenant blocked at edge)
//   - POST /api/admin/license/suspend — operator suspends (tenant blocked at edge)
//   - GET  /api/tenant/me             — authenticated customer views own plan/license.
//
// Authentication: operator endpoints require the operator admin key
// (x-gs-key / Authorization: *** read from GS_ADMIN_SECRET. Fails closed if unset.
// /api/tenant/me requires the signed session cookie from auth.Login.
func RegisterTenant(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler) {
	th := &tenantHandler{ts: ts, ah: ah}
	mux.HandleFunc("POST /api/admin/tenant/onboard", th.onboard)
	mux.HandleFunc("POST /api/admin/license/issue", th.issueLicense)
	mux.HandleFunc("POST /api/admin/license/renew", th.renewLicense)
	mux.HandleFunc("POST /api/admin/license/revoke", th.setStatus("revoked", "license.revoke"))
	mux.HandleFunc("POST /api/admin/license/suspend", th.setStatus("suspended", "license.suspend"))
	mux.HandleFunc("GET /api/tenant/me", th.requireSession(th.me))
	// Versioned alias (/api/v1) — the forward-compatible route the commercial
	// API standardizes on.
	mux.HandleFunc("GET /api/v1/tenant/me", th.requireSession(th.me))
	// Tenant-scoped programmatic API keys (hashed, scoped, expiring, revocable).
	registerAPIKeys(mux, ts, ah)
	// Tenant-owned protected domains (DNS-verified, SSRF-safe).
	registerAssets(mux, ts, ah)
	// Tenant-scoped audit history (read-only).
	registerAudit(mux, ts, ah)
	// Team members and their roles (viewer < admin < owner).
	registerMembers(mux, ts, ah)
	// Operator adds a team member to any tenant (after a WhatsApp request).
	mux.HandleFunc("POST /api/admin/tenant/member", th.addMemberOperator)
}

type tenantHandler struct {
	ts *tenant.Store
	ah *auth.Handler
}

var tenantIDPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9-]{1,62}$`)

func operatorAuthorized(r *http.Request) bool {
	secret := os.Getenv("GS_ADMIN_SECRET")
	if secret == "" {
		return false
	}
	got := r.Header.Get("x-gs-key")
	if got == "" {
		if a := r.Header.Get("Authorization"); strings.HasPrefix(a, "Bearer ") {
			got = a[7:]
		}
	}
	return subtle.ConstantTimeCompare([]byte(got), []byte(secret)) == 1
}

// onboard creates a tenant and its owner atomically after a WhatsApp order is
// confirmed. It is operator-only; no public self-registration exists.
func (h *tenantHandler) onboard(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusForbidden)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
		return
	}
	var req struct {
		Tenant   string `json:"tenant"`
		Name     string `json:"name"`
		Domain   string `json:"domain"`
		Plan     string `json:"plan"`
		Email    string `json:"email"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Tenant = strings.ToLower(strings.TrimSpace(req.Tenant))
	req.Name = strings.TrimSpace(req.Name)
	req.Domain = strings.ToLower(strings.TrimSpace(req.Domain))
	req.Plan = strings.ToLower(strings.TrimSpace(req.Plan))
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	if !tenantIDPattern.MatchString(req.Tenant) || req.Name == "" || req.Domain == "" ||
		!strings.Contains(req.Domain, ".") || !strings.Contains(req.Email, "@") || len(req.Password) < 12 {
		http.Error(w, "invalid tenant, domain, email, or password", http.StatusBadRequest)
		return
	}
	if req.Plan != "free" && req.Plan != "pro" && req.Plan != "enterprise" {
		http.Error(w, "invalid plan", http.StatusBadRequest)
		return
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "password rejected", http.StatusBadRequest)
		return
	}
	pool := h.ts.Pool()
	tx, err := pool.Begin(r.Context())
	if err != nil {
		http.Error(w, "store unavailable", http.StatusServiceUnavailable)
		return
	}
	defer tx.Rollback(r.Context())
	if _, err = tx.Exec(r.Context(),
		`INSERT INTO tenants (id,name,plan,domain) VALUES ($1,$2,$3,$4)`,
		req.Tenant, req.Name, req.Plan, req.Domain); err != nil {
		if pgxErr, ok := err.(*pgconn.PgError); ok && pgxErr.Code == "23505" {
			w.WriteHeader(http.StatusConflict)
			return
		}
		http.Error(w, "tenant create failed", http.StatusInternalServerError)
		return
	}
	if _, err = tx.Exec(r.Context(),
		`INSERT INTO users (tenant_id,email,password_hash,role) VALUES ($1,$2,$3,'owner')`,
		req.Tenant, req.Email, string(hash)); err != nil {
		http.Error(w, "owner create failed", http.StatusInternalServerError)
		return
	}
	if _, err = tx.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id,actor,action,detail,ip) VALUES ($1,$2,'tenant.onboard',$3,$4)`,
		req.Tenant, "operator", req.Email, r.RemoteAddr); err != nil {
		http.Error(w, "audit failed", http.StatusInternalServerError)
		return
	}
	if err = tx.Commit(r.Context()); err != nil {
		http.Error(w, "commit failed", http.StatusInternalServerError)
		return
	}
	h.ts.Invalidate()
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok": true, "tenant": req.Tenant, "plan": req.Plan, "domain": req.Domain,
		"owner": req.Email, "next": "issue-license-after-whatsapp-confirmation",
	})
}

func (h *tenantHandler) requireSession(next func(w http.ResponseWriter, r *http.Request, tenantID string)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tid, err := h.ah.TenantFromRequest(r)
		if err != nil {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusUnauthorized)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "unauthorized"})
			return
		}
		next(w, r, tid)
	}
}

func (h *tenantHandler) me(w http.ResponseWriter, r *http.Request, tid string) {
	t, err := h.ts.Get(r.Context(), tid)
	if err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusNotFound)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "tenant not found"})
		return
	}
	status := "active"
	if t.LicenseExp != 0 && time.Now().Unix() > t.LicenseExp {
		status = "expired"
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"tenant": t.ID,
		"name":   t.Name,
		"plan":   t.Plan,
		"domain": t.Domain,
		"license": map[string]any{
			"status": status,
			"exp":    t.LicenseExp,
		},
	})
}

func (h *tenantHandler) renewLicense(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusForbidden)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
		return
	}
	var req struct {
		Tenant string `json:"tenant"`
		Months int    `json:"months"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Tenant = strings.TrimSpace(req.Tenant)
	if req.Tenant == "" {
		http.Error(w, "tenant required", http.StatusBadRequest)
		return
	}
	exp, err := h.ts.Renew(r.Context(), req.Tenant, req.Months)
	if err != nil {
		http.Error(w, "renew failed", http.StatusInternalServerError)
		return
	}
	h.ts.Audit(r.Context(), req.Tenant, "operator", "license.renew",
		fmt.Sprintf("months=%d expiresAt=%d", req.Months, exp), r.RemoteAddr)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok": true, "tenant": req.Tenant, "expiresAt": exp,
	})
}

// setStatus returns a handler that flips a tenant's commercial status and
// records an audit row. Used for suspend/revoke (edge blocks until reactivated).
func (h *tenantHandler) setStatus(status, action string) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !operatorAuthorized(r) {
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusForbidden)
			_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
			return
		}
		var req struct {
			Tenant string `json:"tenant"`
			Reason string `json:"reason"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, "bad request", http.StatusBadRequest)
			return
		}
		req.Tenant = strings.TrimSpace(req.Tenant)
		if req.Tenant == "" {
			http.Error(w, "tenant required", http.StatusBadRequest)
			return
		}
		if err := h.ts.SetStatus(r.Context(), req.Tenant, status); err != nil {
			http.Error(w, "status update failed", http.StatusInternalServerError)
			return
		}
		h.ts.Audit(r.Context(), req.Tenant, "operator", action,
			fmt.Sprintf("status=%s reason=%s", status, req.Reason), r.RemoteAddr)
		w.Header().Set("Content-Type", "application/json")
		_ = json.NewEncoder(w).Encode(map[string]any{
			"ok": true, "tenant": req.Tenant, "status": status,
		})
	}
}

func (h *tenantHandler) issueLicense(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	// Operator auth via admin key (same secret the engine uses for /api/*).
	if os.Getenv("GS_ADMIN_SECRET") == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "operator auth unavailable"})
		return
	}
	if !operatorAuthorized(r) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusForbidden)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
		return
	}

	var req struct {
		Tenant string `json:"tenant"`
		Plan   string `json:"plan"`
		Months int    `json:"months"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Tenant = strings.TrimSpace(req.Tenant)
	if req.Tenant == "" || req.Plan == "" {
		http.Error(w, "tenant and plan required", http.StatusBadRequest)
		return
	}
	if req.Months <= 0 {
		req.Months = 1
	}

	licSecret := os.Getenv("GS_LICENSE_SECRET")
	if licSecret == "" {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusServiceUnavailable)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "license signing unavailable"})
		return
	}

	now := time.Now().Unix()
	exp := now + int64(req.Months)*30*24*3600
	lic := license.Sign(license.License{
		TenantID: req.Tenant,
		Plan:     license.Plan(req.Plan),
		Expiry:   exp,
		Issued:   now,
		Features: []string{"waf", "ddos", "geo"},
	}, licSecret)
	key := lic.Key()

	if err := h.ts.SetLicense(r.Context(), req.Tenant, key, exp); err != nil {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusInternalServerError)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "persist failed"})
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok":         true,
		"tenant":     req.Tenant,
		"plan":       req.Plan,
		"expiresAt":  exp,
		"licenseKey": key,
	})
}

// addMemberOperator lets an operator add a teammate (admin/viewer) to a tenant
// after a WhatsApp request. Operator-only (GS_ADMIN_SECRET). Owners are only
// created by onboarding/registration.
func (h *tenantHandler) addMemberOperator(w http.ResponseWriter, r *http.Request) {
	if !operatorAuthorized(r) {
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusForbidden)
		_ = json.NewEncoder(w).Encode(map[string]string{"error": "forbidden"})
		return
	}
	var req struct {
		Tenant   string `json:"tenant"`
		Email    string `json:"email"`
		Password string `json:"password"`
		Role     string `json:"role"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Tenant = strings.ToLower(strings.TrimSpace(req.Tenant))
	if req.Tenant == "" {
		http.Error(w, "tenant required", http.StatusBadRequest)
		return
	}
	if _, err := h.ts.Get(r.Context(), req.Tenant); err != nil {
		http.Error(w, "tenant not found", http.StatusNotFound)
		return
	}
	mh := &memberHandler{ts: h.ts, ah: h.ah}
	if err := mh.createMember(r, req.Tenant, req.Email, req.Password, req.Role); err != nil {
		writeMemberError(w, err)
		return
	}
	h.ts.Audit(r.Context(), req.Tenant, "operator", "member.add",
		"email="+strings.ToLower(strings.TrimSpace(req.Email))+" role="+strings.ToLower(strings.TrimSpace(req.Role)), r.RemoteAddr)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"ok": true, "tenant": req.Tenant, "email": strings.ToLower(strings.TrimSpace(req.Email)),
		"role": strings.ToLower(strings.TrimSpace(req.Role)),
	})
}
