package admin

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/db"
	"github.com/ahkurdev/garudashield/internal/tenant"
	"golang.org/x/crypto/bcrypt"
)

// plantestSession logs a user in through the real auth handler and returns the
// signed session cookie, exactly as the portal would receive it.
func plantestSession(t *testing.T, ah *auth.Handler, email, pass string) *http.Cookie {
	t.Helper()
	srv := httptest.NewServer(http.HandlerFunc(ah.Login))
	defer srv.Close()
	resp, err := http.Post(srv.URL, "application/json",
		strings.NewReader(`{"email":"`+email+`","password":"`+pass+`"}`))
	if err != nil {
		t.Fatalf("login %s: %v", email, err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("login %s status %d", email, resp.StatusCode)
	}
	for _, c := range resp.Cookies() {
		if c.Name == auth.SessionCookieName {
			return c
		}
	}
	t.Fatalf("login %s set no session cookie", email)
	return nil
}

// TestFreePlanDomainLimitPG proves the free plan may hold only ONE protected
// domain: the first create succeeds, the second is refused with 402 and a
// machine-readable upgrade payload, and the list endpoint advertises the cap.
// A pro tenant running the same flow is unconstrained.
func TestFreePlanDomainLimitPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	const pass = "kuat-rahasia-123"
	setup := func(id, domain, plan, email string) {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE email=$1`, email)
		_, _ = pool.Exec(ctx, `DELETE FROM protected_assets WHERE tenant_id=$1`, id)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, id)
		_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan,domain) VALUES ($1,$1,$2,$3)`, id, plan, domain)
		hash, _ := bcrypt.GenerateFromPassword([]byte(pass), bcrypt.DefaultCost)
		_, _ = pool.Exec(ctx,
			`INSERT INTO users (tenant_id,email,password_hash,role) VALUES ($1,$2,$3,'owner')`,
			id, email, string(hash))
	}
	cleanup := func(id, email string) {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE email=$1`, email)
		_, _ = pool.Exec(ctx, `DELETE FROM protected_assets WHERE tenant_id=$1`, id)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, id)
	}

	setup("plangate-free", "plangate-free.id", "free", "free@plangate.id")
	setup("plangate-pro", "plangate-pro.id", "pro", "pro@plangate.id")
	defer cleanup("plangate-free", "free@plangate.id")
	defer cleanup("plangate-pro", "pro@plangate.id")

	ts := tenant.New(pool)
	ah := auth.New(pool, "plangate-session-secret")
	mux := http.NewServeMux()
	RegisterTenant(mux, ts, ah)

	freeCk := plantestSession(t, ah, "free@plangate.id", pass)
	proCk := plantestSession(t, ah, "pro@plangate.id", pass)

	post := func(ck *http.Cookie, domain string) *httptest.ResponseRecorder {
		body, _ := json.Marshal(map[string]any{"domain": domain})
		req := httptest.NewRequest("POST", "/api/v1/assets", bytes.NewReader(body))
		req.AddCookie(ck)
		rec := httptest.NewRecorder()
		mux.ServeHTTP(rec, req)
		return rec
	}

	// Free: first domain accepted, second blocked at the cap.
	if rec := post(freeCk, "a.plangate-free.id"); rec.Code != http.StatusCreated {
		t.Fatalf("free first asset = %d, want 201 (body %s)", rec.Code, rec.Body.String())
	}
	rec2 := post(freeCk, "b.plangate-free.id")
	if rec2.Code != http.StatusPaymentRequired {
		t.Fatalf("free second asset = %d, want 402 (body %s)", rec2.Code, rec2.Body.String())
	}
	var limit struct {
		Error   string `json:"error"`
		Code    string `json:"code"`
		Plan    string `json:"plan"`
		Limit   int    `json:"limit"`
		Used    int    `json:"used"`
		Upgrade string `json:"upgrade"`
	}
	if err := json.Unmarshal(rec2.Body.Bytes(), &limit); err != nil {
		t.Fatal(err)
	}
	if limit.Code != "plan_domain_limit" || limit.Plan != "free" || limit.Limit != 1 ||
		limit.Used != 1 || limit.Upgrade != "pro" || limit.Error == "" {
		t.Fatalf("upgrade payload wrong: %+v", limit)
	}

	// The list endpoint advertises the cap so the portal can render the prompt.
	listReq := httptest.NewRequest("GET", "/api/v1/assets", nil)
	listReq.AddCookie(freeCk)
	listRec := httptest.NewRecorder()
	mux.ServeHTTP(listRec, listReq)
	if listRec.Code != http.StatusOK {
		t.Fatalf("free list = %d", listRec.Code)
	}
	var lb struct {
		Assets      []any  `json:"assets"`
		Plan        string `json:"plan"`
		DomainLimit int    `json:"domainLimit"`
	}
	if err := json.Unmarshal(listRec.Body.Bytes(), &lb); err != nil {
		t.Fatal(err)
	}
	if lb.DomainLimit != 1 || lb.Plan != "free" || len(lb.Assets) != 1 {
		t.Fatalf("free list payload wrong: %+v", lb)
	}

	// Pro: two domains both accepted (unlimited plan).
	if rec := post(proCk, "a.plangate-pro.id"); rec.Code != http.StatusCreated {
		t.Fatalf("pro first asset = %d, want 201 (body %s)", rec.Code, rec.Body.String())
	}
	if rec := post(proCk, "b.plangate-pro.id"); rec.Code != http.StatusCreated {
		t.Fatalf("pro second asset = %d, want 201 (body %s)", rec.Code, rec.Body.String())
	}
}
