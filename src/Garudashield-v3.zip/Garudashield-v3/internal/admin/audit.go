package admin

import (
	"net/http"
	"strconv"

	"github.com/ahkurdev/garudashield/internal/audit"
	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// auditHandler serves the tenant's own audit history. Read-only and scoped to
// the caller's tenant (resolved from the session) — there is no way to select
// another tenant's history.
//
//	GET /api/v1/audit?action=&actor=&limit=&offset=
type auditHandler struct {
	store *audit.Store
	ah    *auth.Handler
}

func registerAudit(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler) {
	h := &auditHandler{store: audit.New(ts.Pool()), ah: ah}
	mux.HandleFunc("GET /api/v1/audit", requireRole(ah, auth.RoleViewer, h.list))
}

func (h *auditHandler) list(w http.ResponseWriter, r *http.Request, p auth.Principal) {
	q := r.URL.Query()
	limit, _ := strconv.Atoi(q.Get("limit"))
	offset, _ := strconv.Atoi(q.Get("offset"))
	f := audit.Filter{
		Action: q.Get("action"),
		Actor:  q.Get("actor"),
		Limit:  limit,
		Offset: offset,
	}
	entries, err := h.store.List(r.Context(), p.TenantID, f)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	total, err := h.store.Count(r.Context(), p.TenantID, f)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	nf := f.Normalize()
	writeJSON(w, http.StatusOK, map[string]any{
		"entries": entries,
		"total":   total,
		"limit":   nf.Limit,
		"offset":  nf.Offset,
	})
}
