package admin

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"net"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/asset"
	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/plan"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// assetHandler serves tenant-owned protected domains ("assets"). Every endpoint
// is authenticated by the signed session cookie (auth.Handler) and acts only on
// the caller's own tenant — the tenant id is never taken from the request.
//
//	GET    /api/v1/assets             — list the tenant's protected domains
//	POST   /api/v1/assets             — register a domain (returns a DNS challenge)
//	POST   /api/v1/assets/{id}/verify — prove DNS ownership and activate it
//	DELETE /api/v1/assets/{id}        — stop protecting the domain
//
// A domain is only enforced at the edge after successful verification.
type assetHandler struct {
	store *asset.Store
	ts    *tenant.Store
	ah    *auth.Handler
	txt   asset.TXTResolver
	ipres asset.IPResolver
}

func registerAssets(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler) {
	h := &assetHandler{
		store: asset.New(ts.Pool()),
		ts:    ts,
		ah:    ah,
		txt:   net.DefaultResolver,
		ipres: net.DefaultResolver,
	}
	mux.HandleFunc("GET /api/v1/assets", h.requireSession(h.list))
	// Registering/verifying/removing protected domains is admin+ only.
	mux.HandleFunc("POST /api/v1/assets", roleShim(auth.RoleAdmin, ah, h.create))
	mux.HandleFunc("POST /api/v1/assets/{id}/verify", roleShim(auth.RoleAdmin, ah, h.verify))
	mux.HandleFunc("DELETE /api/v1/assets/{id}", roleShim(auth.RoleAdmin, ah, h.remove))
}

func (h *assetHandler) requireSession(next func(http.ResponseWriter, *http.Request, string)) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		tid, err := h.ah.TenantFromRequest(r)
		if err != nil {
			writeJSONError(w, http.StatusUnauthorized, "unauthorized")
			return
		}
		next(w, r, tid)
	}
}

func (h *assetHandler) list(w http.ResponseWriter, r *http.Request, tid string) {
	assets, err := h.store.List(r.Context(), tid)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	// Surface the tenant's plan + domain cap so the portal can render the
	// "x of y domains" context and pre-empt the limit with an upgrade prompt.
	// Enrichment is best-effort: a read failure must not break the list.
	planName := ""
	limit := 0
	if t, terr := h.ts.Get(r.Context(), tid); terr == nil {
		planName = t.Plan
		limit = plan.MaxDomains(t.Plan)
	}
	writeJSON(w, http.StatusOK, map[string]any{
		"assets":      assets,
		"plan":        planName,
		"domainLimit": limit,
	})
}

func (h *assetHandler) create(w http.ResponseWriter, r *http.Request, tid string) {
	var req struct {
		Domain     string `json:"domain"`
		OriginHost string `json:"originHost"`
		OriginPort int    `json:"originPort"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil {
		writeJSONError(w, http.StatusBadRequest, "bad request")
		return
	}

	// Screen the optional origin host before touching the store: never accept a
	// URL (ValidateOrigin rejects scheme/path/port), and never accept a host
	// that resolves into private/loopback/link-local/metadata space (SSRF).
	originHost := strings.TrimSpace(req.OriginHost)
	if originHost != "" {
		oh, _, err := asset.ValidateOrigin(originHost, req.OriginPort)
		if err != nil {
			writeJSONError(w, http.StatusBadRequest, "origin host/port not allowed")
			return
		}
		if net.ParseIP(oh) == nil {
			// hostname: it must still resolve to a public address
			ctx, cancel := context.WithTimeout(r.Context(), 4*time.Second)
			defer cancel()
			if err := asset.CheckHost(ctx, h.ipres, oh); err != nil {
				writeJSONError(w, http.StatusBadRequest, "origin resolves to a blocked address")
				return
			}
		}
	}

	// Plan gate: a protected domain is the metered feature, so enforce the
	// per-tier cap BEFORE inserting. The count includes pending + verified
	// domains so a tenant cannot hoard unverified slots. An unknown/empty plan
	// is treated as free (deny-by-default). The response carries a
	// machine-readable "plan_domain_limit" code + upgrade hint so the portal
	// can show a clear upgrade prompt instead of a generic error.
	t, err := h.ts.Get(r.Context(), tid)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "tenant unavailable")
		return
	}
	if max := plan.MaxDomains(t.Plan); max > 0 {
		n, cerr := h.store.CountByTenant(r.Context(), tid)
		if cerr != nil {
			writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
			return
		}
		if n >= int64(max) {
			writeJSON(w, http.StatusPaymentRequired, map[string]any{
				"error": fmt.Sprintf(
					"Paket %s hanya dapat melindungi %d domain. Upgrade paket untuk menambah domain lain.",
					strings.ToUpper(t.Plan), max),
				"code":    "plan_domain_limit",
				"plan":    t.Plan,
				"limit":   max,
				"used":    n,
				"upgrade": upgradeTarget(t.Plan),
			})
			return
		}
	}

	a, err := h.store.Create(r.Context(), tid, req.Domain, req.OriginHost, req.OriginPort)
	switch {
	case errors.Is(err, asset.ErrDomainTaken):
		writeJSONError(w, http.StatusConflict, "domain already registered")
		return
	case errors.Is(err, asset.ErrInvalidDomain):
		writeJSONError(w, http.StatusBadRequest, "invalid domain (use a public hostname, no scheme/path/port)")
		return
	case errors.Is(err, asset.ErrInvalidOrigin):
		writeJSONError(w, http.StatusBadRequest, "invalid origin")
		return
	case errors.Is(err, asset.ErrBlockedTarget):
		writeJSONError(w, http.StatusBadRequest, "origin resolves to a blocked address")
		return
	case err != nil:
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}

	h.ts.Audit(r.Context(), tid, "tenant", "asset.create", "domain="+a.Domain, r.RemoteAddr)
	writeJSON(w, http.StatusCreated, map[string]any{
		"asset": a,
		"dns": map[string]string{
			"type":  "TXT",
			"name":  asset.ChallengeName(a.Domain),
			"value": asset.ChallengeValue(a.VerifyToken),
		},
		"next": "Buat TXT record di atas, lalu POST /api/v1/assets/" + strconv.FormatInt(a.ID, 10) + "/verify",
	})
}

func (h *assetHandler) verify(w http.ResponseWriter, r *http.Request, tid string) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		writeJSONError(w, http.StatusBadRequest, "invalid id")
		return
	}
	a, err := h.store.Get(r.Context(), tid, id)
	if err != nil {
		if errors.Is(err, asset.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	if a.Status == asset.StatusVerified {
		writeJSON(w, http.StatusOK, map[string]any{"ok": true, "asset": a})
		return
	}
	ctx, cancel := context.WithTimeout(r.Context(), 5*time.Second)
	defer cancel()
	if err := asset.VerifyOwnership(ctx, h.txt, a.Domain, a.VerifyToken); err != nil {
		name := asset.ChallengeName(a.Domain)
		value := asset.ChallengeValue(a.VerifyToken)
		switch {
		case errors.Is(err, asset.ErrDNSTimeout):
			// Transient resolver timeout: mutable, the tenant should just retry.
			writeJSONError(w, http.StatusGatewayTimeout,
				"DNS timeout saat membaca TXT record "+name+". Tunggu sebentar lalu coba lagi.")
		case errors.Is(err, asset.ErrDNSUnavailable):
			writeJSONError(w, http.StatusBadGateway, "dns lookup failed")
		case errors.Is(err, asset.ErrNotVerified):
			var ve *asset.VerifyError
			_ = errors.As(err, &ve)
			if ve != nil && !ve.Missing {
				// A record exists but its token is wrong — a real mismatch, not a
				// propagation delay, so the message tells the tenant it is a value
				// problem (not "wait longer").
				writeJSONError(w, http.StatusUnprocessableEntity,
					"TXT record ditemukan tetapi token belum cocok. Pastikan nilai TXT \""+value+
						"\" pada "+name+" (atau "+a.Domain+").")
			} else {
				writeJSONError(w, http.StatusBadRequest,
					"TXT record belum ditemukan. Buat record TXT pada \""+name+"\" (alternatif: \""+a.Domain+
						"\") dengan nilai \""+value+"\", lalu tunggu propagasi DNS.")
			}
		default:
			writeJSONError(w, http.StatusBadGateway, "dns lookup failed")
		}
		return
	}
	if err := h.store.MarkVerified(r.Context(), tid, id); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	a.Status = asset.StatusVerified
	a.VerifiedAt = time.Now().Unix()
	h.ts.Audit(r.Context(), tid, "tenant", "asset.verify", "domain="+a.Domain, r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "asset": a})
}

func (h *assetHandler) remove(w http.ResponseWriter, r *http.Request, tid string) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		writeJSONError(w, http.StatusBadRequest, "invalid id")
		return
	}
	if err := h.store.Delete(r.Context(), tid, id); err != nil {
		if errors.Is(err, asset.ErrNotFound) {
			writeJSONError(w, http.StatusNotFound, "not found")
			return
		}
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.ts.Audit(r.Context(), tid, "tenant", "asset.delete", "id="+strconv.FormatInt(id, 10), r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "id": id})
}

// upgradeTarget suggests the next higher tier to offer when a plan hits its
// domain cap. A free tenant is pointed at pro; pro at enterprise; anything else
// defaults to pro.
func upgradeTarget(p string) string {
	switch strings.ToLower(strings.TrimSpace(p)) {
	case plan.Free:
		return plan.Pro
	case plan.Pro:
		return plan.Enterprise
	default:
		return plan.Pro
	}
}
