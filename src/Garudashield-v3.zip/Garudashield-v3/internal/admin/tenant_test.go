package admin

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/db"
	"github.com/ahkurdev/garudashield/internal/tenant"
)

// TestTenantMeRequiresSession confirms the customer profile endpoint the portal
// loads after login is not reachable without a valid session cookie.
func TestTenantMeRequiresSession(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}

	ts := tenant.New(pool)
	ah := auth.New(pool, "me-session-secret")
	mux := http.NewServeMux()
	RegisterTenant(mux, ts, ah)

	req := httptest.NewRequest("GET", "/api/tenant/me", nil) // no cookie
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("anonymous /api/tenant/me = %d, want 401", rec.Code)
	}
}

// TestIssueLicense signs and persists a tenant license via the operator API and
// then confirms the tenant store reflects it (the same path the edge gate reads).
func TestIssueLicense(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	os.Setenv("GS_ADMIN_SECRET", "op-secret")
	os.Setenv("GS_LICENSE_SECRET", "lic-secret")
	defer os.Unsetenv("GS_ADMIN_SECRET")
	defer os.Unsetenv("GS_LICENSE_SECRET")

	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='issuetest'`)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan,domain) VALUES ('issuetest','Issue','pro','it.example.com') ON CONFLICT (id) DO NOTHING`)
	defer func() { _, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='issuetest'`) }()

	ts := tenant.New(pool)
	ah := auth.New(pool, "")
	mux := http.NewServeMux()
	RegisterTenant(mux, ts, ah)

	body, _ := json.Marshal(map[string]any{"tenant": "issuetest", "plan": "pro", "months": 3})
	req := httptest.NewRequest("POST", "/api/admin/license/issue", bytes.NewReader(body))
	req.Header.Set("x-gs-key", "op-secret")
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("issue status %d body %s", rec.Code, rec.Body.String())
	}
	var out struct {
		OK         bool   `json:"ok"`
		LicenseKey string `json:"licenseKey"`
		ExpiresAt  int64  `json:"expiresAt"`
	}
	if err := json.Unmarshal(rec.Body.Bytes(), &out); err != nil {
		t.Fatal(err)
	}
	if !out.OK || out.LicenseKey == "" {
		t.Fatalf("issue did not return a key: %+v", out)
	}

	// The store must now reflect the issued license.
	got, err := ts.Get(ctx, "issuetest")
	if err != nil {
		t.Fatal(err)
	}
	if got.LicenseKey != out.LicenseKey {
		t.Fatalf("store license mismatch")
	}
	if out.ExpiresAt <= 0 {
		t.Fatalf("expiresAt should be set")
	}
}

// TestCreateTenantOnboarding exercises the WA-order onboarding path: operator
// creates tenant + owner user in one call, then that user can actually log in
// via the real auth handler (bcrypt verified against Postgres).
func TestCreateTenantOnboarding(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	os.Setenv("GS_ADMIN_SECRET", "op-secret")
	defer os.Unsetenv("GS_ADMIN_SECRET")

	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='onboard'`)
	defer func() { _, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='onboard'`) }()

	ts := tenant.New(pool)
	ah := auth.New(pool, "onboard-session-secret")
	mux := http.NewServeMux()
	RegisterTenant(mux, ts, ah)

	// 1. Without operator key -> 403, nothing created.
	body, _ := json.Marshal(map[string]any{
		"tenant": "onboard", "name": "Onboard Co", "domain": "onboard.example.com",
		"plan": "pro", "email": "owner@onboard.id", "password": "kuat-rahasia-123",
	})
	reqNoKey := httptest.NewRequest("POST", "/api/admin/tenant/onboard", bytes.NewReader(body))
	recNoKey := httptest.NewRecorder()
	mux.ServeHTTP(recNoKey, reqNoKey)
	if recNoKey.Code != http.StatusForbidden {
		t.Fatalf("create without key should be 403, got %d", recNoKey.Code)
	}

	// 2. With operator key -> 200, tenant + owner exist.
	req := httptest.NewRequest("POST", "/api/admin/tenant/onboard", bytes.NewReader(body))
	req.Header.Set("x-gs-key", "op-secret")
	rec := httptest.NewRecorder()
	mux.ServeHTTP(rec, req)
	if rec.Code != http.StatusOK {
		t.Fatalf("create status %d body %s", rec.Code, rec.Body.String())
	}
	got, err := ts.Get(ctx, "onboard")
	if err != nil {
		t.Fatalf("tenant not created: %v", err)
	}
	if got.Plan != "pro" || got.Domain != "onboard.example.com" {
		t.Fatalf("tenant fields wrong: %+v", got)
	}

	// 3. The owner can log in with the real auth handler (round-trip bcrypt).
	loginSrv := httptest.NewServer(http.HandlerFunc(ah.Login))
	defer loginSrv.Close()
	resp, err := http.Post(loginSrv.URL, "application/json",
		strings.NewReader(`{"email":"owner@onboard.id","password":"kuat-rahasia-123"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("owner login should be 200, got %d", resp.StatusCode)
	}

	// 4. Duplicate create -> 409, not a silent overwrite.
	reqDup := httptest.NewRequest("POST", "/api/admin/tenant/onboard", bytes.NewReader(body))
	reqDup.Header.Set("x-gs-key", "op-secret")
	recDup := httptest.NewRecorder()
	mux.ServeHTTP(recDup, reqDup)
	if recDup.Code != http.StatusConflict {
		t.Fatalf("duplicate create should be 409, got %d", recDup.Code)
	}

	// 5. Weak password is rejected at the trust boundary.
	weakBody, _ := json.Marshal(map[string]any{
		"tenant": "weak-one", "name": "Weak", "domain": "weak.example.com",
		"plan": "pro", "email": "owner@weak.id", "password": "short",
	})
	reqWeak := httptest.NewRequest("POST", "/api/admin/tenant/onboard", bytes.NewReader(weakBody))
	reqWeak.Header.Set("x-gs-key", "op-secret")
	recWeak := httptest.NewRecorder()
	mux.ServeHTTP(recWeak, reqWeak)
	if recWeak.Code != http.StatusBadRequest {
		t.Fatalf("weak password should be 400, got %d", recWeak.Code)
	}
}
