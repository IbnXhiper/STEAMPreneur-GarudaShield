package admin

import (
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/auth"
	"github.com/ahkurdev/garudashield/internal/tenant"
	"github.com/jackc/pgx/v5/pgconn"
	"golang.org/x/crypto/bcrypt"
)

// memberHandler manages the users that share a tenant's dashboard access.
//
//	GET    /api/v1/members       — list teammates (any role)
//	POST   /api/v1/members       — add an admin/viewer (owner only)
//	DELETE /api/v1/members/{id}  — remove a teammate (owner only)
//
// The tenant is always the caller's own (resolved from the session); no route
// accepts a tenant id, so cross-tenant membership changes are impossible.
type memberHandler struct {
	ts *tenant.Store
	ah *auth.Handler
}

func registerMembers(mux *http.ServeMux, ts *tenant.Store, ah *auth.Handler) {
	h := &memberHandler{ts: ts, ah: ah}
	mux.HandleFunc("GET /api/v1/members", requireRole(ah, auth.RoleViewer, h.list))
	mux.HandleFunc("POST /api/v1/members", requireRole(ah, auth.RoleOwner, h.add))
	mux.HandleFunc("DELETE /api/v1/members/{id}", requireRole(ah, auth.RoleOwner, h.remove))
}

// memberView is the safe projection returned to clients (never a hash).
type memberView struct {
	ID        int64  `json:"id"`
	Email     string `json:"email"`
	Role      string `json:"role"`
	CreatedAt string `json:"createdAt"`
}

// addableRole reports whether a role may be assigned through member management.
// Owners are only ever created by registration/operator onboarding.
func addableRole(role string) bool {
	return role == auth.RoleAdmin || role == auth.RoleViewer
}

func (h *memberHandler) list(w http.ResponseWriter, r *http.Request, p auth.Principal) {
	rows, err := h.ts.Pool().Query(r.Context(),
		`SELECT id, email, role, created_at FROM users WHERE tenant_id = $1 ORDER BY id`,
		p.TenantID)
	if err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	defer rows.Close()
	out := make([]memberView, 0, 4)
	for rows.Next() {
		var (
			m  memberView
			at time.Time
		)
		if err := rows.Scan(&m.ID, &m.Email, &m.Role, &at); err != nil {
			writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
			return
		}
		m.Role = auth.NormalizeRole(m.Role)
		m.CreatedAt = at.UTC().Format(time.RFC3339)
		out = append(out, m)
	}
	if err := rows.Err(); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	writeJSON(w, http.StatusOK, map[string]any{"members": out, "role": p.Role})
}

func (h *memberHandler) add(w http.ResponseWriter, r *http.Request, p auth.Principal) {
	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
		Role     string `json:"role"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		writeJSONError(w, http.StatusBadRequest, "bad request")
		return
	}
	if err := h.createMember(r, p.TenantID, req.Email, req.Password, req.Role); err != nil {
		writeMemberError(w, err)
		return
	}
	h.ts.Audit(r.Context(), p.TenantID, strconv.FormatInt(p.UserID, 10), "member.add",
		"email="+strings.ToLower(strings.TrimSpace(req.Email))+" role="+strings.ToLower(strings.TrimSpace(req.Role)), r.RemoteAddr)
	writeJSON(w, http.StatusCreated, map[string]any{
		"ok": true, "email": strings.ToLower(strings.TrimSpace(req.Email)),
		"role": strings.ToLower(strings.TrimSpace(req.Role)),
	})
}

// createMember validates input, hashes the password, and inserts the user. It
// is shared by the owner endpoint and the operator endpoint.
func (h *memberHandler) createMember(r *http.Request, tenantID, email, password, role string) error {
	email = strings.ToLower(strings.TrimSpace(email))
	role = strings.ToLower(strings.TrimSpace(role))
	if !strings.Contains(email, "@") || strings.Contains(email, " ") {
		return errBadMember("valid email required")
	}
	if len(password) < 12 {
		return errBadMember("password must be at least 12 characters")
	}
	if !addableRole(role) {
		return errBadMember("role must be admin or viewer")
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	if err != nil {
		return errBadMember("password rejected")
	}
	_, err = h.ts.Pool().Exec(r.Context(),
		`INSERT INTO users (tenant_id, email, password_hash, role) VALUES ($1,$2,$3,$4)`,
		tenantID, email, string(hash), role)
	if err != nil {
		var pe *pgconn.PgError
		if errors.As(err, &pe) && pe.Code == "23505" {
			return errConflictMember("email already a member")
		}
		return errStore
	}
	return nil
}

func (h *memberHandler) remove(w http.ResponseWriter, r *http.Request, p auth.Principal) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil || id <= 0 {
		writeJSONError(w, http.StatusBadRequest, "invalid id")
		return
	}
	if id == p.UserID {
		writeJSONError(w, http.StatusConflict, "cannot remove yourself")
		return
	}
	// The target must belong to the caller's tenant.
	var role string
	if err := h.ts.Pool().QueryRow(r.Context(),
		`SELECT role FROM users WHERE id = $1 AND tenant_id = $2`,
		id, p.TenantID).Scan(&role); err != nil {
		writeJSONError(w, http.StatusNotFound, "not found")
		return
	}
	if auth.NormalizeRole(role) == auth.RoleOwner {
		var owners int
		if err := h.ts.Pool().QueryRow(r.Context(),
			`SELECT count(*) FROM users WHERE tenant_id = $1 AND role = 'owner'`,
			p.TenantID).Scan(&owners); err != nil {
			writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
			return
		}
		if owners <= 1 {
			writeJSONError(w, http.StatusConflict, "cannot remove the last owner")
			return
		}
	}
	if _, err := h.ts.Pool().Exec(r.Context(),
		`DELETE FROM users WHERE id = $1 AND tenant_id = $2`, id, p.TenantID); err != nil {
		writeJSONError(w, http.StatusServiceUnavailable, "store unavailable")
		return
	}
	h.ts.Audit(r.Context(), p.TenantID, strconv.FormatInt(p.UserID, 10), "member.remove",
		"id="+strconv.FormatInt(id, 10), r.RemoteAddr)
	writeJSON(w, http.StatusOK, map[string]any{"ok": true, "id": id})
}

// ---------- error plumbing ----------

type memberError struct {
	msg  string
	code int
}

func (e memberError) Error() string { return e.msg }

var errStore = memberError{msg: "store unavailable", code: http.StatusServiceUnavailable}

func errBadMember(msg string) memberError { return memberError{msg: msg, code: http.StatusBadRequest} }

func errConflictMember(msg string) memberError {
	return memberError{msg: msg, code: http.StatusConflict}
}

func writeMemberError(w http.ResponseWriter, err error) {
	var me memberError
	if errors.As(err, &me) {
		writeJSONError(w, me.code, me.msg)
		return
	}
	writeJSONError(w, http.StatusInternalServerError, "internal error")
}
