// Package db provides the PostgreSQL connection pool and schema migration for
// GarudaShield commercial state (tenants, users, licenses, subscriptions,
// audit log). The engine still uses Redis L1/L2 for hot-path threat state; this
// store is the durable, queryable system of record.
//
// Security notes:
//   - Uses pgx (prepared statements only) — no string-built SQL anywhere.
//   - TLS to Postgres is enforced when DATABASE_URL contains sslmode=require/verify-full.
//   - Connection pool is bounded; a exhausted pool fails closed, never leaks.
//   - All tenant data is keyed by tenant_id; cross-tenant reads are impossible
//     without the tenant scoping in every query (see tenant package).
package db

import (
	"context"
	"fmt"
	"os"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
)

// Connect opens a bounded pool from DATABASE_URL (or GS_DATABASE_URL). It returns
// an error rather than a nil pool on failure — callers must not proceed without
// a verified store.
func Connect() (*pgxpool.Pool, error) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		dsn = os.Getenv("DATABASE_URL")
	}
	if dsn == "" {
		return nil, fmt.Errorf("GS_DATABASE_URL not set")
	}

	cfg, err := pgxpool.ParseConfig(dsn)
	if err != nil {
		return nil, fmt.Errorf("parse DATABASE_URL: %w", err)
	}

	// Bounded pool — fail closed under load instead of exhausting the server.
	if cfg.MaxConns == 0 {
		cfg.MaxConns = 20
	}
	cfg.MinConns = 2
	cfg.MaxConnLifetime = 30 * time.Minute
	cfg.MaxConnIdleTime = 5 * time.Minute
	cfg.HealthCheckPeriod = 30 * time.Second

	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	pool, err := pgxpool.NewWithConfig(ctx, cfg)
	if err != nil {
		return nil, fmt.Errorf("connect postgres: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("postgres ping: %w", err)
	}
	return pool, nil
}

// Migrate creates the commercial schema idempotently. It is safe to call on
// every boot. DDL is static (no user input) so there is no injection surface.
func Migrate(ctx context.Context, pool *pgxpool.Pool) error {
	stmts := []string{
		`CREATE TABLE IF NOT EXISTS tenants (
			id            TEXT PRIMARY KEY,
			name          TEXT NOT NULL,
			plan          TEXT NOT NULL DEFAULT 'free',
			domain        TEXT UNIQUE,
			created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
			license_key   TEXT,
			license_exp   BIGINT NOT NULL DEFAULT 0,
			status        TEXT NOT NULL DEFAULT 'active'
		)`,
		`ALTER TABLE tenants ADD COLUMN IF NOT EXISTS status TEXT NOT NULL DEFAULT 'active'`,
		`CREATE TABLE IF NOT EXISTS users (
			id            BIGSERIAL PRIMARY KEY,
			tenant_id     TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
			email         TEXT NOT NULL,
			password_hash TEXT NOT NULL,
			role          TEXT NOT NULL DEFAULT 'owner',
			created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
			UNIQUE (tenant_id, email)
		)`,
		`CREATE TABLE IF NOT EXISTS subscriptions (
			tenant_id     TEXT PRIMARY KEY REFERENCES tenants(id) ON DELETE CASCADE,
			status        TEXT NOT NULL DEFAULT 'active',
			provider      TEXT,
			plan          TEXT NOT NULL,
			current_period_end BIGINT NOT NULL DEFAULT 0,
			updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
		)`,
		`CREATE TABLE IF NOT EXISTS audit_log (
			id            BIGSERIAL PRIMARY KEY,
			tenant_id     TEXT,
			actor         TEXT,
			action        TEXT NOT NULL,
			detail        TEXT,
			ip            TEXT,
			created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
		)`,
		`CREATE TABLE IF NOT EXISTS api_keys (
			id            BIGSERIAL PRIMARY KEY,
			tenant_id     TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
			name          TEXT NOT NULL,
			prefix        TEXT NOT NULL,
			key_hash      TEXT NOT NULL,
			scopes        TEXT NOT NULL DEFAULT 'read',
			created_at    BIGINT NOT NULL DEFAULT 0,
			last_used_at  BIGINT NOT NULL DEFAULT 0,
			expires_at    BIGINT NOT NULL DEFAULT 0,
			revoked_at    BIGINT NOT NULL DEFAULT 0
		)`,
		`CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id)`,
		`ALTER TABLE users ADD COLUMN IF NOT EXISTS session_version BIGINT NOT NULL DEFAULT 0`,
		`CREATE INDEX IF NOT EXISTS idx_audit_tenant ON audit_log(tenant_id)`,
		`CREATE INDEX IF NOT EXISTS idx_api_keys_tenant ON api_keys(tenant_id)`,
		`CREATE UNIQUE INDEX IF NOT EXISTS idx_api_keys_prefix ON api_keys(prefix)`,
		`CREATE TABLE IF NOT EXISTS usage_quota (
			tenant_id   TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
			period      TEXT NOT NULL,
			requests    BIGINT NOT NULL DEFAULT 0,
			PRIMARY KEY (tenant_id, period)
		)`,
		`ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_secret TEXT NOT NULL DEFAULT ''`,
		`ALTER TABLE users ADD COLUMN IF NOT EXISTS mfa_enabled BOOLEAN NOT NULL DEFAULT false`,
		`CREATE TABLE IF NOT EXISTS mfa_recovery (
			code_hash   TEXT PRIMARY KEY,
			user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
			used_at     BIGINT NOT NULL DEFAULT 0
		)`,
		`CREATE INDEX IF NOT EXISTS idx_mfa_recovery_user ON mfa_recovery(user_id)`,
		`CREATE TABLE IF NOT EXISTS password_resets (
			token_hash  TEXT PRIMARY KEY,
			user_id     BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
			created_at  BIGINT NOT NULL DEFAULT 0,
			expires_at  BIGINT NOT NULL,
			used_at     BIGINT NOT NULL DEFAULT 0
		)`,
		`CREATE INDEX IF NOT EXISTS idx_password_resets_user ON password_resets(user_id)`,
		`CREATE TABLE IF NOT EXISTS protected_assets (
			id           BIGSERIAL PRIMARY KEY,
			tenant_id    TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
			domain       TEXT NOT NULL,
			origin_host  TEXT NOT NULL DEFAULT '',
			origin_port  INTEGER NOT NULL DEFAULT 0,
			status       TEXT NOT NULL DEFAULT 'pending',
			verify_token TEXT NOT NULL DEFAULT '',
			created_at   BIGINT NOT NULL DEFAULT 0,
			verified_at  BIGINT NOT NULL DEFAULT 0,
			UNIQUE (domain)
		)`,
		`CREATE INDEX IF NOT EXISTS idx_protected_assets_tenant ON protected_assets(tenant_id)`,
		`CREATE INDEX IF NOT EXISTS idx_protected_assets_domain ON protected_assets(domain, status)`,
		`CREATE TABLE IF NOT EXISTS domain_policies (
			domain       TEXT PRIMARY KEY,
			tenant_id    TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
			config       JSONB NOT NULL DEFAULT '{}'::jsonb,
			updated_at   BIGINT NOT NULL DEFAULT 0,
			updated_by   TEXT NOT NULL DEFAULT ''
		)`,
		`CREATE INDEX IF NOT EXISTS idx_domain_policies_tenant ON domain_policies(tenant_id)`,
	}
	for _, s := range stmts {
		if _, err := pool.Exec(ctx, s); err != nil {
			return fmt.Errorf("migrate: %w", err)
		}
	}
	return nil
}
