// Package geo provides optional offline IP enrichment: country from an
// ip-to-country MMDB, and ASN from an ip-to-asn MMDB.
//
// Two deliberate design constraints:
//
//  1. Optional by construction. A nil *Resolver is fully usable — every method
//     is nil-safe and reports "no data". Callers therefore never need to check
//     whether geo is configured, and a missing database can never take the
//     engine down.
//
//  2. Offline only. Lookups never leave the process. Sending visitor IPs to a
//     third-party lookup API would make every attacker-controlled IP an
//     outbound request (an amplification vector against our own egress) and
//     would share visitor data with a third party. A local MMDB avoids both.
//
// Databases are memory-mapped, so a large file does not become resident
// memory. Free, redistributable builds are published by sapics/ip-location-db;
// see tools/fetch-geodb.ps1. The reader is oschwald/maxminddb-golang/v2 and
// works with any valid .mmdb regardless of publisher.
package geo

import (
	"errors"
	"fmt"
	"net/netip"
	"os"
	"strconv"
	"sync/atomic"

	"github.com/oschwald/maxminddb-golang/v2"
)

// Location is the enrichment result for one IP. Zero values mean "unknown";
// callers render them as an em dash rather than guessing.
type Location struct {
	CountryCode string `json:"countryCode,omitempty"` // ISO 3166-1 alpha-2, e.g. "ID"
	Country     string `json:"country,omitempty"`     // English name when the DB carries one
	ASN         string `json:"asn,omitempty"`         // e.g. "AS15169"
	Org         string `json:"org,omitempty"`         // autonomous system organization
}

// Empty reports whether nothing was resolved.
func (l Location) Empty() bool {
	return l.CountryCode == "" && l.ASN == ""
}

// Resolver holds the open MMDB readers. A nil *Resolver behaves as disabled.
type Resolver struct {
	country *maxminddb.Reader
	asn     *maxminddb.Reader

	lookups atomic.Uint64
	hits    atomic.Uint64
}

// countryRecord covers both GeoLite2-style country databases (nested
// "country.iso_code") and the flatter third-party layouts that expose
// "country_code" at the top level. Decoding both keys means one struct works
// across publishers instead of silently returning blanks on the other layout.
type countryRecord struct {
	Country struct {
		ISOCode string            `maxminddb:"iso_code"`
		Names   map[string]string `maxminddb:"names"`
	} `maxminddb:"country"`
	RegisteredCountry struct {
		ISOCode string `maxminddb:"iso_code"`
	} `maxminddb:"registered_country"`
	CountryCode string `maxminddb:"country_code"`
}

type asnRecord struct {
	Number uint   `maxminddb:"autonomous_system_number"`
	Org    string `maxminddb:"autonomous_system_organization"`
}

// Open loads whichever databases are present. Empty paths are skipped, and a
// path that does not exist is skipped rather than failing — an operator who has
// not fetched the databases yet still gets a working engine. A path that exists
// but cannot be opened IS an error: that means a corrupt or truncated file, and
// silently ignoring it would hide a real misconfiguration.
func Open(countryPath, asnPath string) (*Resolver, error) {
	r := &Resolver{}

	if db, err := openIfPresent(countryPath); err != nil {
		return nil, fmt.Errorf("country database: %w", err)
	} else {
		r.country = db
	}

	if db, err := openIfPresent(asnPath); err != nil {
		r.Close()
		return nil, fmt.Errorf("asn database: %w", err)
	} else {
		r.asn = db
	}

	if r.country == nil && r.asn == nil {
		return nil, nil // nothing configured: disabled, not an error
	}
	return r, nil
}

func openIfPresent(path string) (*maxminddb.Reader, error) {
	if path == "" {
		return nil, nil
	}
	if _, err := os.Stat(path); errors.Is(err, os.ErrNotExist) {
		return nil, nil
	}
	return maxminddb.Open(path)
}

// Available reports whether any database is loaded.
func (r *Resolver) Available() bool {
	return r != nil && (r.country != nil || r.asn != nil)
}

// HasCountry reports whether country lookups can resolve.
func (r *Resolver) HasCountry() bool { return r != nil && r.country != nil }

// HasASN reports whether ASN lookups can resolve.
func (r *Resolver) HasASN() bool { return r != nil && r.asn != nil }

// Lookup enriches a single IP. It never returns an error: enrichment is
// best-effort metadata, and a failed lookup must not change a security verdict
// or fail an API response. Unparseable input and missing records both yield an
// empty Location.
func (r *Resolver) Lookup(ip string) Location {
	if !r.Available() {
		return Location{}
	}
	addr, err := netip.ParseAddr(ip)
	if err != nil {
		return Location{}
	}
	// IPv4-mapped IPv6 (::ffff:1.2.3.4) must be unmapped, or every lookup in
	// an IPv4 database misses.
	addr = addr.Unmap()

	r.lookups.Add(1)
	var out Location

	if r.country != nil {
		var rec countryRecord
		if err := r.country.Lookup(addr).Decode(&rec); err == nil {
			out.CountryCode = firstNonEmpty(
				rec.Country.ISOCode,
				rec.CountryCode,
				rec.RegisteredCountry.ISOCode,
			)
			out.Country = rec.Country.Names["en"]
		}
	}

	if r.asn != nil {
		var rec asnRecord
		if err := r.asn.Lookup(addr).Decode(&rec); err == nil && rec.Number != 0 {
			out.ASN = "AS" + strconv.FormatUint(uint64(rec.Number), 10)
			out.Org = rec.Org
		}
	}

	if !out.Empty() {
		r.hits.Add(1)
	}
	return out
}

// Stats reports lookup counters for the dashboard.
func (r *Resolver) Stats() (lookups, hits uint64) {
	if r == nil {
		return 0, 0
	}
	return r.lookups.Load(), r.hits.Load()
}

// Close releases the mapped files.
func (r *Resolver) Close() {
	if r == nil {
		return
	}
	if r.country != nil {
		_ = r.country.Close()
		r.country = nil
	}
	if r.asn != nil {
		_ = r.asn.Close()
		r.asn = nil
	}
}

func firstNonEmpty(values ...string) string {
	for _, v := range values {
		if v != "" {
			return v
		}
	}
	return ""
}
