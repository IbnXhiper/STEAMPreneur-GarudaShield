package geo

import (
	"os"
	"testing"
)

// TestNilSafe verifies a nil *Resolver never panics and reports "no data".
func TestNilSafe(t *testing.T) {
	var r *Resolver
	if r.Available() {
		t.Error("nil resolver must report not available")
	}
	if r.HasCountry() || r.HasASN() {
		t.Error("nil resolver must report no country/asn")
	}
	// Lookup on nil must not panic and returns zero Location.
	loc := r.Lookup("1.2.3.4")
	if !loc.Empty() {
		t.Errorf("nil lookup must be empty, got %+v", loc)
	}
	lookups, hits := r.Stats()
	if lookups != 0 || hits != 0 {
		t.Error("nil stats must be zero")
	}
	// Close on nil must be a no-op.
	r.Close()
}

// TestLookupUnparseable verifies garbage input yields an empty Location without
// erroring (enrichment must never affect a verdict).
func TestLookupUnparseable(t *testing.T) {
	r := &Resolver{} // no DB loaded
	loc := r.Lookup("not-an-ip")
	if !loc.Empty() {
		t.Errorf("unparseable IP should be empty, got %+v", loc)
	}
}

// TestOpenMissingPaths verifies Open returns (nil, nil) when no database is
// configured — enrichment is optional, not an error.
func TestOpenMissingPaths(t *testing.T) {
	r, err := Open("", "")
	if r != nil {
		t.Error("Open with empty paths should return nil resolver")
	}
	if err != nil {
		t.Errorf("Open with empty paths should not error, got %v", err)
	}
}

// TestLookupRealMMDB exercises the real offline resolver against the bundled
// GeoLite2 databases (when present). It asserts country + ASN enrichment for a
// well-known public IP, proving the decoder handles the GeoLite2 layout.
// Skipped automatically if the databases are not checked out locally.
func TestLookupRealMMDB(t *testing.T) {
	const country = "../../data/GeoIP/geoip-country.mmdb"
	const asn = "../../data/GeoIP/geoip-asn.mmdb"
	if _, err := os.Stat(country); err != nil {
		t.Skip("country MMDB not present; download via tools/fetch-geodb.ps1")
	}
	r, err := Open(country, asn)
	if err != nil {
		t.Fatalf("Open failed: %v", err)
	}
	defer r.Close()
	if !r.Available() {
		t.Fatal("resolver should be available after Open")
	}
	if !r.HasCountry() {
		t.Error("country DB loaded but HasCountry false")
	}
	// 8.8.8.8 is Google DNS — reliably present in GeoLite2 as US / AS15169.
	loc := r.Lookup("8.8.8.8")
	if loc.CountryCode == "" {
		t.Errorf("expected country code for 8.8.8.8, got empty (%+v)", loc)
	}
	if loc.ASN == "" {
		t.Errorf("expected ASN for 8.8.8.8, got empty (%+v)", loc)
	}
	// Stats must reflect the lookup.
	lookups, hits := r.Stats()
	if lookups < 1 {
		t.Errorf("expected at least 1 lookup, got %d", lookups)
	}
	if hits < 1 {
		t.Errorf("expected at least 1 hit, got %d", hits)
	}
	// A private IP should resolve to empty (not in the public DB).
	priv := r.Lookup("10.0.0.1")
	if !priv.Empty() {
		t.Errorf("private IP should be empty, got %+v", priv)
	}
}
