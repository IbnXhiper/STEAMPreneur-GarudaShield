package shield

import (
	"context"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/defense/reputation"
)

func mustCtx() context.Context { return context.Background() }

// TestReputationMirroredToL2 verifies reputation score mutations mirror into
// the state store and rehydrate into a fresh Shield (restart survival).
func TestReputationMirroredToL2(t *testing.T) {
	cfg := config.Default()
	cfg.Cluster.Redis.Enabled = false // memory store: same code path
	s1 := New(cfg)
	defer s1.Close()

	s1.Rep.Adjust("203.0.113.90", 90, "test-attack")
	if got := s1.Rep.GetScore("203.0.113.90"); got != 90 {
		t.Fatalf("local score must be 90, got %d", got)
	}
	// The score must have been mirrored to the shared store.
	if _, ok := s1.store.Get(mustCtx(), "rep:203.0.113.90"); !ok {
		t.Fatal("rep:<ip> must exist in L2 store after Adjust")
	}

	// Fresh shield over the same store: score must rehydrate.
	s2 := New(cfg)
	defer s2.Close()
	s2.store = s1.store
	s2.rehydrateReputation()
	if got := s2.Rep.GetScore("203.0.113.90"); got != 90 {
		t.Fatalf("score must rehydrate from L2, got %d", got)
	}

	// Reset must clear the L2 mirror too.
	s1.Rep.Reset("203.0.113.90")
	if _, ok := s1.store.Get(mustCtx(), "rep:203.0.113.90"); ok {
		t.Fatal("rep:<ip> must be deleted from L2 on Reset")
	}
}

// TestReputationWithoutL2 verifies the engine works unchanged when no state
// store is attached (single-node ephemeral mode, v2 parity).
func TestReputationWithoutL2(t *testing.T) {
	e := reputation.New(config.Reputation{})
	e.Adjust("1.2.3.4", 50, "x")
	if got := e.GetScore("1.2.3.4"); got != 50 {
		t.Fatalf("score must work without L2, got %d", got)
	}
	e.RestoreScore("1.2.3.4", -100)
	if got := e.GetScore("1.2.3.4"); got != -100 {
		t.Fatalf("RestoreScore must seed (clamped) score, got %d", got)
	}
}
