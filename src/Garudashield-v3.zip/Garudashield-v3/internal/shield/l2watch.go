package shield

import "time"

// L2 health watch: when the Redis-backed state store goes down the engine
// silently degrades to local mode (fail-safe, but a cluster becomes
// inconsistent: blocks made while down do not propagate). checkL2Health
// detects the transition and alerts the operator ONCE per transition so a
// split-brain never happens silently.
//
// Called from healthLoop every 5s.

// checkL2Health compares the current store mode against the last known mode
// and fires a notifier alert on down/up transitions. It also records when the
// store went down so /api/status can report the outage duration.
func (s *Shield) checkL2Health() {
	wasDown := s.l2DownSince.Load() != 0
	down := s.cfg.Cluster.Redis.Enabled && !s.store.Healthy()

	switch {
	case down && !wasDown:
		s.l2DownSince.Store(time.Now().UnixMilli())
		s.addEvent("mode", "system", "l2-down", 0)
		s.notifier.Send("warning", "L2 state store DOWN — degraded to local mode", map[string]string{
			"impact": "blocklist/reputation sync paused; node diverges until restored",
		})
	case !down && wasDown:
		durMs := time.Now().UnixMilli() - s.l2DownSince.Load()
		s.l2DownSince.Store(0)
		s.addEvent("mode", "system", "l2-restored", 0)
		s.notifier.Send("info", "L2 state store restored", map[string]string{
			"outageMs": itoaInt64(durMs),
		})
	}
}

// L2DownSince reports when the L2 store went down (0 = healthy/never down).
func (s *Shield) L2DownSince() int64 { return s.l2DownSince.Load() }

func itoaInt64(v int64) string {
	if v == 0 {
		return "0"
	}
	neg := v < 0
	if neg {
		v = -v
	}
	var b [20]byte
	i := len(b)
	for v > 0 {
		i--
		b[i] = byte('0' + v%10)
		v /= 10
	}
	if neg {
		i--
		b[i] = '-'
	}
	return string(b[i:])
}
