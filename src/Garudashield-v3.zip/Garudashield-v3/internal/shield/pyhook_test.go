package shield

import (
	"context"
	"io"
	"net/http/httptest"
	"os"
	"os/exec"
	"path/filepath"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

// pyBinary locates a Python interpreter that actually runs. It deliberately
// verifies the binary executes: on Windows "python3"/"python" are frequently
// App Execution Alias stubs pointing at the Microsoft Store that LookPath
// resolves happily but that only print an install prompt and exit non-zero.
// Treating such a stub as present makes the hook fail with "pyhook-exec"
// instead of skipping, so a functional interpreter is required.
// Set GARUDASHIELD_PYTHON to point at an interpreter not on PATH.
func pyBinary(t *testing.T) string {
	t.Helper()
	if p := findPython(); p != "" {
		return p
	}
	t.Skip("no working python3 interpreter available, skipping shield pyhook tests")
	return ""
}

func findPython() string {
	candidates := []string{}
	if env := os.Getenv("GARUDASHIELD_PYTHON"); env != "" {
		candidates = append(candidates, env)
	}
	candidates = append(candidates, "python3", "python")
	for _, name := range candidates {
		p, err := exec.LookPath(name)
		if err != nil {
			continue
		}
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		cmd := exec.CommandContext(ctx, p, "-c", "import sys")
		cmd.Stdout = io.Discard
		cmd.Stderr = io.Discard
		err = cmd.Run()
		cancel()
		if err == nil {
			return p
		}
	}
	return ""
}

func pyScript(t *testing.T, body string) string {
	t.Helper()
	p := filepath.Join(t.TempDir(), "hook.py")
	if err := os.WriteFile(p, []byte(body), 0600); err != nil {
		t.Fatal(err)
	}
	return p
}

func viewFor(path string) *reqview.View {
	r := httptest.NewRequest("GET", "http://x"+path, nil)
	r.Header.Set("User-Agent", "test-agent")
	r.RemoteAddr = "1.1.1.11:1234"
	return reqview.New(r, nil)
}

// Enforce mode: a Python block verdict must hard-block an otherwise clean IP.
func TestPyHookEnforceBlock(t *testing.T) {
	py := pyBinary(t)
	cfg := config.Default()
	cfg.Shield.BudgetMs = 30000
	cfg.PyHook.Enabled = true
	cfg.PyHook.Mode = "enforce"
	cfg.PyHook.Python = py
	cfg.PyHook.TimeoutMs = 20000
	cfg.PyHook.Script = pyScript(t, "print('{\"action\":\"block\",\"reason\":\"ml-test\"}')\n")
	s := New(cfg)
	defer s.Close()
	d := s.Evaluate(viewFor("/clean-path"), "1.1.1.11")
	if d.Action != ActionBlock || d.Reason != "pyhook:ml-test" {
		t.Fatalf("got %+v, want pyhook block", d)
	}
}

// Monitor mode: the same verdict must only record, never block.
func TestPyHookMonitorNoBlock(t *testing.T) {
	py := pyBinary(t)
	cfg := config.Default()
	cfg.Shield.BudgetMs = 30000
	cfg.PyHook.Enabled = true
	cfg.PyHook.Mode = "monitor"
	cfg.PyHook.Python = py
	cfg.PyHook.TimeoutMs = 20000
	cfg.PyHook.Script = pyScript(t, "print('{\"action\":\"block\",\"reason\":\"ml-test\"}')\n")
	s := New(cfg)
	defer s.Close()
	d := s.Evaluate(viewFor("/clean-path"), "1.1.1.12")
	if d.Action == ActionBlock && d.Reason == "pyhook:ml-test" {
		t.Fatalf("monitor mode must not block, got %+v", d)
	}
}

// Disabled hook: nil, zero cost, pipeline unaffected.
func TestPyHookDisabled(t *testing.T) {
	cfg := config.Default()
	s := New(cfg)
	defer s.Close()
	if s.Py != nil {
		t.Fatal("disabled pyhook must be nil")
	}
}
