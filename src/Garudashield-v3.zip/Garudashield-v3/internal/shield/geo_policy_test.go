package shield

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/geo"
)

// geoStub lets tests fake country resolution without MMDB files. It patches
// the Shield's resolver via the geoForPolicy hook (production path uses
// s.Geo directly).
type geoStub struct{ country string }

// TestGeoDecisionPolicyOff verifies the no-policy fast path: with empty
// block/allow lists nothing is ever blocked, even without any geo resolver.
func TestGeoDecisionPolicyOff(t *testing.T) {
	s := newTestShield()
	s.Geo = nil // no MMDB at all
	if d, blocked := s.geoDecision("8.8.8.8"); blocked {
		t.Fatalf("policy off must never block: %+v", d)
	}
}

// TestGeoDecisionDefaultDenyNoDB verifies default-deny mode: a non-empty
// allowlist blocks unknown countries AND missing databases (fail-closed for
// the allowlist contract: "only these countries may pass").
func TestGeoDecisionDefaultDenyNoDB(t *testing.T) {
	s := newTestShield()
	s.Geo = nil // no MMDB: every country is unknown
	s.cfg.Geo.GeoPolicy = config.GeoPolicyConfig{
		AllowlistCountries: []string{"ID"},
	}
	d, blocked := s.geoDecision("8.8.8.8")
	if !blocked || d.Reason != "geo-unknown-country" {
		t.Fatalf("no DB + allowlist must block unknown: blocked=%v d=%+v", blocked, d)
	}
}

// TestGeoDecisionWithoutPolicyNoDB verifies no DB + blocklist-only = pass
// (fail-open for unknown countries; enrichment must never take the engine down).
func TestGeoDecisionWithoutPolicyNoDB(t *testing.T) {
	s := newTestShield()
	s.Geo = nil
	s.cfg.Geo.GeoPolicy = config.GeoPolicyConfig{
		BlocklistCountries: []string{"CN"},
	}
	if _, blocked := s.geoDecision("1.2.3.4"); blocked {
		t.Fatal("no DB + blocklist-only must pass (fail-open for unknown)")
	}
}

// TestGeoDecisionBlocklist verifies the blocklist path using the geo test hook.
func TestGeoDecisionBlocklist(t *testing.T) {
	s := newTestShield()
	s.cfg.Geo.GeoPolicy = config.GeoPolicyConfig{
		BlocklistCountries: []string{"cn"}, // case-insensitive
	}
	geoTestSet, geoTestCountry = true, "CN"
	defer func() { geoTestSet = false }()
	d, blocked := s.geoDecision("1.2.3.4")
	if !blocked || d.Reason != "geo-blocked-CN" {
		t.Fatalf("blocklisted country must block: blocked=%v d=%+v", blocked, d)
	}

	geoTestCountry = "ID"
	if _, blocked := s.geoDecision("1.2.3.4"); blocked {
		t.Fatal("non-blocklisted country must pass")
	}
}

// TestGeoDecisionAllowlist verifies allowlist mode end to end.
func TestGeoDecisionAllowlist(t *testing.T) {
	s := newTestShield()
	s.cfg.Geo.GeoPolicy = config.GeoPolicyConfig{
		AllowlistCountries: []string{"ID", "SG"},
	}
	geoTestSet = true
	defer func() { geoTestSet = false }()

	geoTestCountry = "ID"
	if _, blocked := s.geoDecision("1.2.3.4"); blocked {
		t.Fatal("allowlisted country must pass")
	}
	geoTestCountry = "US"
	d, blocked := s.geoDecision("1.2.3.4")
	if !blocked || d.Reason != "geo-not-allowed-US" {
		t.Fatalf("non-allowlisted country must block: blocked=%v d=%+v", blocked, d)
	}
	geoTestCountry = "" // unknown country
	if _, blocked = s.geoDecision("1.2.3.4"); !blocked {
		t.Fatal("unknown country under allowlist must block (default-deny)")
	}
}

// compile-time guard: geo.Location stays the enrichment contract.
var _ = geo.Location{}
