package shield

import (
	"context"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/defense/layer7"
	"github.com/ahkurdev/garudashield/internal/defense/waf"
	"github.com/ahkurdev/garudashield/internal/policy"
	"github.com/ahkurdev/garudashield/internal/ratelimit"
)

// runtime is the per-request evaluation context. The global runtime wraps the
// Shield's shared components; a domain runtime overlays a tenant policy and
// owns only the components that policy actually overrides (so an unset knob
// keeps using the live global component instead of a stale copy).
type runtime struct {
	cfg        *config.Config
	l7         *layer7.Defender
	waf        *waf.Engine
	rate       *ratelimit.Limiter
	isGlobal   bool
	emergency  bool
	aggressive bool

	ownL7   bool
	ownWAF  bool
	ownRate bool
}

// closeOwned releases only the components this runtime created.
func (rt *runtime) closeOwned() {
	if rt == nil {
		return
	}
	if rt.ownL7 && rt.l7 != nil {
		rt.l7.Close()
	}
	if rt.ownWAF && rt.waf != nil {
		rt.waf.Close()
	}
	if rt.ownRate && rt.rate != nil {
		rt.rate.Close()
	}
}

// domainEntry is one domain's policy and its lazily-built runtime.
type domainEntry struct {
	pol       policy.Policy
	tenantID  string
	updatedAt int64

	mu sync.Mutex
	rt *runtime
}

func (e *domainEntry) runtimeFor(s *Shield) *runtime {
	e.mu.Lock()
	defer e.mu.Unlock()
	if e.rt == nil {
		e.rt = s.buildDomainRuntime(e.pol)
	}
	return e.rt
}

// initDomains wires the always-present global runtime. Called from New.
func (s *Shield) initDomains() {
	s.domains = make(map[string]*domainEntry)
	s.globalRT = &runtime{
		cfg:      &s.cfg,
		l7:       s.L7,
		waf:      s.WAF,
		rate:     s.Rate,
		isGlobal: true,
	}
}

// buildDomainRuntime overlays a policy on the global config and constructs only
// the components the policy overrides. Fail-closed: the effective config is a
// copy of the global baseline with the policy applied, so an empty policy can
// never weaken protection.
func (s *Shield) buildDomainRuntime(p policy.Policy) *runtime {
	eff := p.Apply(s.cfg)
	rt := &runtime{
		cfg:        &eff,
		emergency:  p.Emergency(),
		aggressive: p.Aggressive(s.aggMode.Load()),
	}
	if p.Layer7 != nil {
		rt.l7 = layer7.New(eff.Defense.Layer7)
		rt.ownL7 = true
	} else {
		rt.l7 = s.L7
	}
	if p.WAF != nil {
		rt.waf = waf.New(eff.Defense.WAF)
		rt.ownWAF = true
	} else {
		rt.waf = s.WAF
	}
	if p.RateLimit != nil {
		rt.rate = ratelimit.New(eff.Defense.RateLimit)
		rt.ownRate = true
	} else {
		rt.rate = s.Rate
	}
	return rt
}

// runtimeFor resolves the evaluation context for a request Host. With no
// policies loaded this is a single map-length check.
func (s *Shield) runtimeFor(host string) *runtime {
	if s.globalRT == nil {
		return nil
	}
	if len(s.domains) == 0 {
		return s.globalRT
	}
	d := policy.NormalizeDomain(host)
	if d == "" {
		return s.globalRT
	}
	s.domMu.RLock()
	e := s.domains[d]
	s.domMu.RUnlock()
	if e == nil {
		return s.globalRT
	}
	return e.runtimeFor(s)
}

// SetDomainPolicy installs (or replaces) the policy for a domain and drops any
// cached runtime so the next request rebuilds it from the new policy.
func (s *Shield) SetDomainPolicy(domain string, p policy.Policy, tenantID string, updatedAt int64) {
	d := policy.NormalizeDomain(domain)
	if d == "" {
		return
	}
	s.domMu.Lock()
	e := s.domains[d]
	if e == nil {
		e = &domainEntry{}
		s.domains[d] = e
	}
	e.mu.Lock()
	e.rt.closeOwned()
	e.pol, e.tenantID, e.updatedAt, e.rt = p, tenantID, updatedAt, nil
	e.mu.Unlock()
	s.domMu.Unlock()
}

// DeleteDomainPolicy removes a domain's policy so it falls back to global.
func (s *Shield) DeleteDomainPolicy(domain string) {
	d := policy.NormalizeDomain(domain)
	if d == "" {
		return
	}
	s.domMu.Lock()
	if e := s.domains[d]; e != nil {
		delete(s.domains, d)
		e.mu.Lock()
		e.rt.closeOwned()
		e.rt = nil
		e.mu.Unlock()
	}
	s.domMu.Unlock()
}

// DomainPolicy returns a copy of the domain's stored policy, if any.
func (s *Shield) DomainPolicy(domain string) (policy.Policy, bool) {
	d := policy.NormalizeDomain(domain)
	if d == "" {
		return policy.Policy{}, false
	}
	s.domMu.RLock()
	e := s.domains[d]
	s.domMu.RUnlock()
	if e == nil {
		return policy.Policy{}, false
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.pol, true
}

// DomainCount reports how many per-domain policies are loaded.
func (s *Shield) DomainCount() int {
	s.domMu.RLock()
	defer s.domMu.RUnlock()
	return len(s.domains)
}

// LoadPolicyEntries reconciles the in-memory registry with a full set of
// stored policies (used at boot and by the background poller). Domains absent
// from entries are removed; domains whose row is unchanged keep their live
// runtime (so a periodic reconcile never resets per-domain rate counters).
func (s *Shield) LoadPolicyEntries(entries map[string]policy.Entry) {
	seen := make(map[string]bool, len(entries))
	for domain, e := range entries {
		d := policy.NormalizeDomain(domain)
		seen[d] = true
		if s.domainUnchanged(d, e.TenantID, e.UpdatedAt) {
			continue
		}
		s.SetDomainPolicy(domain, e.Policy, e.TenantID, e.UpdatedAt)
	}
	s.domMu.RLock()
	stale := make([]string, 0)
	for d := range s.domains {
		if !seen[d] {
			stale = append(stale, d)
		}
	}
	s.domMu.RUnlock()
	for _, d := range stale {
		s.DeleteDomainPolicy(d)
	}
}

// domainUnchanged reports whether the stored row matches what is already
// loaded, so the poller can skip a no-op rebuild.
func (s *Shield) domainUnchanged(d, tenantID string, updatedAt int64) bool {
	s.domMu.RLock()
	e := s.domains[d]
	s.domMu.RUnlock()
	if e == nil {
		return false
	}
	e.mu.Lock()
	defer e.mu.Unlock()
	return e.tenantID == tenantID && e.updatedAt == updatedAt
}

// StartPolicyWatcher loads stored policies once and then reconciles them every
// interval until the Shield closes. Both nodes share Postgres, so a change
// applied on one node is picked up by the other within one interval without a
// dedicated bus. A store error leaves the current registry untouched.
func (s *Shield) StartPolicyWatcher(st *policy.Store, interval time.Duration) {
	if st == nil {
		return
	}
	if interval <= 0 {
		interval = 10 * time.Second
	}
	load := func() {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		entries, err := st.List(ctx)
		if err != nil {
			return
		}
		s.LoadPolicyEntries(entries)
	}
	load()
	go func() {
		t := time.NewTicker(interval)
		defer t.Stop()
		for {
			select {
			case <-s.stop:
				return
			case <-t.C:
				load()
			}
		}
	}()
}

func (s *Shield) closeDomainRuntimes() {
	s.domMu.Lock()
	for d, e := range s.domains {
		e.mu.Lock()
		e.rt.closeOwned()
		e.rt = nil
		e.mu.Unlock()
		delete(s.domains, d)
	}
	s.domMu.Unlock()
}

// isEmergency / isAggressive read the live atomic for the global runtime so
// operator mode changes still take effect, and the static policy value for a
// domain runtime.
func (s *Shield) isEmergency(rt *runtime) bool {
	if rt == nil || rt.isGlobal {
		return s.emergency.Load()
	}
	return rt.emergency
}

func (s *Shield) isAggressive(rt *runtime) bool {
	if rt == nil || rt.isGlobal {
		return s.aggMode.Load()
	}
	return rt.aggressive
}
