// Package shield is the v3 port of v2's src/shield.js orchestrator: the
// request pipeline with its exact fast-path ordering, hybrid scoring
// thresholds (20/60), verdict/auto-block caches, flood fast-path, mode state
// machine and event ring.
package shield

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/defense/analyzer"
	"github.com/ahkurdev/garudashield/internal/defense/anomaly"
	"github.com/ahkurdev/garudashield/internal/defense/challenge"
	"github.com/ahkurdev/garudashield/internal/defense/fingerprint"
	"github.com/ahkurdev/garudashield/internal/defense/honeypot"
	"github.com/ahkurdev/garudashield/internal/defense/layer4"
	"github.com/ahkurdev/garudashield/internal/defense/layer7"
	"github.com/ahkurdev/garudashield/internal/defense/reputation"
	"github.com/ahkurdev/garudashield/internal/defense/waf"
	"github.com/ahkurdev/garudashield/internal/geo"
	"github.com/ahkurdev/garudashield/internal/offload"
	"github.com/ahkurdev/garudashield/internal/pyhook"
	"github.com/ahkurdev/garudashield/internal/ratelimit"
	"github.com/ahkurdev/garudashield/internal/statestore"
	"github.com/ahkurdev/garudashield/internal/storage"
	"github.com/ahkurdev/garudashield/internal/token"
)

const (
	ActionPass      = "pass"
	ActionChallenge = "challenge"
	ActionBlock     = "block"
)

// Decision is the pipeline verdict (v2 evaluate() return shape).
type Decision struct {
	Action      string `json:"action"`
	Score       int    `json:"score"`
	Reason      string `json:"reason,omitempty"`
	ChallengeID string `json:"challengeId,omitempty"`
	RetryAfter  int64  `json:"retryAfter,omitempty"`
	Token       string `json:"-"`
}

type blockEntry struct {
	Expires int64  `json:"e"`
	Reason  string `json:"r"`
	Score   int    `json:"s"`
}

type verdict struct {
	action      string
	reason      string
	score       int
	challengeID string
	until       int64
}

type autoBlockEntry struct {
	until  int64
	reason string
	score  int
}

// Notifier receives alert callbacks (wired to alerts package in Phase 3).
type Notifier interface {
	Send(severity, title string, fields map[string]string)
}

// PeerBroadcaster lets the engine propagate blocklist mutations to peer nodes
// (Phase 3 cluster sync). It is optional; nil means single-node operation.
type PeerBroadcaster interface {
	Broadcast(op, ip, rec string, ttlMs int64)
}

type noopNotifier struct{}

func (noopNotifier) Send(string, string, map[string]string) {}

// Event mirrors v2's _addEvent entry.
type Event struct {
	Time   int64  `json:"time"`
	Type   string `json:"type"`
	IP     string `json:"ip"`
	Detail string `json:"detail"`
	Score  int    `json:"score"`
	ID     string `json:"id"`
}

// Shield wires every defense module and owns pipeline state.
type Shield struct {
	cfg config.Config

	L4   *layer4.Defender
	L7   *layer7.Defender
	WAF  *waf.Engine
	Rate *ratelimit.Limiter
	FP   *fingerprint.Fingerprinter
	Chal *challenge.Manager
	Rep  *reputation.Engine
	Anom *anomaly.Detector
	Ana  *analyzer.Analyzer
	Geo  *geo.Resolver
	Py   *pyhook.Hook
	// Honey blocks scanner/exploit probe paths (/.env, /.git, /wp-login, ...)
	// outright before any heavier inspection.
	Honey *honeypot.Guard
	// roleEdge short-circuits Evaluate after L4/rate-limit: this node is a
	// Tier-1 scrubber and forwards the rest to a core tier node.
	roleEdge bool

	challengeSecret string

	blocksMu  sync.RWMutex
	whitelist map[string]bool
	store     statestore.StateStore
	autoBlock sync.Map // ip -> autoBlockEntry
	verdicts  sync.Map // ip -> verdict
	sessions  *storage.Store

	// Per-domain (per protected website) policy overlay. The global runtime
	// wraps the shared components; a domain runtime is built lazily when a
	// policy exists for the request Host.
	domMu    sync.RWMutex
	domains  map[string]*domainEntry
	globalRT *runtime

	emergency   atomic.Bool
	aggMode     atomic.Bool
	floodMode   atomic.Bool
	floodSince  atomic.Int64
	l2DownSince atomic.Int64 // unix ms when L2 went down; 0 = healthy

	eventsMu sync.Mutex
	events   []Event

	totalProcessed  atomic.Uint64
	totalBlocked    atomic.Uint64
	totalChallenged atomic.Uint64
	totalPassed     atomic.Uint64
	budgetExceeded  atomic.Uint64

	attackMu        sync.Mutex
	attackActive    bool
	attackSeverity  string
	attackStartedAt time.Time
	attackTotal     int

	notifier Notifier
	peer     PeerBroadcaster
	blkSync  offload.Offloader // optional kernel offload (XDP) kept in sync with blocklist
	stop     chan struct{}
	once     sync.Once
}

func New(cfg config.Config) *Shield {
	if cfg.Version == "" {
		cfg = config.Default()
	}
	var geoResolver *geo.Resolver
	if cfg.Geo.Enabled {
		geoResolver, _ = geo.Open(cfg.Geo.CountryPath, cfg.Geo.ASNPath)
	}
	s := &Shield{
		cfg:      cfg,
		L4:       layer4.New(cfg.Defense.Layer4),
		L7:       layer7.New(cfg.Defense.Layer7),
		WAF:      waf.New(cfg.Defense.WAF),
		Rate:     ratelimit.New(cfg.Defense.RateLimit),
		FP:       fingerprint.New(cfg.Defense.Fingerprint),
		Chal:     challenge.New(cfg.Defense.Fingerprint),
		Rep:      reputation.New(cfg.Reputation),
		Anom:     anomaly.New(cfg.Anomaly),
		Ana:      analyzer.New(cfg.Detection),
		Geo:      geoResolver,
		Honey:    honeypot.New(cfg.Defense.Honeypot),
		roleEdge: cfg.Cluster.Role == "edge",
		Py: pyhook.New(pyhook.Config{
			Enabled:    cfg.PyHook.Enabled,
			Script:     cfg.PyHook.Script,
			Python:     cfg.PyHook.Python,
			TimeoutMs:  cfg.PyHook.TimeoutMs,
			Mode:       cfg.PyHook.Mode,
			FailClosed: cfg.PyHook.FailClosed,
			Worker:     cfg.PyHook.Worker,
		}),
		challengeSecret: token.NewSecret(),
		store:           statestore.New(cfg.Cluster.Redis),
		whitelist:       make(map[string]bool),
		sessions:        storage.NewStore(),
		notifier:        noopNotifier{},
		stop:            make(chan struct{}),
	}
	for _, ip := range cfg.Whitelist {
		if ip != "" {
			s.whitelist[ip] = true
		}
	}
	s.initDomains()
	s.loadWhitelistFromStore()
	if geoResolver != nil {
		s.Rep.SetGeo(geoResolver)
	}
	// Mirror reputation into the shared L2 store (Redis) when configured, and
	// rehydrate prior scores so reputation survives restarts.
	s.Rep.SetStateStore(s.store)
	s.rehydrateReputation()
	go s.healthLoop()
	go s.statsLoop()
	return s
}

// SetNotifier attaches an alert sink.
func (s *Shield) SetNotifier(n Notifier) {
	if n != nil {
		s.notifier = n
	}
}

// SetPeerBroadcaster attaches the cluster sync hook (optional).
func (s *Shield) SetPeerBroadcaster(p PeerBroadcaster) {
	if p != nil {
		s.peer = p
	}
}

// SetBlocklistSync attaches an optional kernel offloader (XDP/eBPF). When set,
// every BlockIP/UnblockIP also mirrors into the kernel drop list so volumetric
// floods are dropped before they reach userspace.
func (s *Shield) SetBlocklistSync(o offload.Offloader) {
	if o != nil {
		s.blkSync = o
	}
}

// Store exposes the underlying state store (used by cluster PeerSync).
func (s *Shield) Store() statestore.StateStore {
	return s.store
}

// StoreHealthy reports whether the L2 (Redis) state layer is reachable.
func (s *Shield) StoreHealthy() bool { return s.store.Healthy() }

// StoreMode returns "redis" or "local" for the active state layer.
func (s *Shield) StoreMode() string { return s.store.Mode() }

// GeoLookup enriches an IP with country/ASN when a geo database is loaded.
// Safe when geo is disabled: returns a zero Location.
func (s *Shield) GeoLookup(ip string) geo.Location {
	return s.Geo.Lookup(ip)
}

// GeoAvailable reports whether any geo database is loaded.
func (s *Shield) GeoAvailable() bool { return s.Geo.Available() }

// ---------- lookups ----------

func (s *Shield) IsWhitelisted(ip string) bool {
	s.blocksMu.RLock()
	defer s.blocksMu.RUnlock()
	return s.whitelist[ip]
}

func (s *Shield) isBlocklisted(ip string) (blockEntry, bool) {
	raw, ok := s.store.Get(context.Background(), "block:"+ip)
	if !ok {
		return blockEntry{}, false
	}
	var be blockEntry
	if err := json.Unmarshal([]byte(raw), &be); err != nil {
		return blockEntry{}, false
	}
	if time.Now().UnixMilli() >= be.Expires {
		return blockEntry{}, false
	}
	return be, true
}

// BlockIP manually blocks (dashboard/API); persists to L1+L2 (survives
// restart) and broadcasts to peer nodes when cluster sync is configured.
func (s *Shield) BlockIP(ip string, durMs int64, reason string) {
	if s.IsWhitelisted(ip) {
		return
	}
	be := blockEntry{Expires: time.Now().UnixMilli() + durMs, Reason: reason, Score: 50}
	raw, _ := json.Marshal(be)
	rec := string(raw)
	s.store.Set(context.Background(), "block:"+ip, rec, durMs)
	if s.peer != nil {
		s.peer.Broadcast("block", ip, rec, durMs)
	}
	if s.blkSync != nil {
		s.blkSync.BlockIP(net.ParseIP(ip))
	}
	s.Rep.Adjust(ip, 50, reason)
	s.addEvent("block", ip, reason, 100)
}

// ClearSoftState drops automated enforcement state for an IP after it proves
// humanity (e.g. solved the access-gate proof-of-work): the reputation score,
// cached verdict and auto-block entry are reset so a legitimate visitor behind
// a shared/NAT IP is not trapped by accumulated heuristics. Operator blocklist
// and whitelist entries are intentionally left untouched — only the shield's
// own soft signals are cleared.
func (s *Shield) ClearSoftState(ip string) {
	s.autoBlock.Delete(ip)
	s.verdicts.Delete(ip)
	s.Rep.Reset(ip)
}

// UnblockIP clears every cache layer for the IP.
func (s *Shield) UnblockIP(ip string) {
	s.store.Delete(context.Background(), "block:"+ip)
	if s.peer != nil {
		s.peer.Broadcast("unblock", ip, "", 0)
	}
	if s.blkSync != nil {
		s.blkSync.UnblockIP(net.ParseIP(ip))
	}
	s.autoBlock.Delete(ip)
	s.verdicts.Delete(ip)
	s.Rep.Reset(ip)
}

// WhitelistIP adds and clears enforcement caches. The whitelist is persisted
// to the state store (L2) and broadcast to peers so every node denies the
// same set; on boot the local map is rehydrated from the store.
func (s *Shield) WhitelistIP(ip string) {
	s.blocksMu.Lock()
	s.whitelist[ip] = true
	s.blocksMu.Unlock()
	s.store.Set(context.Background(), "wl:"+ip, "1", 0) // 0 = no expiry
	if s.peer != nil {
		s.peer.Broadcast("wl-add", ip, "", 0)
	}
	s.store.Delete(context.Background(), "block:"+ip)
	s.autoBlock.Delete(ip)
	s.verdicts.Delete(ip)
	s.Rep.Reset(ip)
}

func (s *Shield) UnwhitelistIP(ip string) {
	s.blocksMu.Lock()
	delete(s.whitelist, ip)
	s.blocksMu.Unlock()
	s.store.Delete(context.Background(), "wl:"+ip)
	if s.peer != nil {
		s.peer.Broadcast("wl-del", ip, "", 0)
	}
}

// loadWhitelistFromStore rehydrates the L1 whitelist map from the L2 state
// store so whitelist entries survive restarts and are consistent cluster-wide.
// The map is rebuilt from scratch: entries removed by peers disappear too.
func (s *Shield) loadWhitelistFromStore() {
	s.blocksMu.Lock()
	defer s.blocksMu.Unlock()
	fresh := make(map[string]bool, len(s.whitelist))
	for _, ip := range s.cfg.Whitelist {
		if ip != "" {
			fresh[ip] = true
		}
	}
	s.store.ForEach("wl:", func(key, _ string) bool {
		fresh[strings.TrimPrefix(key, "wl:")] = true
		return true
	})
	s.whitelist = fresh
}

// rehydrateReputation pulls mirrored reputation scores (rep:<ip>) from the L2
// store back into the local L1 cache at boot, so a restarted node remembers
// what it (and its peers) learned about an IP.
func (s *Shield) rehydrateReputation() {
	s.store.ForEach("rep:", func(key, val string) bool {
		ip := strings.TrimPrefix(key, "rep:")
		if ip == "" {
			return true
		}
		var sc int
		if _, err := fmt.Sscanf(val, "%d", &sc); err == nil {
			s.Rep.RestoreScore(ip, sc)
		}
		return true
	})
}

func (s *Shield) BlocklistSnapshot() []map[string]any {
	out := []map[string]any{}
	s.store.ForEach("block:", func(key, value string) bool {
		var be blockEntry
		if err := json.Unmarshal([]byte(value), &be); err != nil {
			return true
		}
		ip := strings.TrimPrefix(key, "block:")
		out = append(out, map[string]any{"ip": ip, "reason": be.Reason, "expires": be.Expires})
		return true
	})
	return out
}

func (s *Shield) WhitelistSnapshot() []string {
	s.blocksMu.RLock()
	defer s.blocksMu.RUnlock()
	out := make([]string, 0, len(s.whitelist))
	for ip := range s.whitelist {
		out = append(out, ip)
	}
	return out
}

// ---------- events ----------

var eventSeq atomic.Uint64

func (s *Shield) addEvent(typ, ip, detail string, score int) {
	e := Event{
		Time: time.Now().UnixMilli(), Type: typ, IP: ip,
		Detail: detail, Score: score,
		ID: strconvUint(eventSeq.Add(1)),
	}
	s.eventsMu.Lock()
	s.events = append(s.events, e)
	if len(s.events) > 500 {
		s.events = s.events[len(s.events)-500:]
	}
	s.eventsMu.Unlock()
}

func (s *Shield) Events(limit int) []Event {
	s.eventsMu.Lock()
	defer s.eventsMu.Unlock()
	if limit <= 0 || limit > len(s.events) {
		limit = len(s.events)
	}
	out := make([]Event, limit)
	copy(out, s.events[len(s.events)-limit:])
	return out
}

func strconvUint(u uint64) string {
	if u == 0 {
		return "0"
	}
	var b [20]byte
	i := len(b)
	for u > 0 {
		i--
		b[i] = byte('0' + u%10)
		u /= 10
	}
	return string(b[i:])
}

// ---------- cookie helper ----------

func getCookie(headerVal, name string) string {
	if headerVal == "" {
		return ""
	}
	for _, part := range strings.Split(headerVal, ";") {
		kv := strings.TrimSpace(part)
		if eq := strings.IndexByte(kv, '='); eq > 0 && kv[:eq] == name {
			return kv[eq+1:]
		}
	}
	return ""
}

// ---------- challenge plumbing ----------

func (s *Shield) getOrCreateChallenge(ip string) string {
	if ch, ok := s.Chal.Existing(ip); ok {
		return ch.ID
	}
	if !s.cfg.Defense.Fingerprint.Enabled {
		return ""
	}
	ch := s.Chal.GenerateJS(ip)
	if ch != nil {
		return ch.ID
	}
	return ""
}

// VerifyChallenge completes a challenge; success issues the gs_ok token.
func (s *Shield) VerifyChallenge(id, ip, answer string) (bool, string) {
	ok, reason := s.Chal.Verify(id, ip, answer)
	if !ok {
		return false, reason
	}
	s.verdicts.Delete(ip)
	s.autoBlock.Delete(ip)
	s.Rep.Adjust(ip, -10, "challenge-passed")
	return true, token.Sign(s.challengeSecret,
		time.Duration(s.cfg.Defense.Fingerprint.TokenTTLms)*time.Millisecond, ip)
}

// VerifyToken validates a gs_ok cookie value for an IP.
func (s *Shield) VerifyToken(ip, tok string) bool {
	return token.Verify(s.challengeSecret, tok, ip)
}

// Close stops background loops.
// Reset clears all mutable runtime state: reputation scores, rate-limit
// counters, and the IP blocklist. Stats counters are also zeroed where the
// engine exposes a reset. Used by the admin /api/reset endpoint.
func (s *Shield) Reset() {
	if s.Rep != nil {
		s.Rep.ResetAll()
	}
	if s.Rate != nil {
		s.Rate.Reset()
	}
	for _, e := range s.BlocklistSnapshot() {
		if ip, ok := e["ip"].(string); ok && ip != "" {
			s.UnblockIP(ip)
		}
	}
}

func (s *Shield) Close() {
	s.once.Do(func() {
		close(s.stop)
		s.closeDomainRuntimes()
		s.L4.Close()
		s.L7.Close()
		s.WAF.Close()
		s.Rate.Close()
		s.FP.Close()
		s.Chal.Close()
		s.Rep.Close()
		s.Ana.Close()
		s.Geo.Close()
		s.sessions.Close()
		s.Py.Close()
	})
}
