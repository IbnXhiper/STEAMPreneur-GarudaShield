package shield

import (
	"strings"

	"github.com/ahkurdev/garudashield/internal/config"
)

// geoDecision applies the configured country policy to one IP. It returns
// (decision, true) when the IP must be hard-blocked.
//
// Semantics (fail-open per unknown country, matching the "enrichment must
// never take the engine down" rule of internal/geo):
//   - geo disabled / no MMDB loaded / unknown country -> pass, UNLESS the
//     allowlist is non-empty, in which case unknown countries are denied
//     (default-deny mode).
//   - country in blocklistCountries -> block.
//   - allowlist non-empty and country not in it -> block.
//
// Whitelisted IPs never reach this (checked earlier in the pipeline). The
// country sets are tiny (a few dozen ISO codes), so membership is scanned
// inline; cost is negligible next to the MMDB lookup.

// geoTestCountry / geoTestSet are a test-only hook: when geoTestSet is true,
// geoDecision uses geoTestCountry instead of the real resolver. Zero value in
// production = the hook is inert.
var (
	geoTestCountry string
	geoTestSet     bool
)

// geoListContains reports whether cc (already normalized) appears in the list.
func geoListContains(list []string, cc string) bool {
	for _, c := range list {
		if strings.ToUpper(strings.TrimSpace(c)) == cc {
			return true
		}
	}
	return false
}

func (s *Shield) geoDecision(ip string) (Decision, bool) {
	return s.geoDecisionCfg(s.cfg.Geo.GeoPolicy, ip)
}

// geoDecisionCfg is geoDecision against an explicit (possibly per-domain) policy.
func (s *Shield) geoDecisionCfg(pol config.GeoPolicyConfig, ip string) (Decision, bool) {
	if len(pol.BlocklistCountries) == 0 && len(pol.AllowlistCountries) == 0 {
		return Decision{}, false // policy off
	}
	var cc string
	if geoTestSet {
		// Test hook: fake resolution without MMDB files.
		cc = strings.ToUpper(strings.TrimSpace(geoTestCountry))
	} else if s.Geo == nil || !s.Geo.Available() {
		// No database: only default-deny mode can still block.
		if len(pol.AllowlistCountries) > 0 {
			return Decision{Action: ActionBlock, Reason: "geo-unknown-country", Score: 100}, true
		}
		return Decision{}, false
	} else {
		loc := s.Geo.Lookup(ip)
		cc = strings.ToUpper(strings.TrimSpace(loc.CountryCode))
	}
	if cc != "" && geoListContains(pol.BlocklistCountries, cc) {
		return Decision{Action: ActionBlock, Reason: "geo-blocked-" + cc, Score: 100}, true
	}
	if len(pol.AllowlistCountries) > 0 && (cc == "" || !geoListContains(pol.AllowlistCountries, cc)) {
		return Decision{Action: ActionBlock, Reason: "geo-not-allowed-" + cc, Score: 100}, true
	}
	return Decision{}, false
}
