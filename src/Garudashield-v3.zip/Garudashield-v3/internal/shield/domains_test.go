package shield

import (
	"net/http"
	"testing"

	"github.com/ahkurdev/garudashield/internal/policy"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

func viewHost(method, path, ip, host string, headers map[string]string) *reqview.View {
	r, _ := http.NewRequest(method, "http://"+host+path, nil)
	r.Host = host
	for k, v := range headers {
		r.Header.Set(k, v)
	}
	v := reqview.New(r, nil)
	if ip != "" {
		v.RemoteAddr = ip + ":12345"
	}
	return v
}

func cleanHeaders() map[string]string {
	return map[string]string{
		"User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	}
}

func TestDomainPolicyEmergencyIsScoped(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	mode := "emergency"
	s.SetDomainPolicy("blocked.example", policy.Policy{Mode: &mode}, "t1", 1)

	d := s.Evaluate(viewHost("GET", "/", "203.0.113.210", "blocked.example", cleanHeaders()), "203.0.113.210")
	if d.Action != ActionBlock || d.Reason != "emergency-mode" {
		t.Fatalf("domain emergency must block, got %+v", d)
	}

	// A different Host is unaffected by the scoped policy.
	d2 := s.Evaluate(viewHost("GET", "/", "203.0.113.211", "ok.example", cleanHeaders()), "203.0.113.211")
	if d2.Action != ActionPass {
		t.Fatalf("other host must pass, got %+v", d2)
	}
}

func TestDomainPolicyDeleteRestoresGlobal(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	mode := "emergency"
	s.SetDomainPolicy("blocked.example", policy.Policy{Mode: &mode}, "t1", 1)
	ip := "203.0.113.212"
	if d := s.Evaluate(viewHost("GET", "/", ip, "blocked.example", cleanHeaders()), ip); d.Action != ActionBlock {
		t.Fatalf("expected block before delete, got %+v", d)
	}
	s.DeleteDomainPolicy("blocked.example")
	ip2 := "203.0.113.213"
	if d := s.Evaluate(viewHost("GET", "/", ip2, "blocked.example", cleanHeaders()), ip2); d.Action != ActionPass {
		t.Fatalf("expected pass after delete, got %+v", d)
	}
}
