package shield

import (
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/metrics"
	"github.com/ahkurdev/garudashield/internal/pyhook"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

// Evaluate runs the full v2-ordered pipeline for one request.
func (s *Shield) Evaluate(v *reqview.View, ip string) Decision {
	rt := s.runtimeFor(v.Host)

	s.Ana.RecordTraffic(ip, v.Path, v.Get("User-Agent"), v.WireBytes())
	start := time.Now()
	budgetExceeded := false
	checkBudget := func() bool {
		if !budgetExceeded {
			// Zero or negative budget => fail closed immediately (misconfig guard).
			if rt.cfg.Shield.BudgetMs <= 0 || time.Since(start).Nanoseconds() > rt.cfg.Shield.BudgetMs*1_000_000 {
				budgetExceeded = true
				s.budgetExceeded.Add(1)
			}
		}
		return budgetExceeded
	}

	// 1. whitelist
	if s.IsWhitelisted(ip) {
		s.totalPassed.Add(1)
		s.Ana.RecordPassed()
		return Decision{Action: ActionPass, Reason: "whitelisted"}
	}

	// 1.5 geo policy (country block/allow). Whitelisted IPs skip this; a
	// missing MMDB or unknown country degrades to pass unless the allowlist
	// is non-empty (default-deny then applies to unknown countries too).
	if d, blocked := s.geoDecisionCfg(rt.cfg.Geo.GeoPolicy, ip); blocked {
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		return d
	}

	// 2. auto-block cache (hard, 30 s)
	if abv, ok := s.autoBlock.Load(ip); ok {
		ab := abv.(autoBlockEntry)
		if time.Now().UnixMilli() < ab.until {
			s.totalBlocked.Add(1)
			s.Ana.RecordBlocked()
			s.Ana.RecordBlockedBytes(v.WireBytes())
			return Decision{Action: ActionBlock, Reason: ab.reason, Score: ab.score,
				RetryAfter: ab.until - time.Now().UnixMilli()}
		}
		s.autoBlock.Delete(ip)
	}

	// 3. manual blocklist. Surface the stored reason so an automated entry
	// (e.g. a legacy "reputation-block") can be distinguished from an explicit
	// operator block: the edge handler lets the human-verification gate
	// re-check soft reasons, while hard reasons stay a flat 403.
	if be, active := s.isBlocklisted(ip); active {
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		reason := be.Reason
		if reason == "" {
			reason = "blocklisted"
		}
		return Decision{Action: ActionBlock, Reason: reason, Score: 100,
			RetryAfter: be.Expires - time.Now().UnixMilli()}
	}

	// 3.5 honeypot: scanner/exploit probe paths are definitive hostile intent.
	// Block immediately (fail-closed) so the request never reaches the upstream.
	if pat, hit := s.Honey.Match(v.Path); hit {
		s.BlockIP(ip, s.Honey.TTLMs(), "honeypot:"+pat)
		metrics.HoneypotHits.WithLabelValues(pat).Inc()
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		return Decision{Action: ActionBlock, Reason: "honeypot", Score: s.Honey.Score()}
	}

	// 4. flood fast-path
	if s.floodMode.Load() {
		return s.evaluateFlood(rt, v, ip, checkBudget)
	}

	// 5. verdict cache replay
	if vv, ok := s.verdicts.Load(ip); ok {
		vd := vv.(verdict)
		if time.Now().UnixMilli() < vd.until {
			switch vd.action {
			case ActionBlock:
				s.totalBlocked.Add(1)
				s.Ana.RecordBlocked()
				s.Ana.RecordBlockedBytes(v.WireBytes())
				return Decision{Action: ActionBlock, Reason: vd.reason, Score: vd.score,
					RetryAfter: vd.until - time.Now().UnixMilli()}
			case ActionChallenge:
				s.totalChallenged.Add(1)
				s.Ana.RecordChallenged()
				return Decision{Action: ActionChallenge, Reason: vd.reason, Score: vd.score,
					ChallengeID: vd.challengeID}
			}
		} else {
			s.verdicts.Delete(ip)
		}
	}

	// 6. gs_ok token short-circuit
	gsTok := getCookie(v.Get("Cookie"), "gs_ok")
	if gsTok != "" && s.VerifyToken(ip, gsTok) {
		d := rt.rate.Check(ip, v.Path)
		if !d.Allowed {
			s.totalBlocked.Add(1)
			s.Ana.RecordBlocked()
			s.Ana.RecordBlockedBytes(v.WireBytes())
			return Decision{Action: ActionBlock, Reason: d.Reason, Score: 20, RetryAfter: d.RetryAfterMS}
		}
		s.totalPassed.Add(1)
		s.Ana.RecordPassed()
		return Decision{Action: ActionPass, Reason: "challenge-token", Token: gsTok}
	}

	// 7. emergency mode blocks everyone non-whitelisted
	if s.isEmergency(rt) {
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		return Decision{Action: ActionBlock, Reason: "emergency-mode", Score: 100}
	}

	// 8. reputation hard-block. Reputation is a SOFT signal: it must never be
	// written to the durable blocklist, otherwise a purely heuristic auto-score
	// would masquerade as an operator "blocklisted" for the entire TTL and trap
	// legitimate visitors behind shared/NAT IPs (DDoS-time false positive).
	// Deny this request and cache the verdict briefly; the human-verification
	// gate can re-check a real browser, and a successful pass clears the score
	// (Shield.ClearSoftState).
	if s.Rep.ShouldBlock(ip) {
		until := time.Now().UnixMilli() + s.cfg.Shield.AutoBlockTTL
		s.autoBlock.Store(ip, autoBlockEntry{until: until, reason: "reputation-block", score: 100})
		s.verdicts.Store(ip, verdict{action: ActionBlock, reason: "reputation-block", score: 100,
			until: time.Now().UnixMilli() + s.cfg.Shield.VerdictBlockTTL})
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.addEvent("block", ip, "reputation-block", 100)
		return Decision{Action: ActionBlock, Reason: "reputation-block", Score: 100}
	}

	s.totalProcessed.Add(1)

	var totalScore int
	reasons := []string{}

	// 9. ASN tier suspicion in aggressive mode
	if info := s.Rep.GetASN(ip); info.Tier >= 2 && s.isAggressive(rt) {
		totalScore += 10
		reasons = append(reasons, "unknown-asn")
	}

	// 10. Layer 4 â€” hard block on failure
	l4r := s.L4.InspectConnection(ip, v.LocalPort)
	if !l4r.Allowed {
		s.Rep.Adjust(ip, l4r.Score, "layer4")
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.addEvent("block", ip, l4r.Reason, l4r.Score)
		return Decision{Action: ActionBlock, Reason: l4r.Reason, Score: l4r.Score}
	}
	totalScore += l4r.Score

	if checkBudget() {
		return Decision{Action: ActionBlock, Reason: "budget-exceeded", Score: 100}
	}

	// 11. rate limit â€” hard block on failure
	rateRes := rt.rate.Check(ip, v.Path)
	if !rateRes.Allowed {
		s.Rep.Adjust(ip, 15, "rate-limit")
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.addEvent("block", ip, rateRes.Reason, 20)
		return Decision{Action: ActionBlock, Reason: rateRes.Reason, Score: 20, RetryAfter: rateRes.RetryAfterMS}
	}

	// 11.5 edge tier short-circuit. Edge nodes own steps 1-11 (whitelist,
	// geo, auto-block, blocklist, flood, token, emergency, reputation,
	// L4, rate). Everything past this point is L7 work for the core tier,
	// so a surviving request is passed toward the core upstream.
	if s.roleEdge {
		s.totalPassed.Add(1)
		s.Ana.RecordPassed()
		s.addEvent("pass", ip, "edge-pass", totalScore)
		return Decision{Action: ActionPass, Reason: "edge-pass", Score: totalScore}
	}

	// 12. fingerprint â€” additive risk only
	fpRes := s.FP.Analyze(ip, v.Header.Get("User-Agent"), v.Header, tlsProtoFor(v))
	if fpRes.IsHeadless || fpRes.IsAutomated {
		totalScore += 30
		reasons = append(reasons, "headless")
	}
	if fpRes.ConsistencyScore < 50 {
		totalScore += 20
		reasons = append(reasons, "low-consistency")
	}

	// 13. layer 7 â€” hard block or additive score
	l7r := rt.l7.Validate(v)
	if !l7r.Allowed {
		s.Rep.Adjust(ip, maxInt(l7r.Score, 15), "layer7")
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.addEvent("block", ip, l7r.Reason, l7r.Score)
		return Decision{Action: ActionBlock, Reason: l7r.Reason, Score: l7r.Score}
	}
	totalScore += l7r.Score

	if checkBudget() {
		return Decision{Action: ActionBlock, Reason: "budget-exceeded", Score: 100}
	}

	// 14. WAF â€” hard block or additive score
	wafRes := rt.waf.InspectRequest(v)
	if !wafRes.Allowed {
		s.Rep.Adjust(ip, maxInt(wafRes.Score, 20), "waf")
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.addEvent("block", ip, wafRes.Reason, wafRes.Score)
		return Decision{Action: ActionBlock, Reason: wafRes.Reason, Score: wafRes.Score}
	}
	totalScore += wafRes.Score

	// 15. payload entropy â€” additive
	if ps := s.Anom.CheckPayload(v.Body); ps > 0 {
		totalScore += ps
		reasons = append(reasons, "anomalous-payload")
	}

	// 16. reputation contribution (â‰¤20)
	repScore := s.Rep.OwnScore(ip)
	if repScore > 0 {
		contrib := repScore / 5
		if contrib > 20 {
			contrib = 20
		}
		totalScore += contrib
		reasons = append(reasons, "reputation")
	}

	// 16.5 Python policy hook (opt-in). Runs after the Go pipeline scored the
	// request so the script sees the accumulated score. Monitor mode only
	// records; enforce mode can add score, challenge, or hard-block.
	// Skipped when the eval budget is already gone (subprocess = slow path).
	if s.Py != nil && !checkBudget() {
		pv := s.Py.Evaluate(pyhook.Features{
			IP: ip, Method: v.Method, Path: v.Path,
			UserAgent: v.Get("User-Agent"), Score: totalScore,
			WireBytes: v.WireBytes(),
		})
		if s.Py.Mode() == "monitor" {
			s.addEvent("pyhook", ip, pv.Reason, pv.Score)
		} else {
			switch pv.Action {
			case "block":
				s.Rep.Adjust(ip, 15, "pyhook")
				s.totalBlocked.Add(1)
				s.Ana.RecordBlocked()
				s.Ana.RecordBlockedBytes(v.WireBytes())
				s.addEvent("block", ip, "pyhook:"+pv.Reason, totalScore+pv.Score)
				return Decision{Action: ActionBlock, Reason: "pyhook:" + pv.Reason, Score: totalScore + pv.Score}
			case "challenge":
				s.totalChallenged.Add(1)
				s.Ana.RecordChallenged()
				s.addEvent("challenge", ip, "pyhook:"+pv.Reason, totalScore+pv.Score)
				cid := s.getOrCreateChallenge(ip)
				s.verdicts.Store(ip, verdict{action: ActionChallenge, reason: "pyhook:" + pv.Reason,
					score: totalScore + pv.Score, challengeID: cid,
					until: time.Now().UnixMilli() + s.cfg.Shield.VerdictChallengeTTL})
				return Decision{Action: ActionChallenge, Reason: "pyhook:" + pv.Reason,
					Score: totalScore + pv.Score, ChallengeID: cid}
			default:
				if pv.Score > 0 {
					totalScore += pv.Score
					reasons = append(reasons, "pyhook:"+pv.Reason)
				}
			}
		}
	}

	// 17. verdict thresholds
	action := ActionPass
	reason := ""
	challengeID := ""

	switch {
	case totalScore >= 60:
		action = ActionBlock
		reason = "score"
		s.totalBlocked.Add(1)
		s.Ana.RecordBlocked()
		s.Ana.RecordBlockedBytes(v.WireBytes())
		s.Rep.Adjust(ip, 15, "blocked")
		s.addEvent("block", ip, joinReasons(reasons, totalScore), totalScore)
	case totalScore >= 20:
		action = ActionChallenge
		reason = "suspicious"
		s.totalChallenged.Add(1)
		s.Ana.RecordChallenged()
		if totalScore >= 30 {
			s.Rep.Adjust(ip, 5, "challenged")
		}
		s.addEvent("challenge", ip, joinReasons(reasons, totalScore), totalScore)
	default:
		if s.verifyBrowserRequired(rt, v, gsTok) {
			action = ActionChallenge
			reason = "verify-browser"
			s.totalChallenged.Add(1)
			s.Ana.RecordChallenged()
			s.addEvent("challenge", ip, "verify-browser-first-visit", 0)
		} else {
			s.totalPassed.Add(1)
			s.Ana.RecordPassed()
			if repScore > 0 {
				s.Rep.Adjust(ip, -1, "good")
			}
		}
	}

	// 18. cache the verdict
	if action == ActionBlock {
		s.autoBlock.Store(ip, autoBlockEntry{
			until:  time.Now().UnixMilli() + s.cfg.Shield.AutoBlockTTL,
			reason: reason, score: totalScore})
		s.verdicts.Store(ip, verdict{action: action, reason: reason, score: totalScore,
			until: time.Now().UnixMilli() + s.cfg.Shield.VerdictBlockTTL})
	} else if action == ActionChallenge {
		challengeID = s.getOrCreateChallenge(ip)
		s.verdicts.Store(ip, verdict{action: action, reason: reason, score: totalScore,
			challengeID: challengeID,
			until:       time.Now().UnixMilli() + s.cfg.Shield.VerdictChallengeTTL})
	}

	_ = start // budget already measured via closure
	return Decision{Action: action, Score: totalScore, Reason: reason, ChallengeID: challengeID}
}

// evaluateFlood mirrors v2's _evaluateFlood fast path.
func (s *Shield) evaluateFlood(rt *runtime, v *reqview.View, ip string, checkBudget func() bool) Decision {
	if s.IsWhitelisted(ip) {
		s.totalPassed.Add(1)
		return Decision{Action: ActionPass, Reason: "whitelisted"}
	}

	if abv, ok := s.autoBlock.Load(ip); ok {
		ab := abv.(autoBlockEntry)
		if time.Now().UnixMilli() < ab.until {
			s.totalBlocked.Add(1)
			return Decision{Action: ActionBlock, Reason: ab.reason, Score: ab.score,
				RetryAfter: ab.until - time.Now().UnixMilli()}
		}
		s.autoBlock.Delete(ip)
	}
	if be, active := s.isBlocklisted(ip); active {
		s.totalBlocked.Add(1)
		reason := be.Reason
		if reason == "" {
			reason = "blocklisted"
		}
		return Decision{Action: ActionBlock, Reason: reason, Score: 100,
			RetryAfter: be.Expires - time.Now().UnixMilli()}
	}
	if vv, ok := s.verdicts.Load(ip); ok {
		vd := vv.(verdict)
		if vd.action == ActionBlock && time.Now().UnixMilli() < vd.until {
			s.totalBlocked.Add(1)
			return Decision{Action: ActionBlock, Reason: vd.reason, Score: vd.score,
				RetryAfter: vd.until - time.Now().UnixMilli()}
		}
	}

	gsTok := getCookie(v.Get("Cookie"), "gs_ok")
	if gsTok != "" && s.VerifyToken(ip, gsTok) {
		d := rt.rate.Check(ip, v.Path)
		if !d.Allowed {
			s.totalBlocked.Add(1)
			return Decision{Action: ActionBlock, Reason: d.Reason, Score: 20, RetryAfter: d.RetryAfterMS}
		}
		s.totalPassed.Add(1)
		return Decision{Action: ActionPass, Reason: "challenge-token", Token: gsTok}
	}

	if s.isEmergency(rt) {
		s.totalBlocked.Add(1)
		return Decision{Action: ActionBlock, Reason: "emergency-mode", Score: 100}
	}

	s.totalProcessed.Add(1)

	if rate := rt.rate.Check(ip, v.Path); !rate.Allowed {
		until := time.Now().UnixMilli() + 10000
		s.autoBlock.Store(ip, autoBlockEntry{until: until, reason: rate.Reason, score: 50})
		s.totalBlocked.Add(1)
		s.addEvent("block", ip, "flood:"+rate.Reason, 50)
		return Decision{Action: ActionBlock, Reason: rate.Reason, Score: 50,
			RetryAfter: until - time.Now().UnixMilli()}
	}

	if vv, ok := s.verdicts.Load(ip); ok {
		vd := vv.(verdict)
		if vd.action == ActionChallenge && time.Now().UnixMilli() < vd.until {
			s.totalChallenged.Add(1)
			return Decision{Action: ActionChallenge, Reason: vd.reason, Score: vd.score,
				ChallengeID: vd.challengeID}
		}
	}

	cid := s.getOrCreateChallenge(ip)
	until := time.Now().UnixMilli() + rt.cfg.Shield.VerdictChallengeTTL
	s.verdicts.Store(ip, verdict{action: ActionChallenge, reason: "flood-verification",
		score: 30, challengeID: cid, until: until})
	s.totalChallenged.Add(1)
	s.addEvent("challenge", ip, "flood-verification", 30)
	return Decision{Action: ActionChallenge, Reason: "flood-verification", Score: 30, ChallengeID: cid}
}

func (s *Shield) verifyBrowserRequired(rt *runtime, v *reqview.View, gsTok string) bool {
	if !rt.cfg.Shield.VerifyOnFirstVisit || gsTok != "" {
		return false
	}
	// A per-domain policy that explicitly asks for first-visit verification
	// applies to its own Host only.
	if !rt.isGlobal {
		return true
	}
	host := strings.ToLower(v.Host)
	if len(rt.cfg.Shield.VerifyOnFirstVisitHost) == 0 {
		return true
	}
	for _, h := range rt.cfg.Shield.VerifyOnFirstVisitHost {
		if host == strings.ToLower(h) {
			return true
		}
	}
	return false
}

func joinReasons(reasons []string, score int) string {
	if len(reasons) == 0 {
		return "score"
	}
	out := reasons[0]
	for _, r := range reasons[1:] {
		out += "," + r
	}
	return out
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func tlsProtoFor(v *reqview.View) string {
	if v.HasTLS {
		return "HTTP/" + v.Proto
	}
	return ""
}
