package shield

import (
	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/metrics"
	"math"

	"strconv"
	"time"
)

// ---------- mode state machine (v2 dashboard handlers) ----------

func (s *Shield) SetAggressive(on bool) {
	s.aggMode.Store(on)
	if on {
		s.L4.SetAggressive(true)
		s.Rate.UpdateConfig(config.RateLimitConfig{GlobalMaxRPS: 200, PerIPRPS: 10, PerIPBurst: 15})
		s.Rep.SetThreshold(60)
		s.addEvent("mode", "system", "aggressive-on", 0)
	} else {
		s.L4.SetAggressive(false)
		s.Rate.UpdateConfig(config.RateLimitConfig{GlobalMaxRPS: s.cfg.Defense.RateLimit.GlobalMaxRPS,
			PerIPRPS: s.cfg.Defense.RateLimit.PerIPRPS, PerIPBurst: s.cfg.Defense.RateLimit.PerIPBurst})
		s.Rep.SetThreshold(s.cfg.Reputation.BlockThreshold)
		s.addEvent("mode", "system", "aggressive-off", 0)
	}
}

func (s *Shield) SetEmergency(on bool) {
	s.emergency.Store(on)
	if on {
		s.Rate.UpdateConfig(config.RateLimitConfig{GlobalMaxRPS: math.Max(1, s.cfg.Defense.RateLimit.GlobalMaxRPS*3/10), PerIPRPS: maxInt(1, int(s.cfg.Defense.RateLimit.PerIPRPS*3/10))})
		s.addEvent("mode", "system", "emergency-on", 0)
	} else {
		s.Rate.UpdateConfig(config.RateLimitConfig{GlobalMaxRPS: s.cfg.Defense.RateLimit.GlobalMaxRPS,
			PerIPRPS: s.cfg.Defense.RateLimit.PerIPRPS})
		s.addEvent("mode", "system", "emergency-off", 0)
	}
}

func (s *Shield) AggressiveOn() bool { return s.aggMode.Load() }
func (s *Shield) EmergencyOn() bool  { return s.emergency.Load() }
func (s *Shield) FloodOn() bool      { return s.floodMode.Load() }

// ---------- background loops ----------

func (s *Shield) healthLoop() {
	t := time.NewTicker(5 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-s.stop:
			return
		case <-t.C:
			active := s.Ana.AttackActive()
			s.checkL2Health()
			s.attackMu.Lock()
			if active && !s.attackActive {
				s.attackActive = true
				s.attackSeverity = "medium"
				s.attackStartedAt = time.Now()
				s.attackTotal++
				s.notifier.Send("info", "Serangan terdeteksi", map[string]string{
					"types": joinStrings(s.Ana.AttackTypes(), ","),
				})
			} else if !active && s.attackActive {
				s.attackActive = false
				dur := time.Since(s.attackStartedAt).String()
				s.notifier.Send("info", "Serangan mereda", map[string]string{"duration": dur})
			}
			if active {
				sev := "medium"
				for _, ty := range s.Ana.AttackTypes() {
					if ty == "rate-spike" || ty == "udp-flood" || ty == "syn-flood" {
						sev = "high"
					}
				}
				s.attackSeverity = sev
			}
			s.attackMu.Unlock()
		}
	}
}

func (s *Shield) statsLoop() {
	t := time.NewTicker(2 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-s.stop:
			return
		case <-t.C:
			rps := s.Ana.TickSecond()
			s.Anom.RecordMetrics(rps)
			s.Ana.LockBaseline()
			s.runFloodCheck(rps)
		}
	}
}

// runFloodCheck is the flood-mode transition. Unlike v2 it is driven by the
// live request rate alone (no anomaly-baseline warm-up), so a volumetric
// spike flips the engine into the cheap challenge path within one stats tick
// (<=2 s) instead of after the 60 s baseline lock. Enter: rps >=
// shield.floodRpsThreshold. Exit: rps < threshold/2 held for at least
// shield.floodMinMs. Zero knobs fall back to the v2 defaults (3000 / 15000).
// Split out of statsLoop so it is unit-testable.
func (s *Shield) runFloodCheck(rps float64) {
	now := time.Now()
	thr := s.cfg.Shield.FloodRpsThreshold
	if thr <= 0 {
		thr = 3000
	}
	soak := s.cfg.Shield.FloodMinMs
	if soak <= 0 {
		soak = 15000
	}
	if !s.floodMode.Load() && rps >= thr {
		s.floodMode.Store(true)
		s.floodSince.Store(now.UnixMilli())
		s.applyFloodRates(true)
		metrics.FloodMode.Set(1)
		s.addEvent("mode", "system", "flood-on", 0)
		s.notifier.Send("warning", "Mode banjir aktif", map[string]string{"rps": ftos(rps)})
	} else if s.floodMode.Load() {
		since := now.UnixMilli() - s.floodSince.Load()
		if rps < thr/2 && since > soak {
			s.floodMode.Store(false)
			s.applyFloodRates(false)
			metrics.FloodMode.Set(0)
			s.addEvent("mode", "system", "flood-off", 0)
			s.notifier.Send("info", "Mode banjir nonaktif", nil)
		}
	}
}

// applyFloodRates tightens the per-IP rate ceiling while flood mode is on
// (a fifth of the configured budget, floored at 10 rps / 20 burst) and
// restores the configured values when it lifts. Combined with evaluateFlood's
// hard auto-block this caps a single-IP flooder within ~1 s.
func (s *Shield) applyFloodRates(on bool) {
	if on {
		s.Rate.UpdateConfig(config.RateLimitConfig{
			PerIPRPS:   maxInt(10, s.cfg.Defense.RateLimit.PerIPRPS/5),
			PerIPBurst: maxInt(20, s.cfg.Defense.RateLimit.PerIPBurst/5),
		})
		return
	}
	s.Rate.UpdateConfig(config.RateLimitConfig{
		PerIPRPS:   s.cfg.Defense.RateLimit.PerIPRPS,
		PerIPBurst: s.cfg.Defense.RateLimit.PerIPBurst,
	})
}

// ---------- stats snapshot for dashboard / API ----------

type Stats struct {
	Processed      uint64           `json:"processed"`
	Blocked        uint64           `json:"blocked"`
	BytesIn        uint64           `json:"bytesIn"`
	BlockedBytes   uint64           `json:"blockedBytes"`
	BandwidthBps   int64            `json:"bandwidthBps"`
	Challenged     uint64           `json:"challenged"`
	Passed         uint64           `json:"passed"`
	BudgetExceeded uint64           `json:"budgetExceeded"`
	CurrentRPS     int64            `json:"currentRps"`
	PeakRPS        float64          `json:"peakRps"`
	AnomalyScore   float64          `json:"anomalyScore"`
	LastEntropy    float64          `json:"lastEntropy"`
	BaselineLocked bool             `json:"baselineLocked"`
	AttackActive   bool             `json:"attackActive"`
	AttackTypes    []string         `json:"attackTypes"`
	Aggressive     bool             `json:"aggressive"`
	Emergency      bool             `json:"emergency"`
	Flood          bool             `json:"flood"`
	TopIPs         [][2]any         `json:"topIps"`
	TopPaths       [][2]any         `json:"topPaths"`
	Blocklist      []map[string]any `json:"blocklist"`
	Whitelist      []string         `json:"whitelist"`
}

func (s *Shield) GetStats() Stats {
	proc, blk, chl, pas := s.Ana.Totals()
	return Stats{
		Processed:      proc,
		Blocked:        blk + s.totalBlocked.Load(),
		BytesIn:        s.Ana.BytesIn(),
		BlockedBytes:   s.Ana.BlockedBytes(),
		BandwidthBps:   s.Ana.CurrentBytes(),
		Challenged:     chl + s.totalChallenged.Load(),
		Passed:         pas + s.totalPassed.Load(),
		BudgetExceeded: s.budgetExceeded.Load(),
		CurrentRPS:     s.Ana.CurrentRPS(),
		PeakRPS:        s.Ana.PeakRPS(),
		AnomalyScore:   s.Ana.AnomalyScore(),
		LastEntropy:    s.Ana.LastEntropy(),
		BaselineLocked: s.Ana.BaselineLocked(),
		AttackActive:   s.Ana.AttackActive(),
		AttackTypes:    s.Ana.AttackTypes(),
		Aggressive:     s.aggMode.Load(),
		Emergency:      s.emergency.Load(),
		Flood:          s.floodMode.Load(),
		TopIPs:         s.Ana.TopIPs(10),
		TopPaths:       s.Ana.TopPaths(10),
		Blocklist:      s.BlocklistSnapshot(),
		Whitelist:      s.WhitelistSnapshot(),
	}
}

func joinStrings(in []string, sep string) string {
	if len(in) == 0 {
		return ""
	}
	out := in[0]
	for _, x := range in[1:] {
		out += sep + x
	}
	return out
}

func ftos(f float64) string {
	return strconv.FormatFloat(f, 'f', -1, 64)
}
