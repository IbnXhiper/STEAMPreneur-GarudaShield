package shield

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestFloodFastPath verifies the flood fast-path pipeline:
//   - whitelisted IPs pass even in flood mode
//   - blocklisted IPs are hard-blocked from the L1/L2 cache
//   - token holders get rate-limited pass (challenge-token)
//   - fresh IPs get flood-verification challenge (verdict cached)
func TestFloodFastPath(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.cfg.Shield.VerifyOnFirstVisit = false
	s.floodMode.Store(true)
	defer s.floodMode.Store(false)

	// 1. whitelisted passes in flood mode
	s.WhitelistIP("203.0.113.10")
	wl := view("GET", "/", "203.0.113.10", map[string]string{"User-Agent": "Mozilla/5.0 Chrome/126.0"})
	if d := s.Evaluate(wl, "203.0.113.10"); d.Action != ActionPass {
		t.Fatalf("whitelisted must pass in flood mode, got %+v", d)
	}

	// 2. blocklisted IP is hard-blocked (no challenge, no rate check). The
	// stored reason is surfaced verbatim so soft automated entries can be told
	// apart from operator blocks by the edge handler.
	s.BlockIP("203.0.113.11", 60000, "test-bl")
	if d := s.Evaluate(view("GET", "/", "203.0.113.11", nil), "203.0.113.11"); d.Action != ActionBlock || d.Reason != "test-bl" {
		t.Fatalf("blocklisted must block in flood mode, got %+v", d)
	}

	// 3. fresh IP: flood fast path issues a verification challenge
	ip := "203.0.113.12"
	benign := view("GET", "/", ip, map[string]string{"User-Agent": "Mozilla/5.0 Chrome/126.0"})
	d := s.Evaluate(benign, ip)
	if d.Action != ActionChallenge || d.Reason != "flood-verification" {
		t.Fatalf("fresh IP in flood mode must be challenged, got %+v", d)
	}
	// 4. the challenge verdict is cached: the second request replays it
	if d2 := s.Evaluate(benign, ip); d2.Action != ActionChallenge {
		t.Fatalf("cached flood verdict must replay, got %+v", d2)
	}
}

// TestFloodFastPathTokenHolder verifies a valid gs_ok token gets through the
// flood fast path with only a rate check (the point of the challenge system).
func TestFloodFastPathTokenHolder(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.floodMode.Store(true)
	defer s.floodMode.Store(false)

	ip := "203.0.113.13"
	// Issue a token via the challenge verify path.
	cid := s.getOrCreateChallenge(ip)
	ans, _ := s.Chal.Answer(cid)
	ok, tok := s.VerifyChallenge(cid, ip, ans)
	if !ok || tok == "" {
		t.Fatalf("challenge verify must issue token: ok=%v tok=%q", ok, tok)
	}

	v := view("GET", "/", ip, map[string]string{
		"User-Agent": "Mozilla/5.0 Chrome/126.0",
		"Cookie":     "gs_ok=" + tok,
	})
	d := s.Evaluate(v, ip)
	if d.Action != ActionPass {
		t.Fatalf("token holder must pass flood fast path, got %+v", d)
	}
}

// TestAggressiveModeTightensRateLimit verifies aggressive mode engages and
// sets the v2 aggressive per-IP budget (10 rps / burst 15).
func TestAggressiveModeTightensRateLimit(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.SetAggressive(true)
	defer s.SetAggressive(false)

	if !s.AggressiveOn() {
		t.Fatal("aggressive must be on")
	}
	if got := s.Rate.EffectiveIPRPS(); got != 10 {
		t.Fatalf("aggressive per-IP rps must be 10 (v2 parity), got %v", got)
	}
	// A bursty IP must get rate-limited under the aggressive budget.
	ip := "203.0.113.14"
	blocked := 0
	for i := 0; i < 100 && blocked == 0; i++ {
		if d := s.Rate.Check(ip, "/"); !d.Allowed {
			blocked++
		}
	}
	if blocked == 0 {
		t.Fatal("aggressive mode must rate-limit a bursty IP")
	}
}

// TestFloodAutoEngagement verifies the statsLoop flood transition logic:
// the live rps alone engages flood mode (no baseline/attack requirement) so a
// spike is mitigated within one tick, and it lifts only after the soak window.
func TestFloodAutoEngagement(t *testing.T) {
	cfg := config.Default()
	cfg.Shield.VerifyOnFirstVisit = false
	s := New(cfg)
	defer s.Close()

	if s.FloodOn() {
		t.Fatal("flood mode must start off")
	}
	// A rate spike engages flood mode even with no anomaly baseline.
	s.runFloodCheck(cfg.Shield.FloodRpsThreshold)
	if !s.FloodOn() {
		t.Fatal("flood mode must engage on a rate spike")
	}
	// The limiter is tightened while flood mode is on.
	if got := s.Rate.EffectiveIPRPS(); got >= float64(cfg.Defense.RateLimit.PerIPRPS) {
		t.Fatalf("flood mode must tighten the per-IP rps, got %v", got)
	}
	// Recovery: rps below threshold/2 but inside the soak window -> stays on.
	s.runFloodCheck(0)
	if !s.FloodOn() {
		t.Fatal("flood mode must stay on during the soak window")
	}
}

// TestFloodThresholdFromConfig verifies the flood trigger honours the
// shield.floodRpsThreshold knob instead of the hard-coded v2 value.
func TestFloodThresholdFromConfig(t *testing.T) {
	cfg := config.Default()
	cfg.Shield.VerifyOnFirstVisit = false
	cfg.Shield.FloodRpsThreshold = 500
	cfg.Shield.FloodMinMs = 1000
	s := New(cfg)
	defer s.Close()

	s.runFloodCheck(499)
	if s.FloodOn() {
		t.Fatal("flood mode must not engage below the configured threshold")
	}
	s.runFloodCheck(500)
	if !s.FloodOn() {
		t.Fatal("flood mode must engage at the configured threshold")
	}
}
