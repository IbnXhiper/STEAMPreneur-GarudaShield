package shield

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestWhitelistPersistedToStore verifies whitelist mutations write to the L2
// state store and rehydrate into a fresh Shield (restart survival).
func TestWhitelistPersistedToStore(t *testing.T) {
	cfg := config.Default()
	cfg.Cluster.Redis.Enabled = false // memory store: same code path, no Docker
	s1 := New(cfg)
	s1.WhitelistIP("203.0.113.77")
	if !s1.IsWhitelisted("203.0.113.77") {
		t.Fatal("ip must be whitelisted in L1")
	}

	// New Shield over the same store: whitelist must survive "restart".
	s2 := New(cfg)
	s2.store = s1.store
	s2.loadWhitelistFromStore()
	if !s2.IsWhitelisted("203.0.113.77") {
		t.Fatal("whitelist must rehydrate from L2 store")
	}

	// Removal must propagate to the store too.
	s1.UnwhitelistIP("203.0.113.77")
	s2.loadWhitelistFromStore()
	if s2.IsWhitelisted("203.0.113.77") {
		t.Fatal("unwhitelist must delete from L2 store")
	}
}

// TestWhitelistPeerBroadcast verifies wl-add/wl-del ops are broadcast to peers.
func TestWhitelistPeerBroadcast(t *testing.T) {
	cfg := config.Default()
	s := New(cfg)
	b := &broadcastRecorder{}
	s.peer = b

	s.WhitelistIP("198.51.100.5")
	if len(b.ops) != 1 || b.ops[0].op != "wl-add" || b.ops[0].ip != "198.51.100.5" {
		t.Fatalf("wl-add must be broadcast, got %+v", b.ops)
	}
	s.UnwhitelistIP("198.51.100.5")
	if len(b.ops) != 2 || b.ops[1].op != "wl-del" {
		t.Fatalf("wl-del must be broadcast, got %+v", b.ops)
	}
}

type broadcastRecorder struct {
	ops []struct {
		op, ip string
	}
}

func (b *broadcastRecorder) Broadcast(op, ip, _ string, _ int64) {
	b.ops = append(b.ops, struct {
		op, ip string
	}{op, ip})
}
