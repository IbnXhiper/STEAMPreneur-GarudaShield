package shield

import (
	"net/http/httptest"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

const tierSQLi = "/?id=1%20UNION%20SELECT%20password%20FROM%20users"

func tierView(path string) *reqview.View {
	r := httptest.NewRequest("GET", "http://x"+path, nil)
	r.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
	r.RemoteAddr = "1.1.1.13:1234"
	return reqview.New(r, nil)
}

// Full pipeline (role=all) must block the SQLi probe.
func TestTierAllBlocksSQLi(t *testing.T) {
	cfg := config.Default()
	cfg.Shield.BudgetMs = 10000
	s := New(cfg)
	defer s.Close()
	d := s.Evaluate(tierView(tierSQLi), "1.1.1.13")
	if d.Action != ActionBlock {
		t.Fatalf("role=all SQLi = %+v, want block", d)
	}
}

// Edge tier passes the same probe to the core tier (no L7 on edge).
func TestTierEdgePassesSQLi(t *testing.T) {
	cfg := config.Default()
	cfg.Shield.BudgetMs = 10000
	cfg.Cluster.Role = "edge"
	s := New(cfg)
	defer s.Close()
	if !s.roleEdge {
		t.Fatal("role=edge must set roleEdge")
	}
	d := s.Evaluate(tierView(tierSQLi), "1.1.1.13")
	if d.Action != ActionPass || d.Reason != "edge-pass" {
		t.Fatalf("role=edge SQLi = %+v, want edge-pass", d)
	}
}

// Edge still enforces its own layers: blocklisted IPs die on edge.
func TestTierEdgeEnforcesBlocklist(t *testing.T) {
	cfg := config.Default()
	cfg.Shield.BudgetMs = 10000
	cfg.Cluster.Role = "edge"
	s := New(cfg)
	defer s.Close()
	s.BlockIP("1.1.1.14", 60000, "test")
	r := httptest.NewRequest("GET", "http://x/", nil)
	r.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64)")
	r.RemoteAddr = "1.1.1.14:1234"
	d := s.Evaluate(reqview.New(r, nil), "1.1.1.14")
	if d.Action != ActionBlock {
		t.Fatalf("role=edge blocklisted = %+v, want block", d)
	}
}
