package shield

import (
	"fmt"
	"net/http"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

func newTestShield() *Shield {
	cfg := config.Default()
	cfg.Shield.BudgetMs = 50
	cfg.Defense.Fingerprint.Enabled = true
	cfg.Defense.Layer4.BogonFilter = false // test IPs live in TEST-NET ranges
	cfg.Defense.RateLimit.PerIPRPS = 5
	cfg.Defense.RateLimit.PerIPBurst = 10
	cfg.Shield.VerifyOnFirstVisit = false // avoid first-visit challenge cache masking later stages
	s := New(cfg)
	return s
}

func view(method, path, ip string, headers map[string]string) *reqview.View {
	r, _ := http.NewRequest(method, path, nil)
	for k, v := range headers {
		r.Header.Set(k, v)
	}
	v := reqview.New(r, nil)
	if ip != "" {
		v.RemoteAddr = ip + ":12345"
	}
	return v
}

func TestCleanRequestPasses(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "203.0.113.7"
	v := view("GET", "/", ip, map[string]string{
		"User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	})
	d := s.Evaluate(v, ip)
	if d.Action != ActionPass {
		t.Fatalf("clean request should pass, got %+v", d)
	}
}

func TestWhitelistBypass(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.WhitelistIP("198.51.100.9")
	v := view("GET", "/", "198.51.100.9", map[string]string{"User-Agent": "curl/8.0"})
	d := s.Evaluate(v, "198.51.100.9")
	if d.Action != ActionPass {
		t.Fatalf("whitelisted must pass, got %+v", d)
	}
}

func TestSQLMapUserAgentBlocked(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "192.0.2.55"
	v := view("GET", "/", ip, map[string]string{"User-Agent": "sqlmap/1.7"})
	d := s.Evaluate(v, ip)
	if d.Action != ActionBlock {
		t.Fatalf("sqlmap UA must be blocked, got %+v", d)
	}
}

func TestTrafficTelemetryAndBlockEvent(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "198.51.100.44"
	hdr := map[string]string{
		"User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	}
	clean := view("GET", "/", ip, hdr)
	if d := s.Evaluate(clean, ip); d.Action != ActionPass {
		t.Fatalf("clean request should pass, got %+v", d)
	}
	attack := view("GET", "/?q=%27%20OR%20%27%3D", ip, hdr)
	if d := s.Evaluate(attack, ip); d.Action != ActionBlock {
		t.Fatalf("SQLi should block, got %+v", d)
	}
	stats := s.GetStats()
	if stats.Processed < 2 {
		t.Fatalf("processed=%d, want at least 2", stats.Processed)
	}
	if len(stats.TopIPs) == 0 || len(stats.TopPaths) == 0 {
		t.Fatalf("telemetry missing: topIps=%v topPaths=%v", stats.TopIPs, stats.TopPaths)
	}
	events := s.Events(10)
	sawBlock := false
	for _, e := range events {
		if e.Type == "block" {
			sawBlock = true
			break
		}
	}
	if !sawBlock {
		t.Fatalf("block event missing: %v", events)
	}
}

func TestRateLimitBlocks(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "198.51.100.20"
	ua := "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
	blocked := false
	for i := 0; i < 300; i++ {
		v := view("GET", "/", ip, map[string]string{
			"User-Agent":      ua,
			"Accept":          "text/html",
			"Accept-Language": "en-US,en;q=0.9",
		})
		if d := s.Evaluate(v, ip); d.Action == ActionBlock {
			blocked = true
			break
		}
	}
	if !blocked {
		t.Fatal("expected rate-limit block after burst")
	}
}

func TestScoreTriggersChallenge(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "198.51.100.30"
	// headless UA (30) + short UA length (10) => 40 >= 20 => challenge
	v := view("GET", "/", ip, map[string]string{"User-Agent": "HeadlessChrome"})
	d := s.Evaluate(v, ip)
	if d.Action != ActionChallenge {
		t.Fatalf("score>=20 must challenge, got %+v", d)
	}
	if d.ChallengeID == "" {
		t.Fatal("challenge must carry an id")
	}
}

func TestChallengeVerifyIssuesToken(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "198.51.100.40"
	v := view("GET", "/", ip, map[string]string{"User-Agent": "HeadlessChrome"})
	d := s.Evaluate(v, ip)
	if d.Action != ActionChallenge {
		t.Fatalf("expected challenge, got %+v", d)
	}
	c, ok := s.Chal.Existing(ip)
	if !ok {
		t.Fatal("challenge not registered")
	}
	ans, _ := s.Chal.Answer(c.ID)
	if c == nil {
		t.Fatal("challenge not registered")
	}
	ok, token := s.VerifyChallenge(c.ID, ip, ans)
	if !ok {
		t.Fatalf("challenge verify failed: %s", token)
	}
	// subsequent request with gs_ok cookie short-circuits to pass
	v2 := view("GET", "/", ip, map[string]string{
		"User-Agent": "HeadlessChrome",
		"Cookie":     "gs_ok=" + token,
	})
	d2 := s.Evaluate(v2, ip)
	if d2.Action != ActionPass {
		t.Fatalf("valid token must pass, got %+v", d2)
	}
}

func TestEmergencyBlocks(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.SetEmergency(true)
	ip := "203.0.113.99"
	v := view("GET", "/", ip, map[string]string{
		"User-Agent":      "Mozilla/5.0 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	})
	d := s.Evaluate(v, ip)
	if d.Action != ActionBlock {
		t.Fatalf("emergency must block, got %+v", d)
	}
}

// TestModeToggles verifies the mode flags flip and that an evaluate respects
// emergency even for otherwise-benign traffic, and that turning it off restores
// pass behavior.
func TestModeToggles(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	if s.AggressiveOn() || s.EmergencyOn() {
		t.Fatal("modes should start off")
	}
	s.SetAggressive(true)
	if !s.AggressiveOn() {
		t.Error("aggressive should be on")
	}
	s.SetAggressive(false)
	if s.AggressiveOn() {
		t.Error("aggressive should be off after toggle")
	}

	ip := "203.0.113.200"
	benign := view("GET", "/", ip, map[string]string{
		"User-Agent": "Mozilla/5.0 Chrome/126.0 Safari/537.36",
		"Accept":     "text/html",
	})
	// Pre-emergency: benign passes.
	if d := s.Evaluate(benign, ip); d.Action != ActionPass {
		t.Fatalf("benign should pass pre-emergency, got %+v", d)
	}
	s.SetEmergency(true)
	// Emergency: same benign IP is now blocked (non-whitelisted).
	if d := s.Evaluate(benign, ip); d.Action != ActionBlock {
		t.Fatalf("benign should block in emergency, got %+v", d)
	}
	s.SetEmergency(false)
	// Post-emergency: passes again.
	if d := s.Evaluate(benign, ip); d.Action != ActionPass {
		t.Fatalf("benign should pass after emergency off, got %+v", d)
	}
}

func TestBudgetExceededBlocks(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	s.cfg.Shield.BudgetMs = 0 // force immediate budget fail
	ip := "203.0.113.123"
	v := view("GET", "/", ip, map[string]string{
		"User-Agent":      "Mozilla/5.0 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	})
	d := s.Evaluate(v, ip)
	if d.Action != ActionBlock || d.Reason != "budget-exceeded" {
		t.Fatalf("budget=0 must block budget-exceeded, got %+v", d)
	}
}

func TestDebugCleanBreakdown(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "203.0.113.50"
	v := view("GET", "/", ip, map[string]string{
		"User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	})
	s.cfg.Defense.Layer4.BogonFilter = false
	l4 := s.L4.InspectConnection(ip, v.LocalPort)
	fp := s.FP.Analyze(ip, v.Header.Get("User-Agent"), v.Header, tlsProtoFor(v))
	l7 := s.L7.Validate(v)
	waf := s.WAF.InspectRequest(v)
	rep := s.Rep.GetScore(ip)
	t.Logf("l4=%+v fp.head=%v fp.auto=%v fp.cons=%d l7=%+v waf=%+v rep=%d", l4, fp.IsHeadless, fp.IsAutomated, fp.ConsistencyScore, l7, waf, rep)
	d := s.Evaluate(v, ip)
	t.Logf("decision=%+v", d)
}

// TestSubnetPoisonDoesNotBlockCleanNeighbour is the end-to-end guard for the
// DDoS false positive: once attacker IPs in 198.51.100.0/24 have poisoned the
// subnet score over the block threshold, a clean neighbour in the same /24 (and
// /16) must still be served, not hard-blocked by reputation.
func TestSubnetPoisonDoesNotBlockCleanNeighbour(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	for i := 0; i < 6; i++ {
		s.Rep.Adjust(fmt.Sprintf("198.51.100.%d", 10+i), 35, "attack")
	}
	victim := "198.51.100.200"
	if s.Rep.GetScore(victim) < s.Rep.GetThreshold() {
		t.Fatalf("precondition: subnet should be poisoned, blended=%d", s.Rep.GetScore(victim))
	}
	v := view("GET", "/", victim, map[string]string{
		"User-Agent":      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
		"Accept":          "text/html",
		"Accept-Language": "en-US,en;q=0.9",
	})
	d := s.Evaluate(v, victim)
	if d.Action == ActionBlock && d.Reason == "reputation-block" {
		t.Fatalf("FALSE POSITIVE: clean neighbour blocked by reputation, %+v", d)
	}
}

// TestResetAllClearsL2Reputation guards the admin "reset reputation" path: a
// reset must purge the shared L2 mirror too, otherwise a node restart (or peer
// node) rehydrates the very scores the operator just cleared.
func TestResetAllClearsL2Reputation(t *testing.T) {
	cfg := config.Default()
	cfg.Cluster.Redis.Enabled = false // memory store exercises the same mirror path
	s := New(cfg)
	defer s.Close()
	ip := "203.0.113.200"
	s.Rep.Adjust(ip, 90, "attack")
	if _, ok := s.store.Get(mustCtx(), "rep:"+ip); !ok {
		t.Fatal("precondition: rep:<ip> mirror must exist")
	}
	s.Rep.ResetAll()
	if _, ok := s.store.Get(mustCtx(), "rep:"+ip); ok {
		t.Fatal("ResetAll must purge the L2 rep mirror (else a restart re-poisons state)")
	}
}

// TestReputationBlockIsSoftNotBlocklist guards the real-user false positive
// where a reputation-driven block was written to the durable blocklist and then
// surfaced as "blocklisted" for the whole TTL (trapping legitimate visitors
// behind shared/NAT IPs). It must deny the request but leave the blocklist empty.
func TestReputationBlockIsSoftNotBlocklist(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "203.0.113.50"
	s.Rep.Adjust(ip, 90, "rate-limit") // own score >= block threshold (80)
	v := view("GET", "/", ip, map[string]string{
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
	})
	d := s.Evaluate(v, ip)
	if d.Action != ActionBlock || d.Reason != "reputation-block" {
		t.Fatalf("expected reputation-block, got %+v", d)
	}
	if be, active := s.isBlocklisted(ip); active {
		t.Fatalf("reputation block must NOT write the durable blocklist: %+v", be)
	}
	if snap := s.BlocklistSnapshot(); len(snap) != 0 {
		t.Fatalf("blocklist should stay empty, got %v", snap)
	}
}

// TestClearSoftStateResetsEnforcement verifies that once a client proves
// humanity the soft enforcement state is wiped, so a real visitor is not
// re-blocked on the very next request.
func TestClearSoftStateResetsEnforcement(t *testing.T) {
	s := newTestShield()
	defer s.Close()
	ip := "203.0.113.51"
	s.Rep.Adjust(ip, 90, "attack")
	v := view("GET", "/", ip, map[string]string{
		"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0 Safari/537.36",
	})
	if d := s.Evaluate(v, ip); d.Action != ActionBlock {
		t.Fatalf("precondition: want block, got %+v", d)
	}
	s.ClearSoftState(ip)
	if got := s.Rep.OwnScore(ip); got != 0 {
		t.Fatalf("reputation should be cleared, got %d", got)
	}
	if d := s.Evaluate(v, ip); d.Action == ActionBlock {
		t.Fatalf("after ClearSoftState a clean request must not be blocked, got %+v", d)
	}
}
