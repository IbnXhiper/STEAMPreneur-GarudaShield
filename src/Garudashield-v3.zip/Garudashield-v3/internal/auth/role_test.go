package auth

import "testing"

func TestRoleAtLeast(t *testing.T) {
	cases := []struct {
		role, min string
		want      bool
	}{
		{RoleOwner, RoleOwner, true},
		{RoleOwner, RoleAdmin, true},
		{RoleOwner, RoleViewer, true},
		{RoleAdmin, RoleAdmin, true},
		{RoleAdmin, RoleViewer, true},
		{RoleAdmin, RoleOwner, false},
		{RoleViewer, RoleViewer, true},
		{RoleViewer, RoleAdmin, false},
		{RoleViewer, RoleOwner, false},
		// Unknown/empty roles rank below viewer (deny by default).
		{"", RoleViewer, false},
		{"superuser", RoleViewer, false},
		{"", RoleOwner, false},
	}
	for _, c := range cases {
		if got := RoleAtLeast(c.role, c.min); got != c.want {
			t.Errorf("RoleAtLeast(%q,%q)=%v want %v", c.role, c.min, got, c.want)
		}
	}
}

func TestNormalizeRole(t *testing.T) {
	if got := NormalizeRole(""); got != RoleViewer {
		t.Errorf("NormalizeRole(empty)=%q want viewer", got)
	}
	if got := NormalizeRole("root"); got != RoleViewer {
		t.Errorf("NormalizeRole(unknown)=%q want viewer", got)
	}
	if got := NormalizeRole(RoleOwner); got != RoleOwner {
		t.Errorf("NormalizeRole(owner)=%q want owner", got)
	}
	if got := NormalizeRole(RoleAdmin); got != RoleAdmin {
		t.Errorf("NormalizeRole(admin)=%q want admin", got)
	}
}
