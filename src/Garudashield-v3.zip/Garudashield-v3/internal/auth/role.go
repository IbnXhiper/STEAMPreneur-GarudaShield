// Role-based access control for the commercial control plane.
//
// Every authenticated customer action resolves to a Principal (tenant, user,
// role) server-side. Roles are ordered viewer < admin < owner and checks are
// deny-by-default: an unknown/empty role ranks below viewer, so a malformed
// row can never grant a privileged action.
package auth

import (
	"net/http"
)

// Customer roles. owner is created by registration/operator onboarding; admin
// and viewer are added by the owner (or operator) for team access.
const (
	RoleViewer = "viewer"
	RoleAdmin  = "admin"
	RoleOwner  = "owner"
)

// roleRank maps a role to its privilege rank. Unknown roles rank -1 (below
// viewer) so RoleAtLeast fails closed.
func roleRank(role string) int {
	switch role {
	case RoleOwner:
		return 2
	case RoleAdmin:
		return 1
	case RoleViewer:
		return 0
	default:
		return -1
	}
}

// NormalizeRole collapses any unknown role to viewer (least privilege). It is
// applied whenever a role is loaded from the database.
func NormalizeRole(role string) string {
	if roleRank(role) < 0 {
		return RoleViewer
	}
	return role
}

// RoleAtLeast reports whether role satisfies the minimum required role.
func RoleAtLeast(role, min string) bool {
	return roleRank(role) >= roleRank(min)
}

// Principal is the authenticated caller's identity, resolved from the signed
// session cookie and re-validated against Postgres on every request.
type Principal struct {
	TenantID string
	UserID   int64
	Role     string
}

// PrincipalFromRequest resolves the full principal (tenant + user + role) for
// an authenticated request. It enforces expiry, signature, user binding, and
// revocation exactly like TenantFromRequest, and additionally loads the role.
func (h *Handler) PrincipalFromRequest(r *http.Request) (Principal, error) {
	c, err := r.Cookie(SessionCookieName)
	if err != nil {
		return Principal{}, ErrNoSession
	}
	s, err := h.verifySession(c.Value)
	if err != nil {
		return Principal{}, ErrNoSession
	}
	var (
		tenantID string
		version  int64
		role     string
		userID   int64
	)
	if err := h.pool.QueryRow(r.Context(),
		`SELECT u.tenant_id, u.session_version, u.role, u.id
		 FROM users u WHERE u.id = $1`,
		s.userID).Scan(&tenantID, &version, &role, &userID); err != nil {
		return Principal{}, ErrNoSession
	}
	if tenantID != s.tenantID || version != s.version {
		return Principal{}, ErrNoSession
	}
	// The tenant must still exist (defense in depth against orphaned users).
	var one int
	if err := h.pool.QueryRow(r.Context(),
		`SELECT 1 FROM tenants WHERE id = $1`, tenantID).Scan(&one); err != nil {
		return Principal{}, ErrNoSession
	}
	return Principal{TenantID: tenantID, UserID: userID, Role: NormalizeRole(role)}, nil
}
