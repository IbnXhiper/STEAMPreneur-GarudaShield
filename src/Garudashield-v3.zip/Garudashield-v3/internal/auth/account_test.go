package auth

import (
	"context"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/db"
)

// TestRegisterFreePlanContractPG locks down the registration security contract:
// the Free plan is assigned by the backend (never by client input), the password
// is stored as a bcrypt hash (never plaintext), role escalation via the request
// body is ignored, a protected endpoint rejects an anonymous caller, and a
// failed registration leaves no partial rows behind.
func TestRegisterFreePlanContractPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()

	const tenantID = "escalate-reg"
	const email = "boss@escalate.id"
	const pass = "super-secret-01!"
	cleanup := func() {
		_, _ = pool.Exec(ctx, `DELETE FROM audit_log WHERE actor IN ($1,$2)`, email, "second@escalate.id")
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id=$1`, tenantID)
		_, _ = pool.Exec(ctx, `DELETE FROM subscriptions WHERE tenant_id=$1`, tenantID)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, tenantID)
	}
	cleanup()
	defer cleanup()

	h := New(pool, "test-session-secret-32bytes-minimum!!")

	// Register while trying to smuggle an admin role and a paid plan — both are
	// attacker-controlled input and must be ignored by the handler.
	body := `{"email":"` + email + `","password":"` + pass + `","tenant":"` + tenantID + `","role":"admin","plan":"enterprise"}`
	rr := httptest.NewRecorder()
	h.Register(rr, httptest.NewRequest("POST", "/api/v1/auth/register", strings.NewReader(body)))
	if rr.Code != http.StatusOK {
		t.Fatalf("register status %d body=%s", rr.Code, rr.Body.String())
	}

	// 1. Free plan is set by the backend regardless of the requested plan.
	var plan string
	if err := pool.QueryRow(ctx, `SELECT plan FROM tenants WHERE id=$1`, tenantID).Scan(&plan); err != nil {
		t.Fatal(err)
	}
	if plan != "free" {
		t.Fatalf("tenant plan = %q, want free", plan)
	}

	// 2. A matching free/active subscription row was created in the same tx.
	var sstatus, splan, provider string
	if err := pool.QueryRow(ctx,
		`SELECT status, plan, provider FROM subscriptions WHERE tenant_id=$1`, tenantID).
		Scan(&sstatus, &splan, &provider); err != nil {
		t.Fatalf("subscription row missing: %v", err)
	}
	if sstatus != "active" || splan != "free" || provider != "self" {
		t.Fatalf("subscription = {%s %s %s}, want {active free self}", sstatus, splan, provider)
	}

	// 3. Role is owner (never admin) and the password is a bcrypt hash, not the
	//    cleartext that was sent.
	var role, hash string
	if err := pool.QueryRow(ctx,
		`SELECT role, password_hash FROM users WHERE tenant_id=$1 AND email=$2`, tenantID, email).
		Scan(&role, &hash); err != nil {
		t.Fatal(err)
	}
	if role != "owner" {
		t.Fatalf("role = %q, want owner (no escalation)", role)
	}
	if hash == pass || !strings.HasPrefix(hash, "$2") {
		t.Fatalf("password is not a bcrypt hash: %q", hash)
	}

	// 4. Re-read from the store (fresh query) — the Free plan persists.
	if err := pool.QueryRow(ctx, `SELECT plan FROM tenants WHERE id=$1`, tenantID).Scan(&plan); err != nil {
		t.Fatal(err)
	}
	if plan != "free" {
		t.Fatalf("plan did not persist: %q", plan)
	}

	// 5. An anonymous caller cannot reach a session-protected endpoint.
	rr = httptest.NewRecorder()
	h.Account(rr, httptest.NewRequest("GET", "/api/v1/account", nil))
	if rr.Code != http.StatusUnauthorized {
		t.Fatalf("anonymous /account = %d, want 401", rr.Code)
	}

	// 6. Failed registration (tenant collision) must not leave partial rows:
	//    the transaction rolls back, so no second user or subscription appears.
	dup := `{"email":"second@escalate.id","password":"` + pass + `","tenant":"` + tenantID + `"}`
	rr = httptest.NewRecorder()
	h.Register(rr, httptest.NewRequest("POST", "/api/v1/auth/register", strings.NewReader(dup)))
	if rr.Code != http.StatusConflict {
		t.Fatalf("duplicate tenant register = %d, want 409", rr.Code)
	}
	var users, subs int
	_ = pool.QueryRow(ctx, `SELECT count(*) FROM users WHERE tenant_id=$1`, tenantID).Scan(&users)
	_ = pool.QueryRow(ctx, `SELECT count(*) FROM subscriptions WHERE tenant_id=$1`, tenantID).Scan(&subs)
	if users != 1 || subs != 1 {
		t.Fatalf("partial rows after failed register: users=%d subs=%d", users, subs)
	}

	// 7. A weak password is rejected before any row is written.
	weak := `{"email":"weak@escalate.id","password":"short","tenant":"weak-escalate"}`
	rr = httptest.NewRecorder()
	h.Register(rr, httptest.NewRequest("POST", "/api/v1/auth/register", strings.NewReader(weak)))
	if rr.Code != http.StatusBadRequest {
		t.Fatalf("weak password register = %d, want 400", rr.Code)
	}
	var weakTenant int
	_ = pool.QueryRow(ctx, `SELECT count(*) FROM tenants WHERE id='weak-escalate'`).Scan(&weakTenant)
	if weakTenant != 0 {
		t.Fatalf("weak registration left tenant rows: %d", weakTenant)
	}
}

func TestSlugFromEmail(t *testing.T) {
	cases := map[string]string{
		"john@example.com":          "john",
		"john+ads@example.com":      "john-ads",
		"Foo.Bar-Baz@example.com":   "foo-bar-baz",
		"first.last_02@example.com": "first-last-02",
		"":                          "",
	}
	for in, want := range cases {
		if got := slugFromEmail(in); got != want {
			t.Errorf("slugFromEmail(%q) = %q, want %q", in, got, want)
		}
	}
}

// TestRegisterAndPasswordRotationPG exercises the real PG path: register mints
// a free tenant + owner + subscription and auto-login cookie; duplicate email
// returns 409; password change rotates the session (old cookie dies, new works).
func TestRegisterAndPasswordRotationPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM audit_log WHERE actor='owner+reg@example.id' OR actor='newpass@example.id'`)
	_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id IN ('owner-reg','newpass-reg')`)
	_, _ = pool.Exec(ctx, `DELETE FROM subscriptions WHERE tenant_id IN ('owner-reg','newpass-reg')`)
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id IN ('owner-reg','newpass-reg')`)
	defer func() {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id IN ('owner-reg','newpass-reg')`)
		_, _ = pool.Exec(ctx, `DELETE FROM subscriptions WHERE tenant_id IN ('owner-reg','newpass-reg')`)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id IN ('owner-reg','newpass-reg')`)
	}()

	h := New(pool, "test-session-secret-32bytes-minimum!!")

	// Register (tenant derived from email).
	rr := httptest.NewRecorder()
	req := httptest.NewRequest("POST", "/api/v1/auth/register",
		strings.NewReader(`{"email":"owner+reg@example.id","password":"super-secret-01!"}`))
	h.Register(rr, req)
	if rr.Code != http.StatusOK {
		t.Fatalf("register status %d body=%s", rr.Code, rr.Body.String())
	}
	cookies := rr.Result().Cookies()
	var ck *http.Cookie
	for _, c := range cookies {
		if c.Name == SessionCookieName {
			ck = c
		}
	}
	if ck == nil || ck.Value == "" {
		t.Fatal("register did not auto-login (no session cookie)")
	}

	// Session resolves to the derived tenant.
	req2 := httptest.NewRequest("GET", "/", nil)
	req2.AddCookie(ck)
	tid, err := h.TenantFromRequest(req2)
	if err != nil {
		t.Fatalf("session from register: %v", err)
	}
	if tid != "owner-reg" {
		t.Fatalf("derived tenant = %q, want owner-reg", tid)
	}

	// Account profile.
	rr = httptest.NewRecorder()
	h.Account(rr, req2)
	if rr.Code != http.StatusOK || !strings.Contains(rr.Body.String(), "owner-reg") {
		t.Fatalf("account profile status=%d body=%s", rr.Code, rr.Body.String())
	}

	// Duplicate email -> 409.
	rr = httptest.NewRecorder()
	dup := httptest.NewRequest("POST", "/api/v1/auth/register",
		strings.NewReader(`{"email":"owner+reg@example.id","password":"another-secret-02!"}`))
	h.Register(rr, dup)
	if rr.Code != http.StatusConflict {
		t.Fatalf("duplicate register should be 409, got %d", rr.Code)
	}

	// Weak password -> 400.
	rr = httptest.NewRecorder()
	weak := httptest.NewRequest("POST", "/api/v1/auth/register",
		strings.NewReader(`{"email":"weak@example.id","password":"short"}`))
	h.Register(rr, weak)
	if rr.Code != http.StatusBadRequest {
		t.Fatalf("weak password should be 400, got %d", rr.Code)
	}

	// Change password: old session must die, new session must work.
	oldToken := ck.Value
	rr = httptest.NewRecorder()
	chg := httptest.NewRequest("POST", "/api/v1/account/password",
		strings.NewReader(`{"currentPassword":"super-secret-01!","newPassword":"rotated-secret-02!"}`))
	chg.AddCookie(ck)
	h.ChangePassword(rr, chg)
	if rr.Code != http.StatusOK {
		t.Fatalf("change password status %d body=%s", rr.Code, rr.Body.String())
	}
	newCk := rr.Result().Cookies()[0]
	if newCk.Value == "" {
		t.Fatal("password change did not re-issue session")
	}

	// Old token now rejected (session_version bumped).
	reqOld := httptest.NewRequest("GET", "/", nil)
	reqOld.AddCookie(&http.Cookie{Name: SessionCookieName, Value: oldToken})
	if _, err := h.TenantFromRequest(reqOld); err == nil {
		t.Fatal("pre-change session must be revoked after password rotation")
	}
	// New token accepted, and old password no longer works at login scope.
	reqNew := httptest.NewRequest("GET", "/", nil)
	reqNew.AddCookie(newCk)
	if tid2, err := h.TenantFromRequest(reqNew); err != nil || tid2 != "owner-reg" {
		t.Fatalf("post-change session invalid: tid=%q err=%v", tid2, err)
	}

	// Wrong current password -> 401.
	rr = httptest.NewRecorder()
	bad := httptest.NewRequest("POST", "/api/v1/account/password",
		strings.NewReader(`{"currentPassword":"wrong-old","newPassword":"whatever-secret-03"}`))
	bad.AddCookie(newCk)
	h.ChangePassword(rr, bad)
	if rr.Code != http.StatusUnauthorized {
		t.Fatalf("wrong current password should be 401, got %d", rr.Code)
	}
}
