// Account self-service: secure registration, password change (with session
// rotation), and profile read. Registration is opt-in public account creation
// for the free plan — paid plans still go through the operator (WhatsApp)
// flow. Every mutating action is audited.
package auth

import (
	"encoding/json"
	"errors"
	"net/http"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgconn"
	"golang.org/x/crypto/bcrypt"
)

const (
	// minPasswordLen is the shared minimum for registration and password change.
	minPasswordLen = 12
	// Registration anti-spam: max 5 new accounts per IP per hour.
	regMax    = 5
	regWindow = time.Hour
)

type regWindowStamps struct {
	mu     sync.Mutex
	stamps []time.Time
}

// Register handles POST /api/v1/auth/register {email,password,tenant?,name?}.
// Creates the free-plan tenant, its owner user (bcrypt), and the subscription
// row atomically, then issues a signed session cookie (register == auto-login).
func (h *Handler) Register(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	ip := remoteIP(r)
	if !h.regAllowed(ip) {
		w.Header().Set("Retry-After", "3600")
		http.Error(w, "too many registrations from this address; try again later", http.StatusTooManyRequests)
		return
	}
	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
		Tenant   string `json:"tenant"`
		Name     string `json:"name"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	req.Name = strings.TrimSpace(req.Name)
	req.Tenant = strings.ToLower(strings.TrimSpace(req.Tenant))
	if !strings.Contains(req.Email, "@") || strings.Contains(req.Email, " ") {
		http.Error(w, "valid email required", http.StatusBadRequest)
		return
	}
	if len(req.Password) < minPasswordLen {
		http.Error(w, "password must be at least 12 characters", http.StatusBadRequest)
		return
	}

	tenantID := req.Tenant
	if tenantID == "" {
		tenantID = slugFromEmail(req.Email)
	}
	if !tenantIDPattern.MatchString(tenantID) {
		http.Error(w, "tenant must be lowercase letters/digits/hyphens (2-63 chars)", http.StatusBadRequest)
		return
	}

	hash, err := bcrypt.GenerateFromPassword([]byte(req.Password), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}

	tx, err := h.pool.Begin(r.Context())
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	defer tx.Rollback(r.Context())

	// Email is globally unique in practice (each registration owns its tenant).
	var one int
	if err := tx.QueryRow(r.Context(),
		`SELECT 1 FROM users WHERE lower(email) = $1 LIMIT 1`, req.Email).Scan(&one); err == nil {
		http.Error(w, "email already registered", http.StatusConflict)
		return
	}
	if _, err := tx.Exec(r.Context(),
		`INSERT INTO tenants (id, name, plan) VALUES ($1, $2, 'free')`,
		tenantID, orDefault(req.Name, tenantID)); err != nil {
		if isUniqueViolation(err) {
			http.Error(w, "tenant already registered", http.StatusConflict)
			return
		}
		http.Error(w, "registration failed", http.StatusInternalServerError)
		return
	}
	if _, err := tx.Exec(r.Context(),
		`INSERT INTO users (tenant_id, email, password_hash, role) VALUES ($1, $2, $3, 'owner')`,
		tenantID, req.Email, string(hash)); err != nil {
		if isUniqueViolation(err) {
			http.Error(w, "email already registered", http.StatusConflict)
			return
		}
		http.Error(w, "registration failed", http.StatusInternalServerError)
		return
	}
	if _, err := tx.Exec(r.Context(),
		`INSERT INTO subscriptions (tenant_id, status, provider, plan, current_period_end)
		 VALUES ($1, 'active', 'self', 'free', 0)`, tenantID); err != nil {
		http.Error(w, "registration failed", http.StatusInternalServerError)
		return
	}
	var uid int64
	if err := tx.QueryRow(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip)
		 VALUES ($1, $2, 'account.register', 'plan=free', $3)
		 RETURNING id`, tenantID, req.Email, ip).Scan(&uid); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	if err := tx.Commit(r.Context()); err != nil {
		http.Error(w, "registration failed", http.StatusInternalServerError)
		return
	}
	h.regRecord(ip)

	var userID int64
	_ = h.pool.QueryRow(r.Context(),
		`SELECT id FROM users WHERE tenant_id = $1`, tenantID).Scan(&userID)

	tok, err := h.signSession(tenantID, strconv.FormatInt(userID, 10))
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     SessionCookieName,
		Value:    tok,
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int((7 * 24 * time.Hour).Seconds()),
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "tenant": tenantID, "plan": "free"})
}

// ChangePassword handles POST /api/v1/account/password
// {currentPassword, newPassword}. Verifies the current password, updates the
// bcrypt hash, bumps session_version (revokes every other session), and
// re-issues a fresh session for the caller (session rotation — A07).
func (h *Handler) ChangePassword(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	s, err := h.currentSession(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var req struct {
		CurrentPassword string `json:"currentPassword"`
		NewPassword     string `json:"newPassword"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 16<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if len(req.NewPassword) < minPasswordLen {
		http.Error(w, "new password must be at least 12 characters", http.StatusBadRequest)
		return
	}
	if req.CurrentPassword == req.NewPassword {
		http.Error(w, "new password must differ from current", http.StatusBadRequest)
		return
	}

	var hash string
	if err := h.pool.QueryRow(r.Context(),
		`SELECT password_hash FROM users WHERE id = $1`, s.userID).Scan(&hash); err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(hash), []byte(req.CurrentPassword)) != nil {
		http.Error(w, "current password is incorrect", http.StatusUnauthorized)
		return
	}

	newHash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	// Bump session_version: old tokens (including other browsers/devices)
	// stop working; a fresh token is minted below for the current caller.
	if _, err := h.pool.Exec(r.Context(),
		`UPDATE users SET password_hash = $2, session_version = session_version + 1
		 WHERE id = $1`, s.userID, string(newHash)); err != nil {
		http.Error(w, "update failed", http.StatusInternalServerError)
		return
	}
	_, _ = h.pool.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip)
		 VALUES ($1, $2, 'account.password_change', '', $3)`,
		s.tenantID, s.userID, remoteIP(r))

	tok, err := h.signSession(s.tenantID, s.userID)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name:     SessionCookieName,
		Value:    tok,
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int((7 * 24 * time.Hour).Seconds()),
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "tenant": s.tenantID})
}

// LogoutAll handles POST /api/v1/account/logout-all — revokes every session
// for the authenticated user (including the caller) by bumping session_version,
// then clears the cookie. Use after a suspected compromise or to force a
// re-login on every device.
func (h *Handler) LogoutAll(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	s, err := h.currentSession(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	if _, err := h.pool.Exec(r.Context(),
		`UPDATE users SET session_version = session_version + 1 WHERE id = $1`, s.userID); err != nil {
		http.Error(w, "update failed", http.StatusInternalServerError)
		return
	}
	_, _ = h.pool.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip)
		 VALUES ($1, $2, 'account.logout_all', '', $3)`,
		s.tenantID, s.userID, remoteIP(r))
	http.SetCookie(w, &http.Cookie{
		Name:     SessionCookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

// Account handles GET /api/v1/account — profile for the authenticated user.
func (h *Handler) Account(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	s, err := h.currentSession(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	var email, role string
	if err := h.pool.QueryRow(r.Context(),
		`SELECT email, role FROM users WHERE id = $1`, s.userID).Scan(&email, &role); err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"tenant": s.tenantID,
		"email":  email,
		"role":   role,
	})
}

// ---------- helpers ----------

var tenantIDPattern = regexp.MustCompile(`^[a-z0-9][a-z0-9-]{1,62}$`)

// slugFromEmail derives a stable tenant id from the email local part
// (e.g. "john+ads@x.com" -> "john-ads"). Invalid chars are collapsed to '-'.
func slugFromEmail(email string) string {
	at := strings.IndexByte(email, '@')
	if at <= 0 {
		return ""
	}
	var b strings.Builder
	prevDash := false
	for _, c := range strings.ToLower(email[:at]) {
		switch {
		case c >= 'a' && c <= 'z' || c >= '0' && c <= '9':
			b.WriteRune(c)
			prevDash = false
		default:
			if !prevDash && b.Len() > 0 {
				b.WriteByte('-')
				prevDash = true
			}
		}
	}
	return strings.Trim(b.String(), "-")
}

func orDefault(v, d string) string {
	if strings.TrimSpace(v) == "" {
		return d
	}
	return v
}

func isUniqueViolation(err error) bool {
	var pe *pgconn.PgError
	return errors.As(err, &pe) && pe.Code == "23505"
}

// currentSession verifies the cookie signature/expiry and re-resolves the
// user's current tenant + session_version from Postgres (revocation check).
func (h *Handler) currentSession(r *http.Request) (session, error) {
	c, err := r.Cookie(SessionCookieName)
	if err != nil {
		return session{}, ErrNoSession
	}
	s, err := h.verifySession(c.Value)
	if err != nil {
		return session{}, ErrNoSession
	}
	var tenantID string
	var version int64
	if err := h.pool.QueryRow(r.Context(),
		`SELECT u.tenant_id, u.session_version FROM users u WHERE u.id = $1`,
		s.userID).Scan(&tenantID, &version); err != nil {
		return session{}, ErrNoSession
	}
	if tenantID != s.tenantID || version != s.version {
		return session{}, ErrNoSession
	}
	return s, nil
}

func (h *Handler) regAllowed(ip string) bool {
	return h.limitAllow("reg:"+ip, regMax, regWindow)
}

func (h *Handler) regRecord(ip string) {
	h.limitRecord("reg:" + ip)
}

// limitAllow reports whether key is under max events in the trailing window.
func (h *Handler) limitAllow(key string, max int, window time.Duration) bool {
	v, _ := h.regs.LoadOrStore(key, &regWindowStamps{})
	win := v.(*regWindowStamps)
	win.mu.Lock()
	defer win.mu.Unlock()
	now := time.Now()
	cut := now.Add(-window)
	kept := win.stamps[:0]
	for _, t := range win.stamps {
		if t.After(cut) {
			kept = append(kept, t)
		}
	}
	win.stamps = kept
	return len(win.stamps) < max
}

// limitRecord appends an event timestamp for key.
func (h *Handler) limitRecord(key string) {
	v, _ := h.regs.LoadOrStore(key, &regWindowStamps{})
	win := v.(*regWindowStamps)
	win.mu.Lock()
	win.stamps = append(win.stamps, time.Now())
	win.mu.Unlock()
}
