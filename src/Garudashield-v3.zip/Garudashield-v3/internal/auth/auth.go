// Package auth implements tenant-scoped customer authentication for the
// GarudaShield commercial control plane (managed SaaS + self-host portal).
//
// Design (fail-closed, minimal):
//   - Passwords stored as bcrypt hashes in the `users` table (never plaintext).
//   - Login returns an HMAC-signed session cookie (tenant-scoped), no server
//     session store to scale. Secret from GS_SESSION_SECRET (or a per-boot
//     random default that invalidates on restart — operators MUST set it).
//   - Every authenticated action re-resolves the tenant from Postgres so a
//     tenant-scoped row can never be read cross-tenant.
package auth

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"net"
	"net/http"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"golang.org/x/crypto/bcrypt"
)

// SessionCookieName is the auth cookie set on successful login.
const SessionCookieName = "gs_session"

// Session lifetime enforced server-side (cookie MaxAge mirrors it).
const sessionTTL = 7 * 24 * time.Hour

// Login lockout: per-email 5 fails / 5 min (account protection), per-IP
// 20 fails / 5 min (higher because dashboard BFF proxies share one IP).
const (
	loginMaxFailsEmail = 5
	loginMaxFailsIP    = 20
	loginLockWindow    = 5 * time.Minute
)

type loginAttempt struct {
	mu          sync.Mutex
	fails       int
	lockedUntil time.Time
}

// Handler authenticates users and issues tenant-scoped sessions.
type Handler struct {
	pool   *pgxpool.Pool
	secret []byte
	fails  sync.Map // key ("e:"+email / "i:"+ip) -> *loginAttempt
	regs   sync.Map // key ip -> *regWindowStamps (registration anti-spam)

	// mailer + publicURL power password-reset email. Both are optional: when
	// unset the reset link is not delivered (degrade gracefully) but the token
	// is still created/validated.
	mailer    Mailer
	publicURL string
}

// Mailer is the minimal transactional-email surface the auth handler needs.
type Mailer interface {
	Configured() bool
	Send(to, subject, body string) error
}

// SetMailer wires the transactional email sender (e.g. internal/mailer.SMTP).
func (h *Handler) SetMailer(m Mailer) { h.mailer = m }

// SetPublicURL sets the base URL used to build password-reset links.
func (h *Handler) SetPublicURL(u string) { h.publicURL = strings.TrimRight(u, "/") }

// New builds an auth handler. If secret is empty a warning is implied by the
// caller; we still derive a per-process key so the server runs, but log it.
func New(pool *pgxpool.Pool, secret string) *Handler {
	if secret == "" {
		secret = randomFallbackSecret()
	}
	return &Handler{pool: pool, secret: []byte(secret)}
}

// Login handles POST /api/auth/login {email,password,tenant?}. It resolves the
// user by tenant+email, verifies bcrypt, and sets a signed session cookie.
func (h *Handler) Login(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Email    string `json:"email"`
		Password string `json:"password"`
		Tenant   string `json:"tenant"`
		// Code is the TOTP / recovery code when the account has 2FA enabled.
		Code string `json:"code"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	if req.Email == "" || req.Password == "" {
		http.Error(w, "email and password required", http.StatusBadRequest)
		return
	}
	ip := remoteIP(r)
	if h.loginLocked("e:"+req.Email) || h.loginLocked("i:"+ip) {
		w.Header().Set("Retry-After", "300")
		http.Error(w, "too many failed attempts; try again later", http.StatusTooManyRequests)
		return
	}

	var (
		tenantID     string
		userID       int64
		passwordHash string
		mfaEnabled   bool
	)
	q := `SELECT t.id, u.id, u.password_hash, u.mfa_enabled FROM users u
	      JOIN tenants t ON t.id = u.tenant_id
	      WHERE lower(u.email) = $1`
	args := []any{req.Email}
	if req.Tenant != "" {
		q += ` AND t.id = $2`
		args = append(args, req.Tenant)
	}
	err := h.pool.QueryRow(r.Context(), q, args...).Scan(&tenantID, &userID, &passwordHash, &mfaEnabled)
	if err != nil {
		// Same response for "no user" and "bad password" to avoid user enumeration.
		h.loginFail("e:"+req.Email, "i:"+ip)
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}
	if bcrypt.CompareHashAndPassword([]byte(passwordHash), []byte(req.Password)) != nil {
		h.loginFail("e:"+req.Email, "i:"+ip)
		http.Error(w, "invalid credentials", http.StatusUnauthorized)
		return
	}

	// Second factor: when enabled the correct password is not sufficient.
	if mfaEnabled {
		if req.Code == "" {
			// Step 1: hand back a short-lived pending token; the client then
			// calls /api/v1/auth/mfa/verify with a TOTP/recovery code.
			ptok, perr := h.signMFAPending(tenantID, strconv.FormatInt(userID, 10))
			if perr != nil {
				http.Error(w, "internal error", http.StatusInternalServerError)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			w.WriteHeader(http.StatusAccepted)
			_ = json.NewEncoder(w).Encode(map[string]any{"mfaRequired": true, "mfaToken": ptok})
			return
		}
		if !h.verifyMFACode(r.Context(), userID, req.Code) {
			h.loginFail("e:"+req.Email, "i:"+ip)
			http.Error(w, "invalid code", http.StatusUnauthorized)
			return
		}
	}

	tok, err := h.signSession(tenantID, strconv.FormatInt(userID, 10))
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	h.loginReset("e:" + req.Email)
	h.loginReset("i:" + ip)
	http.SetCookie(w, &http.Cookie{
		Name:     SessionCookieName,
		Value:    tok,
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   int((7 * 24 * time.Hour).Seconds()),
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "tenant": tenantID})
}

// Logout clears the cookie and revokes the session server-side by bumping
// the user's session_version (best effort: cookie is cleared regardless).
func (h *Handler) Logout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(SessionCookieName); err == nil {
		if s, verr := h.verifySession(c.Value); verr == nil && h.pool != nil {
			_, _ = h.pool.Exec(r.Context(),
				`UPDATE users SET session_version = session_version + 1 WHERE id = $1`, s.userID)
		}
	}
	http.SetCookie(w, &http.Cookie{
		Name:     SessionCookieName,
		Value:    "",
		Path:     "/",
		HttpOnly: true,
		Secure:   true,
		SameSite: http.SameSiteLaxMode,
		MaxAge:   -1,
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

// session is a verified session token's claims.
type session struct {
	tenantID string
	userID   string
	version  int64
}

// TenantFromRequest resolves the authenticated tenant from the session cookie.
// Expiry, signature, user binding, and revocation are enforced server-side;
// old 2-part tokens (no expiry) are rejected outright (re-login required).
func (h *Handler) TenantFromRequest(r *http.Request) (string, error) {
	c, err := r.Cookie(SessionCookieName)
	if err != nil {
		return "", ErrNoSession
	}
	s, err := h.verifySession(c.Value)
	if err != nil {
		return "", ErrNoSession
	}
	var (
		tenantID string
		version  int64
	)
	if err := h.pool.QueryRow(r.Context(),
		`SELECT u.tenant_id, u.session_version FROM users u WHERE u.id = $1`,
		s.userID).Scan(&tenantID, &version); err != nil {
		return "", ErrNoSession
	}
	if tenantID != s.tenantID || version != s.version {
		return "", ErrNoSession // user moved tenants or logged out elsewhere
	}
	var tok bool
	if err := h.pool.QueryRow(r.Context(),
		`SELECT true FROM tenants WHERE id = $1`, tenantID).Scan(&tok); err != nil {
		return "", ErrNoSession
	}
	return tenantID, nil
}

// signSession mints tenantID.userID.exp.nonce.mac. Nonce makes every login
// unique; version pins the token to the user's session_version at issue.
func (h *Handler) signSession(tenantID, userID string) (string, error) {
	var version int64
	if h.pool != nil {
		_ = h.pool.QueryRow(context.Background(),
			`SELECT session_version FROM users WHERE id = $1`, userID).Scan(&version)
	}
	nonce := make([]byte, 8)
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	payload := strings.Join([]string{tenantID, userID,
		strconv.FormatInt(time.Now().Add(sessionTTL).Unix(), 10),
		strconv.FormatInt(version, 10),
		hex.EncodeToString(nonce)}, ".")
	mac := hmac.New(sha256.New, h.secret)
	mac.Write([]byte(payload))
	return payload + "." + hex.EncodeToString(mac.Sum(nil)), nil
}

// verifySession checks shape, signature, and expiry (no DB involved).
func (h *Handler) verifySession(tok string) (session, error) {
	parts := strings.Split(tok, ".")
	if len(parts) != 6 {
		return session{}, ErrNoSession // old format or garbage: reject
	}
	mac := hmac.New(sha256.New, h.secret)
	mac.Write([]byte(strings.Join(parts[:5], ".")))
	macSum := mac.Sum(nil)
	sig, err := hex.DecodeString(parts[5])
	if err != nil || !hmac.Equal(macSum, sig) {
		return session{}, ErrNoSession
	}
	exp, err := strconv.ParseInt(parts[2], 10, 64)
	if err != nil || time.Now().Unix() > exp {
		return session{}, ErrNoSession
	}
	version, err := strconv.ParseInt(parts[3], 10, 64)
	if err != nil {
		return session{}, ErrNoSession
	}
	return session{tenantID: parts[0], userID: parts[1], version: version}, nil
}

// ---------- login lockout ----------

func (h *Handler) loginLocked(key string) bool {
	limit := loginMaxFailsEmail
	if strings.HasPrefix(key, "i:") {
		limit = loginMaxFailsIP
	}
	v, ok := h.fails.Load(key)
	if !ok {
		return false
	}
	at := v.(*loginAttempt)
	at.mu.Lock()
	defer at.mu.Unlock()
	if time.Now().Before(at.lockedUntil) {
		return true
	}
	if at.fails >= limit {
		at.fails = 0
		at.lockedUntil = time.Time{}
	}
	return false
}

func (h *Handler) loginFail(keys ...string) {
	for _, key := range keys {
		limit := loginMaxFailsEmail
		if strings.HasPrefix(key, "i:") {
			limit = loginMaxFailsIP
		}
		v, _ := h.fails.LoadOrStore(key, &loginAttempt{})
		at := v.(*loginAttempt)
		at.mu.Lock()
		at.fails++
		if at.fails >= limit {
			at.lockedUntil = time.Now().Add(loginLockWindow)
		}
		at.mu.Unlock()
	}
}

func (h *Handler) loginReset(keys ...string) {
	for _, key := range keys {
		h.fails.Delete(key)
	}
}

func remoteIP(r *http.Request) string {
	host := r.RemoteAddr
	if h, _, err := net.SplitHostPort(host); err == nil {
		host = h
	}
	return host
}

// ErrNoSession means the request has no valid authenticated session.
var ErrNoSession = errors.New("no session")

func randomFallbackSecret() string {
	// Crypto-random per-boot key (invalidates old sessions on restart).
	// Operators MUST set GS_SESSION_SECRET in production.
	b := make([]byte, 32)
	if _, err := rand.Read(b); err != nil {
		panic("auth: crypto/rand unavailable")
	}
	return hex.EncodeToString(b)
}
