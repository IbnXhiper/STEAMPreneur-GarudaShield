package auth

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/db"
	"github.com/ahkurdev/garudashield/internal/totp"
	"golang.org/x/crypto/bcrypt"
)

// captureMailer records the last message so the test can extract the reset link.
type captureMailer struct{ last string }

func (m *captureMailer) Configured() bool                    { return true }
func (m *captureMailer) Send(to, subject, body string) error { m.last = body; return nil }

func newReq(method, target, body string) *http.Request {
	return httptest.NewRequest(method, target, strings.NewReader(body))
}

func sessionCookie(rec *httptest.ResponseRecorder) *http.Cookie {
	for _, c := range rec.Result().Cookies() {
		if c.Name == SessionCookieName {
			return c
		}
	}
	return nil
}

// TestMFAEnrollAndTwoStepLoginPG exercises the full TOTP lifecycle against PG.
func TestMFAEnrollAndTwoStepLoginPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id='mfa-test'`)
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='mfa-test'`)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan) VALUES ('mfa-test','MFA','free')`)
	hash, _ := bcrypt.GenerateFromPassword([]byte("initial-secret-01!"), bcrypt.DefaultCost)
	_, _ = pool.Exec(ctx, `INSERT INTO users (tenant_id,email,password_hash,role) VALUES ('mfa-test','mfa@example.id',$1,'owner')`, string(hash))
	defer func() {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id='mfa-test'`)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='mfa-test'`)
	}()

	h := New(pool, "test-session-secret-32bytes-minimum!!")

	login := func(body string) *httptest.ResponseRecorder {
		rec := httptest.NewRecorder()
		h.Login(rec, newReq("POST", "/api/v1/auth/login", body))
		return rec
	}

	// 1. Plain login (MFA off) works.
	rec := login(`{"email":"mfa@example.id","password":"initial-secret-01!"}`)
	if rec.Code != http.StatusOK {
		t.Fatalf("pre-MFA login = %d body=%s", rec.Code, rec.Body.String())
	}
	ck := sessionCookie(rec)
	if ck == nil {
		t.Fatal("no session cookie on login")
	}

	// 2. Setup: returns a secret to scan.
	rec = httptest.NewRecorder()
	h.MFASetup(rec, withCookie(newReq("POST", "/api/v1/account/mfa/setup", ""), ck))
	var setup struct {
		Secret     string `json:"secret"`
		OtpauthURL string `json:"otpauthUrl"`
	}
	if rec.Code != http.StatusOK || json.Unmarshal(rec.Body.Bytes(), &setup) != nil || setup.Secret == "" {
		t.Fatalf("mfa setup = %d body=%s", rec.Code, rec.Body.String())
	}

	// 3. Enable with a live code; capture recovery codes.
	code, _ := totp.Code(setup.Secret, time.Now())
	rec = httptest.NewRecorder()
	h.MFAEnable(rec, withCookie(newReq("POST", "/api/v1/account/mfa/enable", `{"code":"`+code+`"}`), ck))
	var en struct {
		RecoveryCodes []string `json:"recoveryCodes"`
	}
	if rec.Code != http.StatusOK || json.Unmarshal(rec.Body.Bytes(), &en) != nil || len(en.RecoveryCodes) != recoveryCount {
		t.Fatalf("mfa enable = %d body=%s", rec.Code, rec.Body.String())
	}

	// 4. Login without code -> 202 with pending token, no session.
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!"}`)
	if rec.Code != http.StatusAccepted {
		t.Fatalf("mfa login step1 = %d body=%s", rec.Code, rec.Body.String())
	}
	if sessionCookie(rec) != nil {
		t.Fatal("no session must be issued before second factor")
	}
	var pend struct {
		MFAToken string `json:"mfaToken"`
	}
	_ = json.Unmarshal(rec.Body.Bytes(), &pend)
	if pend.MFAToken == "" {
		t.Fatal("missing mfaToken")
	}

	// 5. Wrong code rejected.
	rec = httptest.NewRecorder()
	h.LoginMFA(rec, newReq("POST", "/api/v1/auth/mfa/verify", `{"mfaToken":"`+pend.MFAToken+`","code":"000000"}`))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("wrong code should be 401, got %d", rec.Code)
	}

	// 6. Correct TOTP completes login.
	code, _ = totp.Code(setup.Secret, time.Now())
	rec = httptest.NewRecorder()
	h.LoginMFA(rec, newReq("POST", "/api/v1/auth/mfa/verify", `{"mfaToken":"`+pend.MFAToken+`","code":"`+code+`"}`))
	if rec.Code != http.StatusOK || sessionCookie(rec) == nil {
		t.Fatalf("mfa verify = %d body=%s", rec.Code, rec.Body.String())
	}

	// 7. One-request login with inline code also works.
	code, _ = totp.Code(setup.Secret, time.Now())
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!","code":"` + code + `"}`)
	if rec.Code != http.StatusOK {
		t.Fatalf("inline-code login = %d body=%s", rec.Code, rec.Body.String())
	}

	// 8. Recovery code works exactly once.
	rc := en.RecoveryCodes[0]
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!"}`)
	_ = json.Unmarshal(rec.Body.Bytes(), &pend)
	rec = httptest.NewRecorder()
	h.LoginMFA(rec, newReq("POST", "/api/v1/auth/mfa/verify", `{"mfaToken":"`+pend.MFAToken+`","code":"`+rc+`"}`))
	if rec.Code != http.StatusOK {
		t.Fatalf("recovery login = %d body=%s", rec.Code, rec.Body.String())
	}
	// Consumed: a fresh pending token with the same recovery code must fail.
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!"}`)
	_ = json.Unmarshal(rec.Body.Bytes(), &pend)
	rec = httptest.NewRecorder()
	h.LoginMFA(rec, newReq("POST", "/api/v1/auth/mfa/verify", `{"mfaToken":"`+pend.MFAToken+`","code":"`+rc+`"}`))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("consumed recovery code must fail, got %d", rec.Code)
	}

	// 9. Disable MFA (need a live session first via inline-code login).
	code, _ = totp.Code(setup.Secret, time.Now())
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!","code":"` + code + `"}`)
	ck2 := sessionCookie(rec)
	if ck2 == nil {
		t.Fatalf("inline login for disable failed: %d %s", rec.Code, rec.Body.String())
	}
	code, _ = totp.Code(setup.Secret, time.Now())
	rec = httptest.NewRecorder()
	h.MFADisable(rec, withCookie(newReq("POST", "/api/v1/account/mfa/disable", `{"code":"`+code+`"}`), ck2))
	if rec.Code != http.StatusOK {
		t.Fatalf("mfa disable = %d body=%s", rec.Code, rec.Body.String())
	}
	rec = login(`{"email":"mfa@example.id","password":"initial-secret-01!"}`)
	if rec.Code != http.StatusOK {
		t.Fatalf("post-disable login = %d body=%s", rec.Code, rec.Body.String())
	}
}

// TestPasswordResetFlowPG covers request -> emailed token -> reset -> login.
func TestPasswordResetFlowPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id='reset-test'`)
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='reset-test'`)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan) VALUES ('reset-test','Reset','free')`)
	hash, _ := bcrypt.GenerateFromPassword([]byte("forgotten-pass-01!"), bcrypt.DefaultCost)
	_, _ = pool.Exec(ctx, `INSERT INTO users (tenant_id,email,password_hash,role) VALUES ('reset-test','reset@example.id',$1,'owner')`, string(hash))
	defer func() {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE tenant_id='reset-test'`)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='reset-test'`)
	}()

	h := New(pool, "test-session-secret-32bytes-minimum!!")
	cm := &captureMailer{}
	h.SetMailer(cm)
	h.SetPublicURL("https://dash.example.id")

	// Unknown email -> still 200, nothing sent.
	rec := httptest.NewRecorder()
	h.PasswordResetRequest(rec, newReq("POST", "/api/v1/auth/password/reset-request", `{"email":"nobody@example.id"}`))
	if rec.Code != http.StatusOK || cm.last != "" {
		t.Fatalf("unknown email: code=%d sent=%q", rec.Code, cm.last)
	}

	// Known email -> 200 + link emailed.
	rec = httptest.NewRecorder()
	h.PasswordResetRequest(rec, newReq("POST", "/api/v1/auth/password/reset-request", `{"email":"reset@example.id"}`))
	if rec.Code != http.StatusOK {
		t.Fatalf("reset request = %d", rec.Code)
	}
	token := extractToken(cm.last)
	if token == "" {
		t.Fatalf("no token in email body: %q", cm.last)
	}

	// Weak new password rejected.
	rec = httptest.NewRecorder()
	h.PasswordReset(rec, newReq("POST", "/api/v1/auth/password/reset", `{"token":"`+token+`","newPassword":"short"}`))
	if rec.Code != http.StatusBadRequest {
		t.Fatalf("weak reset password = %d, want 400", rec.Code)
	}

	// Valid reset.
	rec = httptest.NewRecorder()
	h.PasswordReset(rec, newReq("POST", "/api/v1/auth/password/reset", `{"token":"`+token+`","newPassword":"brand-new-pass-02!"}`))
	if rec.Code != http.StatusOK {
		t.Fatalf("reset = %d body=%s", rec.Code, rec.Body.String())
	}

	// Token is single-use.
	rec = httptest.NewRecorder()
	h.PasswordReset(rec, newReq("POST", "/api/v1/auth/password/reset", `{"token":"`+token+`","newPassword":"another-pass-03!"}`))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("reused token = %d, want 401", rec.Code)
	}

	// Old password fails, new password logs in.
	rec = httptest.NewRecorder()
	h.Login(rec, newReq("POST", "/api/v1/auth/login", `{"email":"reset@example.id","password":"forgotten-pass-01!"}`))
	if rec.Code != http.StatusUnauthorized {
		t.Fatalf("old password should fail, got %d", rec.Code)
	}
	rec = httptest.NewRecorder()
	h.Login(rec, newReq("POST", "/api/v1/auth/login", `{"email":"reset@example.id","password":"brand-new-pass-02!"}`))
	if rec.Code != http.StatusOK {
		t.Fatalf("new password should work, got %d", rec.Code)
	}
}

func withCookie(r *http.Request, c *http.Cookie) *http.Request {
	r.AddCookie(c)
	return r
}

func extractToken(body string) string {
	i := strings.Index(body, "token=")
	if i < 0 {
		return ""
	}
	rest := body[i+len("token="):]
	for j, ch := range rest {
		if ch == '\n' || ch == '\r' || ch == ' ' {
			return rest[:j]
		}
	}
	return rest
}
