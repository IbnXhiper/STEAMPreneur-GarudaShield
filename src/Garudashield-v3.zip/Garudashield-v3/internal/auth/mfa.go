// MFA (TOTP + recovery codes) and password reset. Registration/password-change
// live in account.go; login's second-factor branch lives in auth.go. Everything
// here is tenant-scoped and audited; recovery codes and reset tokens are stored
// only as SHA-256 hashes and are single-use.
package auth

import (
	"context"
	"crypto/hmac"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"github.com/ahkurdev/garudashield/internal/totp"
	"golang.org/x/crypto/bcrypt"
)

const (
	mfaPendingTTL = 5 * time.Minute
	resetTTL      = time.Hour
	recoveryCount = 8
)

// ---------- login step 2 (second factor) ----------

// LoginMFA handles POST /api/v1/auth/mfa/verify {mfaToken, code}. It verifies
// the short-lived pending token from login step 1 and the TOTP/recovery code,
// then issues the real session cookie.
func (h *Handler) LoginMFA(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		MFAToken string `json:"mfaToken"`
		Code     string `json:"code"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	tenantID, userIDStr, err := h.verifyMFAPending(req.MFAToken)
	if err != nil {
		http.Error(w, "invalid or expired mfa token", http.StatusUnauthorized)
		return
	}
	userID, _ := strconv.ParseInt(userIDStr, 10, 64)
	if !h.verifyMFACode(r.Context(), userID, req.Code) {
		http.Error(w, "invalid code", http.StatusUnauthorized)
		return
	}
	tok, err := h.signSession(tenantID, userIDStr)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	http.SetCookie(w, &http.Cookie{
		Name: SessionCookieName, Value: tok, Path: "/",
		HttpOnly: true, Secure: true, SameSite: http.SameSiteLaxMode,
		MaxAge: int((7 * 24 * time.Hour).Seconds()),
	})
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "tenant": tenantID})
}

// MFASetup handles POST /api/v1/account/mfa/setup. Generates and persists a
// new secret (still disabled) and returns the otpauth URI for the app to scan.
func (h *Handler) MFASetup(w http.ResponseWriter, r *http.Request) {
	s, ok := h.sessionOrFail(w, r)
	if !ok {
		return
	}
	secret, err := totp.GenerateSecret()
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	if _, err := h.pool.Exec(r.Context(),
		`UPDATE users SET mfa_secret = $2, mfa_enabled = false WHERE id = $1`,
		s.userID, secret); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	var email string
	_ = h.pool.QueryRow(r.Context(), `SELECT email FROM users WHERE id = $1`, s.userID).Scan(&email)
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{
		"secret":     secret,
		"otpauthUrl": totp.ProvisioningURL("GarudaShield", email, secret),
	})
}

// MFAEnable handles POST /api/v1/account/mfa/enable {code}. Confirms the setup
// with a live code, flips the flag, and returns one-time recovery codes.
func (h *Handler) MFAEnable(w http.ResponseWriter, r *http.Request) {
	s, ok := h.sessionOrFail(w, r)
	if !ok {
		return
	}
	code := decodeCodeField(r)
	var secret string
	if err := h.pool.QueryRow(r.Context(),
		`SELECT mfa_secret FROM users WHERE id = $1`, s.userID).Scan(&secret); err != nil || secret == "" {
		http.Error(w, "run setup first", http.StatusBadRequest)
		return
	}
	if !totp.Validate(secret, code, time.Now()) {
		http.Error(w, "invalid code", http.StatusUnauthorized)
		return
	}
	codes, err := h.issueRecoveryCodes(r.Context(), s.userID)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	if _, err := h.pool.Exec(r.Context(),
		`UPDATE users SET mfa_enabled = true WHERE id = $1`, s.userID); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	_, _ = h.pool.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip) VALUES ($1,$2,'account.mfa_enable','', $3)`,
		s.tenantID, s.userID, remoteIP(r))
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true, "recoveryCodes": codes})
}

// MFADisable handles POST /api/v1/account/mfa/disable {code}. Requires a valid
// TOTP or recovery code; clears the secret and all recovery codes.
func (h *Handler) MFADisable(w http.ResponseWriter, r *http.Request) {
	s, ok := h.sessionOrFail(w, r)
	if !ok {
		return
	}
	uid, _ := strconv.ParseInt(s.userID, 10, 64)
	if !h.verifyMFACode(r.Context(), uid, decodeCodeField(r)) {
		http.Error(w, "invalid code", http.StatusUnauthorized)
		return
	}
	if _, err := h.pool.Exec(r.Context(),
		`UPDATE users SET mfa_enabled = false, mfa_secret = '' WHERE id = $1`, s.userID); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	_, _ = h.pool.Exec(r.Context(), `DELETE FROM mfa_recovery WHERE user_id = $1`, s.userID)
	_, _ = h.pool.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip) VALUES ($1,$2,'account.mfa_disable','', $3)`,
		s.tenantID, s.userID, remoteIP(r))
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

// ---------- password reset ----------

// PasswordResetRequest handles POST /api/v1/auth/password/reset-request {email}.
// Always returns 200 (no account enumeration). When the account exists it mints
// a single-use token (hashed at rest) and emails the reset link.
func (h *Handler) PasswordResetRequest(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	ip := remoteIP(r)
	if !h.limitAllow("reset:"+ip, 5, time.Hour) {
		w.Header().Set("Retry-After", "3600")
		http.Error(w, "too many reset requests; try again later", http.StatusTooManyRequests)
		return
	}
	var req struct {
		Email string `json:"email"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	req.Email = strings.ToLower(strings.TrimSpace(req.Email))
	if req.Email == "" {
		http.Error(w, "email required", http.StatusBadRequest)
		return
	}
	h.limitRecord("reset:" + ip)

	var (
		userID   int64
		tenantID string
	)
	err := h.pool.QueryRow(r.Context(),
		`SELECT u.id, u.tenant_id FROM users u WHERE lower(u.email) = $1`, req.Email).
		Scan(&userID, &tenantID)
	if err == nil {
		raw := make([]byte, 32)
		if _, rerr := rand.Read(raw); rerr == nil {
			token := hex.EncodeToString(raw)
			now := time.Now().Unix()
			if _, ierr := h.pool.Exec(r.Context(),
				`INSERT INTO password_resets (token_hash, user_id, created_at, expires_at)
				 VALUES ($1,$2,$3,$4)`, hashToken(token), userID, now, now+int64(resetTTL.Seconds())); ierr == nil {
				h.sendResetEmail(r.Context(), req.Email, tenantID, userID, token)
			}
		}
	}
	// Uniform response regardless of whether the account existed.
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

// PasswordReset handles POST /api/v1/auth/password/reset {token,newPassword}.
// Validates the single-use token, updates the hash, and revokes all sessions.
func (h *Handler) PasswordReset(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Token       string `json:"token"`
		NewPassword string `json:"newPassword"`
	}
	if err := json.NewDecoder(http.MaxBytesReader(w, r.Body, 8<<10)).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	if len(req.NewPassword) < minPasswordLen {
		http.Error(w, "password must be at least 12 characters", http.StatusBadRequest)
		return
	}
	if strings.TrimSpace(req.Token) == "" {
		http.Error(w, "token required", http.StatusBadRequest)
		return
	}
	var (
		userID  int64
		expires int64
		usedAt  int64
	)
	err := h.pool.QueryRow(r.Context(),
		`SELECT user_id, expires_at, used_at FROM password_resets WHERE token_hash = $1`, hashToken(req.Token)).
		Scan(&userID, &expires, &usedAt)
	if err != nil || usedAt != 0 || time.Now().Unix() > expires {
		http.Error(w, "invalid or expired token", http.StatusUnauthorized)
		return
	}
	hash, err := bcrypt.GenerateFromPassword([]byte(req.NewPassword), bcrypt.DefaultCost)
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	tx, err := h.pool.Begin(r.Context())
	if err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	defer tx.Rollback(r.Context())
	if _, err := tx.Exec(r.Context(),
		`UPDATE users SET password_hash = $2, session_version = session_version + 1 WHERE id = $1`,
		userID, string(hash)); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	if _, err := tx.Exec(r.Context(),
		`UPDATE password_resets SET used_at = $2 WHERE token_hash = $1`,
		hashToken(req.Token), time.Now().Unix()); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	// Invalidate every other outstanding reset for this user (belt & suspenders).
	_, _ = tx.Exec(r.Context(),
		`UPDATE password_resets SET used_at = $2 WHERE user_id = $1 AND used_at = 0`,
		userID, time.Now().Unix())
	if err := tx.Commit(r.Context()); err != nil {
		http.Error(w, "internal error", http.StatusInternalServerError)
		return
	}
	var tenantID string
	_ = h.pool.QueryRow(r.Context(), `SELECT tenant_id FROM users WHERE id = $1`, userID).Scan(&tenantID)
	_, _ = h.pool.Exec(r.Context(),
		`INSERT INTO audit_log (tenant_id, actor, action, detail, ip) VALUES ($1,$2,'account.password_reset','', $3)`,
		tenantID, userID, remoteIP(r))
	w.Header().Set("Content-Type", "application/json")
	_ = json.NewEncoder(w).Encode(map[string]any{"ok": true})
}

// ---------- helpers ----------

func decodeCodeField(r *http.Request) string {
	var body struct {
		Code string `json:"code"`
	}
	_ = json.NewDecoder(io.LimitReader(r.Body, 4<<10)).Decode(&body)
	return body.Code
}

// sessionOrFail resolves the session cookie or writes 401 and returns false.
func (h *Handler) sessionOrFail(w http.ResponseWriter, r *http.Request) (session, bool) {
	s, err := h.currentSession(r)
	if err != nil {
		http.Error(w, "unauthorized", http.StatusUnauthorized)
		return session{}, false
	}
	return s, true
}

// verifyMFACode accepts a live TOTP code OR a one-time recovery code (which is
// consumed on success).
func (h *Handler) verifyMFACode(ctx context.Context, userID int64, code string) bool {
	code = strings.TrimSpace(code)
	if code == "" {
		return false
	}
	var (
		secret  string
		enabled bool
	)
	if err := h.pool.QueryRow(ctx,
		`SELECT mfa_secret, mfa_enabled FROM users WHERE id = $1`, userID).Scan(&secret, &enabled); err != nil || !enabled {
		return false
	}
	if totp.Validate(secret, code, time.Now()) {
		return true
	}
	res, err := h.pool.Exec(ctx,
		`UPDATE mfa_recovery SET used_at = $2 WHERE code_hash = $1 AND user_id = $3 AND used_at = 0`,
		hashToken(normalizeRecovery(code)), time.Now().Unix(), userID)
	return err == nil && res.RowsAffected() == 1
}

// issueRecoveryCodes replaces the user's recovery codes and returns the
// plaintext set exactly once.
func (h *Handler) issueRecoveryCodes(ctx context.Context, userID string) ([]string, error) {
	if _, err := h.pool.Exec(ctx, `DELETE FROM mfa_recovery WHERE user_id = $1`, userID); err != nil {
		return nil, err
	}
	codes := make([]string, 0, recoveryCount)
	for i := 0; i < recoveryCount; i++ {
		c, err := recoveryCode()
		if err != nil {
			return nil, err
		}
		if _, err := h.pool.Exec(ctx,
			`INSERT INTO mfa_recovery (code_hash, user_id) VALUES ($1,$2)`,
			hashToken(normalizeRecovery(c)), userID); err != nil {
			return nil, err
		}
		codes = append(codes, c)
	}
	return codes, nil
}

// recoveryCode returns a "XXXXX-XXXXX" code from an unambiguous alphabet.
func recoveryCode() (string, error) {
	const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
	b := make([]byte, 10)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	var sb strings.Builder
	for i, v := range b {
		if i == 5 {
			sb.WriteByte('-')
		}
		sb.WriteByte(alphabet[int(v)%len(alphabet)])
	}
	return sb.String(), nil
}

func normalizeRecovery(code string) string {
	return strings.ToUpper(strings.ReplaceAll(strings.TrimSpace(code), "-", ""))
}

func hashToken(t string) string {
	sum := sha256.Sum256([]byte(t))
	return hex.EncodeToString(sum[:])
}

func (h *Handler) signMFAPending(tenantID, userID string) (string, error) {
	nonce := make([]byte, 8)
	if _, err := rand.Read(nonce); err != nil {
		return "", err
	}
	payload := strings.Join([]string{"mfa", tenantID, userID,
		strconv.FormatInt(time.Now().Add(mfaPendingTTL).Unix(), 10),
		hex.EncodeToString(nonce)}, ".")
	mac := hmac.New(sha256.New, h.secret)
	mac.Write([]byte(payload))
	return payload + "." + hex.EncodeToString(mac.Sum(nil)), nil
}

func (h *Handler) verifyMFAPending(tok string) (tenantID, userID string, err error) {
	parts := strings.Split(tok, ".")
	if len(parts) != 6 || parts[0] != "mfa" {
		return "", "", ErrNoSession
	}
	mac := hmac.New(sha256.New, h.secret)
	mac.Write([]byte(strings.Join(parts[:5], ".")))
	sig, derr := hex.DecodeString(parts[5])
	if derr != nil || !hmac.Equal(mac.Sum(nil), sig) {
		return "", "", ErrNoSession
	}
	exp, perr := strconv.ParseInt(parts[3], 10, 64)
	if perr != nil || time.Now().Unix() > exp {
		return "", "", ErrNoSession
	}
	return parts[1], parts[2], nil
}

func (h *Handler) sendResetEmail(ctx context.Context, email, tenantID string, userID int64, token string) {
	if h.mailer == nil || !h.mailer.Configured() {
		return
	}
	base := h.publicURL
	if base == "" {
		base = "http://localhost:3000"
	}
	link := base + "/reset?token=" + token
	body := "Halo,\n\n" +
		"Kami menerima permintaan reset password untuk akun GarudaShield Anda (" + email + ", tenant " + tenantID + ").\n\n" +
		"Buka tautan berikut (berlaku 60 menit, sekali pakai):\n" + link + "\n\n" +
		"Jika Anda tidak meminta ini, abaikan email ini — password Anda tidak berubah.\n\n" +
		"— GarudaShield"
	if err := h.mailer.Send(email, "Reset password GarudaShield", body); err != nil {
		// Delivery failure must not reveal anything; record for operators.
		_, _ = h.pool.Exec(ctx,
			`INSERT INTO audit_log (tenant_id, actor, action, detail, ip) VALUES ($1,$2,'account.reset_email_failed',$3,'')`,
			tenantID, userID, err.Error())
	}
}
