package auth

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"net/http/httptest"
	"os"
	"strings"
	"testing"

	"github.com/ahkurdev/garudashield/internal/db"
	"golang.org/x/crypto/bcrypt"
)

// TestLoginIssuesTenantScopedSession exercises the real PG-backed login path:
// a user with a bcrypt hash logs in, receives a signed session cookie scoped to
// their tenant, and TenantFromRequest resolves that tenant from the cookie.
func TestLoginIssuesTenantScopedSession(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	if err := db.Migrate(context.Background(), pool); err != nil {
		t.Fatal(err)
	}
	ctx := context.Background()
	_, _ = pool.Exec(ctx, `DELETE FROM users WHERE email=$1`, "owner@acme.id")
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id='acme'`)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan,domain) VALUES ('acme','Acme','pro','acme.id') ON CONFLICT (id) DO NOTHING`)
	hash, _ := bcrypt.GenerateFromPassword([]byte("s3cret-pass"), bcrypt.DefaultCost)
	_, _ = pool.Exec(ctx, `INSERT INTO users (tenant_id,email,password_hash,role) VALUES ('acme','owner@acme.id',$1,'owner')`, string(hash))
	defer func() {
		_, _ = pool.Exec(ctx, `DELETE FROM users WHERE email='owner@acme.id'; DELETE FROM tenants WHERE id='acme'`)
	}()

	h := New(pool, "test-session-secret")
	srv := httptest.NewServer(http.HandlerFunc(h.Login))
	defer srv.Close()

	resp, err := http.Post(srv.URL+"/api/auth/login", "application/json",
		strings.NewReader(`{"email":"owner@acme.id","password":"s3cret-pass"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		t.Fatalf("login status %d", resp.StatusCode)
	}
	cookies := resp.Cookies()
	if len(cookies) == 0 {
		t.Fatal("no session cookie set")
	}
	ck := cookies[0]
	if ck.Name != SessionCookieName || ck.HttpOnly == false {
		t.Fatalf("bad cookie: %+v", ck)
	}

	// Resolve tenant from the cookie via a request carrying it.
	req := httptest.NewRequest("GET", "/", nil)
	req.AddCookie(ck)
	tid, err := h.TenantFromRequest(req)
	if err != nil {
		t.Fatalf("tenant from request: %v", err)
	}
	if tid != "acme" {
		t.Fatalf("expected tenant acme, got %q", tid)
	}

	// Wrong password must not issue a session.
	resp2, err := http.Post(srv.URL+"/api/auth/login", "application/json",
		strings.NewReader(`{"email":"owner@acme.id","password":"wrong"}`))
	if err != nil {
		t.Fatal(err)
	}
	defer resp2.Body.Close()
	if resp2.StatusCode != http.StatusUnauthorized {
		t.Fatalf("bad password should be 401, got %d", resp2.StatusCode)
	}
}

// Session v2 (no PG needed): roundtrip, tamper, expiry, old-format reject.
func TestSessionV2Roundtrip(t *testing.T) {
	h := New(nil, "test-session-secret-32bytes-minimum!!")
	tok, err := h.signSession("acme", "42")
	if err != nil {
		t.Fatal(err)
	}
	s, err := h.verifySession(tok)
	if err != nil {
		t.Fatalf("valid token rejected: %v", err)
	}
	if s.tenantID != "acme" || s.userID != "42" {
		t.Fatalf("claims = %+v", s)
	}
	if _, err := h.verifySession(tok + "x"); err == nil {
		t.Fatal("tampered token accepted")
	}
	if _, err := h.verifySession("acme.deadbeef"); err == nil {
		t.Fatal("old 2-part token must be rejected")
	}
	other := New(nil, "different-secret-32bytes-minimum!!!!")
	if _, err := other.verifySession(tok); err == nil {
		t.Fatal("cross-secret token accepted")
	}
}

func TestSessionV2Expiry(t *testing.T) {
	secret := "test-session-secret-32bytes-minimum!!"
	h := New(nil, secret)
	// Craft an expired token with a valid MAC.
	payload := "acme.42.1.0.abcdef0123456789"
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(payload))
	tok := payload + "." + hex.EncodeToString(mac.Sum(nil))
	if _, err := h.verifySession(tok); err == nil {
		t.Fatal("expired token accepted")
	}
}

// Login lockout helpers (no PG needed).
func TestLoginLockout(t *testing.T) {
	h := New(nil, "test-session-secret-32bytes-minimum!!")
	for i := 0; i < 4; i++ {
		h.loginFail("e:victim@example.id")
	}
	if h.loginLocked("e:victim@example.id") {
		t.Fatal("locked before 5 fails")
	}
	h.loginFail("e:victim@example.id")
	if !h.loginLocked("e:victim@example.id") {
		t.Fatal("not locked after 5 fails")
	}
	h.loginReset("e:victim@example.id")
	if h.loginLocked("e:victim@example.id") {
		t.Fatal("still locked after reset")
	}
	ip := New(nil, "test-session-secret-32bytes-minimum!!")
	for i := 0; i < 19; i++ {
		ip.loginFail("i:203.0.113.9")
	}
	if ip.loginLocked("i:203.0.113.9") {
		t.Fatal("IP locked before 20 fails")
	}
	ip.loginFail("i:203.0.113.9")
	if !ip.loginLocked("i:203.0.113.9") {
		t.Fatal("IP not locked after 20 fails")
	}
}

func TestFallbackSecretStrong(t *testing.T) {
	a, b := randomFallbackSecret(), randomFallbackSecret()
	if len(a) != 64 || a == b {
		t.Fatalf("weak fallback secret: %q vs %q", a, b)
	}
}
