// Package apikey implements tenant-scoped programmatic API keys for the
// GarudaShield commercial control plane (managed SaaS + self-host portal).
//
// Security model (OWASP API2:2023 Broken Authentication, A02/A04/A07/A09):
//   - The raw key is revealed exactly ONCE, at creation. Only a SHA-256 hash of
//     the secret half is persisted, so a database leak cannot reconstruct keys.
//   - Keys carry explicit scopes (read/write/admin); a key may only do what its
//     scopes allow, enforced server-side by RequireScope.
//   - Keys support an absolute expiry and immediate revocation. Verification is
//     fail-closed and uses constant-time comparison.
//   - Every query is tenant-scoped: a key belonging to tenant A can never be
//     listed, used, or revoked by tenant B (no cross-tenant object reference).
package apikey

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/base64"
	"encoding/hex"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgxpool"
)

const (
	// KeyPrefix is the literal prefix of every GarudaShield API key. It makes
	// keys greppable in logs/secret scanners and distinguishable at a glance.
	KeyPrefix = "gsk"
	// secretBytes is the entropy of the secret half (256 bits).
	secretBytes = 32
	// prefixBytes is the entropy of the lookup prefix (48 bits). It is indexed
	// so verification is a single fast lookup, never a table scan.
	prefixBytes = 6

	// DefaultTTL is applied when a caller does not specify an expiry (0).
	DefaultTTL = 90 * 24 * time.Hour
)

// Scope is a coarse permission granted to a key. Enforcement is fail-closed:
// an unknown scope cannot be stored, and a missing scope denies the action.
type Scope string

const (
	ScopeRead  Scope = "read"  // read-only access to the tenant's own data
	ScopeWrite Scope = "write" // mutate the tenant's own protection config
	ScopeAdmin Scope = "admin" // manage the tenant's keys/account (privileged)
)

var allowedScopes = map[Scope]bool{ScopeRead: true, ScopeWrite: true, ScopeAdmin: true}

// Errors returned by the store. Callers map these to HTTP status codes; none of
// them ever reveals whether a key existed (no user/oracle enumeration).
var (
	ErrInvalidKey  = errors.New("invalid api key")
	ErrExpired     = errors.New("api key expired")
	ErrRevoked     = errors.New("api key revoked")
	ErrScopeDenied = errors.New("api key lacks required scope")
	ErrNotFound    = errors.New("api key not found")
)

// Key is the public (secret-free) representation of an API key. It never
// contains the raw secret or its hash, so it is safe to return to a client.
type Key struct {
	ID         int64   `json:"id"`
	TenantID   string  `json:"tenant"`
	Name       string  `json:"name"`
	Prefix     string  `json:"prefix"`
	Scopes     []Scope `json:"scopes"`
	CreatedAt  int64   `json:"createdAt"`
	LastUsedAt int64   `json:"lastUsedAt"`
	ExpiresAt  int64   `json:"expiresAt"`
	RevokedAt  int64   `json:"revokedAt"`
}

// Active reports whether the key is usable at now (not revoked, not expired).
func (k Key) Active(now time.Time) bool {
	if k.RevokedAt != 0 {
		return false
	}
	if k.ExpiresAt != 0 && now.Unix() > k.ExpiresAt {
		return false
	}
	return true
}

// HasScope reports whether the key carries the given scope.
func (k Key) HasScope(s Scope) bool {
	for _, x := range k.Scopes {
		if x == s {
			return true
		}
	}
	return false
}

// Masked returns a displayable identifier that reveals nothing usable, e.g.
// "gsk_1f3a9c_********". Safe to log.
func (k Key) Masked() string {
	return KeyPrefix + "_" + k.Prefix + "_" + strings.Repeat("*", 8)
}

// RequireScope fails closed when the key does not carry the required scope.
func RequireScope(k *Key, s Scope) error {
	if k == nil || !k.HasScope(s) {
		return ErrScopeDenied
	}
	return nil
}

// Store persists API keys in PostgreSQL. All reads/writes are tenant-scoped.
type Store struct {
	pool *pgxpool.Pool
}

// New builds a key store over the given pool.
func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// Create mints a new API key for tenantID and returns the raw key exactly once,
// together with its public metadata. ttl <= 0 applies DefaultTTL.
func (s *Store) Create(ctx context.Context, tenantID, name string, scopes []string, ttl time.Duration) (string, Key, error) {
	tenantID = strings.TrimSpace(tenantID)
	name = strings.TrimSpace(name)
	if tenantID == "" {
		return "", Key{}, errors.New("tenant required")
	}
	if name == "" {
		return "", Key{}, errors.New("name required")
	}
	sc, err := normalizeScopes(scopes)
	if err != nil {
		return "", Key{}, err
	}

	pb := make([]byte, prefixBytes)
	if _, err := rand.Read(pb); err != nil {
		return "", Key{}, err
	}
	prefix := hex.EncodeToString(pb)

	sb := make([]byte, secretBytes)
	if _, err := rand.Read(sb); err != nil {
		return "", Key{}, err
	}
	secret := base64.RawURLEncoding.EncodeToString(sb)

	now := time.Now()
	if ttl <= 0 {
		ttl = DefaultTTL
	}
	exp := now.Add(ttl).Unix()

	var (
		k         Key
		rawScopes string
	)
	err = s.pool.QueryRow(ctx,
		`INSERT INTO api_keys (tenant_id, name, prefix, key_hash, scopes, created_at, expires_at)
		 VALUES ($1,$2,$3,$4,$5,$6,$7)
		 RETURNING id, tenant_id, name, prefix, scopes, created_at, last_used_at, expires_at, revoked_at`,
		tenantID, name, prefix, hashSecret(secret), scopeString(sc), now.Unix(), exp).
		Scan(&k.ID, &k.TenantID, &k.Name, &k.Prefix, &rawScopes,
			&k.CreatedAt, &k.LastUsedAt, &k.ExpiresAt, &k.RevokedAt)
	if err != nil {
		return "", Key{}, fmt.Errorf("create api key: %w", err)
	}
	k.Scopes = parseScopes(rawScopes)
	return KeyPrefix + "_" + prefix + "_" + secret, k, nil
}

// List returns the tenant's keys (active and revoked), newest first. The raw
// secret is never available here.
func (s *Store) List(ctx context.Context, tenantID string) ([]Key, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, tenant_id, name, prefix, scopes, created_at, last_used_at, expires_at, revoked_at
		 FROM api_keys WHERE tenant_id = $1 ORDER BY created_at DESC, id DESC`, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []Key{}
	for rows.Next() {
		var (
			k         Key
			rawScopes string
		)
		if err := rows.Scan(&k.ID, &k.TenantID, &k.Name, &k.Prefix, &rawScopes,
			&k.CreatedAt, &k.LastUsedAt, &k.ExpiresAt, &k.RevokedAt); err != nil {
			return nil, err
		}
		k.Scopes = parseScopes(rawScopes)
		out = append(out, k)
	}
	return out, rows.Err()
}

// Revoke marks the tenant's key with id revoked. A key from another tenant is
// invisible (ErrNotFound), so this cannot be used for cross-tenant tampering.
func (s *Store) Revoke(ctx context.Context, tenantID string, id int64) error {
	ct, err := s.pool.Exec(ctx,
		`UPDATE api_keys SET revoked_at = $3 WHERE id = $1 AND tenant_id = $2 AND revoked_at = 0`,
		id, tenantID, time.Now().Unix())
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// Verify authenticates a raw key, enforcing revocation and expiry. On success
// it best-effort updates last_used_at and returns the key's metadata.
func (s *Store) Verify(ctx context.Context, raw string) (*Key, error) {
	prefix, secret, ok := split(raw)
	if !ok {
		return nil, ErrInvalidKey
	}
	var (
		k         Key
		rawScopes string
		stored    string
	)
	err := s.pool.QueryRow(ctx,
		`SELECT id, tenant_id, name, prefix, key_hash, scopes, created_at, last_used_at, expires_at, revoked_at
		 FROM api_keys WHERE prefix = $1`, prefix).
		Scan(&k.ID, &k.TenantID, &k.Name, &k.Prefix, &stored, &rawScopes,
			&k.CreatedAt, &k.LastUsedAt, &k.ExpiresAt, &k.RevokedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return nil, ErrInvalidKey
		}
		return nil, err
	}
	if subtle.ConstantTimeCompare([]byte(hashSecret(secret)), []byte(stored)) != 1 {
		return nil, ErrInvalidKey
	}
	k.Scopes = parseScopes(rawScopes)
	now := time.Now()
	if k.RevokedAt != 0 {
		return nil, ErrRevoked
	}
	if k.ExpiresAt != 0 && now.Unix() > k.ExpiresAt {
		return nil, ErrExpired
	}
	_, _ = s.pool.Exec(ctx, `UPDATE api_keys SET last_used_at = $2 WHERE id = $1`, k.ID, now.Unix())
	k.LastUsedAt = now.Unix()
	return &k, nil
}

// ---------- pure helpers (unit-tested without a database) ----------

func hashSecret(secret string) string {
	sum := sha256.Sum256([]byte(secret))
	return hex.EncodeToString(sum[:])
}

// split parses "gsk_<prefix>_<secret>". The prefix is fixed-width hex, so the
// parse is positional — the secret half may itself contain "_" (base64url),
// which a naive strings.Split would misparse.
func split(raw string) (prefix, secret string, ok bool) {
	const lead = KeyPrefix + "_"
	if !strings.HasPrefix(raw, lead) {
		return "", "", false
	}
	rest := raw[len(lead):]
	if len(rest) <= 2*prefixBytes || rest[2*prefixBytes] != '_' {
		return "", "", false
	}
	prefix = rest[:2*prefixBytes]
	secret = rest[2*prefixBytes+1:]
	if _, err := hex.DecodeString(prefix); err != nil || len(prefix) != 2*prefixBytes {
		return "", "", false
	}
	decoded, err := base64.RawURLEncoding.DecodeString(secret)
	if err != nil || len(decoded) != secretBytes {
		return "", "", false
	}
	return prefix, secret, true
}

func normalizeScopes(in []string) ([]Scope, error) {
	if len(in) == 0 {
		return []Scope{ScopeRead}, nil
	}
	seen := map[Scope]bool{}
	out := make([]Scope, 0, len(in))
	for _, raw := range in {
		s := Scope(strings.ToLower(strings.TrimSpace(raw)))
		if !allowedScopes[s] {
			return nil, fmt.Errorf("unknown scope %q", raw)
		}
		if !seen[s] {
			seen[s] = true
			out = append(out, s)
		}
	}
	return out, nil
}

func scopeString(scopes []Scope) string {
	parts := make([]string, len(scopes))
	for i, s := range scopes {
		parts[i] = string(s)
	}
	return strings.Join(parts, ",")
}

func parseScopes(s string) []Scope {
	if strings.TrimSpace(s) == "" {
		return nil
	}
	seen := map[Scope]bool{}
	parts := strings.Split(s, ",")
	out := make([]Scope, 0, len(parts))
	for _, p := range parts {
		if p = strings.TrimSpace(p); p != "" {
			sc := Scope(p)
			if !seen[sc] {
				seen[sc] = true
				out = append(out, sc)
			}
		}
	}
	return out
}
