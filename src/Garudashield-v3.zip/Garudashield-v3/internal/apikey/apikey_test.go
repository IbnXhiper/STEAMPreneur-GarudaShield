package apikey

import (
	"context"
	"encoding/base64"
	"os"
	"strings"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/db"
)

// ---------- pure unit tests (no database required) ----------

func TestKeyFormat(t *testing.T) {
	// Build a realistic key: prefix is 12 hex chars, secret is base64url of 32
	// bytes and may itself contain "_" (which a naive split would misparse).
	sb := make([]byte, secretBytes)
	for i := range sb {
		sb[i] = 2 // 0x02 keeps base64url clean, deterministic
	}
	secret := base64.RawURLEncoding.EncodeToString(sb)
	raw := KeyPrefix + "_" + "aabbccddeeff" + "_" + secret

	prefix, gotSecret, ok := split(raw)
	if !ok || prefix != "aabbccddeeff" || gotSecret != secret {
		t.Fatalf("split = %q %q %v", prefix, gotSecret, ok)
	}
	if _, _, ok := split("nope_aabbccddeeff_" + secret); ok {
		t.Fatal("accepted key without gsk prefix")
	}
	if _, _, ok := split("gsk_" + secret); ok {
		t.Fatal("accepted truncated key")
	}
	if _, _, ok := split("gsk_" + "aabbccddeeff" + "_short"); ok {
		t.Fatal("accepted key with a too-short secret")
	}
	if _, _, ok := split("gsk_" + "zzzzzzzzzzzz" + "_" + secret); ok {
		t.Fatal("accepted non-hex prefix")
	}
	if _, _, ok := split("gsk_" + "aabbccddeeff" + "_" + secret); !ok {
		t.Fatal("rejected valid key")
	}
	// Secret containing "_" must still parse (base64url alphabet).
	secretWithUnderscore := "BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB" // 43 chars, valid base64url
	raw2 := KeyPrefix + "_" + "112233445566" + "_" + secretWithUnderscore
	if _, s, ok := split(raw2); !ok || s != secretWithUnderscore {
		t.Fatalf("underscore secret split = %q %v", s, ok)
	}
}

func TestHashSecretIsOneWayAndDeterministic(t *testing.T) {
	h1 := hashSecret("super-secret")
	h2 := hashSecret("super-secret")
	h3 := hashSecret("other")
	if h1 != h2 {
		t.Fatal("hash must be deterministic")
	}
	if h1 == h3 {
		t.Fatal("different secrets must not collide")
	}
	if strings.Contains(h1, "super-secret") {
		t.Fatal("hash must not embed the raw secret")
	}
}

func TestNormalizeScopes(t *testing.T) {
	got, err := normalizeScopes(nil)
	if err != nil || len(got) != 1 || got[0] != ScopeRead {
		t.Fatalf("default scopes = %v, %v", got, err)
	}
	got, err = normalizeScopes([]string{"ADMIN", "read", "ADMIN"})
	if err != nil {
		t.Fatal(err)
	}
	if len(got) != 2 {
		t.Fatalf("duplicate scopes not deduped: %v", got)
	}
	if _, err := normalizeScopes([]string{"read", "deleteeverything"}); err == nil {
		t.Fatal("unknown scope accepted")
	}
}

func TestParseScopeString(t *testing.T) {
	if s := scopeString([]Scope{ScopeRead, ScopeWrite}); s != "read,write" {
		t.Fatalf("scopeString = %q", s)
	}
	sc := parseScopes(" read, write ,read ")
	if len(sc) != 2 {
		t.Fatalf("parseScopes = %v", sc)
	}
	if sc[0] != ScopeRead || sc[1] != ScopeWrite {
		t.Fatalf("parseScopes order = %v", sc)
	}
}

func TestKeyActiveAndScopes(t *testing.T) {
	now := time.Now()
	k := Key{ExpiresAt: now.Add(time.Hour).Unix(), Scopes: []Scope{ScopeRead}}
	if !k.Active(now) {
		t.Fatal("fresh key must be active")
	}
	k.RevokedAt = now.Unix()
	if k.Active(now) {
		t.Fatal("revoked key must not be active")
	}
	k.RevokedAt = 0
	k.ExpiresAt = now.Add(-time.Minute).Unix()
	if k.Active(now) {
		t.Fatal("expired key must not be active")
	}
	if !k.HasScope(ScopeRead) || k.HasScope(ScopeWrite) {
		t.Fatal("scope check wrong")
	}
	if RequireScope(&k, ScopeWrite) != ErrScopeDenied {
		t.Fatal("scope enforcement must deny")
	}
	k.Scopes = []Scope{ScopeRead, ScopeWrite}
	if RequireScope(&k, ScopeWrite) != nil {
		t.Fatal("scope enforcement must allow granted scope")
	}
}

func TestMaskedNeverLeaksSecret(t *testing.T) {
	secret := base64.RawURLEncoding.EncodeToString(make([]byte, secretBytes))
	raw := KeyPrefix + "_aabbccddeeff_" + secret
	k := Key{Prefix: "aabbccddeeff"}
	m := k.Masked()
	if !strings.HasPrefix(m, KeyPrefix+"_aabbccddeeff_") || !strings.Contains(m, "*") {
		t.Fatalf("masked = %q", m)
	}
	if m == raw || strings.Contains(m, secret) {
		t.Fatalf("masked leaked the secret: %q", m)
	}
}

// ---------- PostgreSQL integration (skipped without GS_DATABASE_URL) ----------

// TestAPIKeyLifecyclePG exercises create → list → verify → expiry → revoke
// against real Postgres, mirroring the tenant/auth integration tests.
func TestAPIKeyLifecyclePG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set; skipping PG integration test")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	ctx := context.Background()
	if err := db.Migrate(ctx, pool); err != nil {
		t.Fatalf("migrate: %v", err)
	}

	tenantID := "test-apikey-pg"
	_, _ = pool.Exec(ctx, `DELETE FROM api_keys WHERE tenant_id=$1`, tenantID)
	_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, tenantID)
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan,domain) VALUES ($1,'ApiKey Test','free','apikey.example.test') ON CONFLICT (id) DO NOTHING`, tenantID)
	defer func() {
		_, _ = pool.Exec(ctx, `DELETE FROM api_keys WHERE tenant_id=$1`, tenantID)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, tenantID)
	}()

	s := New(pool)

	// Create: raw key returned exactly once.
	raw, k, err := s.Create(ctx, tenantID, "ci-agent", []string{"read", "write"}, time.Hour)
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if !strings.HasPrefix(raw, KeyPrefix+"_") {
		t.Fatalf("raw key format: %q", raw)
	}
	if k.ID == 0 || k.TenantID != tenantID || len(k.Scopes) != 2 {
		t.Fatalf("created key meta: %+v", k)
	}
	if k.Masked() == raw {
		t.Fatal("masked must not equal raw")
	}

	// List contains it (masked metadata only).
	keys, err := s.List(ctx, tenantID)
	if err != nil || len(keys) == 0 || keys[0].ID != k.ID {
		t.Fatalf("list: %v keys=%+v", err, keys)
	}

	// Verify authenticates.
	got, err := s.Verify(ctx, raw)
	if err != nil {
		t.Fatalf("verify: %v", err)
	}
	if got.ID != k.ID || got.Name != "ci-agent" {
		t.Fatalf("verified key mismatch: %+v", got)
	}
	if got.LastUsedAt == 0 {
		t.Fatal("last_used_at not updated")
	}

	// Wrong secret for the same prefix fails closed.
	if _, err := s.Verify(ctx, raw[:len(raw)-1]+"x"); err == nil {
		t.Fatal("tampered key accepted")
	}

	// Cross-tenant isolation: tenant B cannot see/revoke tenant A's key.
	otherTenant := "test-apikey-other"
	_, _ = pool.Exec(ctx, `INSERT INTO tenants (id,name,plan,domain) VALUES ($1,'Other','free','other.example.test') ON CONFLICT (id) DO NOTHING`, otherTenant)
	defer pool.Exec(ctx, `DELETE FROM tenants WHERE id=$1`, otherTenant)
	otherKeys, _ := s.List(ctx, otherTenant)
	if len(otherKeys) != 0 {
		t.Fatal("cross-tenant list leaked rows")
	}
	if err := s.Revoke(ctx, otherTenant, k.ID); err != ErrNotFound {
		t.Fatalf("cross-tenant revoke returned %v, want ErrNotFound", err)
	}

	// Revocation takes effect.
	if err := s.Revoke(ctx, tenantID, k.ID); err != nil {
		t.Fatalf("revoke: %v", err)
	}
	if _, err := s.Verify(ctx, raw); err != ErrRevoked {
		t.Fatalf("verify after revoke = %v, want ErrRevoked", err)
	}

	// Expiry takes effect (short TTL inserted directly).
	expiredRaw, expiredKey, err := s.Create(ctx, tenantID, "ephemeral", []string{"read"}, 0)
	if err != nil {
		t.Fatalf("create expired: %v", err)
	}
	if _, err := pool.Exec(ctx, `UPDATE api_keys SET expires_at = $2 WHERE id = $1`, expiredKey.ID, time.Now().Add(-time.Minute).Unix()); err != nil {
		t.Fatal(err)
	}
	if _, err := s.Verify(ctx, expiredRaw); err != ErrExpired {
		t.Fatalf("verify expired = %v, want ErrExpired", err)
	}
}
