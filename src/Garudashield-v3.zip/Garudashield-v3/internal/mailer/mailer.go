// Package mailer sends transactional email (currently the password-reset link)
// over the same SMTP relay the alert manager uses. It is nil-safe: when SMTP is
// not configured, Configured() is false and Send is a no-op returning a
// sentinel error, so callers can degrade gracefully instead of failing the
// request. This mirrors the alert manager's "email disabled" behaviour.
package mailer

import (
	"errors"
	"fmt"
	"net/smtp"
	"strings"

	"github.com/ahkurdev/garudashield/internal/config"
)

// ErrNotConfigured is returned by Send when no SMTP relay is set.
var ErrNotConfigured = errors.New("mailer: smtp not configured")

// SMTP is a minimal plaintext/TLS SMTP sender.
type SMTP struct {
	host string
	port int
	user string
	pass string
	from string
}

// New builds an SMTP sender from the alert config block (shared credentials).
func New(cfg config.Alerts) *SMTP {
	return &SMTP{host: cfg.SMTPHost, port: cfg.SMTPPort, user: cfg.SMTPUser, pass: cfg.SMTPPass, from: cfg.SMTPFrom}
}

// Configured reports whether the relay has enough settings to attempt a send.
func (m *SMTP) Configured() bool {
	return m != nil && m.host != "" && m.from != ""
}

// Send delivers a plaintext message to a single recipient. It returns
// ErrNotConfigured when SMTP is off (callers treat that as "drop silently").
func (m *SMTP) Send(to, subject, body string) error {
	if !m.Configured() {
		return ErrNotConfigured
	}
	port := m.port
	if port == 0 {
		port = 587
	}
	addr := fmt.Sprintf("%s:%d", m.host, port)
	var auth smtp.Auth
	if m.user != "" {
		auth = smtp.PlainAuth("", m.user, m.pass, m.host)
	}
	var msg strings.Builder
	msg.WriteString("From: " + m.from + "\r\n")
	msg.WriteString("To: " + to + "\r\n")
	msg.WriteString("Subject: " + subject + "\r\n")
	msg.WriteString("MIME-Version: 1.0\r\n")
	msg.WriteString("Content-Type: text/plain; charset=UTF-8\r\n\r\n")
	msg.WriteString(body + "\r\n")
	return smtp.SendMail(addr, auth, m.from, []string{to}, []byte(msg.String()))
}
