package udpproxy

import (
	"context"
	"net"
	"testing"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/defense/layer4"
)

// echoUpstream returns addr of a UDP echo server and a close func.
func echoUpstream(t *testing.T) (string, func()) {
	t.Helper()
	pc, err := net.ListenPacket("udp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	go func() {
		buf := make([]byte, 65507)
		for {
			n, addr, err := pc.ReadFrom(buf)
			if err != nil {
				return
			}
			_, _ = pc.WriteTo(buf[:n], addr)
		}
	}()
	return pc.LocalAddr().String(), func() { _ = pc.Close() }
}

func testGuard(t *testing.T, up, listen string, port int, rps int) (*Guard, context.CancelFunc) {
	t.Helper()
	l4 := layer4.New(config.Layer4Config{
		BogonFilter: false, SynFloodProtection: false,
		PortScanDetection: false, UDPAmplificationProtection: true,
	})
	g := New(Config{
		Enabled: true, Listen: listen, Upstream: up,
		ServicePort: port, MaxRPSPerIP: rps, TimeoutMs: 2000,
	}, l4)
	if g == nil {
		t.Fatal("guard must build")
	}
	ctx, cancel := context.WithCancel(context.Background())
	go func() { _ = g.Run(ctx) }()
	time.Sleep(200 * time.Millisecond)
	return g, cancel
}

func dial(t *testing.T, addr string) *net.UDPConn {
	t.Helper()
	raddr, err := net.ResolveUDPAddr("udp", addr)
	if err != nil {
		t.Fatal(err)
	}
	c, err := net.DialUDP("udp", nil, raddr)
	if err != nil {
		t.Fatal(err)
	}
	_ = c.SetDeadline(time.Now().Add(3 * time.Second))
	return c
}

// Clean datagrams are forwarded and echoed back.
func TestForward(t *testing.T) {
	up, stop := echoUpstream(t)
	defer stop()
	g, cancel := testGuard(t, up, "127.0.0.1:15360", 5353, 1000)
	defer cancel()
	c := dial(t, "127.0.0.1:15360")
	defer c.Close()
	if _, err := c.Write([]byte("hello-udp")); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 1024)
	n, err := c.Read(buf)
	if err != nil {
		t.Fatalf("no echo: %v", err)
	}
	if string(buf[:n]) != "hello-udp" {
		t.Fatalf("echo = %q", buf[:n])
	}
	if g.Stats()["forwarded"] == 0 {
		t.Fatal("forwarded counter stuck at 0")
	}
}

// Amplification-shaped datagrams (service port 53, >512B) are dropped.
func TestAmpDrop(t *testing.T) {
	up, stop := echoUpstream(t)
	defer stop()
	g, cancel := testGuard(t, up, "127.0.0.1:15361", 53, 10000)
	defer cancel()
	var abused []string
	g.OnAbuse = func(ip, reason string) { abused = append(abused, reason) }
	c := dial(t, "127.0.0.1:15361")
	defer c.Close()
	big := make([]byte, 600) // >512B to DNS port = amplification shape
	if _, err := c.Write(big); err != nil {
		t.Fatal(err)
	}
	buf := make([]byte, 2048)
	_ = c.SetReadDeadline(time.Now().Add(800 * time.Millisecond))
	if n, err := c.Read(buf); err == nil {
		t.Fatalf("amp datagram forwarded (%d bytes)", n)
	}
	if len(abused) == 0 {
		t.Fatal("OnAbuse not called for amp drop")
	}
}

// Per-IP rate limit trips on flood.
func TestRateLimit(t *testing.T) {
	up, stop := echoUpstream(t)
	defer stop()
	g, cancel := testGuard(t, up, "127.0.0.1:15362", 5353, 5)
	defer cancel()
	c := dial(t, "127.0.0.1:15362")
	defer c.Close()
	for i := 0; i < 20; i++ {
		_, _ = c.Write([]byte("x"))
	}
	time.Sleep(300 * time.Millisecond)
	if g.Stats()["rateDropped"] == 0 {
		t.Fatal("rate limiter never tripped")
	}
}

func TestDisabledNil(t *testing.T) {
	if New(Config{}, nil) != nil {
		t.Fatal("disabled guard must be nil")
	}
}
