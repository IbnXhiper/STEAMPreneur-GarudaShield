// Package udpproxy is a UDP guard reverse-proxy: it sits in front of a UDP
// service (DNS on 53, game servers, NTP) and forwards only datagrams that
// survive the layer4 InspectUDP heuristics (amplification ports + size).
// Dropped senders can be mirrored into the shield blocklist via OnAbuse so
// one abusive IP is cut off on TCP/HTTP too.
//
// This is userspace scrubbing for the traffic class XDP cannot see on this
// host (or where XDP is unavailable). Volumetric floods far above the
// host's link still belong upstream (see docs/ANTI_5TBPS.md).
package udpproxy

import (
	"context"
	"net"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/defense/layer4"
)

// Config mirrors the JSON udpGuard section.
type Config struct {
	Enabled     bool
	Listen      string // e.g. "0.0.0.0:5353"
	Upstream    string // e.g. "127.0.0.1:53"
	ServicePort int    // service port used for amp heuristics (53 = dns)
	MaxRPSPerIP int
	TimeoutMs   int64
	AbuseTTLMs  int64
}

type rpsEntry struct {
	count int
	sec   int64
}

// Guard is a running UDP proxy. Use New + Run(ctx).
type Guard struct {
	cfg Config
	l4  *layeredDefender

	mu  sync.Mutex
	rps map[string]*rpsEntry

	forwarded atomic.Uint64
	dropped   atomic.Uint64
	rateDrop  atomic.Uint64

	// OnAbuse, when set, receives abusive client IPs (shield.BlockIP hookup).
	OnAbuse func(ip, reason string)
}

type layeredDefender = layer4.Defender

// New validates the config; returns nil when disabled.
func New(cfg Config, l4 *layeredDefender) *Guard {
	if !cfg.Enabled || cfg.Listen == "" || cfg.Upstream == "" {
		return nil
	}
	if cfg.MaxRPSPerIP <= 0 {
		cfg.MaxRPSPerIP = 200
	}
	if cfg.TimeoutMs <= 0 {
		cfg.TimeoutMs = 2000
	}
	return &Guard{cfg: cfg, l4: l4, rps: make(map[string]*rpsEntry)}
}

// Stats reports counters.
func (g *Guard) Stats() map[string]uint64 {
	return map[string]uint64{
		"forwarded":   g.forwarded.Load(),
		"dropped":     g.dropped.Load(),
		"rateDropped": g.rateDrop.Load(),
	}
}

// Run serves until ctx ends. Never returns an error for dropped datagrams;
// only listener/upstream resolution failures abort startup (returned).
func (g *Guard) Run(ctx context.Context) error {
	laddr, err := net.ResolveUDPAddr("udp", g.cfg.Listen)
	if err != nil {
		return err
	}
	raddr, err := net.ResolveUDPAddr("udp", g.cfg.Upstream)
	if err != nil {
		return err
	}
	conn, err := net.ListenUDP("udp", laddr)
	if err != nil {
		return err
	}
	defer conn.Close()
	go func() {
		<-ctx.Done()
		_ = conn.Close()
	}()
	buf := make([]byte, 65507)
	for {
		_ = conn.SetReadDeadline(time.Now().Add(500 * time.Millisecond))
		n, client, err := conn.ReadFromUDP(buf)
		if err != nil {
			select {
			case <-ctx.Done():
				return nil
			default:
			}
			if ne, ok := err.(net.Error); ok && ne.Timeout() {
				continue
			}
			return nil
		}
		ip := client.IP.String()
		if !g.allow(ip, n) {
			continue
		}
		go g.relay(conn, raddr, client, append([]byte(nil), buf[:n]...))
	}
}

func (g *Guard) allow(ip string, size int) bool {
	if g.l4 != nil {
		if r := g.l4.InspectUDP(ip, g.cfg.ServicePort, size); !r.Allowed {
			g.dropped.Add(1)
			g.abuse(ip, r.Reason)
			return false
		}
	}
	now := time.Now().Unix()
	g.mu.Lock()
	e := g.rps[ip]
	if e == nil || e.sec != now {
		e = &rpsEntry{sec: now}
		g.rps[ip] = e
	}
	e.count++
	over := e.count > g.cfg.MaxRPSPerIP
	// Opportunistic map hygiene: reset each new second per IP already;
	// full sweep would need a janitor — entries are tiny and keyed by IP.
	g.mu.Unlock()
	if over {
		g.rateDrop.Add(1)
		g.abuse(ip, "udp-rate")
		return false
	}
	return true
}

func (g *Guard) abuse(ip, reason string) {
	if g.OnAbuse != nil {
		g.OnAbuse(ip, reason)
	}
}

func (g *Guard) relay(conn *net.UDPConn, raddr, client *net.UDPAddr, datagram []byte) {
	up, err := net.DialUDP("udp", nil, raddr)
	if err != nil {
		return
	}
	defer up.Close()
	_ = up.SetDeadline(time.Now().Add(time.Duration(g.cfg.TimeoutMs) * time.Millisecond))
	if _, err := up.Write(datagram); err != nil {
		return
	}
	resp := make([]byte, 65507)
	n, err := up.Read(resp)
	if err != nil {
		return
	}
	_, _ = conn.WriteToUDP(resp[:n], client)
	g.forwarded.Add(1)
}
