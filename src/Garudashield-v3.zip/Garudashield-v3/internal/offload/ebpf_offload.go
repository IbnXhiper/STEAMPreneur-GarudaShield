//go:build ebpf

// Package offload provides a kernel-side XDP offloader using cilium/ebpf.
//
// This file is ONLY compiled under the `ebpf` build tag (Linux + a C toolchain
// to build the object, and root to attach). On every other platform the
// default `Userspace` no-op offloader from offload.go is used, so the engine
// still builds and runs unchanged on Windows/macOS.
//
// What it does: loads an XDP program (xdp_drop.o) that drops IPv4 TCP/UDP
// packets whose source IP is present in a BPF hash map. The engine keeps that
// map in sync with its blocklist, so volumetric L3/L4 floods are dropped at the
// NIC before they ever reach userspace — closing the last gap in the DDoS
// posture (slowloris / L7 is still handled by netguard + shield in userspace).
package offload

import (
	"bytes"
	"context"
	_ "embed"
	"fmt"
	"net"

	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
)

//go:embed xdp_drop.o
var xdpObj []byte

// XDPOffloader attaches an XDP program to a network interface and exposes the
// blocklist BPF map for the engine to keep in sync.
type XDPOffloader struct {
	iface string
	objs  xdpObjects
	link  link.Link
}

type xdpObjects struct {
	Prog    *ebpf.Program `ebpf:"xdp_drop"`
	Blocked *ebpf.Map     `ebpf:"blocked_ips"`
}

// NewXDPOrNil builds a kernel XDP offloader for the interface, or returns
// (nil, err) if the object/loader is unavailable on this build. Callers fall back
// to Userspace when it returns nil.
func NewXDPOrNil(iface string) (Offloader, error) {
	if iface == "" {
		return nil, fmt.Errorf("xdp offload requires offload.interface")
	}
	var objs xdpObjects
	spec, err := ebpf.LoadCollectionSpecFromReader(bytes.NewReader(xdpObj))
	if err != nil {
		return nil, fmt.Errorf("load xdp object: %w", err)
	}
	if err := spec.LoadAndAssign(&objs, nil); err != nil {
		return nil, fmt.Errorf("load xdp programs: %w", err)
	}
	return &XDPOffloader{iface: iface, objs: objs}, nil
}

// SupportsXDP reports true for this build (compiled with -tags ebpf on Linux).
func (x *XDPOffloader) SupportsXDP() bool { return true }

// Offload attaches the XDP program to the interface. idempotent-ish: a second
// call replaces the previous attachment.
func (x *XDPOffloader) Offload(ctx context.Context) error {
	iface, err := net.InterfaceByName(x.iface)
	if err != nil {
		return fmt.Errorf("interface %s: %w", x.iface, err)
	}
	l, err := ebpfXDPAttach(iface.Index, x.objs.Prog)
	if err != nil {
		return fmt.Errorf("attach xdp: %w", err)
	}
	x.link = l
	return nil
}

// BlockIP inserts an IPv4 into the kernel blocklist map.
func (x *XDPOffloader) BlockIP(ip net.IP) error {
	v4 := ip.To4()
	if v4 == nil {
		return fmt.Errorf("only IPv4 supported by XDP offload: %s", ip)
	}
	var key [4]byte
	copy(key[:], v4)
	return x.objs.Blocked.Put(key, uint8(1))
}

// UnblockIP removes an IPv4 from the kernel blocklist map.
func (x *XDPOffloader) UnblockIP(ip net.IP) error {
	v4 := ip.To4()
	if v4 == nil {
		return fmt.Errorf("only IPv4 supported by XDP offload: %s", ip)
	}
	var key [4]byte
	copy(key[:], v4)
	return x.objs.Blocked.Delete(key)
}

// Close detaches and frees resources.
func (x *XDPOffloader) Close() error {
	if x.link != nil {
		_ = x.link.Close()
	}
	x.objs.Prog.Close()
	x.objs.Blocked.Close()
	return nil
}
