// Package offload describes GarudaShield's L3/L4 packet-offload boundary.
//
// v3 today defends L4 entirely in userspace (see internal/defense/layer4):
// SYN-half-open tracking, port-scan detection, bogon filtering and UDP
// amplification guard all run inside the Go edge proxy. That is sufficient for
// application-layer and moderate volumetric attacks, but it cannot absorb a
// large volumetric L4 flood — by the time a packet reaches Go it has already
// consumed NIC/CPU on the host.
//
// The real fix is kernel-side offload (XDP / eBPF) that drops attack traffic
// before it reaches the protocol stack. This package defines the seam so the
// offloader can be slotted in later WITHOUT changing the userspace pipeline.
//
// The bundled implementation is userspace-only: Offload() is a no-op and
// SupportsXDP() reports false. A future ebpf build tag would provide a real
// implementation; the rest of the engine treats offload as a best-effort,
// optional layer and never depends on it for a verdict.
package offload

import (
	"context"
	"net"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Offloader drops or rate-limits packets before they reach the userspace edge.
// Implementations MUST be safe to call concurrently and MUST NOT block the
// request path (they run as a side channel, not a verdict input).
type Offloader interface {
	// SupportsXDP reports whether this build/kernel can drop traffic in the
	// kernel fast path. The userspace build returns false.
	SupportsXDP() bool
	// Offload applies the current drop/limit policy to the host's ingress.
	// The userspace no-op returns nil immediately.
	Offload(ctx context.Context) error
	// BlockIP / UnblockIP keep the kernel drop list in sync with the engine's
	// blocklist. No-ops for userspace (the userspace layer4 handles those).
	BlockIP(ip net.IP) error
	UnblockIP(ip net.IP) error
	// Close releases any kernel resources.
	Close() error
}

// Userspace is the default offloader: it does nothing in-kernel and exists so
// the rest of the engine can call offload uniformly. Volumetric L4 protection
// therefore relies on an upstream scrubbing center / anycast when running
// userspace-only.
type Userspace struct{}

func (Userspace) SupportsXDP() bool             { return false }
func (Userspace) Offload(context.Context) error { return nil }
func (Userspace) BlockIP(net.IP) error          { return nil }
func (Userspace) UnblockIP(net.IP) error        { return nil }
func (Userspace) Close() error                  { return nil }

// New returns the offloader for the current build. On a non-ebpf build (or when
// cfg is disabled) it returns Userspace. Under `-tags ebpf` with cfg.Enabled,
// it returns a kernel XDP offloader (see ebpf_offload.go).
func New(cfg config.OffloadConfig) Offloader {
	if cfg.Enabled {
		if x, err := NewXDPOrNil(cfg.Iface); err != nil {
			// Fall back to userspace if the kernel offload can't initialize
			// (wrong platform, missing object, no root). The engine still runs.
			return Userspace{}
		} else if x != nil {
			return x
		}
	}
	return Userspace{}
}
