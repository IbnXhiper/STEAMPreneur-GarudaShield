// XDP drop program: drops IPv4 TCP/UDP packets whose source IP is in the
// blocked_ips BPF hash map. Loaded by ebpf_offload.go (Go build tag `ebpf`).
//
// Build with: clang -O2 -target bpf -c xdp_drop.c -o xdp_drop.o
// (requiresclang + libbpf + kernel headers; do this on Linux/WSL, not Windows.)
#include <linux/bpf.h>
#include <linux/if_ether.h>
#include <linux/in.h>
#include <linux/ip.h>
#include <bpf/bpf_helpers.h>

#define ETH_P_IP 0x0800

// Map of blocked source IPv4 addresses (key = __u32 in network byte order).
struct {
    __uint(type, BPF_MAP_TYPE_HASH);
    __type(key, __u32);
    __type(value, __u8);
    __uint(max_entries, 65536);
} blocked_ips SEC(".maps");

SEC("xdp")
int xdp_drop(struct xdp_md *ctx) {
    void *data_end = (void *)(long)ctx->data_end;
    void *data = (void *)(long)ctx->data;
    struct ethhdr *eth = data;
    if ((void *)(eth + 1) > data_end)
        return XDP_PASS;
    if (eth->h_proto != __constant_htons(ETH_P_IP))
        return XDP_PASS;

    struct iphdr *ip = (void *)(eth + 1);
    if ((void *)(ip + 1) > data_end)
        return XDP_PASS;

    // Only TCP and UDP get the blocklist treatment.
    if (ip->protocol != IPPROTO_TCP && ip->protocol != IPPROTO_UDP)
        return XDP_PASS;

    __u32 src = ip->saddr;
    __u8 *hit = bpf_map_lookup_elem(&blocked_ips, &src);
    if (hit)
        return XDP_DROP;

    return XDP_PASS;
}

char _license[] SEC("license") = "GPL";
