//go:build !ebpf

package offload

// NewXDPOrNil is the no-op variant compiled on non-ebpf builds (Windows, macOS,
// or Linux without -tags ebpf). It reports "not available" so callers fall back
// to the userspace offloader.
func NewXDPOrNil(iface string) (Offloader, error) {
	return nil, nil
}
