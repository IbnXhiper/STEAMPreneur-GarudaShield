//go:build ebpf

package offload

import (
	"github.com/cilium/ebpf"
	"github.com/cilium/ebpf/link"
)

// ebpfXDPAttach attaches prog to ifaceIndex at the XDP layer. Zero Flags
// means driver/generic best-effort (cilium default): fastest where the
// driver supports native XDP, portable SKB mode elsewhere (e.g. WSL eth0).
func ebpfXDPAttach(ifaceIndex int, prog *ebpf.Program) (link.Link, error) {
	return link.AttachXDP(link.XDPOptions{
		Interface: ifaceIndex,
		Program:   prog,
	})
}
