package analyzer

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func newA() *Analyzer {
	return New(config.Detection{})
}

func TestTotalsAndTopN(t *testing.T) {
	a := newA()
	defer a.Close()
	for i := 0; i < 5; i++ {
		a.RecordTraffic("1.1.1.1", "/a", "UA", 100)
	}
	for i := 0; i < 3; i++ {
		a.RecordTraffic("2.2.2.2", "/b", "UA", 100)
	}
	a.RecordTraffic("3.3.3.3", "/a", "UA", 100)

	if _, blk, chl, pas := a.Totals(); blk != 0 || chl != 0 || pas != 0 {
		t.Fatal("counters must start zero")
	}
	a.RecordBlocked()
	a.RecordPassed()
	if req, blk, _, pas := a.Totals(); req != 9 || blk != 1 || pas != 1 {
		t.Fatalf("totals wrong: %d %d", req, blk)
	}

	top := a.TopIPs(2)
	if len(top) != 2 || top[0][0] != "1.1.1.1" || top[1][0] != "2.2.2.2" {
		t.Fatalf("top order wrong: %v", top)
	}
}

func TestBaselineLockRequiresSamples(t *testing.T) {
	a := newA()
	defer a.Close()
	if a.LockBaseline() {
		t.Fatal("must refuse with too few samples")
	}
	for i := 0; i < 40; i++ {
		a.TickSecond()
	}
	if !a.LockBaseline() {
		t.Fatal("should lock after BaselineSamples ticks")
	}
	if d := a.DetectAnomaly(); d.Detected {
		t.Fatalf("flat zero traffic must be quiet: %+v", d)
	}
}

func TestAttackFlagsToggle(t *testing.T) {
	a := newA()
	defer a.Close()
	if a.AttackActive() {
		t.Fatal("starts inactive")
	}
	// simulate detection path directly through public behavior:
	// feed many samples in one second to spike CurrentRPS
	for i := 0; i < 200; i++ {
		a.RecordTraffic("9.9.9.9", "/x", "bot", 100)
	}
	d := a.DetectAnomaly()
	// baseline not locked → falls to std-dev branch or stays quiet; either way flags must be consistent
	if d.Detected != a.AttackActive() {
		t.Fatalf("inconsistent state: detected=%v active=%v", d.Detected, a.AttackActive())
	}
}
