// Package analyzer ports the traffic-statistics core of v2's
// src/engine/analyzer.js: per-second RPS/bandwidth, IP/path/UA frequencies,
// IP-entropy window, baseline locking and the attack detection state machine
// (rate-spike / low-entropy / udp / syn ratio heuristics).
package analyzer

import (
	"math"
	"sort"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/storage"
)

type Detection struct {
	Detected bool
	Types    []string
	Severity string
	Score    float64
}

type secSample struct {
	ts    int64
	rps   float64
	bytes int64 // request bytes observed during this second
}

type Analyzer struct {
	cfg config.Detection

	history *storage.Ring[histEntry]
	mu      sync.Mutex
	seconds []secSample // trailing window (~60s)
	curSec  int64
	curCnt  int64
	curByte int64 // request bytes accumulated in the current second

	ipFreq   sync.Map // ip -> *intCounter
	pathFreq sync.Map
	uaFreq   sync.Map

	totalRequests   atomic.Uint64
	totalBlocked    atomic.Uint64
	totalChallenged atomic.Uint64
	totalPassed     atomic.Uint64
	totalBytes      atomic.Uint64 // cumulative request bytes seen (ingress volume)
	blockedBytes    atomic.Uint64 // request bytes on blocked requests (attack volume)

	peakMu   sync.Mutex
	peakRPS  float64
	anomalyF ValueF
	lastEnt  ValueF

	attackActive atomic.Bool
	attackStart  atomic.Int64
	lastAttack   atomic.Int64
	attackTypes  sync.Map

	tcpPackets atomic.Uint64
	udpPackets atomic.Uint64
	tcpSyn     atomic.Uint64

	entropyWindow []float64
	baseline      baselineState
}

type baselineState struct {
	mu        sync.Mutex
	rate, std float64
	locked    bool
}

type histEntry struct {
	at time.Time
	ip string
}

func New(cfg config.Detection) *Analyzer {
	if cfg.EntropyWindow <= 0 {
		cfg.EntropyWindow = 10
	}
	if cfg.BaselineSamples <= 0 {
		cfg.BaselineSamples = 30
	}
	if cfg.AttackCooldownMs <= 0 {
		cfg.AttackCooldownMs = 30000
	}
	if cfg.RateSpikeMultiplier <= 0 {
		cfg.RateSpikeMultiplier = 4
	}
	if cfg.LowEntropyThreshold <= 0 {
		cfg.LowEntropyThreshold = 0.3
	}
	if cfg.UDPRatioThreshold <= 0 {
		cfg.UDPRatioThreshold = 0.8
	}
	if cfg.SYNRatioThreshold <= 0 {
		cfg.SYNRatioThreshold = 0.7
	}
	return &Analyzer{cfg: cfg, history: storage.NewRing[histEntry](200000)}
}

// RecordTraffic feeds one HTTP request observation.
func (a *Analyzer) RecordTraffic(ip, path, userAgent string, bytes int64) {
	now := time.Now()
	if bytes < 0 {
		bytes = 0
	}
	a.mu.Lock()
	if sec := now.Unix(); sec != a.curSec {
		a.pushSampleLocked()
		a.curSec = sec
		a.curCnt = 0
		a.curByte = 0
	}
	a.curCnt++
	a.curByte += bytes
	a.mu.Unlock()

	a.history.Push(histEntry{at: now, ip: ip})
	incMap(&a.ipFreq, ip)
	incMap(&a.pathFreq, path)
	if userAgent != "" {
		incMap(&a.uaFreq, userAgent)
	}
	a.totalRequests.Add(1)
	a.totalBytes.Add(uint64(bytes))
}

func (a *Analyzer) RecordBlockedBytes(bytes int64) {
	if bytes > 0 {
		a.blockedBytes.Add(uint64(bytes))
	}
}

func (a *Analyzer) BytesIn() uint64      { return a.totalBytes.Load() }
func (a *Analyzer) BlockedBytes() uint64 { return a.blockedBytes.Load() }
func (a *Analyzer) CurrentBytes() int64 {
	a.mu.Lock()
	defer a.mu.Unlock()
	return a.curByte
}

// RecordUDP records a UDP packet observation.
func (a *Analyzer) RecordUDP() { a.udpPackets.Add(1) }
func (a *Analyzer) RecordTCP(syn bool) {
	a.tcpPackets.Add(1)
	if syn {
		a.tcpSyn.Add(1)
	}
}
func (a *Analyzer) RecordBlocked()    { a.totalBlocked.Add(1) }
func (a *Analyzer) RecordChallenged() { a.totalChallenged.Add(1) }
func (a *Analyzer) RecordPassed()     { a.totalPassed.Add(1) }

// CurrentRPS returns this-or-last second's request count.
func (a *Analyzer) CurrentRPS() int64 {
	now := time.Now().Unix()
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.curSec >= now-1 {
		return a.curCnt
	}
	return 0
}

// TickSecond appends a per-second sample (call ~1 Hz from the stats loop).
func (a *Analyzer) TickSecond() float64 {
	a.mu.Lock()
	a.rollLocked(time.Now())
	a.pushSampleLocked()
	s := a.seconds[len(a.seconds)-1]
	a.mu.Unlock()

	a.peakMu.Lock()
	if s.rps > a.peakRPS {
		a.peakRPS = s.rps
	}
	a.peakMu.Unlock()
	return s.rps
}

func (a *Analyzer) rollLocked(now time.Time) {
	cutoff := now.Add(-time.Minute).UnixMilli()
	i := 0
	for i < len(a.seconds) && a.seconds[i].ts < cutoff {
		i++
	}
	if i > 0 {
		a.seconds = append([]secSample{}, a.seconds[i:]...)
	}
}

func (a *Analyzer) pushSampleLocked() {
	a.seconds = append(a.seconds, secSample{ts: time.Now().UnixMilli(), rps: float64(a.curCnt), bytes: a.curByte})
}

// DetectAnomaly runs the v2 attack state machine over recent samples.
func (a *Analyzer) DetectAnomaly() Detection {
	const recentN = 15
	a.mu.Lock()
	start := len(a.seconds) - recentN
	if start < 0 {
		start = 0
	}
	recent := a.seconds[start:]
	if len(recent) < 5 {
		a.mu.Unlock()
		return Detection{}
	}
	rates := make([]float64, len(recent))
	for i, s := range recent {
		rates[i] = s.rps
	}
	avg := mean(rates)
	std := math.Sqrt(sumSq(rates, avg) / float64(len(rates)))
	baseRate, baseStd, baseLocked := a.baseSnapshotLocked()
	a.mu.Unlock()

	current := float64(a.CurrentRPS())
	score := current / math.Max(avg, 1)
	a.anomalyF.Store(score)

	res := Detection{Score: score}
	nowMs := time.Now().UnixMilli()
	inCooldown := a.lastAttack.Load() > 0 && nowMs-a.lastAttack.Load() < int64(a.cfg.AttackCooldownMs)

	if baseLocked && !inCooldown {
		thresh := baseRate + baseStd*a.cfg.RateSpikeMultiplier
		if current > thresh && current > 100 {
			res.Detected = true
			res.Types = append(res.Types, "rate-spike")
			if current > thresh*3 {
				res.Severity = "critical"
			} else {
				res.Severity = "high"
			}
		}
	}

	ent := a.computeEntropy()
	a.lastEnt.Store(ent)
	if ent > 0 && !inCooldown && current > 100 {
		if avgE, ok := a.avgPrevEntropy(); ok && ent < avgE*a.cfg.LowEntropyThreshold {
			res.Detected = true
			res.Types = append(res.Types, "low-entropy")
			res.Severity = "high"
		}
	}

	tcp, udp := a.tcpPackets.Load(), a.udpPackets.Load()
	if t := tcp + udp; t > 0 && !inCooldown &&
		float64(udp)/float64(t) > a.cfg.UDPRatioThreshold && current > 200 {
		res.Detected = true
		res.Types = append(res.Types, "udp-flood")
		res.Severity = "high"
	}
	if tcp > 100 && !inCooldown &&
		float64(a.tcpSyn.Load())/float64(tcp) > a.cfg.SYNRatioThreshold && current > 200 {
		res.Detected = true
		res.Types = append(res.Types, "syn-flood")
		res.Severity = "high"
	}

	if !res.Detected && !baseLocked && !inCooldown && std > 0 &&
		current > avg+std*3 && current > 100 {
		res.Detected = true
		res.Types = append(res.Types, "rate-spike")
		res.Severity = "medium"
	}

	if res.Detected {
		a.attackActive.Store(true)
		a.attackStart.CompareAndSwap(0, nowMs)
		a.lastAttack.Store(nowMs)
		for _, ty := range res.Types {
			a.attackTypes.Store(ty, true)
		}
	} else if a.attackActive.Load() && current < avg {
		a.attackActive.Store(false)
		a.attackStart.Store(0)
	}
	return res
}

func (a *Analyzer) baseSnapshotLocked() (rate, std float64, locked bool) {
	a.baseline.mu.Lock()
	defer a.baseline.mu.Unlock()
	return a.baseline.rate, a.baseline.std, a.baseline.locked
}

// LockBaseline freezes the trailing window as "normal traffic".
func (a *Analyzer) LockBaseline() bool {
	a.mu.Lock()
	defer a.mu.Unlock()
	if a.baseline.locked || len(a.seconds) < a.cfg.BaselineSamples {
		return false
	}
	rates := make([]float64, len(a.seconds))
	for i, s := range a.seconds {
		rates[i] = s.rps
	}
	m := mean(rates)
	a.baseline.rate = m
	a.baseline.std = math.Sqrt(sumSq(rates, m) / float64(len(rates)))
	a.baseline.locked = true
	return true
}

func (a *Analyzer) computeEntropy() float64 {
	cutoff := time.Now().Add(-2 * time.Second)
	counts := map[string]int{}
	total := 0
	a.history.ForEachNewest(func(h histEntry) bool {
		if h.at.Before(cutoff) {
			return false
		}
		counts[h.ip]++
		total++
		return true
	})
	if total < 10 {
		return 0
	}
	e := 0.0
	for _, c := range counts {
		p := float64(c) / float64(total)
		e -= p * math.Log2(p)
	}
	a.mu.Lock()
	a.entropyWindow = append(a.entropyWindow, e)
	if len(a.entropyWindow) > a.cfg.EntropyWindow {
		a.entropyWindow = a.entropyWindow[len(a.entropyWindow)-a.cfg.EntropyWindow:]
	}
	a.mu.Unlock()
	return e
}

func (a *Analyzer) avgPrevEntropy() (float64, bool) {
	a.mu.Lock()
	defer a.mu.Unlock()
	if len(a.entropyWindow) < 5 {
		return 0, false
	}
	prev := a.entropyWindow[:len(a.entropyWindow)-1]
	return sum(prev) / float64(len(prev)), true
}

func (a *Analyzer) AttackActive() bool { return a.attackActive.Load() }

// ForceAttack overrides the attack-active flag (test hook for driving the
// shield's flood-mode state machine without synthetic traffic).
func (a *Analyzer) ForceAttack(on bool)   { a.attackActive.Store(on) }
func (a *Analyzer) AnomalyScore() float64 { return a.anomalyF.Load() }
func (a *Analyzer) LastEntropy() float64  { return a.lastEnt.Load() }
func (a *Analyzer) BaselineLocked() bool {
	a.baseline.mu.Lock()
	defer a.baseline.mu.Unlock()
	return a.baseline.locked
}
func (a *Analyzer) AttackTypes() []string {
	out := []string{}
	a.attackTypes.Range(func(k, _ any) bool { out = append(out, k.(string)); return true })
	return out
}
func (a *Analyzer) Totals() (req, blocked, challenged, passed uint64) {
	return a.totalRequests.Load(), a.totalBlocked.Load(), a.totalChallenged.Load(), a.totalPassed.Load()
}
func (a *Analyzer) PeakRPS() float64 {
	a.peakMu.Lock()
	defer a.peakMu.Unlock()
	return a.peakRPS
}
func (a *Analyzer) TopIPs(n int) [][2]any   { return topN(&a.ipFreq, n) }
func (a *Analyzer) TopPaths(n int) [][2]any { return topN(&a.pathFreq, n) }

func (a *Analyzer) Close() {}

// ---------- helpers ----------

func mean(v []float64) float64 {
	if len(v) == 0 {
		return 0
	}
	return sum(v) / float64(len(v))
}
func sum(v []float64) float64 {
	s := 0.0
	for _, x := range v {
		s += x
	}
	return s
}
func sumSq(v []float64, m float64) float64 {
	s := 0.0
	for _, x := range v {
		d := x - m
		s += d * d
	}
	return s
}

func topN(m *sync.Map, n int) [][2]any {
	type kv struct {
		k string
		v int64
	}
	list := []kv{}
	m.Range(func(mk, mv any) bool {
		list = append(list, kv{k: mk.(string), v: mv.(*counter).get()})
		return true
	})
	sort.Slice(list, func(i, j int) bool { return list[i].v > list[j].v })
	if len(list) > n {
		list = list[:n]
	}
	out := make([][2]any, len(list))
	for i, e := range list {
		out[i] = [2]any{e.k, e.v}
	}
	return out
}

const freqCap = 100000

func incMap(m *sync.Map, key string) {
	v, _ := m.LoadOrStore(key, &counter{})
	v.(*counter).inc()
	n := v.(*counter).get()
	if n == 1 { // possible new key; cheap occasional size check
		size := 0
		m.Range(func(_, _ any) bool { size++; return size <= freqCap+1 })
		if size > freqCap {
			pruneLow(m, freqCap/2)
		}
	}
}

func pruneLow(m *sync.Map, until int) {
	removed := 0
	m.Range(func(k, vv any) bool {
		if vv.(*counter).get() <= 2 {
			m.Delete(k)
			removed++
		}
		return removed < until
	})
}

type counter struct {
	mu sync.Mutex
	v  int64
}

func (c *counter) inc() { c.mu.Lock(); c.v++; c.mu.Unlock() }
func (c *counter) get() int64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.v
}

// ValueF is a tiny mutex-guarded float64 cell.
type ValueF struct {
	mu sync.Mutex
	v  float64
}

func (x *ValueF) Store(v float64) { x.mu.Lock(); x.v = v; x.mu.Unlock() }
func (x *ValueF) Load() float64   { x.mu.Lock(); defer x.mu.Unlock(); return x.v }
