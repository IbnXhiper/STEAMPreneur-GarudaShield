//go:build linux && cgo

// Package rustffi (Linux) loads the Rust wafmatcher cdylib (libwafmatcher.so)
// via cgo/dlopen and exposes a Go-friendly Matcher. This gives the WAF hot path
// a Rust implementation on Linux without giving up the pure-Go fallback.
//
// The .so is built with `cargo build --release` in rust/wafmatcher and must be
// discoverable at runtime (see rustffi.soPath). When it cannot be loaded the
// engine transparently falls back to the pure-Go matcher (Available()==false).
package rustffi

/*
#cgo LDFLAGS: -ldl

#include <stdlib.h>
#include <dlfcn.h>

typedef void* (*waf_create_fn)(const char**, const int*, int);
typedef int   (*waf_score_fn)(void*, const char*);
typedef void  (*waf_destroy_fn)(void*);
typedef int   (*waf_count_fn)(void*);

static void* gs_dlopen(const char* path) {
    return dlopen(path, RTLD_NOW | RTLD_LOCAL);
}
static void* gs_dlsym(void* h, const char* name) {
    return dlsym(h, name);
}
static void  gs_dlclose(void* h) { if (h) dlclose(h); }
static char* gs_dlerror(void)    { return dlerror(); }

// Go cannot call C function pointers directly, so dlsym results cross
// into Go as void* and are invoked through these trampolines.
static void* gs_call_create(void* f, const char** p, const int* s, int n) {
    return ((waf_create_fn)f)(p, s, n);
}
static int gs_call_score(void* f, void* h, const char* in) {
    return ((waf_score_fn)f)(h, in);
}
static void gs_call_destroy(void* f, void* h) {
    ((waf_destroy_fn)f)(h);
}
static int gs_call_count(void* f, void* h) {
    if (!f) return -1;
    return ((waf_count_fn)f)(h);
}
*/
import "C"

import (
	"fmt"
	"os"
	"path/filepath"
	"unsafe"
)

// soPath resolves the wafmatcher shared object. Override with
// GS_WAF_LIB=/abs/path/libwafmatcher.so. Falls back to a few conventional
// locations (repo build dir, /usr/lib).
func soPath() string {
	if p := os.Getenv("GS_WAF_LIB"); p != "" {
		return p
	}
	candidates := []string{
		"rust/wafmatcher/target/release/libwafmatcher.so",
		"rust/wafmatcher/target/debug/libwafmatcher.so",
		"/usr/lib/libwafmatcher.so",
		"/usr/local/lib/libwafmatcher.so",
	}
	for _, c := range candidates {
		if _, err := os.Stat(c); err == nil {
			abs, aerr := filepath.Abs(c)
			if aerr == nil {
				return abs
			}
			return c
		}
	}
	// default best-effort (may be loaded later after cargo build)
	abs, _ := filepath.Abs("rust/wafmatcher/target/release/libwafmatcher.so")
	return abs
}

type handle struct {
	lib     unsafe.Pointer
	create  unsafe.Pointer
	score   unsafe.Pointer
	destroy unsafe.Pointer
	count   unsafe.Pointer // nil when the .so has no waf_count symbol
}

var loaded *handle

// Available reports whether the Rust matcher is loadable on this host.
func Available() bool {
	if loaded != nil {
		return true
	}
	h, err := openLib()
	if err != nil {
		return false
	}
	loaded = h
	return true
}

func openLib() (*handle, error) {
	path := soPath()
	clib := C.CString(path)
	defer C.free(unsafe.Pointer(clib))
	lib := C.gs_dlopen(clib)
	if lib == nil {
		return nil, fmt.Errorf("dlopen %s failed: %s", path, C.GoString(C.gs_dlerror()))
	}
	csym := C.CString("waf_create")
	ssym := C.CString("waf_score")
	dsym := C.CString("waf_destroy")
	defer C.free(unsafe.Pointer(csym))
	defer C.free(unsafe.Pointer(ssym))
	defer C.free(unsafe.Pointer(dsym))
	create := C.gs_dlsym(lib, csym)
	score := C.gs_dlsym(lib, ssym)
	destroy := C.gs_dlsym(lib, dsym)
	if create == nil || score == nil || destroy == nil {
		C.gs_dlclose(lib)
		return nil, fmt.Errorf("missing waf symbol in %s", path)
	}
	cs := C.CString("waf_count")
	defer C.free(unsafe.Pointer(cs))
	count := C.gs_dlsym(lib, cs)
	// waf_count is optional: an older .so without it still works (count
	// verification is then skipped).
	return &handle{
		lib:     lib,
		create:  create,
		score:   score,
		destroy: destroy,
		count:   count,
	}, nil
}

// Matcher wraps a Rust waf_create handle.
type Matcher struct {
	h *handle
	p unsafe.Pointer
}

// New compiles the patterns/scores into a Rust matcher.
func New(patterns []string, scores []int32) (*Matcher, error) {
	if len(patterns) != len(scores) {
		return nil, fmt.Errorf("patterns/scores length mismatch: %d != %d", len(patterns), len(scores))
	}
	if !Available() {
		return nil, errUnavailable
	}
	cps := make([]*C.char, len(patterns))
	cscores := make([]C.int, len(scores))
	for i, p := range patterns {
		cps[i] = C.CString(p)
		cscores[i] = C.int(scores[i])
	}
	defer func() {
		for _, c := range cps {
			C.free(unsafe.Pointer(c))
		}
	}()
	m := &Matcher{h: loaded}
	m.p = C.gs_call_create(m.h.create, &cps[0], &cscores[0], C.int(len(patterns)))
	if m.p == nil {
		return nil, fmt.Errorf("waf_create returned null handle")
	}
	return m, nil
}

// Score returns the cumulative WAF score for input.
func (m *Matcher) Score(input string) int {
	if m == nil || m.p == nil {
		return -1
	}
	cin := C.CString(input)
	defer C.free(unsafe.Pointer(cin))
	return int(C.gs_call_score(m.h.score, m.p, cin))
}

// Close frees the Rust handle.
func (m *Matcher) Close() {
	if m == nil || m.p == nil {
		return
	}
	C.gs_call_destroy(m.h.destroy, m.p)
	m.p = nil
}

// Count returns the number of rules actually compiled into the Rust matcher
// (-1 when unknown). The engine compares it against the rules it sent to
// detect silently skipped invalid patterns.
func (m *Matcher) Count() int {
	if m == nil || m.p == nil || m.h.count == nil {
		return -1
	}
	return int(C.gs_call_count(m.h.count, m.p))
}

var errUnavailable = errMsg("rust wafmatcher (.so) not loaded; using pure-Go fallback")

type errMsg string

func (e errMsg) Error() string { return string(e) }
