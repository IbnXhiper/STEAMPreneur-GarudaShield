//go:build !windows && (!linux || !cgo)

// Package rustffi (non-Windows stub) reports the Rust matcher as unavailable
// so cross-platform builds stay green; the pure-Go engine is always used.
package rustffi

// Available is always false off Windows (the cdylib targets Windows).
func Available() bool { return false }

// Matcher is a no-op placeholder for non-Windows builds.
type Matcher struct{}

// New always errors off Windows.
func New(patterns []string, scores []int32) (*Matcher, error) {
	return nil, errUnavailable
}

// Score always returns -1.
func (m *Matcher) Score(input string) int { return -1 }

// Count always returns -1 (no Rust matcher off Windows/Linux).
func (m *Matcher) Count() int { return -1 }

// Close is a no-op.
func (m *Matcher) Close() {}

var errUnavailable = errMsg("rustffi unavailable on this platform")

type errMsg string

func (e errMsg) Error() string { return string(e) }
