//go:build darwin

// Package rustffi (macOS stub) reports the Rust matcher as unavailable; the
// pure-Go engine is always used on macOS.
package rustffi

// Available is false on macOS (the cdylib targets Windows/Linux).
func Available() bool { return false }

// Matcher is a no-op placeholder for macOS builds.
type Matcher struct{}

// New always errors on macOS.
func New(patterns []string, scores []int32) (*Matcher, error) {
	return nil, errUnavailable
}

// Score always returns -1.
func (m *Matcher) Score(input string) int { return -1 }

// Count always returns -1 (no Rust matcher on macOS).
func (m *Matcher) Count() int { return -1 }

// Close is a no-op.
func (m *Matcher) Close() {}

var errUnavailable = errMsg("rustffi unavailable on this platform")

type errMsg string

func (e errMsg) Error() string { return string(e) }
