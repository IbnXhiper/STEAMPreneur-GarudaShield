//go:build windows

// Package rustffi binds the Rust wafmatcher cdylib over the Windows
// LoadLibrary ABI (no cgo, no C toolchain required). It is the optional
// high-performance WAF matcher; the Go engine remains the source of truth and
// fallback. Load is lazy and best-effort: if the DLL is absent, Available()
// reports false and callers fall back to the pure-Go implementation.
package rustffi

import (
	"fmt"
	"os"
	"path/filepath"
	"sync"
	"syscall"
	"unsafe"
)

var (
	mu      sync.Mutex
	loaded  *lib
	loadErr error
)

type lib struct {
	dll     *syscall.LazyDLL
	create  *syscall.LazyProc
	score   *syscall.LazyProc
	destroy *syscall.LazyProc
	count   *syscall.LazyProc
}

func findDLL() string {
	if p := os.Getenv("WAFMATCHER_DLL"); p != "" {
		return p
	}
	cands := []string{
		"wafmatcher.dll",
		filepath.Join("rust", "wafmatcher", "target", "release", "wafmatcher.dll"),
		filepath.Join("target", "release", "wafmatcher.dll"),
	}
	exe, err := os.Executable()
	if err == nil {
		cands = append(cands, filepath.Join(filepath.Dir(exe), "wafmatcher.dll"))
	}
	for _, c := range cands {
		if _, err := os.Stat(c); err == nil {
			return c
		}
	}
	return ""
}

func getLib() (*lib, error) {
	mu.Lock()
	defer mu.Unlock()
	if loaded != nil || loadErr != nil {
		return loaded, loadErr
	}
	path := findDLL()
	if path == "" {
		loadErr = fmt.Errorf("wafmatcher.dll not found")
		return nil, loadErr
	}
	dll := syscall.NewLazyDLL(path)
	create := dll.NewProc("waf_create")
	score := dll.NewProc("waf_score")
	destroy := dll.NewProc("waf_destroy")
	count := dll.NewProc("waf_count")
	if err := create.Find(); err != nil {
		loadErr = fmt.Errorf("waf_create missing: %w", err)
		return nil, loadErr
	}
	loaded = &lib{dll: dll, create: create, score: score, destroy: destroy, count: count}
	return loaded, nil
}

// Available reports whether the Rust matcher can be loaded.
func Available() bool {
	_, err := getLib()
	return err == nil
}

// Matcher wraps a Rust waf_create handle.
type Matcher struct {
	handle   uintptr
	cstrs    [][]byte // keep C strings alive for the handle's lifetime
	arr      []uintptr
	scores32 []int32
}

// New compiles patterns (parallel to scores) into a Rust matcher.
func New(patterns []string, scores []int32) (*Matcher, error) {
	l, err := getLib()
	if err != nil {
		return nil, err
	}
	if len(patterns) != len(scores) {
		return nil, fmt.Errorf("patterns/scores length mismatch")
	}
	m := &Matcher{cstrs: make([][]byte, len(patterns))}
	m.arr = make([]uintptr, len(patterns))
	for i, p := range patterns {
		b := append([]byte(p), 0)
		m.cstrs[i] = b
		m.arr[i] = uintptr(unsafe.Pointer(&b[0]))
	}
	m.scores32 = make([]int32, len(scores))
	copy(m.scores32, scores)
	var patternsArg, scoresArg uintptr
	if len(patterns) > 0 {
		patternsArg = uintptr(unsafe.Pointer(&m.arr[0]))
		scoresArg = uintptr(unsafe.Pointer(&m.scores32[0]))
	}
	r1, _, _ := l.create.Call(patternsArg, scoresArg, uintptr(len(patterns)))
	if r1 == 0 {
		return nil, fmt.Errorf("waf_create returned null handle")
	}
	m.handle = r1
	return m, nil
}

// Score returns the cumulative rule score for input.
func (m *Matcher) Score(input string) int {
	l, err := getLib()
	if err != nil || m.handle == 0 {
		return -1
	}
	in := append([]byte(input), 0)
	r1, _, _ := l.score.Call(m.handle, uintptr(unsafe.Pointer(&in[0])))
	return int(int32(r1))
}

// Count returns the number of rules actually compiled into the Rust matcher
// (-1 on error). The engine compares it against the rules it sent to detect
// silently skipped invalid patterns.
func (m *Matcher) Count() int {
	l, err := getLib()
	if err != nil || m.handle == 0 {
		return -1
	}
	r1, _, _ := l.count.Call(m.handle)
	return int(int32(r1))
}

// Close releases the Rust handle.
func (m *Matcher) Close() {
	if m.handle == 0 {
		return
	}
	if l, err := getLib(); err == nil {
		l.destroy.Call(m.handle)
	}
	m.handle = 0
}
