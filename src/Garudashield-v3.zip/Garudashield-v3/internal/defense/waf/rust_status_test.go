package waf

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestRustStatusCleanFallback verifies the fail-loud contract: when the
// Rust cdylib is unavailable (the normal case on CI/dev boxes), RustStatus
// reports active=false with a nil error (a clean fallback, not a degradation),
// and rebuildRust leaves lastRustError nil. When the cdylib IS present but
// drops rules, lastRustError must be non-nil (integration: linux/cgo +
// Windows DLL paths, verified via cargo build + WSL smoke).
func TestRustStatusCleanFallback(t *testing.T) {
	e := New(config.WAFConfig{})
	active, err := e.RustStatus()
	if active {
		t.Fatal("rust must be inactive by default")
	}
	if err != nil {
		t.Fatalf("unavailable cdylib is a clean fallback, not an error: %v", err)
	}
}
