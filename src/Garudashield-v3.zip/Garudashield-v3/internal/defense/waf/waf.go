// Package waf is a faithful Go port of v2's src/layers/waf.js.
// All v2 regexes are RE2-compatible (no backrefs/lookarounds); JS /i becomes
// (?i). Cumulative score ≥50 blocks; clean IPs get a short-lived fast-fail
// cache exactly like v2.
package waf

import (
	"errors"
	"fmt"
	"net/url"
	"regexp"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/defense/waf/rustffi"
	"github.com/ahkurdev/garudashield/internal/metrics"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

type rule struct {
	name    string
	typ     string
	re      *regexp.Regexp
	score   int
	custom  bool
	enabled bool
}

type Result struct {
	Allowed      bool
	Score        int
	MatchedRules []string
	Reason       string
}

type Engine struct {
	mu          sync.RWMutex
	cfg         config.WAFConfig
	rules       []rule
	matchCounts map[string]*atomic.Uint64

	fastFailMu sync.Mutex
	fastFail   map[string]int64 // ip -> unix ms of last clean pass

	dropped atomic.Uint64

	overrides map[string]bool // name -> enabled
	closeOnce sync.Once

	// Optional Rust FFI fast path. When rustEnabled and the cdylib is
	// available, Inspect scores via Rust; otherwise the Go rules are used
	// (GoFallback). Protected by mu.
	rustEnabled   bool
	rust          *rustffi.Matcher
	lastRustError error // non-nil when the Rust matcher is degraded (load/count failure)
}

// RustStatus reports whether the Rust fast path is active and, when degraded,
// the reason (e.g. rules silently skipped or the cdylib failed to load).
func (e *Engine) RustStatus() (active bool, err error) {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.rustEnabled && e.rust != nil, e.lastRustError
}

func New(cfg config.WAFConfig) *Engine {
	if cfg.FastFailTTL <= 0 {
		cfg.FastFailTTL = 2000
	}
	e := &Engine{
		cfg:         cfg,
		matchCounts: make(map[string]*atomic.Uint64),
		fastFail:    make(map[string]int64),
		overrides:   make(map[string]bool),
	}
	e.reload()
	return e
}

func mustCompile(pattern string) *regexp.Regexp {
	return regexp.MustCompile(pattern)
}

func (e *Engine) builtin() []rule {
	var rs []rule
	add := func(name, typ, pattern string, score int) {
		rs = append(rs, rule{name: name, typ: typ, re: mustCompile(pattern), score: score})
	}
	c := e.cfg
	if c.SQLi {
		add("sqli-1", "sqli", `(?i)(\bSELECT\b.{0,40}\bFROM\b|\bUNION\b.{0,40}\bSELECT\b|\bINSERT\b.{0,40}\bINTO\b|\bDELETE\b.{0,40}\bFROM\b|\bDROP\b.{0,40}\bTABLE\b)`, 50)
		add("sqli-2", "sqli", `(?i)('|")\s*(OR|AND)\s*('|")\s*(=|LIKE)`, 50)
		add("sqli-3", "sqli", `(?i)admin'\s*--\s*|1'\s*OR\s*'1'\s*=\s*'1`, 50)
		add("sqli-4", "sqli", `(?i)\bUNION\b.{0,20}\bALL\b.{0,20}\bSELECT\b`, 50)
		add("sqli-5", "sqli", `(?i)(?:src|href|action)\s*=\s*(?:\s*['"]?\s*)?(?:javascript|data|vbscript):`, 45)
		add("sqli-6", "sqli", `\b0x[0-9a-fA-F]{6,}\b`, 20)
	}
	if c.XSS {
		add("xss-1", "xss", `(?i)<script[\s>]`, 50)
		add("xss-2", "xss", `(?i)javascript\s*:`, 40)
		add("xss-3", "xss", `(?i)onerror\s*=|onload\s*=|onclick\s*=|onmouseover\s*=`, 40)
		add("xss-4", "xss", `(?i)<embed[\s>]|<object[\s>]|<iframe[\s>]|<frame[\s>]`, 45)
		add("xss-5", "xss", `(?i)document\.cookie|document\.location|window\.location`, 35)
		add("xss-6", "xss", `(?i)alert\s*\(|prompt\s*\(|confirm\s*\(`, 40)
		add("xss-7", "xss", `(?i)<svg[\s>]`, 35)
		add("xss-8", "xss", `(?i)%3Cscript|%3Csvg|%3Ciframe|%3Cembed`, 45)
	}
	if c.CommandInjection {
		add("cmdi-1", "cmdi", `(?i)[|;&$`+"`]"+`\s*(?:id|whoami|pwd|ls|cat|rm|wget|curl|nc|bash|sh|perl|python|php|ruby|powershell|cmd)\b`, 50)
		add("cmdi-2", "cmdi", "`[^`]+`", 45)
		add("cmdi-3", "cmdi", `\$\([^)]+\)`, 40)
		add("cmdi-4", "cmdi", `(?i)[|;&]\s*/bin/|/usr/bin/`, 40)
		add("cmdi-5", "cmdi", `(?i)(ping|nslookup|traceroute)\s+[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+`, 35)
	}
	if c.PathTraversal {
		add("ptrav-1", "ptrav", `(?i)\.\./\.\./|\.\.\\\.\.\\|%2e%2e%2f|%2e%2e%5c`, 45)
		add("ptrav-2", "ptrav", `(?i)/etc/passwd|/etc/shadow|/etc/hosts|/root/\.bash_history`, 50)
		add("ptrav-3", "ptrav", `(?i)/windows/system32|/boot\.ini|/autoexec\.bat`, 50)
		add("ptrav-4", "ptrav", `\.\./\.\./\.\./\.\./`, 50)
	}
	if c.LFI {
		add("lfi-1", "lfi", `(?i)include\s*\(?\s*['"](?:\.\./|/etc/|/var/|/proc/)`, 45)
		add("lfi-2", "lfi", `(?i)(file|php|zlib|data|expect|zip|rar|bzip2)://`, 40)
		add("lfi-3", "lfi", `(?i)\.\./\.\./.*\.(php|phtml|inc|conf|sql|txt)`, 35)
	}
	if c.RFI {
		add("rfi-1", "rfi", `(?i)https?://[^\s'"]+\.(php|phtml|asp|aspx|jsp|cfm)\b`, 40)
		add("rfi-2", "rfi", `(?i)include\s*\(?\s*['"]https?://`, 45)
	}
	if c.Shellshock {
		add("shock-1", "shellshock", `(?i)\(\)\s*\{[\s:]*\};\s*\w+:`, 50)
		add("shock-2", "shellshock", `Shellshock`, 50)
	}
	if c.Scanners {
		add("scan-1", "scanner", `(?i)(acunetix|netsparker|appscan|w3af|zaproxy|burpsuite|nikto|wpscan|nessus|openvas|qualys|nmap|masscan|sqlmap|hydra|medusa)`, 30)
		add("scan-2", "scanner", `(?i)(dirbuster|gobuster|wfuzz|dirsearch|dirb)`, 30)
	}
	for _, cr := range c.CustomRules {
		if cr.Pattern == "" {
			continue
		}
		re, err := regexp.Compile("(?i)" + cr.Pattern)
		if err != nil {
			continue // invalid custom rules are skipped (v2 would throw; we degrade safely)
		}
		score := cr.Score
		if score == 0 {
			score = 50
		}
		rs = append(rs, rule{name: cr.Name, typ: "custom", re: re, score: score, custom: true})
	}
	return rs
}

func (e *Engine) reload() {
	e.mu.Lock()
	defer e.mu.Unlock()
	rs := e.builtin()
	for i := range rs {
		if en, ok := e.overrides[rs[i].name]; ok {
			rs[i].enabled = en
		} else {
			rs[i].enabled = true
		}
		if _, ok := e.matchCounts[rs[i].name]; !ok {
			e.matchCounts[rs[i].name] = &atomic.Uint64{}
		}
	}
	e.rules = rs
	if e.rustEnabled {
		e.rebuildRust()
	}
}

// rebuildRust recompiles the Rust matcher from the current enabled rules.
// Caller must hold mu (write). Fail-loud: after compiling, the number of rules
// the Rust matcher actually holds is verified against what was sent. A
// mismatch means invalid patterns were silently skipped — that is surfaced via
// the rust_waf_rules_active metric (and a non-nil lastRustError) instead of
// quietly running with fewer rules than configured.
func (e *Engine) rebuildRust() {
	if e.rust != nil {
		e.rust.Close()
		e.rust = nil
	}
	metrics.RustWAFRulesActive.Set(-1)
	e.lastRustError = nil
	if !rustffi.Available() {
		return
	}
	patterns := make([]string, 0, len(e.rules))
	scores := make([]int32, 0, len(e.rules))
	for _, r := range e.rules {
		if !r.enabled {
			continue
		}
		patterns = append(patterns, r.re.String())
		scores = append(scores, int32(r.score))
	}
	if len(patterns) == 0 {
		return
	}
	m, err := rustffi.New(patterns, scores)
	if err != nil {
		e.lastRustError = err
		return
	}
	if got := m.Count(); got >= 0 && got != len(patterns) {
		e.lastRustError = fmt.Errorf("rust waf matcher skipped %d of %d rules (invalid patterns)", len(patterns)-got, len(patterns))
	}
	metrics.RustWAFRulesActive.Set(float64(m.Count()))
	e.rust = m
}

// EnableRust toggles the Rust FFI fast path. Returns an error if enabling
// while the cdylib is unavailable.
func (e *Engine) EnableRust(enable bool) error {
	e.mu.Lock()
	defer e.mu.Unlock()
	e.rustEnabled = enable
	if !enable {
		if e.rust != nil {
			e.rust.Close()
			e.rust = nil
		}
		return nil
	}
	if !rustffi.Available() {
		return errors.New("rust waf matcher unavailable")
	}
	e.rebuildRust()
	return nil
}

// Inspect runs all enabled rules over the joined inputs (≤4096 bytes).
func (e *Engine) Inspect(inputs map[string]string) Result {
	e.mu.RLock()
	cfgEnabled := e.cfg.Enabled
	rules := make([]rule, len(e.rules))
	copy(rules, e.rules)
	e.mu.RUnlock()

	if !cfgEnabled || len(inputs) == 0 {
		return Result{Allowed: true}
	}

	search := joinInputs(inputs, 4096)

	// Rust FFI fast path: identical scoring, offloaded from Go.
	if e.rust != nil {
		total := e.rust.Score(search)
		allowed := total < 50
		if !allowed {
			e.dropped.Add(1)
		}
		res := Result{Allowed: allowed, Score: total}
		if !allowed {
			res.Reason = "waf:rust"
		}
		return res
	}

	var matched []string
	total := 0
	for _, r := range rules {
		if !r.enabled {
			continue
		}
		if r.re.MatchString(search) {
			matched = append(matched, r.name)
			total += r.score
			if ctr, ok := e.matchCounts[r.name]; ok {
				ctr.Add(1)
			}
		}
	}
	allowed := total < 50
	if !allowed {
		e.dropped.Add(1)
	}
	res := Result{Allowed: allowed, Score: total, MatchedRules: matched}
	if len(matched) > 3 {
		matched = matched[:3]
	}
	if len(matched) > 0 {
		res.Reason = "waf:" + joinStrings(matched, ",")
	}
	return res
}

// InspectRequest assembles inputs from a View and inspects every request.
//
// Every request is inspected on its own merits: the WAF never short-circuits a
// verdict from cached per-IP state. Persisting a block across requests is the
// shield pipeline's job (autoBlock / verdict cache), which sits in front of this
// layer. The recentlyBlocked map below is bookkeeping for stats and reputation
// only — it must never decide Allowed, in either direction:
//   - skipping inspection for a "clean" IP let an attacker send one benign
//     request and then bypass the WAF entirely for FastFailTTL;
//   - blocking outright for a "dirty" IP made one attack from a shared NAT or
//     CGNAT address take down every legitimate user behind it.
func (e *Engine) InspectRequest(v *reqview.View) Result {
	rawQuery := ""
	if i := indexByte(v.URL, '?'); i >= 0 {
		rawQuery = v.URL[i+1:]
	}
	// Inspect the raw form AND the fully-normalized form. Rules that key on
	// encoded markers (e.g. xss-8 "%3Cscript") need the raw text, while
	// single/multi/plus-encoded payloads only reveal themselves after decoding.
	query := clampStr(rawQuery+" "+normalize(rawQuery), 2048)
	rawBody := string(v.Body)
	body := clampStr(rawBody+" "+normalize(rawBody), 4096)
	path := clampStr(v.Path+" "+normalize(v.Path), 2048)
	cookies := clampStr(v.Get("Cookie"), 2048)

	result := e.Inspect(map[string]string{
		"path":    path,
		"query":   query,
		"body":    body,
		"headers": v.HeaderValues(),
		"cookies": cookies,
	})

	if !result.Allowed {
		if ip := clientIP(v); ip != "" {
			e.fastFailMu.Lock()
			e.fastFail[ip] = time.Now().UnixMilli()
			if len(e.fastFail) > 100000 {
				for k := range e.fastFail { // evict one arbitrary (v2 parity)
					delete(e.fastFail, k)
					break
				}
			}
			e.fastFailMu.Unlock()
		}
	}
	return result
}

// SetModule toggles a category and reloads rules (dashboard action).
func (e *Engine) SetModule(statKey string, enabled bool) {
	e.mu.Lock()
	switch statKey {
	case "sqli":
		e.cfg.SQLi = enabled
	case "xss":
		e.cfg.XSS = enabled
	case "cmdi", "commandInjection":
		e.cfg.CommandInjection = enabled
	case "ptrav", "pathTraversal":
		e.cfg.PathTraversal = enabled
	case "lfi":
		e.cfg.LFI = enabled
	case "rfi":
		e.cfg.RFI = enabled
	case "shellshock":
		e.cfg.Shellshock = enabled
	case "scanners":
		e.cfg.Scanners = enabled
	case "enabled":
		e.cfg.Enabled = enabled
	}
	e.mu.Unlock()
	e.reload()
}

// SetRuleEnabled flips a single rule override.
func (e *Engine) SetRuleEnabled(name string, enabled bool) {
	e.mu.Lock()
	e.overrides[name] = enabled
	e.mu.Unlock()
	e.reload()
}

// AddCustomRule replaces same-named rule then reloads.
func (e *Engine) AddCustomRule(r config.WAFRule) {
	e.mu.Lock()
	out := e.cfg.CustomRules[:0]
	for _, existing := range e.cfg.CustomRules {
		if existing.Name != r.Name {
			out = append(out, existing)
		}
	}
	e.cfg.CustomRules = append(out, r)
	delete(e.overrides, r.Name)
	e.mu.Unlock()
	e.reload()
}

// RemoveCustomRule drops by name then reloads.
func (e *Engine) RemoveCustomRule(name string) {
	e.mu.Lock()
	out := make([]config.WAFRule, 0, len(e.cfg.CustomRules))
	for _, existing := range e.cfg.CustomRules {
		if existing.Name != name {
			out = append(out, existing)
		}
	}
	e.cfg.CustomRules = out
	delete(e.overrides, name)
	e.mu.Unlock()
	e.reload()
}

func (e *Engine) ClearCustomRules() {
	e.mu.Lock()
	e.cfg.CustomRules = nil
	e.mu.Unlock()
	e.reload()
}

type RuleInfo struct {
	Name    string `json:"name"`
	Type    string `json:"type"`
	Score   int    `json:"score"`
	Enabled bool   `json:"enabled"`
	Custom  bool   `json:"source"`
	Matches uint64 `json:"matches"`
}

func (e *Engine) Rules() []RuleInfo {
	e.mu.RLock()
	defer e.mu.RUnlock()
	out := make([]RuleInfo, 0, len(e.rules))
	for _, r := range e.rules {
		var m uint64
		if c, ok := e.matchCounts[r.name]; ok {
			m = c.Load()
		}
		out = append(out, RuleInfo{Name: r.name, Type: r.typ, Score: r.score, Enabled: r.enabled, Custom: r.custom, Matches: m})
	}
	return out
}

type Stats struct {
	RulesCount   int             `json:"rulesCount"`
	EnabledCount int             `json:"enabledCount"`
	DroppedCount uint64          `json:"droppedCount"`
	Enabled      bool            `json:"enabled"`
	FastFailSize int             `json:"fastFailSize"`
	CustomRules  int             `json:"customRules"`
	Modules      map[string]bool `json:"modules"`
}

// Config returns a copy of the live WAF configuration (module toggles).
func (e *Engine) Config() config.WAFConfig {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.cfg
}

func (e *Engine) Stats() Stats {
	e.mu.RLock()
	defer e.mu.RUnlock()
	en := 0
	for _, r := range e.rules {
		if r.enabled {
			en++
		}
	}
	e.fastFailMu.Lock()
	ff := len(e.fastFail)
	e.fastFailMu.Unlock()
	return Stats{
		RulesCount:   len(e.rules),
		EnabledCount: en,
		DroppedCount: e.dropped.Load(),
		Enabled:      e.cfg.Enabled,
		FastFailSize: ff,
		CustomRules:  len(e.cfg.CustomRules),
		Modules: map[string]bool{
			"sqli": e.cfg.SQLi, "xss": e.cfg.XSS, "cmdi": e.cfg.CommandInjection,
			"ptrav": e.cfg.PathTraversal, "lfi": e.cfg.LFI, "rfi": e.cfg.RFI,
			"shellshock": e.cfg.Shellshock, "scanners": e.cfg.Scanners,
		},
	}
}

func (e *Engine) Close() {}

// resetFastFail clears the fast-fail cache. Used by tests that probe many
// payloads from the same (empty) client IP in sequence.
func (e *Engine) resetFastFail() {
	e.fastFailMu.Lock()
	e.fastFail = map[string]int64{}
	e.fastFailMu.Unlock()
}

// ---------- small helpers ----------

// normalize decodes a value the way a downstream app would before acting on it,
// so rules match the payload the app actually sees rather than its wire form.
// It URL-decodes repeatedly (attackers double- or triple-encode to slip past
// single-pass decoders) and treats '+' as a space, stopping when the value
// stops changing or after maxDecodePasses to bound the work per request.
func normalize(s string) string {
	const maxDecodePasses = 3
	cur := s
	for i := 0; i < maxDecodePasses; i++ {
		dec, err := url.QueryUnescape(cur)
		if err != nil {
			// Malformed escapes: fall back to a decode that ignores the bad
			// sequence rather than giving up on the whole value.
			dec = strings.ReplaceAll(cur, "+", " ")
		}
		if dec == cur {
			break
		}
		cur = dec
	}
	return cur
}

func joinInputs(inputs map[string]string, capBytes int) string {
	var parts []string
	for _, key := range []string{"query", "body", "path", "headers", "cookies"} {
		if s, ok := inputs[key]; ok && s != "" {
			parts = append(parts, s)
		}
	}
	return clampStr(joinStrings(parts, " "), capBytes)
}

func joinStrings(parts []string, sep string) string {
	out := ""
	for i, p := range parts {
		if i > 0 {
			out += sep
		}
		out += p
	}
	return out
}

func clampStr(s string, n int) string {
	if len(s) > n {
		return s[:n]
	}
	return s
}

func indexByte(s string, b byte) int {
	for i := 0; i < len(s); i++ {
		if s[i] == b {
			return i
		}
	}
	return -1
}

func clientIP(v *reqview.View) string { return v.RemoteAddr }
