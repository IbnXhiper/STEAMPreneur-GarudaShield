package waf

import (
	"net/http"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

func newEngine() *Engine {
	return New(config.WAFConfig{
		Enabled: true, SQLi: true, XSS: true, CommandInjection: true,
		PathTraversal: true, LFI: true, RFI: true, Shellshock: true,
		Scanners: true, FastFailTTL: 2000,
	})
}

func inspectView(body, urlStr, ua string) *reqview.View {
	v := &reqview.View{
		Method:     "POST",
		URL:        urlStr,
		Path:       urlStr,
		Proto:      "HTTP/1.1",
		Header:     http.Header{},
		Body:       []byte(body),
		RemoteAddr: "",
	}
	if ua != "" {
		v.Header.Set("User-Agent", ua)
	}
	return v
}

func TestSQLiBlocked(t *testing.T) {
	e := newEngine()
	defer e.Close()
	r := e.InspectRequest(inspectView("id=1 UNION SELECT username FROM users", "/login", ""))
	if r.Allowed || len(r.MatchedRules) == 0 || r.MatchedRules[0] != "sqli-1" {
		t.Fatalf("sqli-1 expected, got %+v", r)
	}
	if r.Score < 50 {
		t.Fatalf("score must reach 50, got %d", r.Score)
	}
}

func TestXSSAndEncodedVariants(t *testing.T) {
	e := newEngine()
	defer e.Close()
	for _, body := range []string{
		`<script>alert(1)</script>`,
		`%3Cscript%3Ealert(1)%3C/script%3E`,
		// onerror(40)+alert(40)=80 → cumulative block
		`<img src=x onerror=alert(1)>`,
	} {
		r := e.InspectRequest(inspectView(body, "/c", ""))
		if r.Allowed {
			t.Fatalf("xss not caught for %q", body)
		}
	}
	// lone handler scores 40 < 50 → passes WITH score (exact v2 parity)
	r := e.InspectRequest(inspectView(`<img src=x onerror=steal()>`, "/c", ""))
	if !r.Allowed || r.Score != 40 {
		t.Fatalf("lone onerror must pass at score 40, got %+v", r)
	}
}

func TestCumulativeScoreAcrossRules(t *testing.T) {
	e := newEngine()
	defer e.Close()
	// matches ptrav-2 (50 alone) plus cmdi-1 → blocked regardless
	body := `; cat /etc/passwd`
	r := e.InspectRequest(inspectView(body, "/tools", ""))
	if r.Allowed {
		t.Fatalf("combo must block: %+v", r)
	}
	if len(r.MatchedRules) < 2 {
		t.Fatalf("expected ≥2 matched rules, got %v", r.MatchedRules)
	}
}

func TestScannerScoreBelowBlock(t *testing.T) {
	e := newEngine()
	defer e.Close()
	r := e.InspectRequest(inspectView("", "/", "nmap"))
	if !r.Allowed || r.Score != 30 {
		t.Fatalf("scanner scores 30 (pass): %+v", r)
	}
}

// TestRecentlyBlockedIsBookkeepingOnly pins that per-IP state recorded by the
// WAF never decides the verdict. Inspection must be per-request: a clean request
// from a previously-hostile IP still passes (no collateral damage on shared
// NAT/CGNAT addresses), and an attack from a previously-clean IP still blocks
// (no bypass window after one benign request).
func TestRecentlyBlockedIsBookkeepingOnly(t *testing.T) {
	e := newEngine()
	defer e.Close()

	attack := inspectView("", "/?q=%27%20OR%20%27%3D", "")
	attack.RemoteAddr = "3.3.3.3"
	if r := e.InspectRequest(attack); r.Allowed {
		t.Fatalf("sqli must block, got %+v", r)
	}
	if e.Stats().FastFailSize == 0 {
		t.Fatal("blocked IP should be recorded for stats/reputation")
	}

	clean := inspectView("", "/clean", "")
	clean.RemoteAddr = "3.3.3.3"
	if r := e.InspectRequest(clean); !r.Allowed {
		t.Fatalf("clean request from same IP must be judged on its own merits, got %+v", r)
	}

	// And the reverse: a clean request never buys an IP a bypass window.
	other := inspectView("", "/clean", "")
	other.RemoteAddr = "4.4.4.4"
	if r := e.InspectRequest(other); !r.Allowed {
		t.Fatalf("benign must pass, got %+v", r)
	}
	followUp := inspectView("", "/?q=%27%20OR%20%27%3D", "")
	followUp.RemoteAddr = "4.4.4.4"
	if r := e.InspectRequest(followUp); r.Allowed {
		t.Fatalf("attack after a benign request must still block, got %+v", r)
	}
}

func TestCustomRuleLifecycle(t *testing.T) {
	e := newEngine()
	defer e.Close()
	e.AddCustomRule(config.WAFRule{Name: "block-garuda", Pattern: `garudabadword`, Score: 60})
	if r := e.Inspect(map[string]string{"body": "say garudabadword now"}); r.Allowed {
		t.Fatal("custom rule must block")
	}
	e.RemoveCustomRule("block-garuda")
	if r := e.Inspect(map[string]string{"body": "say garudabadword now"}); !r.Allowed {
		t.Fatal("custom rule removal failed")
	}
}

func TestModuleToggle(t *testing.T) {
	e := newEngine()
	defer e.Close()
	e.SetModule("xss", false)
	if r := e.Inspect(map[string]string{"body": "<script>x</script>"}); !r.Allowed {
		t.Fatal("xss module disabled but still blocking")
	}
	e.SetModule("xss", true)
	if r := e.Inspect(map[string]string{"body": "<script>x</script>"}); r.Allowed {
		t.Fatal("xss re-enabled but not blocking")
	}
}

// probeView builds a GET/POST view with a realistic browser UA, splitting the
// path from the query the way reqview.New does for a live request.
func probeView(urlStr, body, contentType string) *reqview.View {
	path := urlStr
	for i := 0; i < len(urlStr); i++ {
		if urlStr[i] == '?' {
			path = urlStr[:i]
			break
		}
	}
	v := &reqview.View{
		Method: "POST", URL: urlStr, Path: path, Proto: "HTTP/1.1",
		Header: http.Header{}, Body: []byte(body),
	}
	v.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0 Safari/537.36")
	if contentType != "" {
		v.Header.Set("Content-Type", contentType)
	}
	return v
}

// TestEncodingBypassBlocked pins the normalization behaviour: a payload must be
// caught regardless of how many times it is URL-encoded, whether '+' is used
// for spaces, and whether it arrives in the query string or the body. These
// all bypassed the WAF before InspectRequest normalized its inputs.
func TestEncodingBypassBlocked(t *testing.T) {
	e := newEngine()
	defer e.Close()
	cases := []struct{ name, url, body string }{
		{"sqli-single-encoded", "/?q=%27%20OR%20%27%3D", ""},
		{"sqli-double-encoded", "/?q=%2527%2520OR%2520%2527%253D", ""},
		{"sqli-plus-as-space", "/?q=%27+OR+%27%3D", ""},
		{"xss-double-encoded", "/?q=%253Cscript%253Ealert(1)%253C/script%253E", ""},
		{"ptrav-double-encoded", "/%252e%252e%252f%252e%252e%252fetc%252fpasswd", ""},
		{"sqli-in-form-body", "/login", "user=admin&q=%27+OR+%27%3D"},
		{"sqli-double-enc-body", "/login", "q=%2527+OR+%2527%253D"},
		{"xss-in-form-body", "/comment", "q=%3Cscript%3Ealert(1)%3C/script%3E"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r := e.InspectRequest(probeView(c.url, c.body, ""))
			if r.Allowed {
				t.Fatalf("bypass: %s not blocked (score=%d matched=%v)", c.name, r.Score, r.MatchedRules)
			}
			e.resetFastFail()
		})
	}
}

// TestBenignTrafficNotBlocked guards the normalization above against
// over-blocking: decoding more aggressively must not turn ordinary traffic
// (quotes in names, encoded redirect URLs, prose with '&') into false positives.
func TestBenignTrafficNotBlocked(t *testing.T) {
	e := newEngine()
	defer e.Close()
	cases := []struct{ name, url, body, ct string }{
		{"root", "/", "", ""},
		{"search-plain", "/search?q=hello+world", "", ""},
		{"apostrophe-name", "/search?q=O%27Brien", "", ""},
		{"sentence-query", "/search?q=where+is+my+order+from+shop", "", ""},
		{"pagination", "/products?page=2&sort=price&dir=asc", "", ""},
		{"utm-params", "/?utm_source=google&utm_medium=cpc&utm_campaign=spring+sale", "", ""},
		{"json-login", "/api/login", `{"email":"a@b.com","password":"Str0ng!Pass"}`, "application/json"},
		{"json-address", "/api/profile", `{"address":"Jl. Merdeka No. 10, RT 5/RW 2","note":"pagar & taman"}`, "application/json"},
		{"form-signup", "/signup", "name=Budi+Santoso&email=budi%40mail.com&pass=abc12345", "application/x-www-form-urlencoded"},
		{"encoded-redirect", "/redirect?to=https%3A%2F%2Fexample.com%2Fpage%3Fa%3D1", "", ""},
		{"static-image", "/static/img/logo-2x.png", "", ""},
		{"dotted-filename", "/files/report.2024.final.pdf", "", ""},
		{"prose-with-ampersand", "/komentar", "isi=Saya+suka+produk+ini%2C+harganya+murah+%26+kualitas+bagus", "application/x-www-form-urlencoded"},
	}
	for _, c := range cases {
		t.Run(c.name, func(t *testing.T) {
			r := e.InspectRequest(probeView(c.url, c.body, c.ct))
			if !r.Allowed {
				t.Fatalf("false positive: %s blocked (score=%d matched=%v)", c.name, r.Score, r.MatchedRules)
			}
			e.resetFastFail()
		})
	}
}
