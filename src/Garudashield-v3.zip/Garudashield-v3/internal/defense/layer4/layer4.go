// Package layer4 is a Go port of v2's src/layers/layer4.js: bogon filtering,
// SYN/half-open tracking, connection-rate limiting, port-scan detection and
// UDP amplification heuristics.
package layer4

import (
	"net/netip"
	"sync"
	"sync/atomic"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

// Result mirrors v2's inspect return shape.
type Result struct {
	Allowed bool
	Reason  string
	Score   int
}

var pass = Result{Allowed: true}

// amplification ports table (v2 identical)
var ampPorts = map[int]string{
	53: "dns", 123: "ntp", 1900: "ssdp", 11211: "memcached",
	19: "chargen", 161: "snmp", 27015: "quake", 27036: "steam",
	5683: "coap", 20800: "callofduty",
}

// bogon CIDRs (superset matching v2 utils/ip.js intent)
var bogonCIDRs = func() []netip.Prefix {
	strs := []string{
		"0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8",
		"169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24",
		"192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24",
		"224.0.0.0/4", "240.0.0.0/4",
	}
	out := make([]netip.Prefix, 0, len(strs)+3)
	for _, s := range strs {
		if p, err := netip.ParsePrefix(s); err == nil {
			out = append(out, p)
		}
	}
	for _, s := range []string{"::1/128", "fe80::/10", "fc00::/7", "ff00::/8"} {
		if p, err := netip.ParsePrefix(s); err == nil {
			out = append(out, p)
		}
	}
	return out
}()

func IsBogon(ipStr string) bool {
	ip, err := netip.ParseAddr(ipStr)
	if err != nil {
		return false // unparseable handled elsewhere
	}
	if ip.Zone() != "" {
		return true
	}
	for _, p := range bogonCIDRs {
		if p.Contains(ip.Unmap()) {
			return true
		}
	}
	return false
}

type rateEntry struct {
	count int
	sec   int64
}

type scanTrack struct {
	ports       []int
	lastTime    time.Time
	count       int
	windowStart time.Time
}

type histEntry struct {
	at   time.Time
	port int
}

// Defender holds all L4 state.
type Defender struct {
	cfg config.Layer4Config

	mu          sync.RWMutex
	aggressive  bool
	halfOpen    map[string]map[string]struct{} // ip -> set("ip:port")
	connRate    map[string]*rateEntry
	scanTrack   map[string]*scanTrack
	connHistory map[string][]histEntry

	dropped     atomic.Uint64
	synFlood    atomic.Uint64
	bogonDrop   atomic.Uint64
	portScan    atomic.Uint64
	ampDrop     atomic.Uint64
	cleanupOnce sync.Once
	done        chan struct{}
}

func New(cfg config.Layer4Config) *Defender {
	if cfg.MaxHalfOpenPerIP <= 0 {
		cfg.MaxHalfOpenPerIP = 10
	}
	if cfg.MaxConnPerSecPerIP <= 0 {
		cfg.MaxConnPerSecPerIP = 50
	}
	if cfg.MaxConnPerIP <= 0 {
		cfg.MaxConnPerIP = 100
	}
	d := &Defender{
		cfg:         cfg,
		halfOpen:    make(map[string]map[string]struct{}),
		connRate:    make(map[string]*rateEntry),
		scanTrack:   make(map[string]*scanTrack),
		connHistory: make(map[string][]histEntry),
		done:        make(chan struct{}),
	}
	go d.cleanupLoop()
	return d
}

// InspectConnection runs bogon → port-scan → SYN-flood checks (v2 order).
func (d *Defender) InspectConnection(ip string, port int) Result {
	if d.cfg.BogonFilter && IsBogon(ip) {
		d.bogonDrop.Add(1)
		d.dropped.Add(1)
		return Result{Allowed: false, Reason: "bogon-ip", Score: 30}
	}
	if d.cfg.PortScanDetection && d.detectPortScan(ip, port) {
		d.portScan.Add(1)
		d.dropped.Add(1)
		return Result{Allowed: false, Reason: "port-scan", Score: 25}
	}
	if d.cfg.SynFloodProtection && !d.trackSyn(ip, port) {
		d.synFlood.Add(1)
		d.dropped.Add(1)
		return Result{Allowed: false, Reason: "syn-flood", Score: 20}
	}
	return pass
}

// InspectUDP applies bogon + amplification heuristics to a UDP datagram.
func (d *Defender) InspectUDP(ip string, port int, size int) Result {
	if d.cfg.BogonFilter && IsBogon(ip) {
		d.bogonDrop.Add(1)
		d.dropped.Add(1)
		return Result{Allowed: false, Reason: "bogon-ip", Score: 30}
	}
	if d.cfg.UDPAmplificationProtection {
		if proto, ok := ampPorts[port]; ok && size > 512 {
			d.ampDrop.Add(1)
			d.dropped.Add(1)
			return Result{Allowed: false, Reason: "udp-amplification-" + proto, Score: 25}
		}
		if size > 1400 {
			d.ampDrop.Add(1)
			d.dropped.Add(1)
			return Result{Allowed: false, Reason: "large-udp", Score: 15}
		}
	}
	return pass
}

func (d *Defender) trackSyn(ip string, port int) bool {
	now := time.Now()
	sec := now.Unix()

	d.mu.Lock()
	defer d.mu.Unlock()

	set := d.halfOpen[ip]
	if set == nil {
		set = make(map[string]struct{})
		d.halfOpen[ip] = set
	}
	if len(set) >= d.cfg.MaxHalfOpenPerIP {
		return false
	}
	key := ip + ":" + itoa(port)
	set[key] = struct{}{}

	rate := d.connRate[ip]
	if rate == nil || rate.sec != sec {
		rate = &rateEntry{sec: sec}
		d.connRate[ip] = rate
	}
	rate.count++
	if rate.count > d.cfg.MaxConnPerSecPerIP {
		delete(set, key)
		return false
	}

	hist := append(d.connHistory[ip], histEntry{at: now, port: port})
	if len(hist) > 100 {
		hist = hist[len(hist)-100:]
	}
	d.connHistory[ip] = hist
	return true
}

func (d *Defender) detectPortScan(ip string, port int) bool {
	now := time.Now()
	d.mu.Lock()
	defer d.mu.Unlock()

	tr := d.scanTrack[ip]
	if tr == nil || now.Sub(tr.lastTime) > 10*time.Second {
		tr = &scanTrack{lastTime: now, windowStart: now}
		d.scanTrack[ip] = tr
	}
	tr.ports = append(tr.ports, port)
	if len(tr.ports) > 30 {
		tr.ports = tr.ports[len(tr.ports)-30:]
	}
	tr.lastTime = now

	if now.Sub(tr.windowStart) > time.Second {
		tr.count = 0
		tr.windowStart = now
	}
	tr.count++
	if tr.count > 50 {
		return true
	}
	if len(tr.ports) >= 5 {
		// sorted copy; look for ≥5 strictly consecutive ascending ports
		sorted := make([]int, len(tr.ports))
		copy(sorted, tr.ports)
		sortInts(sorted)
		seq := 1
		for i := 1; i < len(sorted); i++ {
			if sorted[i] == sorted[i-1]+1 {
				seq++
				if seq >= 5 {
					return true
				}
			} else {
				seq = 1
			}
		}
	}
	return false
}

// RecordEstablished / RecordClosed mirror v2 connection accounting hooks.
func (d *Defender) RecordEstablished(ip string) {}

func (d *Defender) RecordClosed(ip string) {
	d.mu.Lock()
	if set, ok := d.halfOpen[ip]; ok {
		for k := range set {
			if len(k) > len(ip)+1 { // startsWith(ip+":")
				prefix := ip + ":"
				if k[:len(prefix)] == prefix {
					delete(set, k)
				}
			}
		}
		if len(set) == 0 {
			delete(d.halfOpen, ip)
		}
	}
	d.mu.Unlock()
}

func (d *Defender) cleanupLoop() {
	t := time.NewTicker(15 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-d.done:
			return
		case now := <-t.C:
			d.mu.Lock()
			for ip, set := range d.halfOpen {
				if len(set) == 0 {
					delete(d.halfOpen, ip)
				}
			}
			for ip, tr := range d.scanTrack {
				if now.Sub(tr.lastTime) > time.Minute {
					delete(d.scanTrack, ip)
				}
			}
			sec := now.Unix()
			for ip, r := range d.connRate {
				if r.sec < sec-2 {
					delete(d.connRate, ip)
				}
			}
			cutoff := now.Add(-10 * time.Second)
			for ip, h := range d.connHistory {
				i := 0
				for i < len(h) && h[i].at.Before(cutoff) {
					i++
				}
				if i == len(h) {
					delete(d.connHistory, ip)
				} else if i > 0 {
					d.connHistory[ip] = h[i:]
				}
			}
			d.mu.Unlock()
		}
	}
}

// Close stops background loops.
func (d *Defender) Close() {
	d.cleanupOnce.Do(func() { close(d.done) })
}

// SetAggressive toggles aggressive mode (v2 flood thresholds tighten here;
// layer-4 currently uses the flag to shorten the SYN-half-open window).
func (d *Defender) SetAggressive(on bool) {
	d.mu.Lock()
	d.aggressive = on
	d.mu.Unlock()
}

// ---------- stats ----------

type Stats struct {
	HalfOpen     int    `json:"halfOpen"`
	SynFlood     uint64 `json:"synFloodCount"`
	BogonDrops   uint64 `json:"bogonDropCount"`
	PortScans    uint64 `json:"portScanCount"`
	AmpDrops     uint64 `json:"ampDropCount"`
	TotalDropped uint64 `json:"totalDropped"`
}

func (d *Defender) Stats() Stats {
	d.mu.RLock()
	halfOpen := len(d.halfOpen)
	d.mu.RUnlock()
	return Stats{
		HalfOpen:     halfOpen,
		SynFlood:     d.synFlood.Load(),
		BogonDrops:   d.bogonDrop.Load(),
		PortScans:    d.portScan.Load(),
		AmpDrops:     d.ampDrop.Load(),
		TotalDropped: d.dropped.Load(),
	}
}

func itoa(n int) string {
	if n == 0 {
		return "0"
	}
	var buf [20]byte
	i := len(buf)
	neg := n < 0
	if neg {
		n = -n
	}
	for n > 0 {
		i--
		buf[i] = byte('0' + n%10)
		n /= 10
	}
	if neg {
		i--
		buf[i] = '-'
	}
	return string(buf[i:])
}

func sortInts(a []int) {
	for i := 1; i < len(a); i++ {
		for j := i; j > 0 && a[j] < a[j-1]; j-- {
			a[j], a[j-1] = a[j-1], a[j]
		}
	}
}
