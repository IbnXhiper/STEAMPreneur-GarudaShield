package layer4

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func testCfg() config.Layer4Config {
	return config.Layer4Config{
		Enabled: true, SynFloodProtection: true,
		MaxHalfOpenPerIP: 5, MaxConnPerSecPerIP: 50, MaxConnPerIP: 100,
		BogonFilter: true, PortScanDetection: true, UDPAmplificationProtection: true,
	}
}

func TestBogonFilter(t *testing.T) {
	d := New(testCfg())
	defer d.Close()

	if r := d.InspectConnection("10.1.2.3", 80); r.Allowed {
		t.Fatal("private IP should be bogon-dropped")
	}
	if r := d.InspectConnection("8.8.8.8", 80); !r.Allowed {
		t.Fatalf("public IP should pass: %+v", r)
	}
	if !IsBogon("192.168.1.1") || IsBogon("146.190.104.237") {
		t.Fatal("bogon classification wrong")
	}
}

func TestSynFloodByRate(t *testing.T) {
	cfg := testCfg()
	cfg.MaxConnPerSecPerIP = 3
	d := New(cfg)
	defer d.Close()

	for i := 0; i < 3; i++ {
		if r := d.InspectConnection("9.8.7.6", 10000+i); !r.Allowed {
			t.Fatalf("conn %d should pass", i)
		}
	}
	r := d.InspectConnection("9.8.7.6", 10003)
	if r.Allowed || r.Reason != "syn-flood" {
		t.Fatalf("want syn-flood denial, got %+v", r)
	}
}

func TestPortScanSequential(t *testing.T) {
	d := New(testCfg())
	defer d.Close()

	ip := "6.6.6.6"
	// first hit primes the tracker and records port; hits 2..5 build the run
	// of 5 consecutive ports (2000..2004) → detected on the 5th.
	var last Result
	for p := 2000; p <= 2004; p++ {
		last = d.InspectConnection(ip, p)
	}
	if last.Allowed || last.Reason != "port-scan" {
		t.Fatalf("sequential scan not detected: %+v", last)
	}
}

func TestUDPAmp(t *testing.T) {
	d := New(testCfg())
	defer d.Close()

	if r := d.InspectUDP("4.4.4.4", 53, 600); r.Allowed {
		t.Fatal("DNS payload >512 must be dropped as amplification")
	}
	if r := d.InspectUDP("4.4.4.4", 12345, 1500); r.Allowed || r.Reason != "large-udp" {
		t.Fatalf("large-udp expected, got %+v", r)
	}
	if r := d.InspectUDP("4.4.4.4", 53, 128); !r.Allowed {
		t.Fatalf("small DNS reply should pass, got %+v", r)
	}
}
