package layer4

import (
	"net/netip"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestBogonIPv6 verifies IPv6 bogon detection: loopback, link-local, ULA,
// multicast and IPv4-mapped private ranges must be flagged; public IPv6 must
// pass (gap #16: IPv6 path was untested).
func TestBogonIPv6(t *testing.T) {
	cases := []struct {
		ip    string
		bogon bool
	}{
		{"::1", true},                   // loopback
		{"fe80::1", true},               // link-local
		{"fc00::1", true},               // ULA
		{"ff02::1", true},               // multicast
		{"::ffff:192.168.1.1", true},    // IPv4-mapped private
		{"::ffff:127.0.0.1", true},      // IPv4-mapped loopback
		{"2001:db8::1", false},          // documentation range passes (public-space semantics)
		{"2606:4700:4700::1111", false}, // public IPv6 (Cloudflare DNS)
		{"2001:4860:4860::8888", false}, // public IPv6 (Google DNS)
		{"1.2.3.4", false},              // public IPv4 unaffected
		{"192.168.1.1", true},           // private IPv4 unaffected
	}
	for _, c := range cases {
		if got := IsBogon(c.ip); got != c.bogon {
			t.Errorf("IsBogon(%q) = %v, want %v", c.ip, got, c.bogon)
		}
	}
}

// TestIPv6HalfOpenTracking verifies SYN/half-open tracking keys correctly on
// IPv6 addresses (no cross-contamination with IPv4 or other IPv6 hosts).
func TestIPv6HalfOpenTracking(t *testing.T) {
	d := New(config6())
	defer d.Close()

	// Multiple half-open SYNs from one IPv6 host: distinct ports fill the
	// half-open set (default max 10) until the IP is blocked.
	blocked := false
	for port := 1; port <= 1000 && !blocked; port++ {
		if !d.trackSyn("2001:db8::501", port) {
			blocked = true
		}
	}
	if !blocked {
		t.Fatal("IPv6 host exceeding half-open budget must be blocked")
	}
	// A different IPv6 host is unaffected.
	if !d.trackSyn("2001:db8::502", 443) {
		t.Fatal("separate IPv6 host must have its own budget")
	}
	// The blocked host stays blocked on any port (per-IP budget exhausted).
	if d.trackSyn("2001:db8::501", 9999) {
		t.Fatal("exhausted IPv6 host must stay blocked")
	}
}

func TestIPv6PortScanDetection(t *testing.T) {
	d := New(config6())
	defer d.Close()

	// Rapid unique ports from one IPv6 host = scan.
	scan := false
	for port := 1; port <= 200 && !scan; port++ {
		if d.detectPortScan("2001:db8::601", port) {
			scan = true
		}
	}
	if !scan {
		t.Fatal("IPv6 port scan must be detected")
	}
	if !IsBogonViaParse("fe80::dead") {
		t.Fatal("link-local must be bogon")
	}
}

func IsBogonViaParse(s string) bool { return IsBogon(s) }

func config6() config.Layer4Config {
	return config.Layer4Config{
		BogonFilter:                true,
		SynFloodProtection:         true,
		PortScanDetection:          true,
		UDPAmplificationProtection: true,
	}
}

// compile-time: netip used by production code, keep the import honest here.
var _ = netip.ParseAddr
