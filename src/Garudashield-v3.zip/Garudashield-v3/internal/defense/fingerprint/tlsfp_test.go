package fingerprint

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func TestJA3LiteStable(t *testing.T) {
	a := tlsFPInput{Version: "TLS 1.3", Cipher: "TLS_AES_128_GCM_SHA256", Curve: "X25519", ALPN: "h2"}
	b := tlsFPInput{Version: "TLS 1.3", Cipher: "TLS_AES_128_GCM_SHA256", Curve: "X25519", ALPN: "h2"}
	if ja3Lite(a) != ja3Lite(b) {
		t.Fatal("same TLS params must hash identically")
	}
	c := tlsFPInput{Version: "TLS 1.3", Cipher: "TLS_AES_256_GCM_SHA384", Curve: "X25519", ALPN: "h2"}
	if ja3Lite(a) == ja3Lite(c) {
		t.Fatal("different ciphers must hash differently")
	}
	if ja3Lite(tlsFPInput{}) != "" {
		t.Fatal("empty TLS info must yield empty hash")
	}
}

func TestTLSSuspiciousParams(t *testing.T) {
	cases := []struct {
		in   tlsFPInput
		want bool
	}{
		{tlsFPInput{Version: "TLS 1.3", Cipher: "x", Curve: "y", ALPN: "h2"}, false},
		{tlsFPInput{Version: "TLS 1.0", Cipher: "x", Curve: "y", ALPN: "h2"}, true}, // legacy browser-refused TLS
		{tlsFPInput{Version: "TLS 1.1", Cipher: "x", Curve: "y", ALPN: "h2"}, true}, // legacy
		{tlsFPInput{Version: "TLS 1.3", Cipher: "x", Curve: "y", ALPN: ""}, true},   // no ALPN: raw TLS client
		{tlsFPInput{Version: "", Cipher: "x", Curve: "y", ALPN: ""}, false},         // no TLS info: neutral
	}
	for i, c := range cases {
		if got := tlsSuspiciousParams(c.in); got != c.want {
			t.Fatalf("case %d: got %v want %v (%+v)", i, got, c.want, c.in)
		}
	}
}

func TestAnalyzeUsesTLSState(t *testing.T) {
	f := New(config.FingerprintConfig{})
	f.SetTLSState(&tlsFPInput{Version: "TLS 1.3", Cipher: "TLS_AES_128_GCM_SHA256", Curve: "X25519", ALPN: "h2"})
	res := f.Analyze("1.2.3.4", "Mozilla/5.0 Chrome/126.0", nil, "TLS 1.3")
	if res.JA3Lite == "" {
		t.Fatal("JA3Lite must be computed from TLS state")
	}
	if res.TLSSuspicious {
		t.Fatal("modern browser-like TLS must not be suspicious")
	}
	// A raw TLS client without ALPN flags suspicious.
	f2 := New(config.FingerprintConfig{})
	f2.SetTLSState(&tlsFPInput{Version: "TLS 1.2", Cipher: "TLS_RSA_WITH_AES_128_CBC_SHA", Curve: "", ALPN: ""})
	res2 := f2.Analyze("1.2.3.4", "python-requests/2.0", nil, "TLS 1.2")
	if !res2.TLSSuspicious {
		t.Fatal("no-ALPN TLS must flag suspicious")
	}
	if res2.JA3Lite == res.JA3Lite {
		t.Fatal("different stacks must produce different JA3Lite")
	}
}
