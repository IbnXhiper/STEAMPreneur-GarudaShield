// Package fingerprint ports v2's src/engine/fingerprint.js: HTTP/TLS
// fingerprinting, headless & automation detection, header/browser consistency
// scoring, with a 5 s per-IP cache.
package fingerprint

import (
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

type Result struct {
	HTTPHash         string   `json:"httpFingerprint"`
	TLSProto         string   `json:"tlsProtocol"`
	JA3Lite          string   `json:"ja3Hash"`
	TLSSuspicious    bool     `json:"tlsSuspicious"`
	IsHeadless       bool     `json:"isHeadless"`
	IsAutomated      bool     `json:"isAutomated"`
	ConsistencyScore int      `json:"consistencyScore"`
	Anomalies        []string `json:"anomalies"`
}

type cacheEntry struct {
	fp    Result
	until time.Time
}

type Fingerprinter struct {
	cfg   config.FingerprintConfig
	cache sync.Map // ip -> cacheEntry

	knownFP   sync.Map
	totalSeen atomicCounter
	closeOnce sync.Once
	done      chan struct{}

	// tlsState carries per-request TLS metadata set by the edge handler
	// before Analyze runs (single-threaded per request, no lock needed).
	tlsState *tlsFPInput
}

// SetTLSState attaches the connection's TLS metadata for the next Analyze
// call. Call this from the edge handler per request (r.TLS derived).
func (f *Fingerprinter) SetTLSState(in *tlsFPInput) { f.tlsState = in }

func New(cfg config.FingerprintConfig) *Fingerprinter {
	f := &Fingerprinter{cfg: cfg, done: make(chan struct{})}
	go f.cleanupLoop()
	return f
}

// Analyze computes (or fetches cached) fingerprint for the request.
// tlsState may be nil for plaintext hops behind a TLS terminator.
func (f *Fingerprinter) Analyze(ip, userAgent string, h http.Header, tlsProto string) Result {
	if ip != "" {
		if v, ok := f.cache.Load(ip); ok {
			e := v.(cacheEntry)
			if time.Now().Before(e.until) {
				return e.fp
			}
		}
	}
	res := f.compute(userAgent, h, tlsProto)
	if ip != "" {
		f.cache.Store(ip, cacheEntry{fp: res, until: time.Now().Add(5 * time.Second)})
	}
	return res
}

func (f *Fingerprinter) compute(userAgent string, h http.Header, tlsIn string) Result {
	ua := strings.ToLower(userAgent)

	var anomalies []string
	score := 100

	headless := false
	automated := false
	{ // v2 runs these checks unconditionally inside fingerprint()
		for _, sig := range []string{"headless", "phantom", "puppeteer", "selenium", "webdriver", "playwright", "cypress", "electron", "jsdom", "nock"} {
			if strings.Contains(ua, sig) {
				headless = true
				break
			}
		}
		_, hasSecUA := h["Sec-Ch-Ua"]
		_, hasPlatform := h["Sec-Ch-Ua-Platform"]
		_, hasAcceptLang := h["Accept-Language"]
		_, hasAccept := h["Accept"]
		if hasSecUA && !hasPlatform {
			headless = true
		}
		if userAgent != "" && !hasAcceptLang && !hasAccept {
			headless = true
		}
	}
	{
		autoSignals := []string{"python", "curl", "wget", "go-http-client", "java/", "ruby", "perl", "libwww", "httpclient", "okhttp", "scrapy", "axios", "requests", "aiohttp", "httpx", "postman", "insomnia", "rest-client", "httpie"}
		for _, sig := range autoSignals {
			if strings.Contains(ua, sig) {
				automated = true
				break
			}
		}
		proxyHeaders := 0
		for _, name := range []string{"X-Forwarded-For", "X-Real-Ip", "Via", "X-Requested-With"} {
			if _, ok := h[name]; ok {
				proxyHeaders++
			}
		}
		if proxyHeaders >= 3 {
			automated = true
		}
	}

	tlsOut, ja3 := "tcp", ""
	suspicious := false
	if tlsIn != "" {
		tlsOut = tlsIn
	}
	if f.tlsState != nil {
		// Real TLS metadata (wired from the connection state by the edge).
		in := tlsFPInput{Version: tlsIn, Cipher: f.tlsState.Cipher, Curve: f.tlsState.Curve, ALPN: f.tlsState.ALPN}
		ja3 = ja3Lite(in)
		suspicious = tlsSuspiciousParams(in)
	} else if tlsIn != "" {
		// Fallback: hash the protocol string alone.
		sum := sha256.Sum256([]byte("tls:" + tlsIn))
		ja3 = hex.EncodeToString(sum[:])[:16]
	}
	if suspicious {
		anomalies = append(anomalies, "suspicious-tls")
		score -= 25
	}
	if headless {
		anomalies = append(anomalies, "headless-browser")
		score -= 40
	}
	if automated {
		anomalies = append(anomalies, "automated-tool")
		score -= 30
	}

	// header consistency (×10 each)
	if strings.Contains(ua, "mobile") && h.Get("Sec-Ch-Ua-Mobile") == "?0" {
		anomalies = append(anomalies, "ua-mobile-mismatch")
	}
	if !strings.Contains(ua, "mobile") && h.Get("Sec-Ch-Ua-Mobile") == "?1" {
		anomalies = append(anomalies, "ua-desktop-mismatch")
	}
	if strings.Contains(ua, "chrome") && h.Get("Sec-Ch-Ua") == "" {
		anomalies = append(anomalies, "chrome-no-sec-ua")
	}
	if l := len(userAgent); l > 0 && (l < 30 || l > 500) {
		anomalies = append(anomalies, "short-user-agent")
	}
	headerAnoms := countSuffix(anomalies, []string{"ua-mobile-mismatch", "ua-desktop-mismatch", "chrome-no-sec-ua", "short-user-agent"})
	score -= headerAnoms * 10

	// browser consistency (×15)
	secUA := strings.ToLower(h.Get("Sec-Ch-Ua"))
	if strings.Contains(ua, "chrome") && strings.Contains(ua, "safari") && !strings.Contains(ua, "chromium") {
		if secUA != "" && !strings.Contains(secUA, "chrome") && !strings.Contains(secUA, "chromium") {
			anomalies = append(anomalies, "sec-ua-browser-mismatch")
			score -= 15
		}
	}

	if score < 0 {
		score = 0
	}
	if score > 100 {
		score = 100
	}

	// http fingerprint hash over stable header set
	parts := make([]string, 0, 10)
	appendPart := func(tag, val string, maxLen int) {
		if val != "" {
			if maxLen > 0 && len(val) > maxLen {
				val = val[:maxLen]
			}
			parts = append(parts, tag+":"+val)
		}
	}
	appendPart("ua", userAgent, 50)
	appendPart("ac", h.Get("Accept"), 30)
	appendPart("al", h.Get("Accept-Language"), 20)
	appendPart("ae", h.Get("Accept-Encoding"), 0)
	appendPart("scu", h.Get("Sec-Ch-Ua"), 30)
	appendPart("scp", h.Get("Sec-Ch-Ua-Platform"), 0)
	appendPart("scm", h.Get("Sec-Ch-Ua-Mobile"), 0)
	raw := strings.Join(parts, "|")
	httpSum := sha256.Sum256([]byte(raw))

	f.totalSeen.add(1)
	return Result{
		HTTPHash:         hex.EncodeToString(httpSum[:])[:16],
		TLSProto:         tlsOut,
		JA3Lite:          ja3,
		TLSSuspicious:    suspicious,
		IsHeadless:       headless,
		IsAutomated:      automated,
		ConsistencyScore: score,
		Anomalies:        anomalies,
	}
}

func countSuffix(all []string, set []string) int {
	n := 0
	for _, a := range all {
		for _, s := range set {
			if a == s {
				n++
			}
		}
	}
	return n
}

func (f *Fingerprinter) cleanupLoop() {
	t := time.NewTicker(time.Minute)
	defer t.Stop()
	for {
		select {
		case <-f.done:
			return
		case <-t.C:
			now := time.Now()
			f.cache.Range(func(k, v any) bool {
				e := v.(cacheEntry)
				if now.After(e.until) {
					f.cache.Delete(k)
				}
				return true
			})
		}
	}
}

func (f *Fingerprinter) Close() {
	f.closeOnce.Do(func() { close(f.done) })
}

type Stats struct {
	KnownTLS      int   `json:"knownTLS"`
	CacheSize     int   `json:"cacheSize"`
	TotalAnalyzed int64 `json:"totalAnalyzed"`
}

func (f *Fingerprinter) Stats() Stats {
	n := 0
	f.cache.Range(func(_, _ any) bool { n++; return true })
	return Stats{CacheSize: n, TotalAnalyzed: int64(f.totalSeen.get())}
}

type atomicCounter struct {
	mu sync.Mutex
	v  int64
}

func (c *atomicCounter) add(n int64) {
	c.mu.Lock()
	c.v += n
	c.mu.Unlock()
}

func (c *atomicCounter) get() int64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.v
}
