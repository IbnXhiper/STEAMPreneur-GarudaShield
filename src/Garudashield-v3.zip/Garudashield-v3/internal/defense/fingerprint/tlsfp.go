// TLS ClientHello fingerprinting (JA3-lite). Go's crypto/tls does not expose
// the raw ClientHello, so a true JA3 (md5 of version,ciphers,extensions,...)
// is impossible without utls or a BPF tap. What we CAN fingerprint without
// external deps: the negotiated TLS version, cipher suite, and the server's
// view of curve/alpn — enough to distinguish browser vs tooling TLS stacks
// and to keep a stable per-stack hash for reputation correlation.
package fingerprint

import (
	"crypto/sha256"
	"encoding/hex"
	"strings"
)

// tlsFPInput carries the TLS metadata observable server-side. All fields are
// optional; empty strings are excluded from the hash.
type tlsFPInput struct {
	Version string // e.g. "TLS 1.3" (tls.ConnectionState.NegotiatedProtocol-style)
	Cipher  string // e.g. "TLS_AES_128_GCM_SHA256"
	Curve   string // key-exchange group, e.g. "X25519"
	ALPN    string // negotiated application protocol, e.g. "h2"
}

// ja3Lite computes a stable 16-hex-char digest over the observable TLS
// parameters. Same stack + same params -> same hash; a flood of distinct
// hashes from one IP is a botnet signal (per-IP uniqueness is checked by the
// reputation layer via knownFP).
func ja3Lite(in tlsFPInput) string {
	parts := make([]string, 0, 4)
	for _, p := range []struct{ tag, val string }{
		{"v", in.Version},
		{"c", in.Cipher},
		{"k", in.Curve},
		{"a", in.ALPN},
	} {
		if p.val != "" {
			parts = append(parts, p.tag+":"+p.val)
		}
	}
	if len(parts) == 0 {
		return ""
	}
	sum := sha256.Sum256([]byte(strings.Join(parts, "|")))
	return hex.EncodeToString(sum[:])[:16]
}

// tlsSuspiciousParams flags TLS stacks that are common in attack tooling:
//   - old TLS versions (<=1.1) that browsers refuse but scripts still use
//   - missing ALPN on an HTTP port (raw TLS clients, scanners)
func tlsSuspiciousParams(in tlsFPInput) bool {
	if in.Version == "" {
		return false // no TLS info: never suspicious by itself
	}
	if strings.Contains(in.Version, "1.0") || strings.Contains(in.Version, "1.1") {
		return true
	}
	if in.ALPN == "" {
		return true
	}
	return false
}
