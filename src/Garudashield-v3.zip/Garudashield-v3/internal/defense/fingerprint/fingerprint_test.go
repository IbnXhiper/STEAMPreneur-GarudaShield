package fingerprint

import (
	"net/http"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func reqWith(ua string, setHeaders map[string]string) *http.Request {
	r, _ := http.NewRequest("GET", "http://x/", nil)
	if ua != "" {
		r.Header.Set("User-Agent", ua)
	}
	for k, v := range setHeaders {
		r.Header.Set(k, v)
	}
	return r
}

const chromeUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"

func TestCleanBrowserFullScore(t *testing.T) {
	f := New(config.FingerprintConfig{Enabled: true, HeadlessDetection: true})
	defer f.Close()
	r := reqWith(chromeUA, map[string]string{
		"Accept":             "text/html",
		"Accept-Language":    "en-US,en;q=0.9",
		"Sec-Ch-Ua":          `"Chromium";v="126"`,
		"Sec-Ch-Ua-Platform": `"Windows"`,
		"Sec-Ch-Ua-Mobile":   "?0",
	})
	res := f.Analyze("1.1.1.1", r.Header.Get("User-Agent"), r.Header, "")
	if res.IsHeadless || res.IsAutomated {
		t.Fatalf("clean browser flagged: %+v", res)
	}
	if res.ConsistencyScore != 100 {
		t.Fatalf("want score 100, got %d (%v)", res.ConsistencyScore, res.Anomalies)
	}
}

func TestPuppeteerDetected(t *testing.T) {
	f := New(config.FingerprintConfig{HeadlessDetection: true})
	defer f.Close()
	r := reqWith("Mozilla/5.0 (X11; Linux x86_64) HeadlessChrome/126 Puppeteer", nil)
	res := f.Analyze("2.2.2.2", r.Header.Get("User-Agent"), r.Header, "")
	if !res.IsHeadless {
		t.Fatal("puppeteer UA must be headless")
	}
	if res.ConsistencyScore > 60 {
		t.Fatalf("headless must reduce score ≤60, got %d", res.ConsistencyScore)
	}
}

func TestPythonRequestsAutomated(t *testing.T) {
	f := New(config.FingerprintConfig{})
	defer f.Close()
	r := reqWith("python-requests/2.31.0", nil)
	res := f.Analyze("3.3.3.3", r.Header.Get("User-Agent"), r.Header, "")
	if !res.IsAutomated {
		t.Fatal("python-requests must be automated")
	}
	if res.ConsistencyScore > 70 {
		t.Fatalf("automated must reduce score ≤70, got %d", res.ConsistencyScore)
	}
}

func TestCacheHitWithinTTL(t *testing.T) {
	f := New(config.FingerprintConfig{})
	defer f.Close()
	first := f.Analyze("4.4.4.4", chromeUA, reqWith(chromeUA, nil).Header, "")
	second := f.Analyze("4.4.4.4", chromeUA, reqWith(chromeUA, nil).Header, "")
	if first.HTTPHash != second.HTTPHash {
		t.Fatal("cache miss within TTL window")
	}
	if f.Stats().TotalAnalyzed != 1 {
		t.Fatalf("analyzed once expected, got %d", f.Stats().TotalAnalyzed)
	}
}
