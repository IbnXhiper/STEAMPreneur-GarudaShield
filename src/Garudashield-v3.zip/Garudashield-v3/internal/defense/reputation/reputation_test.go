package reputation

import (
	"fmt"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

// TestCleanNeighbourNotBlockedBySubnet reproduces the DDoS-time false positive:
// an attacker (or a botnet) poisons a /24 and its parent /16, and a completely
// clean neighbour in the same subnet must NOT be hard-blocked nor challenged on
// reputation alone.
func TestCleanNeighbourNotBlockedBySubnet(t *testing.T) {
	e := newEngine()
	defer e.Close()
	for i := 0; i < 6; i++ {
		e.Adjust(fmt.Sprintf("198.51.100.%d", 10+i), 35, "attack")
	}
	victim := "198.51.100.200"
	if e.OwnScore(victim) != 0 {
		t.Fatalf("precondition: victim must be clean, own=%d", e.OwnScore(victim))
	}
	if e.GetScore(victim) < e.GetThreshold() {
		t.Fatalf("precondition: subnet should be poisoned, blended=%d", e.GetScore(victim))
	}
	if e.ShouldBlock(victim) {
		t.Fatalf("FALSE POSITIVE: clean neighbour blocked via subnet (blended=%d)", e.GetScore(victim))
	}
	if e.ShouldChallenge(victim) {
		t.Fatalf("FALSE POSITIVE: clean neighbour challenged via subnet (blended=%d)", e.GetScore(victim))
	}
}

// TestCorroboratedNeighbourStillBlocked verifies the anti-false-positive guard
// does not disable subnet-based enforcement for an IP that already carries its
// own evidence.
func TestCorroboratedNeighbourStillBlocked(t *testing.T) {
	e := newEngine()
	defer e.Close()
	for i := 0; i < 6; i++ {
		e.Adjust(fmt.Sprintf("198.51.100.%d", 10+i), 35, "attack")
	}
	nb := "198.51.100.77"
	e.Adjust(nb, 50, "attack") // own evidence but below the block threshold
	if got := e.OwnScore(nb); got != 50 {
		t.Fatalf("own=%d, want 50", got)
	}
	if !e.ShouldBlock(nb) {
		t.Fatalf("corroborated neighbour must still block (own=%d blended=%d)", e.OwnScore(nb), e.GetScore(nb))
	}
}

func newEngine() *Engine {
	return New(config.Reputation{
		Enabled: true, MaxScore: 100, MinScore: -100,
		BlockThreshold: 80, ChallengeThreshold: 40,
		DecayRate: 0.95, SubnetScores: true,
	})
}

func TestAdjustClampAndThresholds(t *testing.T) {
	e := newEngine()
	defer e.Close()
	ip := "203.0.113.50"
	e.Adjust(ip, 45, "test") // 45 → challenge zone
	if e.GetScore(ip) != 45 || !e.ShouldChallenge(ip) {
		t.Fatalf("score/threshold wrong: %d", e.GetScore(ip))
	}
	e.Adjust(ip, 1000, "test") // clamp to 100
	if e.GetScore(ip) != 100 || !e.ShouldBlock(ip) {
		t.Fatalf("clamp failed: %d", e.GetScore(ip))
	}
}

func TestSubnetInfluence(t *testing.T) {
	e := newEngine()
	defer e.Close()
	bad := "198.51.100.10"
	nb := "198.51.100.77"
	e.Adjust(bad, 90, "attack")
	if s := e.GetScore(nb); s < 45 {
		t.Fatalf("neighbor in /24 should inherit ≥45 via subnet score, got %d", s)
	}
}

func TestDecayReducesScores(t *testing.T) {
	// v2 quirk preserved: subnet:/reason: keys are EXEMPT from decay.
	e := newEngine()
	defer e.Close()
	ip := "203.0.113.99"
	e.Adjust(ip, 100, "x")
	e.Decay() // ip 100→95; subnet stays 50
	if got := e.GetScore(ip); got != 95 {
		t.Fatalf("want 95 after decay, got %d", got)
	}
	for i := 0; i < 85; i++ { // ip residue <2 gets deleted…
		e.Decay()
	}
	// …but the /24 subnet score (50) survives forever in v2 semantics.
	if got := e.GetScore(ip); got != 50 {
		t.Fatalf("v2 parity: subnet score must persist undecayed, got %d", got)
	}

	// without subnet influence the pure-IP decay path fully cleans up
	e2 := New(config.Reputation{MaxScore: 100, MinScore: -100,
		BlockThreshold: 80, ChallengeThreshold: 40, DecayRate: 0.95, SubnetScores: false})
	defer e2.Close()
	e2.Adjust("203.0.113.98", 100, "x")
	for i := 0; i < 85; i++ {
		e2.Decay()
	}
	if got := e2.GetScore("203.0.113.98"); got != 0 {
		t.Fatalf("pure-IP score should vanish, got %d", got)
	}
}

func TestASNTiers(t *testing.T) {
	e := newEngine()
	defer e.Close()
	cases := []struct {
		ip   string
		name string
		tier int
	}{
		{"1.0.1.15", "Google", 1},
		{"10.1.2.3", "Private", 0},
		{"8.8.8.8", "Unknown", 2},
	}
	for _, c := range cases {
		info := e.GetASN(c.ip)
		if info.Name != c.name || info.Tier != c.tier {
			t.Fatalf("%s: want %s/%d got %+v", c.ip, c.name, c.tier, info)
		}
	}
}

func TestReset(t *testing.T) {
	// v2 Reset clears the IP score itself; subnet influence is separate.
	e := New(config.Reputation{MaxScore: 100, MinScore: -100,
		BlockThreshold: 80, ChallengeThreshold: 40, DecayRate: 0.95, SubnetScores: false})
	defer e.Close()
	ip := "203.0.113.7"
	e.Adjust(ip, 80, "r")
	e.Reset(ip)
	if e.GetScore(ip) != 0 {
		t.Fatal("reset failed")
	}
}
