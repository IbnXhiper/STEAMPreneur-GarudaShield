// Package reputation ports v2's src/engine/reputation.js: persistent IP
// scoring [-100..100], exponential decay, subnet influence and ASN tiers.
package reputation

import (
	"context"
	"net"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/geo"
	"github.com/ahkurdev/garudashield/internal/statestore"
	"github.com/ahkurdev/garudashield/internal/storage"
)

// ASNRanges is the v2 static table (Google known-good, RFC1918 private,
// everything else "unknown" tier 2 until a real ASN DB lands in geo/).
var asnranges = []struct {
	cidr *net.IPNet
	asn  string
	name string
	tier int
}{
	{mustCIDR("1.0.0.0/16"), "AS15169", "Google", 1},
	{mustCIDR("10.0.0.0/8"), "RFC1918", "Private", 0},
	{mustCIDR("172.16.0.0/12"), "RFC1918", "Private", 0},
	{mustCIDR("192.168.0.0/16"), "RFC1918", "Private", 0},
}

func mustCIDR(s string) *net.IPNet {
	_, n, _ := net.ParseCIDR(s)
	return n
}

type Info struct {
	ASN  string `json:"asn"`
	Name string `json:"name"`
	Tier int    `json:"tier"`
}

type Engine struct {
	cfg config.Reputation

	scores *storage.Store
	mu     sync.RWMutex
	asn    map[uint32]Info
	geo    *geo.Resolver

	// l2 mirrors score mutations into the shared state store (Redis) so
	// reputation survives restarts and converges across cluster nodes.
	// Optional: nil = single-node ephemeral (v2 behavior).
	l2 statestore.StateStore

	done chan struct{}
	once sync.Once
}

func New(cfg config.Reputation) *Engine {
	if cfg.MaxScore == 0 {
		cfg.MaxScore = 100
	}
	if cfg.MinScore == 0 {
		cfg.MinScore = -100
	}
	if cfg.BlockThreshold <= 0 {
		cfg.BlockThreshold = 80
	}
	if cfg.ChallengeThreshold <= 0 {
		cfg.ChallengeThreshold = 40
	}
	if cfg.DecayRate <= 0 || cfg.DecayRate >= 1 {
		cfg.DecayRate = 0.95
	}
	interval := time.Duration(cfg.DecayIntervalMs) * time.Millisecond
	if interval <= 0 {
		interval = time.Minute
	}
	e := &Engine{
		cfg:    cfg,
		scores: storage.NewStore(),
		asn:    make(map[uint32]Info),
		done:   make(chan struct{}),
	}
	go func() {
		t := time.NewTicker(interval)
		defer t.Stop()
		for {
			select {
			case <-e.done:
				return
			case <-t.C:
				e.Decay()
			}
		}
	}()
	return e
}

func ipToInt(ipStr string) uint32 {
	ip := net.ParseIP(ipStr).To4()
	if ip == nil {
		return 0
	}
	return uint32(ip[0])<<24 | uint32(ip[1])<<16 | uint32(ip[2])<<8 | uint32(ip[3])
}

func maskOf(bits int) uint32 {
	if bits == 32 {
		return 0xFFFFFFFF
	}
	return ^(uint32(0xFFFFFFFF) >> bits) << (32 - bits) & 0xFFFFFFFF
}

// Adjust adds delta to an IP's score (clamped), mirrors to subnets ×0.5.
// SetStateStore attaches the shared L2 state store (Redis). When set, every
// Adjust/Reset mirrors into `rep:<ip>` so scores survive restarts and are
// visible to peer nodes. Optional: reputation stays fully functional without it.
func (e *Engine) SetStateStore(st statestore.StateStore) { e.l2 = st }

// Adjust adds delta to the IP's score (clamped) and mirrors to L2 when wired.
func (e *Engine) Adjust(ip string, delta int, reason string) int {
	cur := e.scores.GetInt(ip)
	ns := clampInt(cur+int64(delta), int64(e.cfg.MinScore), int64(e.cfg.MaxScore))
	e.scores.Set(ip, ns, time.Hour.Milliseconds())
	if e.l2 != nil {
		e.l2.Set(context.Background(), "rep:"+ip, strconv.FormatInt(ns, 10), time.Hour.Milliseconds())
	}

	if e.cfg.SubnetScores {
		i := ipToInt(ip)
		if i != 0 {
			for _, bits := range []int{32, 24, 16} {
				sub := (i & maskOf(bits)) & 0xFFFFFFFF
				key := "subnet:" + strconv.Itoa(bits) + ":" + strconv.FormatUint(uint64(sub), 10)
				cs := e.scores.GetInt(key)
				e.scores.Set(key, clampInt(cs+int64(delta)/2, int64(e.cfg.MinScore), int64(e.cfg.MaxScore)), time.Hour.Milliseconds())
			}
		}
	}
	if reason != "" {
		e.scores.Set("reason:"+ip, reason, time.Hour.Milliseconds())
	}
	return int(ns)
}

// SetGeo attaches the optional offline ASN resolver. Passing nil disables it
// and GetASN falls back to the static table.
func (e *Engine) SetGeo(resolver *geo.Resolver) {
	e.mu.Lock()
	e.geo = resolver
	e.mu.Unlock()
}

// GetScore blends IP score with the strongest matching subnet score.
// NOTE: v2's weighting algebra degenerated to max(ip, subnet); we keep max().
func (e *Engine) GetScore(ip string) int {
	score := e.scores.GetInt(ip)
	if !e.cfg.SubnetScores {
		return int(score)
	}
	i := ipToInt(ip)
	if i == 0 {
		return int(score)
	}
	for _, bits := range []int{32, 24, 16} {
		sub := (i & maskOf(bits)) & 0xFFFFFFFF
		key := "subnet:" + strconv.Itoa(bits) + ":" + strconv.FormatUint(uint64(sub), 10)
		if s := e.scores.GetInt(key); s > score {
			score = s
		}
	}
	return int(score)
}

func (e *Engine) GetReason(ip string) (string, bool) {
	v, ok := e.scores.Get("reason:" + ip)
	if !ok {
		return "", false
	}
	s, _ := v.(string)
	return s, s != ""
}

// OwnScore returns the IP's own accumulated score, excluding any subnet
// influence. Enforcement that hard-blocks an IP must be corroborated by this
// value so a /24 or /16 poisoned by an attacker can never collaterally block a
// clean neighbour (DDoS-time false-positive guard).
func (e *Engine) OwnScore(ip string) int { return int(e.scores.GetInt(ip)) }

// SubnetScore returns the strongest subnet-derived influence for the IP
// (/24 or /16). It is informational/diagnostic: enforcement blends it via
// GetScore only after the IP carries its own evidence.
func (e *Engine) SubnetScore(ip string) int {
	if !e.cfg.SubnetScores {
		return 0
	}
	i := ipToInt(ip)
	if i == 0 {
		return 0
	}
	best := 0
	for _, bits := range []int{24, 16} {
		sub := (i & maskOf(bits)) & 0xFFFFFFFF
		key := "subnet:" + strconv.Itoa(bits) + ":" + strconv.FormatUint(uint64(sub), 10)
		if s := int(e.scores.GetInt(key)); s > best {
			best = s
		}
	}
	return best
}

// subnetBlockMin is the minimum own score an IP must carry before subnet
// influence is allowed to push it over the block threshold. Configurable via
// reputation.subnetBlockMinScore; falls back to the challenge threshold.
func (e *Engine) subnetBlockMin() int {
	if e.cfg.SubnetBlockMinScore > 0 {
		return e.cfg.SubnetBlockMinScore
	}
	if e.cfg.ChallengeThreshold > 0 {
		return e.cfg.ChallengeThreshold
	}
	return 40
}

// ShouldBlock reports whether the IP's reputation warrants a hard block.
// An IP at/above the block threshold on its OWN score always blocks. Otherwise
// subnet influence only counts when the IP already carries its own evidence
// (own >= subnetBlockMin) — this is the anti-false-positive rule that keeps a
// clean neighbour out of the blocklist while a subnet is under attack.
func (e *Engine) ShouldBlock(ip string) bool {
	thr := e.GetThreshold()
	if e.OwnScore(ip) >= thr {
		return true
	}
	if !e.cfg.SubnetScores || e.OwnScore(ip) < e.subnetBlockMin() {
		return false
	}
	return e.GetScore(ip) >= thr
}

// SetThreshold overrides the runtime block threshold (v2 adjusts this in
// aggressive/emergency mode).
func (e *Engine) SetThreshold(t int) {
	if t <= 0 {
		return
	}
	e.mu.Lock()
	e.cfg.BlockThreshold = t
	e.mu.Unlock()
}

func (e *Engine) GetThreshold() int {
	e.mu.RLock()
	defer e.mu.RUnlock()
	return e.cfg.BlockThreshold
}

// ShouldChallenge reports whether the IP should be challenged. Like ShouldBlock
// it never lets pure subnet influence reach an otherwise-clean IP: a neighbour
// with no own evidence is not challenged just because an attacker shares its
// subnet. An IP with any own history may be lifted into the challenge zone by
// subnet correlation.
func (e *Engine) ShouldChallenge(ip string) bool {
	if e.OwnScore(ip) >= e.cfg.ChallengeThreshold {
		return true
	}
	return e.cfg.SubnetScores && e.OwnScore(ip) > 0 &&
		e.GetScore(ip) >= e.cfg.ChallengeThreshold
}

// GetASN classifies an IP against the static table (cached).
// GetASN resolves an IP's autonomous system. When a geo ASN database is
// attached it is authoritative; otherwise the static v2 table is used. Missing
// data yields tier 2 ("unknown"), which the pipeline treats as mildly
// suspicious in aggressive mode — a real ASN lookup therefore reduces false
// positives against legitimate cloud and ISP traffic.
func (e *Engine) GetASN(ip string) Info {
	if e.geo != nil {
		if loc := e.geo.Lookup(ip); loc.ASN != "" {
			return Info{ASN: loc.ASN, Name: loc.Org, Tier: 1}
		}
	}
	i := ipToInt(ip)
	if i == 0 {
		return Info{ASN: "AS0", Name: "Invalid", Tier: 2}
	}
	e.mu.RLock()
	info, ok := e.asn[i]
	e.mu.RUnlock()
	if ok {
		return info
	}
	for _, r := range asnranges {
		if r.cidr.Contains(net.IPv4(byte(i>>24), byte(i>>16), byte(i>>8), byte(i))) {
			info = Info{ASN: r.asn, Name: r.name, Tier: r.tier}
			break
		}
	}
	if info.ASN == "" {
		info = Info{ASN: "AS0", Name: "Unknown", Tier: 2}
	}
	e.mu.Lock()
	if len(e.asn) < 10000 {
		e.asn[i] = info
	}
	e.mu.Unlock()
	return info
}

// Decay multiplies every live score by decayRate (public for tests/dashboard).
func (e *Engine) Decay() {
	type kv struct {
		k string
		v int64
	}
	var updates []kv
	e.scores.ForEach(func(k string, v any) bool {
		if strings.HasPrefix(k, "subnet:") || strings.HasPrefix(k, "reason:") {
			return true
		}
		if n, ok := v.(int64); ok {
			updates = append(updates, kv{k, n})
		}
		return true
	})
	rate := e.cfg.DecayRate
	for _, u := range updates {
		d := int64(float64(u.v) * rate)
		if d < 0 {
			d = -d
		}
		if d < 2 {
			e.scores.Delete(u.k)
			continue
		}
		nv := clampInt(int64(float64(u.v)*rate), int64(e.cfg.MinScore), int64(e.cfg.MaxScore))
		e.scores.Set(u.k, nv, time.Hour.Milliseconds())
	}
}

// RestoreScore seeds the local cache from a mirrored L2 value (boot
// rehydration). It does NOT write back to L2 (avoid loops) and bypasses the
// clamp delta path since the value is already clamped.
func (e *Engine) RestoreScore(ip string, score int) {
	ns := clampInt(int64(score), int64(e.cfg.MinScore), int64(e.cfg.MaxScore))
	e.scores.Set(ip, ns, time.Hour.Milliseconds())
}

// Reset clears the IP's score (L1 + L2 mirror).
func (e *Engine) Reset(ip string) {
	e.scores.Delete(ip)
	e.scores.Delete("reason:" + ip)
	if e.l2 != nil {
		e.l2.Delete(context.Background(), "rep:"+ip)
	}
}

// ResetAll clears every reputation score and stored reason — both the local
// cache and the shared L2 mirror. Purging the mirror is essential: otherwise a
// node restart (or a peer node) rehydrates the scores the operator just cleared.
func (e *Engine) ResetAll() {
	keys := make([]string, 0, 64)
	e.scores.ForEach(func(k string, _ any) bool {
		keys = append(keys, k)
		return true
	})
	for _, k := range keys {
		e.scores.Delete(k)
	}
	if e.l2 != nil {
		l2keys := make([]string, 0, 64)
		e.l2.ForEach("rep:", func(k, _ string) bool {
			l2keys = append(l2keys, k)
			return true
		})
		for _, k := range l2keys {
			e.l2.Delete(context.Background(), k)
		}
	}
}

type Entry struct {
	IP    string `json:"ip"`
	Score int    `json:"score"`
}

func (e *Engine) Top(limit int) []Entry {
	list := make([]Entry, 0, 32)
	e.scores.ForEach(func(k string, v any) bool {
		if len(k) > 7 && (k[:7] == "subnet:" || k[:7] == "reason:") {
			return true
		}
		if n, ok := v.(int64); ok {
			if n > 10 || n < -10 {
				list = append(list, Entry{IP: k, Score: int(n)})
			}
		}
		return true
	})
	sortEntriesDesc(list)
	if len(list) > limit {
		list = list[:limit]
	}
	return list
}

func sortEntriesDesc(l []Entry) {
	for i := 1; i < len(l); i++ {
		for j := i; j > 0 && l[j].Score > l[j-1].Score; j-- {
			l[j], l[j-1] = l[j-1], l[j]
		}
	}
}

func clampInt(v, lo, hi int64) int64 {
	if v < lo {
		return lo
	}
	if v > hi {
		return hi
	}
	return v
}

func (e *Engine) Close() { e.once.Do(func() { close(e.done); e.scores.Close() }) }

func (e *Engine) Config() config.Reputation { return e.cfg }

type Stats struct {
	TotalTracked int     `json:"totalTracked"`
	HighRisk     int     `json:"highRisk"`
	BlockedCount int     `json:"blockedCount"`
	TopScored    []Entry `json:"topScored"`
}

func (e *Engine) Stats() Stats {
	top := e.Top(20)
	high, blocked := 0, 0
	for _, t := range top {
		if t.Score >= e.cfg.ChallengeThreshold {
			high++
		}
		if t.Score >= e.cfg.BlockThreshold {
			blocked++
		}
	}
	return Stats{HighRisk: high, BlockedCount: blocked, TopScored: top}
}
