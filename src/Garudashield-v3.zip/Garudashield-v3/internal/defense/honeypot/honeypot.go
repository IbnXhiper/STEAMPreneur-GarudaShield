// Package honeypot blocks requests to paths that only vulnerability scanners,
// exploit tooling and misconfigured bots ever touch (/.env, /.git/, /wp-login,
// /phpmyadmin, ...). A hit is treated as definitive hostile intent: the source
// IP is blocked immediately (fail-closed) and the request never reaches the
// upstream. Matching is a case-insensitive substring test on the request path,
// so it is safe to run on the hot path before any heavier inspection.
package honeypot

import (
	"strings"

	"github.com/ahkurdev/garudashield/internal/config"
)

// DefaultPatterns returns the built-in probe/exploit path fragments. They are
// deliberately narrow: each one targets a file/dir that a legitimate visitor
// never requests, so the false-positive risk is minimal.
func DefaultPatterns() []string {
	return []string{
		"/.env",
		"/.git",
		"/.svn/",
		"/.hg/",
		"/.aws/",
		"/.ssh/",
		"/.terraform",
		"/.vscode/",
		"/.idea/",
		"/.ds_store",
		"/wp-login",
		"/wp-admin",
		"/wp-content/",
		"/wp-includes/",
		"/xmlrpc.php",
		"/phpmyadmin",
		"/pma/",
		"/myadmin/",
		"/server-status",
		"/vendor/phpunit",
		"/_ignition/execute-solution",
		"/telescope/requests",
		"/config.php.bak",
		"/cgi-bin/",
		"/solr/admin",
		"/druid/index",
	}
}

// Guard is a compiled honeypot matcher.
type Guard struct {
	enabled bool
	ttlMs   int64
	score   int
	pats    []string
}

// New compiles a guard from config, filling in safe defaults.
func New(cfg config.Honeypot) *Guard {
	g := &Guard{enabled: cfg.Enabled, ttlMs: cfg.BlockTTLMs, score: cfg.Score}
	if g.ttlMs <= 0 {
		g.ttlMs = 3600000
	}
	if g.score <= 0 {
		g.score = 100
	}
	pats := cfg.Paths
	if len(pats) == 0 {
		pats = DefaultPatterns()
	}
	for _, p := range pats {
		p = strings.ToLower(strings.TrimSpace(p))
		if p == "" {
			continue
		}
		g.pats = append(g.pats, p)
	}
	return g
}

// Enabled reports whether the guard will inspect requests.
func (g *Guard) Enabled() bool { return g != nil && g.enabled }

// TTLMs is the block duration applied on a hit.
func (g *Guard) TTLMs() int64 {
	if g == nil || g.ttlMs <= 0 {
		return 3600000
	}
	return g.ttlMs
}

// Score is the block score reported for a hit.
func (g *Guard) Score() int {
	if g == nil || g.score <= 0 {
		return 100
	}
	return g.score
}

// Match reports the matched pattern (if any) for a request path. The check is a
// case-insensitive substring test; nil/disabled guards never match.
func (g *Guard) Match(path string) (string, bool) {
	if g == nil || !g.enabled || len(g.pats) == 0 {
		return "", false
	}
	lp := strings.ToLower(path)
	for _, p := range g.pats {
		if strings.Contains(lp, p) {
			return p, true
		}
	}
	return "", false
}
