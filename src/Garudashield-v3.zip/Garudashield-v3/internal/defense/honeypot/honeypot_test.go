package honeypot

import (
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func TestMatchDefaults(t *testing.T) {
	g := New(config.Honeypot{Enabled: true})
	cases := []struct {
		path string
		want bool
	}{
		{"/.env", true},
		{"/.env.local", true},
		{"/.git/config", true},
		{"/wp-login.php", true},
		{"/WP-ADMIN/setup.php", true},
		{"/phpmyadmin/index.php", true},
		{"/vendor/phpunit/phpunit/src/Util/PHP/eval-stdin.php", true},
		{"/", false},
		{"/products/42", false},
		{"/api/v1/assets/3/policy", false},
		{"/blog/how-to-use-env-vars", false},
	}
	for _, c := range cases {
		_, got := g.Match(c.path)
		if got != c.want {
			t.Errorf("Match(%q) = %v, want %v", c.path, got, c.want)
		}
	}
}

func TestDisabledNeverMatches(t *testing.T) {
	g := New(config.Honeypot{Enabled: false})
	if _, ok := g.Match("/.env"); ok {
		t.Fatal("disabled guard matched /.env")
	}
}

func TestCustomPathsOverrideDefaults(t *testing.T) {
	g := New(config.Honeypot{Enabled: true, Paths: []string{"/secret-admin"}})
	if _, ok := g.Match("/.env"); ok {
		t.Fatal("custom path list should replace defaults")
	}
	if _, ok := g.Match("/secret-admin/login"); !ok {
		t.Fatal("custom path not matched")
	}
}

func TestDefaultsFillTTLAndScore(t *testing.T) {
	g := New(config.Honeypot{Enabled: true})
	if g.TTLMs() != 3600000 {
		t.Fatalf("ttl = %d, want 3600000", g.TTLMs())
	}
	if g.Score() != 100 {
		t.Fatalf("score = %d, want 100", g.Score())
	}
}

func TestNilGuardSafe(t *testing.T) {
	var g *Guard
	if g.Enabled() {
		t.Fatal("nil guard should be disabled")
	}
	if _, ok := g.Match("/.env"); ok {
		t.Fatal("nil guard matched")
	}
	if g.TTLMs() <= 0 || g.Score() <= 0 {
		t.Fatal("nil guard defaults should be positive")
	}
}
