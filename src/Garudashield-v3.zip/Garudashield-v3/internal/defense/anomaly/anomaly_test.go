package anomaly

import (
	"math/rand"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
)

func TestRateSpikeDetection(t *testing.T) {
	d := New(config.Anomaly{WindowSize: 60, MinSamples: 10, ZScoreThreshold: 3.0, EnableRateAnomaly: true})

	// flat baseline (single outlier against long flat run ⇒ z>3)
	for i := 0; i < 40; i++ {
		d.RecordMetrics(100)
	}
	if a := d.Detect(); len(a) != 0 {
		t.Fatalf("flat baseline must be quiet, got %+v", a)
	}
	d.RecordMetrics(5000) // one huge sample
	found := false
	for _, a := range d.Detect() {
		if a.Type == "rate-spike" && (a.Severity == "critical" || a.Severity == "high") {
			found = true
		}
	}
	if !found {
		t.Fatal("spike not detected")
	}
}

func TestPayloadEntropy(t *testing.T) {
	d := New(config.Anomaly{EnablePayloadAnomaly: true, EntropyThreshold: 4.5})

	if s := d.CheckPayload([]byte("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")); s != 0 {
		t.Fatalf("low-entropy text must score 0, got %d", s)
	}

	raw := make([]byte, 512)
	for i := range raw {
		raw[i] = byte(rand.Intn(256))
	}
	s := d.CheckPayload(raw)
	if s <= 0 || s > 30 {
		t.Fatalf("random payload should score (0,30], got %d", s)
	}
}

func TestBaselineLocks(t *testing.T) {
	d := New(config.Anomaly{WindowSize: 20, MinSamples: 10, EnableRateAnomaly: true})
	for i := 0; i < 25; i++ {
		d.RecordMetrics(50)
		d.Detect()
	}
	if !d.BaselineLocked() {
		t.Fatal("baseline should lock after windowSize samples")
	}
}

func TestShannonEntropyBounds(t *testing.T) {
	if e := shannonEntropy([]byte("")); e != 0 {
		t.Fatalf("empty=0, got %v", e)
	}
	if e := shannonEntropy([]byte("abab")); e > 1.01 || e < 0.99 {
		t.Fatalf("two-symbol uniform ≈1 bit, got %v", e)
	}
}
