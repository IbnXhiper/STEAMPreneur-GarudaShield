// Package anomaly ports v2's src/engine/anomaly.js: statistical detection
// using z-scores over RPS history, per-path spikes, protocol distribution and
// Shannon-entropy payload scoring ("ML-inspired", zero dependencies).
package anomaly

import (
	"math"
	"sort"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

type Anomaly struct {
	Type      string    `json:"type"`
	Severity  string    `json:"severity"` // info | medium | high | critical
	Path      string    `json:"path,omitempty"`
	Value     float64   `json:"value,omitempty"`
	Baseline  float64   `json:"baseline,omitempty"`
	ZScore    float64   `json:"zScore,omitempty"`
	Timestamp time.Time `json:"timestamp"`
}

type Detector struct {
	cfg config.Anomaly

	mu          sync.Mutex
	rpsHistory  []float64
	pathRPS     map[string][]float64
	protocolTCP uint64
	protocolUDP uint64
	anomalies   []Anomaly // ring of last 200
	baseline    struct {
		mean, std float64
		locked    bool
	}
}

func New(cfg config.Anomaly) *Detector {
	if cfg.WindowSize <= 0 {
		cfg.WindowSize = 60
	}
	if cfg.ZScoreThreshold <= 0 {
		cfg.ZScoreThreshold = 3.0
	}
	if cfg.MinSamples <= 0 {
		cfg.MinSamples = 10
	}
	if cfg.EntropyThreshold <= 0 {
		cfg.EntropyThreshold = 4.5
	}
	return &Detector{
		cfg:     cfg,
		pathRPS: make(map[string][]float64),
	}
}

// RecordMetrics feeds one sample tick (v2 recordMetrics).
func (d *Detector) RecordMetrics(rps float64) {
	d.mu.Lock()
	defer d.mu.Unlock()
	d.rpsHistory = append(d.rpsHistory, rps)
	if len(d.rpsHistory) > d.cfg.WindowSize*2 {
		d.rpsHistory = d.rpsHistory[len(d.rpsHistory)-d.cfg.WindowSize:]
	}
}

// RecordProtocol tracks tcp/udp packet counts for ratio anomalies.
func (d *Detector) RecordProtocol(proto string) {
	d.mu.Lock()
	defer d.mu.Unlock()
	if proto == "udp" {
		d.protocolUDP++
	} else if proto == "tcp" {
		d.protocolTCP++
	}
}

// Detect computes current anomalies (v2 detect()).
func (d *Detector) Detect() []Anomaly {
	now := time.Now()
	var out []Anomaly

	d.mu.Lock()
	defer d.mu.Unlock()

	if d.cfg.EnableRateAnomaly && len(d.rpsHistory) >= d.cfg.MinSamples {
		mean := mean(d.rpsHistory)
		std := stdev(d.rpsHistory, mean)
		cur := d.rpsHistory[len(d.rpsHistory)-1]
		z := zScore(cur, mean, std)

		if z > d.cfg.ZScoreThreshold {
			sev := "high"
			if z > d.cfg.ZScoreThreshold*2 {
				sev = "critical"
			}
			out = append(out, Anomaly{Type: "rate-spike", Severity: sev, Value: cur, Baseline: mean, ZScore: z, Timestamp: now})
		}
		if std > 0 && std/math.Max(mean, 1) > 2.0 {
			out = append(out, Anomaly{Type: "high-variance", Severity: "medium", Value: std, Baseline: mean, Timestamp: now})
		}
		if !d.baseline.locked && len(d.rpsHistory) >= d.cfg.WindowSize {
			d.baseline.mean = mean
			d.baseline.std = std
			d.baseline.locked = true
		}
	}

	if d.cfg.EnableProtocolAnomaly {
		total := d.protocolTCP + d.protocolUDP
		if total > 100 {
			if r := float64(d.protocolUDP) / float64(total); r > 0.8 {
				out = append(out, Anomaly{Type: "udp-flood", Severity: "high", Value: r, Timestamp: now})
			}
		}
	}

	for path, hist := range d.pathRPS {
		if len(hist) >= 5 {
			mean := mean(hist)
			std := stdev(hist, mean)
			cur := hist[len(hist)-1]
			z := zScore(cur, mean, std)
			if z > d.cfg.ZScoreThreshold {
				sev := "high"
				if z > d.cfg.ZScoreThreshold*2 {
					sev = "critical"
				}
				out = append(out, Anomaly{Type: "path-spike", Severity: sev, Path: path, Value: cur, Baseline: mean, ZScore: z, Timestamp: now})
			}
		}
	}

	d.anomalies = append(d.anomalies, out...)
	if len(d.anomalies) > 200 {
		d.anomalies = d.anomalies[len(d.anomalies)-200:]
	}
	return out
}

// CheckPayload returns additive risk for high-entropy bodies (v2 checkPayload).
func (d *Detector) CheckPayload(payload []byte) int {
	if !d.cfg.EnablePayloadAnomaly || len(payload) < 10 {
		return 0
	}
	e := shannonEntropy(payload)
	if e > d.cfg.EntropyThreshold {
		v := int((e - d.cfg.EntropyThreshold) * 10)
		if v > 30 {
			v = 30
		}
		return v
	}
	return 0
}

// Baseline exposes locked baseline for stats/dashboards.
func (d *Detector) BaselineLocked() bool {
	d.mu.Lock()
	defer d.mu.Unlock()
	return d.baseline.locked
}

func (d *Detector) Stats() map[string]any {
	d.mu.Lock()
	defer d.mu.Unlock()
	out := map[string]any{
		"historySize":    len(d.rpsHistory),
		"totalAnomalies": len(d.anomalies),
		"baselineLocked": d.baseline.locked,
	}
	if n := len(d.rpsHistory); n > 0 {
		mean := mean(d.rpsHistory)
		std := stdev(d.rpsHistory, mean)
		out["currentRPS"] = d.rpsHistory[n-1]
		out["meanRPS"] = int64(mean)
		out["stdRPS"] = int64(std)
		if std > 0 {
			out["zScore"] = (d.rpsHistory[n-1] - mean) / std
		}
	}
	recent := d.anomalies
	if len(recent) > 10 {
		recent = recent[len(recent)-10:]
	}
	out["recentAnomalies"] = recent
	return out
}

// ---------- math helpers ----------

func mean(a []float64) float64 {
	if len(a) == 0 {
		return 0
	}
	s := 0.0
	for _, v := range a {
		s += v
	}
	return s / float64(len(a))
}

func stdev(a []float64, m float64) float64 {
	if len(a) < 2 {
		return 0
	}
	s := 0.0
	for _, v := range a {
		d := v - m
		s += d * d
	}
	return math.Sqrt(s / float64(len(a)-1))
}

func zScore(v, m, sd float64) float64 {
	if sd == 0 {
		return 0
	}
	return (v - m) / sd
}

// ShannonEntropy mirrors v2's _entropy over bytes.
func shannonEntropy(b []byte) float64 {
	if len(b) == 0 {
		return 0
	}
	freq := make(map[byte]int, 256)
	for _, c := range b {
		freq[c]++
	}
	n := float64(len(b))
	e := 0.0
	for _, cnt := range freq {
		p := float64(cnt) / n
		e -= p * math.Log2(p)
	}
	return e
}

// SortBySeverity orders anomalies critical→info (dashboard convenience).
func SortBySeverity(list []Anomaly) {
	rank := map[string]int{"critical": 0, "high": 1, "medium": 2, "info": 3}
	sort.SliceStable(list, func(i, j int) bool { return rank[list[i].Severity] < rank[list[j].Severity] })
}
