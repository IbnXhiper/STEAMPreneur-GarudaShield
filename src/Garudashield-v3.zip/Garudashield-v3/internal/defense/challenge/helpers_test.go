package challenge

import (
	"crypto/sha256"
	"encoding/hex"
)

// sha256hex is a test-visible helper for PoW verification.
func sha256hex(s string) string {
	h := sha256.Sum256([]byte(s))
	return hex.EncodeToString(h[:])
}
