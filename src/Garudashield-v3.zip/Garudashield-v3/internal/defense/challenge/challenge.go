// Package challenge ports v2's src/engine/challenge.js: JS hash challenges
// (identical custom hash algorithm so real browsers solve them), optional
// SHA-256 proof-of-work, per-IP binding, attempt limits and stats.
package challenge

import (
	"crypto/rand"
	"crypto/sha256"
	"encoding/binary"
	"encoding/hex"
	"fmt"
	"strings"
	"sync"
	"time"

	"github.com/ahkurdev/garudashield/internal/config"
)

type Kind string

const (
	KindJS  Kind = "js"
	KindPoW Kind = "pow"
)

// Challenge is what gets serialized to the client (Answer stays server-side).
type Challenge struct {
	ID         string `json:"id"`
	Type       string `json:"type"`
	Seed       string `json:"seed"`
	Salt       string `json:"salt,omitempty"`
	Nonce      int    `json:"nonce,omitempty"`
	Prefix     string `json:"prefix,omitempty"`
	Expires    int64  `json:"expires"`
	Difficulty int    `json:"difficulty"`
}

type pending struct {
	ch       Challenge
	ip       string
	answer   string
	attempts int
	created  time.Time
}

// Manager owns pending/completed challenges and failure accounting.
type Manager struct {
	cfg config.FingerprintConfig

	mu        sync.Mutex
	byIP      map[string]string
	pending   map[string]*pending
	completed map[string]time.Time
	failures  map[string]int
	lastFail  map[string]time.Time

	totalIssued uint64
	totalPassed uint64
	totalFailed uint64

	done chan struct{}
	once sync.Once
}

func New(cfg config.FingerprintConfig) *Manager {
	if cfg.ChallengeDifficulty <= 0 {
		cfg.ChallengeDifficulty = 4
	}
	if cfg.ChallengeTTLms <= 0 {
		cfg.ChallengeTTLms = 30000
	}
	m := &Manager{
		cfg:       cfg,
		byIP:      make(map[string]string),
		pending:   make(map[string]*pending),
		completed: make(map[string]time.Time),
		failures:  make(map[string]int),
		lastFail:  make(map[string]time.Time),
		done:      make(chan struct{}),
	}
	go m.cleanupLoop()
	return m
}

// GenerateJS creates a JS challenge for ip (v2 generateJSChallenge).
func (m *Manager) GenerateJS(ip string) *Challenge {
	id := randHex(16)
	seed := randHex(8)
	salt := randHex(4)
	nonce := int(randomUint64()%900000) + 100000 // crypto.randomInt(100000,999999)
	answer := jsHashString(seed + salt + fmt.Sprint(nonce))
	return m.store(Challenge{
		ID: id, Type: "js", Seed: seed, Salt: salt,
		Nonce: nonce, Expires: time.Now().UnixMilli() + int64(m.cfg.ChallengeTTLms),
		Difficulty: m.cfg.ChallengeDifficulty,
	}, ip, answer)
}

// GeneratePoW creates a proof-of-work challenge; the server pre-solves it.
func (m *Manager) GeneratePoW(ip string) *Challenge {
	id := randHex(8)
	seed := randHex(4)
	prefix := strings.Repeat("0", m.cfg.ChallengeDifficulty)
	answer := solvePow(seed, prefix)
	return m.store(Challenge{
		ID: id, Type: "pow", Seed: seed, Prefix: prefix,
		Expires:    time.Now().UnixMilli() + int64(m.cfg.ChallengeTTLms),
		Difficulty: m.cfg.ChallengeDifficulty,
	}, ip, answer)
}

func (m *Manager) store(ch Challenge, ip, answer string) *Challenge {
	m.mu.Lock()
	defer m.mu.Unlock()
	m.pending[ch.ID] = &pending{ch: ch, ip: ip, answer: answer, created: time.Now()}
	m.byIP[ip] = ch.ID
	m.totalIssued++
	return &ch
}

// Existing returns the live challenge for an IP if any (v2 getExisting).
func (m *Manager) Existing(ip string) (*Challenge, bool) {
	if ip == "" {
		return nil, false
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	id, ok := m.byIP[ip]
	if !ok {
		return nil, false
	}
	p, ok := m.pending[id]
	if !ok {
		delete(m.byIP, ip)
		return nil, false
	}
	if time.Now().UnixMilli() > p.ch.Expires {
		delete(m.pending, id)
		delete(m.byIP, ip)
		return nil, false
	}
	ch := p.ch
	return &ch, true
}

// Answer returns the expected answer for a live challenge (used by tests and
// the admin debug endpoint). Not exposed to untrusted clients.
func (m *Manager) Answer(id string) (string, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	if p, ok := m.pending[id]; ok {
		return p.answer, true
	}
	return "", false
}

// Verify mirrors v2 verifyChallenge result semantics.
func (m *Manager) Verify(id, ip, answer string) (passed bool, reason string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	p, ok := m.pending[id]
	if !ok {
		if _, done := m.completed[id]; done {
			return true, "already"
		}
		return false, "invalid-challenge"
	}
	if p.ip != ip {
		p.attempts++
		if p.attempts >= 3 {
			m.dropLocked(id, p)
		}
		return false, "ip-mismatch"
	}
	if time.Now().UnixMilli() > p.ch.Expires {
		m.dropLocked(id, p)
		return false, "expired"
	}

	var valid bool
	switch p.ch.Type {
	case "js":
		valid = answer == p.answer
	case "pow":
		h := sha256.Sum256([]byte(p.ch.Seed + answer))
		valid = strings.HasPrefix(hex.EncodeToString(h[:]), strings.Repeat("0", m.cfg.ChallengeDifficulty))
	}

	if valid {
		delete(m.pending, id)
		delete(m.byIP, ip)
		m.completed[id] = time.Now()
		m.totalPassed++
		return true, ""
	}
	p.attempts++
	m.totalFailed++
	if p.attempts >= 5 {
		m.dropLocked(id, p)
		m.failures[ip]++
		m.lastFail[ip] = time.Now()
	}
	return false, "wrong-answer"
}

func (m *Manager) dropLocked(id string, p *pending) {
	delete(m.pending, id)
	if m.byIP[p.ip] == id {
		delete(m.byIP, p.ip)
	}
}

// BlockedByChallenge reports IPs with ≥10 cumulative failures (v2 threshold).
func (m *Manager) BlockedByChallenge(ip string) bool {
	m.mu.Lock()
	defer m.mu.Unlock()
	return m.failures[ip] >= 10
}

func (m *Manager) cleanupLoop() {
	t := time.NewTicker(10 * time.Second)
	defer t.Stop()
	for {
		select {
		case <-m.done:
			return
		case now := <-t.C:
			m.mu.Lock()
			for id, p := range m.pending {
				if now.UnixMilli() > p.ch.Expires {
					delete(m.pending, id)
				}
			}
			for ip, id := range m.byIP {
				if _, ok := m.pending[id]; !ok {
					delete(m.byIP, ip)
				}
			}
			for id, ts := range m.completed {
				if now.Sub(ts) > 5*time.Minute {
					delete(m.completed, id)
				}
			}
			for ip, ts := range m.lastFail {
				if now.Sub(ts) > time.Hour {
					delete(m.failures, ip)
					delete(m.lastFail, ip)
				}
			}
			m.mu.Unlock()
		}
	}
}

func (m *Manager) Close() { m.once.Do(func() { close(m.done) }) }

type Stats struct {
	Pending     int     `json:"pending"`
	Completed   int     `json:"completed"`
	Issued      uint64  `json:"totalIssued"`
	Passed      uint64  `json:"totalPassed"`
	Failed      uint64  `json:"totalFailed"`
	PassRatePct float64 `json:"passRate"`
	FailedIPs   int     `json:"failedIPs"`
}

func (m *Manager) Stats() Stats {
	m.mu.Lock()
	defer m.mu.Unlock()
	rate := 0.0
	if m.totalIssued > 0 {
		rate = float64(m.totalPassed) / float64(m.totalIssued) * 100
	}
	return Stats{
		Pending: len(m.pending), Completed: len(m.completed),
		Issued: m.totalIssued, Passed: m.totalPassed, Failed: m.totalFailed,
		PassRatePct: rate, FailedIPs: len(m.failures),
	}
}

// ---------- v2-identical primitives ----------

// JSHash replicates the browser-side hash in _generateJSScript bit-for-bit:
//
//	h = ((h << 5) - h) + chr | 0   →   return h >>> 0
func JSHash(s string) string {
	var h int32
	for i := 0; i < len(s); i++ {
		h = h<<5 - h + int32(s[i]) // int32 wraps like JS |0
	}
	return fmt.Sprint(uint32(h)) // >>> 0
}

func jsHashString(s string) string { return JSHash(s) }

func solvePow(seed, prefix string) string {
	for nonce := uint64(0); ; nonce++ {
		h := sha256.Sum256([]byte(seed + fmt.Sprint(nonce)))
		if strings.HasPrefix(hex.EncodeToString(h[:]), prefix) {
			return fmt.Sprint(nonce)
		}
	}
}

func randHex(bytes int) string {
	b := make([]byte, bytes)
	_, _ = rand.Read(b)
	return hex.EncodeToString(b)
}

func randomUint64() uint64 {
	b := make([]byte, 8)
	_, _ = rand.Read(b)
	return binary.BigEndian.Uint64(b)
}
