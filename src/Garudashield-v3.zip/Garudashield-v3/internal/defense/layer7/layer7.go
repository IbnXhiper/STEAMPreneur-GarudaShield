// Package layer7 is a faithful Go port of v2's src/layers/layer7.js.
//
// Semantics preserved exactly: validators run in a fixed order; any
// allowed=false verdict is an immediate block regardless of score; otherwise
// scores accumulate and a total ≥50 blocks. Note that in v2 most violations
// set allowed=false — i.e. L7 is predominantly a hard-block layer.
package layer7

import (
	"net/http"
	"net/url"
	"regexp"
	"strconv"
	"strings"
	"sync/atomic"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

type Result struct {
	Allowed bool
	Score   int
	Reason  string
	Reasons []string
}

var (
	allowedMethods = map[string]bool{
		"GET": true, "POST": true, "PUT": true, "DELETE": true,
		"PATCH": true, "HEAD": true, "OPTIONS": true,
	}
	safeMethods = map[string]bool{"GET": true, "HEAD": true, "OPTIONS": true}

	blockedExtensions = []string{
		".htaccess", ".htpasswd", ".ini", ".log", ".sql", ".db",
		".bak", ".old", ".swp", ".env", ".git", ".svn",
		".ds_store", ".thumbs.db", ".idea/", ".vscode/",
		".xmlrpc", ".php7", "wp-config", "config.php",
	}

	blockedPaths = []string{
		"/wp-admin", "/wp-login", "/admin", "/administrator",
		"/phpmyadmin", "/pma", "/myadmin", "/mysql",
		"/.env", "/.git/config", "/vendor/phpunit",
		"/shell", "/cmd", "/exec", "/backdoor",
	}

	validContentTypes = []string{
		"application/json", "application/xml", "text/xml",
		"application/x-www-form-urlencoded", "multipart/form-data",
		"text/plain", "text/html", "application/javascript",
		"text/css", "image/", "video/", "audio/",
		"application/pdf", "application/octet-stream",
	}

	reInvalidChars  = regexp.MustCompile(`[<>"'\\]`)
	reControlChars  = regexp.MustCompile(`[\x00-\x1F\x7F]`)
	reTraversal     = regexp.MustCompile(`\.\./`)
	reDoubleSlash   = regexp.MustCompile(`//+`)
	reUnusualQuery  = regexp.MustCompile(`[^\w\-.%&=+#~@!*(),/:;'\[\]]`)
	reNullByteQuery = regexp.MustCompile(`(?i)(%00|%0d|%0a)`)
	reBlockedUA     = regexp.MustCompile(`(?i)(ahrefs|semrush|majestic|spyfu|zgrab|masscan|nmap|sqlmap|nikto|wpscan|acunetix|netsparker|python-requests|aiohttp|httpx|curl|wget|go-http-client|java/)`)
)

// Defender runs the ten-toggle validation chain.
type Defender struct {
	cfg        config.Layer7Config
	droppedCnt atomic.Uint64
}

func New(cfg config.Layer7Config) *Defender {
	if cfg.MaxURILength <= 0 {
		cfg.MaxURILength = 2048
	}
	if cfg.MaxHeaderCount <= 0 {
		cfg.MaxHeaderCount = 50
	}
	if cfg.MaxCookieLen <= 0 {
		cfg.MaxCookieLen = 4096
	}
	return &Defender{cfg: cfg}
}

func (d *Defender) Stats() (dropped uint64, rules int) { return d.droppedCnt.Load(), 10 }

// Close is a no-op (layer7 has no background workers).
func (d *Defender) Close() {}

type checkFn func(v *reqview.View) Result

// Validate executes the full chain in v2 order.
func (d *Defender) Validate(v *reqview.View) Result {
	res := Result{Allowed: true}
	checks := []struct {
		on bool
		fn checkFn
	}{
		{d.cfg.Method, d.validateMethod},
		{d.cfg.Protocol, d.validateProtocol},
		{d.cfg.Path, d.validatePath},
		{d.cfg.Query, d.validateQuery},
		{d.cfg.Headers, d.validateHeaders},
		{d.cfg.ContentType, d.validateContentType},
		{d.cfg.UserAgent, d.validateUserAgent},
		{d.cfg.Referer, d.validateReferer},
		{d.cfg.Origin, d.validateOrigin},
		{d.cfg.Cookies, d.validateCookies},
	}
	for _, c := range checks {
		if !c.on || !d.cfg.Enabled {
			continue
		}
		r := c.fn(v)
		if !r.Allowed {
			d.droppedCnt.Add(1)
			res.Allowed = false
			res.Reason = r.Reason
			res.Score = r.Score
			res.Reasons = append(res.Reasons, r.Reason)
			return res
		}
		res.Score += r.Score
	}
	if res.Score >= 50 {
		res.Allowed = false
		d.droppedCnt.Add(1)
	}
	return res
}

func allow(score int) Result { return Result{Allowed: true, Score: score} }

func block(reason string, score int) Result {
	return Result{Allowed: false, Reason: reason, Score: score}
}

func (d *Defender) validateMethod(v *reqview.View) Result {
	method := strings.ToUpper(v.Method)
	if method == "" {
		method = "GET"
	}
	if !allowedMethods[method] {
		return block("invalid-method", 50)
	}
	if int64(len(v.Body)) > d.cfg.MaxBodySize && !safeMethods[method] {
		return block("body-too-large", 30)
	}
	return allow(0)
}

func (d *Defender) validateProtocol(v *reqview.View) Result {
	ver := strings.TrimPrefix(v.Proto, "HTTP/")
	if ver == "" {
		ver = "1.1"
	}
	switch ver {
	case "1.0", "1.1", "2.0", "2", "3":
	default:
		return block("unsupported-http-version", 50)
	}
	if strings.EqualFold(v.Get("Upgrade"), "h2c") {
		return allow(5)
	}
	return allow(0)
}

func (d *Defender) validatePath(v *reqview.View) Result {
	path := v.Path
	if path == "" {
		path = "/"
	}
	if len(path) > d.cfg.MaxURILength {
		return block("uri-too-long", 50)
	}
	lower := strings.ToLower(path)

	for _, ext := range blockedExtensions {
		if strings.Contains(lower, ext) {
			return block("blocked-extension", 50)
		}
	}
	for _, bp := range blockedPaths {
		if strings.HasPrefix(lower, bp) ||
			strings.Contains(lower, bp+"/") ||
			strings.Contains(lower, bp+"?") {
			return block("blocked-path", 50)
		}
	}
	if reInvalidChars.MatchString(path) {
		return block("invalid-chars", 30)
	}
	if reControlChars.MatchString(path) {
		return block("control-chars", 40)
	}
	if strings.Contains(path, "../") || strings.Contains(path, `..\`) || reTraversal.MatchString(path) {
		return block("path-traversal", 40)
	}
	if reDoubleSlash.MatchString(path) && !strings.HasPrefix(path, "http") {
		return allow(10) // score-only quirk preserved from v2
	}
	return allow(0)
}

func (d *Defender) validateQuery(v *reqview.View) Result {
	i := strings.IndexByte(v.URL, '?')
	if i == -1 {
		return allow(0)
	}
	qs := v.URL[i+1:]
	if len(qs) > d.cfg.MaxURILength {
		return block("query-too-long", 30)
	}
	// v2 returns early here — null-byte check is skipped when unusual chars present.
	if reUnusualQuery.MatchString(qs) {
		return allow(5)
	}
	if reNullByteQuery.MatchString(qs) {
		return block("null-byte-in-query", 40)
	}
	return allow(0)
}

func (d *Defender) validateHeaders(v *reqview.View) Result {
	h := v.Header
	var problems []string
	add := func(p string) { problems = append(problems, p) }

	clStr, hasCL := first(h, "Content-Length")
	teVal, hasTE := first(h, "Transfer-Encoding")
	if hasCL && hasTE {
		add("cl+te")
	}
	if hasCL {
		if cl, err := strconv.Atoi(clStr); err != nil || cl < 0 {
			add("bad-cl")
		} else if int64(cl) > d.maxBody() {
			add("cl-too-large")
		}
	}
	if hasTE {
		te := strings.ToLower(teVal)
		if te != "chunked" && !strings.Contains(te, ",") {
			add("bad-te")
		}
	}
	if host, ok := first(h, "Host"); ok {
		if strings.Contains(host, "/") || strings.Contains(host, "#") {
			add("bad-host")
		}
		if len(host) > 255 {
			add("long-host")
		}
	}
	if xff, ok := first(h, "X-Forwarded-For"); ok {
		parts := strings.Split(xff, ",")
		if len(parts) > 10 {
			add("too-many-proxies")
		}
		for _, ip := range parts {
			if len(strings.TrimSpace(ip)) > 45 {
				add("bad-xff")
				break
			}
		}
	}
	if ck, ok := first(h, "Cookie"); ok && len(ck) > d.cfg.MaxCookieLen {
		add("large-cookie")
	}
	if len(h) > d.cfg.MaxHeaderCount {
		add("too-many-headers")
	}
	if ex, ok := first(h, "Expect"); ok && !strings.EqualFold(ex, "100-continue") {
		add("bad-expect")
	}
	if te, ok := first(h, "TE"); ok && strings.Contains(strings.ToLower(te), "trailers") {
		add("te-trailers")
	}

	if len(problems) > 0 {
		// v2: ANY header problem = hard block with joined reason
		r := block(strings.Join(problems, ","), 15*len(problems))
		if r.Score > 50 {
			r.Score = 50
		}
		return r
	}
	return allow(0)
}

func (d *Defender) validateContentType(v *reqview.View) Result {
	ct := v.Get("Content-Type")
	if ct == "" {
		return allow(0)
	}
	method := strings.ToUpper(v.Method)
	if safeMethods[method] {
		return allow(5)
	}
	lower := strings.TrimSpace(strings.SplitN(ct, ";", 2)[0])
	lower = strings.ToLower(lower)
	okType := false
	for _, t := range validContentTypes {
		if strings.HasPrefix(lower, t) {
			okType = true
			break
		}
	}
	if !okType {
		return block("invalid-content-type", 20)
	}
	if len(ct) > 128 {
		return allow(5)
	}
	return allow(0)
}

func (d *Defender) validateUserAgent(v *reqview.View) Result {
	ua := strings.TrimSpace(v.Get("User-Agent"))
	switch {
	case ua == "":
		return block("missing-ua", 30)
	case len(ua) > 512:
		return block("long-ua", 20)
	case reBlockedUA.MatchString(ua):
		return block("blocked-ua", 40)
	}
	return allow(-5)
}

func (d *Defender) validateReferer(v *reqview.View) Result {
	ref := v.Get("Referer")
	if ref == "" {
		return allow(0)
	}
	if len(ref) > 1024 {
		return allow(5)
	}
	u, err := url.Parse(ref)
	if err != nil || u.Scheme == "" {
		return allow(10) // JS new URL() throws → +10 branch
	}
	if u.Scheme != "https" && u.Scheme != "http" {
		return allow(5)
	}
	return allow(0)
}

func (d *Defender) validateOrigin(v *reqview.View) Result {
	origin := v.Get("Origin")
	if origin == "" {
		return allow(0)
	}
	u, err := url.Parse(origin)
	if err != nil || u.Scheme == "" {
		return block("bad-origin", 20)
	}
	if u.Scheme != "https" && u.Scheme != "http" {
		return block("bad-origin-proto", 30)
	}
	return allow(0)
}

func (d *Defender) validateCookies(v *reqview.View) Result {
	cookies := v.Get("Cookie")
	if cookies == "" {
		return allow(0)
	}
	if len(cookies) > d.cfg.MaxCookieLen {
		return block("cookie-too-large", 30)
	}
	seen := make(map[string]bool)
	for _, part := range strings.Split(cookies, ";") {
		t := strings.TrimSpace(part)
		if t == "" {
			continue
		}
		name := t
		if eq := strings.IndexByte(t, '='); eq > 0 {
			name = strings.TrimSpace(t[:eq])
		}
		if len(name) > 128 {
			return allow(5)
		}
		if seen[name] {
			return allow(5)
		}
		seen[name] = true
	}
	return allow(0)
}

func (d *Defender) maxBody() int64 {
	if d.cfg.MaxBodySize > 0 {
		return d.cfg.MaxBodySize
	}
	return 1 << 20 // v2 default 1 MiB
}

func first(h http.Header, name string) (string, bool) {
	v := h.Values(name)
	if len(v) == 0 {
		return "", false
	}
	return v[0], true
}
