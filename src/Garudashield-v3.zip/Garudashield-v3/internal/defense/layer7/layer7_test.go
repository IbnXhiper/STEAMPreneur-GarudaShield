package layer7

import (
	"net/http"
	"testing"

	"github.com/ahkurdev/garudashield/internal/config"
	"github.com/ahkurdev/garudashield/internal/reqview"
)

func newDefender() *Defender {
	return New(config.Layer7Config{
		Enabled: true, Method: true, UserAgent: true, Headers: true,
		Referer: true, Origin: true, Cookies: true, Path: true,
		Query: true, ContentType: true, Protocol: true,
		MaxURILength: 2048, MaxHeaderCount: 50, MaxCookieLen: 4096,
		MaxBodySize: 1 << 20,
	})
}

func view(method, url string) *reqview.View {
	return &reqview.View{
		Method: method,
		URL:    url,
		Path:   pathOf(url),
		Proto:  "HTTP/1.1",
		Header: http.Header{},
	}
}

func pathOf(url string) string {
	for i := 0; i < len(url); i++ {
		if url[i] == '?' {
			return url[:i]
		}
	}
	return url
}

func withUA(v *reqview.View, ua string) *reqview.View {
	v.Header.Set("User-Agent", ua)
	return v
}

func TestCleanBrowserRequestPasses(t *testing.T) {
	d := newDefender()
	r := d.Validate(withUA(view("GET", "/products?page=2"), "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/126.0 Safari/537.36"))
	if !r.Allowed || r.Score != -5 {
		t.Fatalf("clean request should pass with -5, got %+v", r)
	}
}

func TestInvalidMethodBlocks(t *testing.T) {
	d := newDefender()
	r := d.Validate(withUA(view("TRACE", "/"), "Mozilla/5.0"))
	if r.Allowed || r.Reason != "invalid-method" {
		t.Fatalf("got %+v", r)
	}
}

func TestPathTraversalBlocks(t *testing.T) {
	d := newDefender()
	r := d.Validate(withUA(view("GET", "/files/../etc/passwd"), "Mozilla/5.0"))
	if r.Allowed || r.Reason != "path-traversal" {
		t.Fatalf("got %+v", r)
	}
}

func TestBlockedExtensionAndAdminPaths(t *testing.T) {
	d := newDefender()
	cases := map[string]string{
		"/backup/.env":     "blocked-extension",
		"/site/wp-admin/x": "blocked-path",
		"/dl/app.sql":      "blocked-extension",
	}
	for u, want := range cases {
		r := d.Validate(withUA(view("GET", u), "Mozilla/5.0"))
		if r.Allowed || r.Reason != want {
			t.Fatalf("%s: want %s got %+v", u, want, r)
		}
	}
}

func TestMissingAndBlockedUA(t *testing.T) {
	d := newDefender()
	if r := d.Validate(view("GET", "/")); r.Allowed || r.Reason != "missing-ua" {
		t.Fatalf("missing ua: %+v", r)
	}
	r := d.Validate(withUA(view("GET", "/"), "sqlmap/1.7"))
	if r.Allowed || r.Reason != "blocked-ua" {
		t.Fatalf("sqlmap: %+v", r)
	}
}

func TestSmugglingCLTE(t *testing.T) {
	d := newDefender()
	v := withUA(view("POST", "/api"), "Mozilla/5.0")
	v.Header.Set("Content-Length", "10")
	v.Header.Set("Transfer-Encoding", "chunked")
	r := d.Validate(v)
	if r.Allowed || r.Reason != "cl+te" {
		t.Fatalf("smuggling not caught: %+v", r)
	}
}

func TestDoubleSlashScoreOnly(t *testing.T) {
	d := newDefender()
	r := d.Validate(withUA(view("GET", "/a//b"), "Mozilla/5.0"))
	if !r.Allowed || r.Score != -5+10 {
		t.Fatalf("double-slash must be score-only: %+v", r)
	}
}

func TestNullByteQuery(t *testing.T) {
	d := newDefender()
	r := d.Validate(withUA(view("GET", "/search?q=abc%00"), "Mozilla/5.0"))
	if r.Allowed || r.Reason != "null-byte-in-query" {
		t.Fatalf("got %+v", r)
	}
}

func TestBadOrigin(t *testing.T) {
	d := newDefender()
	v := withUA(view("POST", "/x"), "Mozilla/5.0")
	v.Header.Set("Origin", "not-a-url")
	if r := d.Validate(v); r.Allowed || r.Reason != "bad-origin" {
		t.Fatalf("got %+v", r)
	}
}
