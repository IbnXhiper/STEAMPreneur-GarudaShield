package asset

import (
	"context"
	"errors"
	"net"
	"strings"
	"testing"
)

func TestNormalizeDomain(t *testing.T) {
	valid := map[string]string{
		"Example.COM":          "example.com",
		"shop.maju.co.id.":     "shop.maju.co.id",
		"a-b.example.com":      "a-b.example.com",
		"xn--d1acufc.xn--p1ai": "xn--d1acufc.xn--p1ai",
	}
	for in, want := range valid {
		got, err := NormalizeDomain(in)
		if err != nil {
			t.Errorf("NormalizeDomain(%q) unexpected error: %v", in, err)
			continue
		}
		if got != want {
			t.Errorf("NormalizeDomain(%q) = %q, want %q", in, got, want)
		}
	}

	invalid := []string{
		"", " ", "example", "localhost", "example.local", "db.internal",
		"http://example.com", "https://example.com/path", "example.com/path",
		"user@example.com", "example.com:8080", "1.2.3.4", "::1",
		"[2001:db8::1]", "*.example.com", "exa mple.com", "-example.com",
		"example-.com", "192.168.0.1", "example.test", "service.onion",
	}
	for _, in := range invalid {
		if _, err := NormalizeDomain(in); !errors.Is(err, ErrInvalidDomain) {
			t.Errorf("NormalizeDomain(%q) = %v, want ErrInvalidDomain", in, err)
		}
	}
}

func TestValidateOrigin(t *testing.T) {
	// empty is allowed and means "no explicit origin"
	if h, p, err := ValidateOrigin("", 0); err != nil || h != "" || p != 0 {
		t.Fatalf("empty origin: got (%q,%d,%v)", h, p, err)
	}
	if h, p, err := ValidateOrigin("Origin.Example.COM", 9000); err != nil || h != "origin.example.com" || p != 9000 {
		t.Fatalf("valid origin: got (%q,%d,%v)", h, p, err)
	}
	// public IP origin is allowed
	if _, _, err := ValidateOrigin("93.184.216.34", 443); err != nil {
		t.Fatalf("public IP origin rejected: %v", err)
	}

	bad := []struct {
		host string
		port int
	}{
		{"", 8080}, {"127.0.0.1", 80}, {"10.0.0.1", 80},
		{"169.254.169.254", 80}, {"localhost", 80}, {"db.internal", 80},
		{"http://origin.example.com", 80}, {"origin.example.com:80", 80},
		{"origin.example.com", 70000}, {"origin.example.com", -1},
	}
	for _, c := range bad {
		if _, _, err := ValidateOrigin(c.host, c.port); err == nil {
			t.Errorf("ValidateOrigin(%q,%d) accepted, want error", c.host, c.port)
		}
	}
	// private IP must specifically be a blocked target, not just "invalid"
	if _, _, err := ValidateOrigin("192.168.1.1", 80); !errors.Is(err, ErrBlockedTarget) {
		t.Errorf("private IP origin: got %v, want ErrBlockedTarget", err)
	}
}

type fakeTXTResolver struct {
	m   map[string][]string
	err error
}

func (f fakeTXTResolver) LookupTXT(_ context.Context, name string) ([]string, error) {
	if f.err != nil {
		return nil, f.err
	}
	v, ok := f.m[name]
	if !ok {
		return nil, errors.New("no such txt record")
	}
	return v, nil
}

func TestVerifyOwnership(t *testing.T) {
	ctx := context.Background()
	const domain = "shop.example.com"
	const token = "abc123"

	ok := fakeTXTResolver{m: map[string][]string{
		ChallengeName(domain): {ChallengeValue(token)},
		// Also accept the tag embedded among other fields.
		"_garudashield.multi.example.com": {"v=spf1 " + ChallengeValue(token) + " more"},
	}}
	if err := VerifyOwnership(ctx, ok, domain, token); err != nil {
		t.Fatalf("exact match rejected: %v", err)
	}
	if err := VerifyOwnership(ctx, ok, "multi.example.com", token); err != nil {
		t.Fatalf("field match rejected: %v", err)
	}

	// wrong token
	bad := fakeTXTResolver{m: map[string][]string{ChallengeName(domain): {"gs-verify=nope"}}}
	if err := VerifyOwnership(ctx, bad, domain, token); !errors.Is(err, ErrNotVerified) {
		t.Errorf("wrong token: got %v, want ErrNotVerified", err)
	}
	// missing record
	missing := fakeTXTResolver{m: map[string][]string{}}
	if err := VerifyOwnership(ctx, missing, domain, token); err == nil {
		t.Error("missing record: want error")
	}
	// empty token is never valid
	if err := VerifyOwnership(ctx, ok, domain, ""); !errors.Is(err, ErrNotVerified) {
		t.Errorf("empty token: got %v, want ErrNotVerified", err)
	}
}

func TestNewTokenUnique(t *testing.T) {
	seen := map[string]bool{}
	for i := 0; i < 100; i++ {
		tok, err := newToken()
		if err != nil {
			t.Fatal(err)
		}
		if len(tok) != 32 {
			t.Fatalf("token length = %d, want 32 hex chars", len(tok))
		}
		if seen[tok] {
			t.Fatalf("duplicate token %q", tok)
		}
		seen[tok] = true
	}
}

// dnsErrResolver returns canned answers keyed by name and distinguishes the real
// resolver failure modes (not-found vs timeout vs generic) so the classifier can
// be exercised without touching the network.
type dnsErrResolver struct {
	records map[string][]string
	errs    map[string]error
}

func (r dnsErrResolver) LookupTXT(_ context.Context, name string) ([]string, error) {
	if r.errs != nil {
		if e, ok := r.errs[name]; ok {
			return nil, e
		}
	}
	if v, ok := r.records[name]; ok {
		return v, nil
	}
	return nil, &net.DNSError{Err: "no such host", Name: name, IsNotFound: true}
}

// TestChallengeNameFormation locks the challenge hostname shape: exactly one
// "_garudashield." prefix and no duplicated suffix for a normal FQDN.
func TestChallengeNameFormation(t *testing.T) {
	cases := map[string]string{
		"shop.example.com":            "_garudashield.shop.example.com",
		"logx-nusahost.jscorp.web.id": "_garudashield.logx-nusahost.jscorp.web.id",
		"a-b.c-d.co.id":               "_garudashield.a-b.c-d.co.id",
	}
	for domain, want := range cases {
		got := ChallengeName(domain)
		if got != want {
			t.Errorf("ChallengeName(%q) = %q, want %q", domain, got, want)
		}
		if strings.Count(got, "_garudashield.") != 1 {
			t.Errorf("ChallengeName(%q) has a duplicated prefix: %q", domain, got)
		}
	}
	// ChallengeNames must be [canonical, apex] with no duplication.
	names := ChallengeNames("shop.example.com")
	if len(names) != 2 || names[0] != "_garudashield.shop.example.com" || names[1] != "shop.example.com" {
		t.Fatalf("ChallengeNames = %v", names)
	}
}

// TestChallengeValueConsistent proves the value shown to the tenant (UI) is the
// same value the verifier matches — create/UI/verify never disagree.
func TestChallengeValueConsistent(t *testing.T) {
	const token = "8c3e9174078430cd9be3c3678e9718d9"
	if got, want := ChallengeValue(token), "gs-verify="+token; got != want {
		t.Fatalf("ChallengeValue(%q) = %q, want %q", token, got, want)
	}
}

// TestVerifyOwnershipApexFallback reproduces the real-world case: the tenant
// published the TXT at the domain apex (many DNS panels do) with the value being
// the full instruction line; the token is present as a field and must verify.
func TestVerifyOwnershipApexFallback(t *testing.T) {
	const domain = "logx-nusahost.jscorp.web.id"
	const token = "8c3e9174078430cd9be3c3678e9718d9"
	r := dnsErrResolver{records: map[string][]string{
		// Only the apex exists; the canonical _garudashield name does not.
		domain: {
			"_garudashield." + domain + " TXT gs-verify=" + token,
			"v=spf1 +mx +a +ip4:103.187.147.237 ~all",
		},
	}}
	if err := VerifyOwnership(context.Background(), r, domain, token); err != nil {
		t.Fatalf("apex fallback rejected: %v", err)
	}
}

// TestVerifyOwnershipErrorClassification checks the four failure classes are
// distinguishable.
func TestVerifyOwnershipErrorClassification(t *testing.T) {
	ctx := context.Background()
	const domain = "shop.example.com"
	const token = "abc123"
	canonical := ChallengeName(domain)

	// (1) No record anywhere -> not verified, Missing=true.
	r := dnsErrResolver{}
	err := VerifyOwnership(ctx, r, domain, token)
	var ve *VerifyError
	if !errors.Is(err, ErrNotVerified) || !errors.As(err, &ve) || !ve.Missing {
		t.Errorf("missing: got %v (as *VerifyError=%v)", err, ve)
	}

	// (2) Record present but token wrong -> not verified, Missing=false.
	r = dnsErrResolver{records: map[string][]string{canonical: {"gs-verify=nope"}}}
	err = VerifyOwnership(ctx, r, domain, token)
	ve = nil
	if !errors.Is(err, ErrNotVerified) || !errors.As(err, &ve) || ve.Missing {
		t.Errorf("wrong token: got %v (missing=%v)", err, ve != nil && ve.Missing)
	}

	// (3) Resolver timeout -> ErrDNSTimeout (never "not found").
	r = dnsErrResolver{errs: map[string]error{
		canonical: &net.DNSError{Err: "timeout", Name: canonical, IsTimeout: true},
		domain:    &net.DNSError{Err: "timeout", Name: domain, IsTimeout: true},
	}}
	if err := VerifyOwnership(ctx, r, domain, token); !errors.Is(err, ErrDNSTimeout) {
		t.Errorf("timeout: got %v, want ErrDNSTimeout", err)
	}

	// (4) Generic resolver failure -> ErrDNSUnavailable.
	r = dnsErrResolver{errs: map[string]error{
		canonical: errors.New("SERVFAIL"),
		domain:    errors.New("SERVFAIL"),
	}}
	if err := VerifyOwnership(ctx, r, domain, token); !errors.Is(err, ErrDNSUnavailable) {
		t.Errorf("resolver error: got %v, want ErrDNSUnavailable", err)
	}
}

// TestVerifyOwnershipMultiRecord ensures multi-string / multi-record answers are
// matched field-wise and a token that only partly matches is rejected.
func TestVerifyOwnershipMultiRecord(t *testing.T) {
	ctx := context.Background()
	const domain = "multi.example.com"
	const token = "abc123"

	ok := dnsErrResolver{records: map[string][]string{
		ChallengeName(domain): {"v=spf1 " + ChallengeValue(token) + " more", "unrelated"},
	}}
	if err := VerifyOwnership(ctx, ok, domain, token); err != nil {
		t.Fatalf("multi-record field match rejected: %v", err)
	}

	// Substring must NOT match: "gs-verify=abc123x" is not "gs-verify=abc123".
	partial := dnsErrResolver{records: map[string][]string{
		ChallengeName(domain): {"gs-verify=" + token + "x"},
	}}
	if err := VerifyOwnership(ctx, partial, domain, token); !errors.Is(err, ErrNotVerified) {
		t.Errorf("substring match accepted: %v", err)
	}
}
