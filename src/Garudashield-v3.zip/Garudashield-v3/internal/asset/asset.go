// Package asset implements tenant-owned protected domains ("assets") for the
// commercial control plane.
//
// Security model (OWASP A01 Broken Access Control, A10 / API7 SSRF):
//   - Every read/write is tenant-scoped: a tenant can only list, verify, or
//     delete its OWN assets (no cross-tenant object reference, no tenant id in
//     the request body).
//   - A domain only becomes a protected domain after the tenant proves ownership
//     via a DNS TXT challenge. The canonical name is "_garudashield.<domain>"
//     with value "gs-verify=<token>"; the bare "<domain>" apex is also accepted
//     (exact token match still required) because many DNS panels publish TXT at
//     the apex and only the domain owner can set either name. Protection
//     configuration is therefore restricted to verified, owned assets.
//   - A tenant may never submit a URL or an arbitrary IP. Domains are strict
//     hostnames (no scheme/path/port/IP literal), and origin hosts are screened
//     by the SSRF guard in ssrf.go.
//
// The package splits pure validation/verification (unit-tested without a
// database) from the PostgreSQL-backed Store.
package asset

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"errors"
	"fmt"
	"net"
	"regexp"
	"strings"
	"time"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Status is the lifecycle of a protected asset.
type Status string

const (
	StatusPending  Status = "pending"  // created, awaiting DNS proof
	StatusVerified Status = "verified" // ownership proven; edge will protect it
)

// Verification challenge constants. A tenant sets a DNS TXT record
// "_garudashield.<domain>" whose value contains "gs-verify=<token>".
const (
	dnsChallengePrefix = "_garudashield"
	verifyTag          = "gs-verify="
)

// Errors. Callers map these to HTTP statuses; none reveals another tenant's data.
var (
	ErrInvalidDomain = errors.New("invalid domain")
	ErrInvalidOrigin = errors.New("invalid origin")
	ErrDomainTaken   = errors.New("domain already registered")
	ErrNotFound      = errors.New("asset not found")

	// ErrNotVerified means the caller has not (yet) proven ownership: either no
	// matching TXT record was published, or a record exists but its token is
	// wrong. It is the umbrella for the "not verified" family; use errors.As with
	// *VerifyError to tell "no record" from "wrong token".
	ErrNotVerified = errors.New("ownership not verified")

	// ErrDNSTimeout means the resolver did not answer in time — a transient
	// condition the tenant can retry, not a wrong record.
	ErrDNSTimeout = errors.New("dns lookup timed out")

	// ErrDNSUnavailable means the resolver itself failed (SERVFAIL, network
	// error, ...). Distinct from ErrNotVerified so callers never report a broken
	// resolver as "record not found".
	ErrDNSUnavailable = errors.New("dns lookup unavailable")
)

// VerifyError is returned by VerifyOwnership when ownership is not proven. It
// carries whether any TXT record was found at all (Missing) and which DNS names
// were queried (Candidates), so the API can give the tenant an actionable hint
// without ever accepting a record whose token does not match.
type VerifyError struct {
	Missing    bool
	Candidates []string
}

func (e *VerifyError) Error() string {
	if e.Missing {
		return "no TXT record found for " + strings.Join(e.Candidates, " or ")
	}
	return "TXT record found but the token did not match for " + strings.Join(e.Candidates, " or ")
}

// Is lets errors.Is(err, ErrNotVerified) hold for any VerifyError.
func (e *VerifyError) Is(target error) bool { return target == ErrNotVerified }

// Asset is a protected domain owned by exactly one tenant.
type Asset struct {
	ID          int64  `json:"id"`
	TenantID    string `json:"tenant"`
	Domain      string `json:"domain"`
	OriginHost  string `json:"originHost,omitempty"`
	OriginPort  int    `json:"originPort,omitempty"`
	Status      Status `json:"status"`
	VerifyToken string `json:"verifyToken"` // owner-only: needed to place the TXT record
	CreatedAt   int64  `json:"createdAt"`
	VerifiedAt  int64  `json:"verifiedAt"`
}

// TXTResolver is the subset of net.Resolver used for the ownership challenge.
type TXTResolver interface {
	LookupTXT(ctx context.Context, name string) ([]string, error)
}

// ChallengeName returns the DNS name a tenant must create a TXT record on.
func ChallengeName(domain string) string { return dnsChallengePrefix + "." + domain }

// ChallengeValue returns the TXT value that proves ownership of domain.
func ChallengeValue(token string) string { return verifyTag + token }

// ChallengeNames returns every DNS name accepted for proving ownership of
// domain, in priority order: the canonical "_garudashield.<domain>" first, then
// the bare "<domain>" as a compatibility fallback. Many DNS panels place a TXT
// record at the zone apex, and only the domain's own owner can publish a TXT
// record at either name — so accepting the bare name does not weaken the proof.
// The published instruction keeps using ChallengeName; the fallback only makes
// the check tolerant of real-world panel behaviour.
func ChallengeNames(domain string) []string {
	return []string{ChallengeName(domain), domain}
}

// VerifyOwnership confirms that domain's DNS serves the expected challenge tag.
// It queries ChallengeNames(domain) in order and accepts the tag either as the
// whole record or as a whitespace-separated field of a longer TXT record (so
// multi-string / multi-record answers work). The token comparison is exact.
//
// Failure modes are returned as sentinels: ErrNotVerified (via *VerifyError)
// when the record is absent or the token is wrong, ErrDNSTimeout on a resolver
// timeout, and ErrDNSUnavailable on any other resolver failure.
func VerifyOwnership(ctx context.Context, r TXTResolver, domain, token string) error {
	names := ChallengeNames(domain)
	if token == "" {
		return &VerifyError{Missing: true, Candidates: names}
	}
	if r == nil {
		r = net.DefaultResolver
	}
	want := ChallengeValue(token)

	sawRecords := false
	var lookupErr error
	for _, name := range names {
		txts, err := r.LookupTXT(ctx, name)
		if err != nil {
			if isNotFoundErr(err) {
				continue // name simply has no TXT yet — try the next candidate
			}
			if isTimeoutErr(err) {
				lookupErr = fmt.Errorf("%w: %v", ErrDNSTimeout, err)
			} else if lookupErr == nil {
				lookupErr = fmt.Errorf("%w: %v", ErrDNSUnavailable, err)
			}
			continue
		}
		if len(txts) > 0 {
			sawRecords = true
		}
		if matchTXT(txts, want) {
			return nil
		}
	}
	// A found-but-non-matching record is a definitive "wrong token" verdict and
	// must win over any transient error on a different candidate.
	if sawRecords {
		return &VerifyError{Missing: false, Candidates: names}
	}
	if lookupErr != nil {
		return lookupErr
	}
	return &VerifyError{Missing: true, Candidates: names}
}

func matchTXT(txts []string, want string) bool {
	for _, t := range txts {
		if strings.TrimSpace(t) == want {
			return true
		}
		for _, f := range strings.Fields(t) {
			if f == want {
				return true
			}
		}
	}
	return false
}

func isNotFoundErr(err error) bool {
	var dnsErr *net.DNSError
	return errors.As(err, &dnsErr) && dnsErr.IsNotFound
}

func isTimeoutErr(err error) bool {
	var dnsErr *net.DNSError
	return errors.As(err, &dnsErr) && dnsErr.IsTimeout
}

// ---------- pure validation (unit-tested without a database) ----------

var labelRe = regexp.MustCompile(`^[a-z0-9]([a-z0-9-]*[a-z0-9])?$`)

// reservedSuffixes are internal / non-public DNS suffixes that must never be
// accepted as a protected domain (defence against pointing the edge at internal
// infrastructure or special-use space).
var reservedSuffixes = []string{
	".local", ".localhost", ".internal", ".intranet", ".lan", ".home",
	".corp", ".invalid", ".test", ".example", ".onion", ".arpa",
}

// NormalizeDomain strictly validates and canonicalises a protected domain.
// It rejects URLs (scheme/path/port/userinfo), IP literals, single-label names,
// wildcards, and reserved internal suffixes.
func NormalizeDomain(raw string) (string, error) {
	d := strings.ToLower(strings.TrimSpace(raw))
	d = strings.TrimSuffix(d, ".")
	if d == "" {
		return "", ErrInvalidDomain
	}
	// Any of these means the caller sent a URL / authority, not a hostname.
	if strings.ContainsAny(d, "/:@?#[]\\ \t\r\n*") {
		return "", ErrInvalidDomain
	}
	if net.ParseIP(d) != nil {
		return "", ErrInvalidDomain
	}
	if !validHostname(d) || hasReservedSuffix(d) {
		return "", ErrInvalidDomain
	}
	return d, nil
}

// ValidateOrigin validates an optional origin host/port. An empty host means
// "no explicit origin". A host may be a strict hostname OR a public IP literal;
// IP literals are screened by the SSRF guard, so private/loopback/metadata
// addresses are rejected.
func ValidateOrigin(host string, port int) (string, int, error) {
	h := strings.ToLower(strings.TrimSpace(host))
	if h == "" && port == 0 {
		return "", 0, nil
	}
	if h == "" {
		return "", 0, ErrInvalidOrigin
	}
	if port < 0 || port > 65535 {
		return "", 0, ErrInvalidOrigin
	}
	if strings.ContainsAny(h, "/:@?#[]\\ \t\r\n*") {
		return "", 0, ErrInvalidOrigin
	}
	if ip := net.ParseIP(h); ip != nil {
		if BlockedIP(ip) {
			return "", 0, ErrBlockedTarget
		}
		return h, port, nil
	}
	if !validHostname(h) || hasReservedSuffix(h) {
		return "", 0, ErrInvalidOrigin
	}
	return h, port, nil
}

func validHostname(h string) bool {
	if len(h) == 0 || len(h) > 253 {
		return false
	}
	labels := strings.Split(h, ".")
	if len(labels) < 2 { // require a registrable FQDN, never a bare internal name
		return false
	}
	for _, l := range labels {
		if len(l) == 0 || len(l) > 63 || !labelRe.MatchString(l) {
			return false
		}
	}
	return true
}

func hasReservedSuffix(h string) bool {
	if h == "localhost" {
		return true
	}
	for _, s := range reservedSuffixes {
		if strings.HasSuffix(h, s) {
			return true
		}
	}
	return false
}

func newToken() (string, error) {
	b := make([]byte, 16)
	if _, err := rand.Read(b); err != nil {
		return "", err
	}
	return hex.EncodeToString(b), nil
}

// ---------- PostgreSQL store ----------

// Store persists protected assets. Every query is tenant-scoped.
type Store struct {
	pool *pgxpool.Pool
}

// New builds an asset store over the given pool.
func New(pool *pgxpool.Pool) *Store { return &Store{pool: pool} }

// Create registers a pending asset for tenantID. The caller must have already
// proven it may act for the tenant (session) and screened any origin host
// (SSRF). Domain and origin are re-validated here as defence in depth.
func (s *Store) Create(ctx context.Context, tenantID, domain, originHost string, originPort int) (Asset, error) {
	tenantID = strings.TrimSpace(tenantID)
	if tenantID == "" {
		return Asset{}, errors.New("tenant required")
	}
	d, err := NormalizeDomain(domain)
	if err != nil {
		return Asset{}, err
	}
	oh, op, err := ValidateOrigin(originHost, originPort)
	if err != nil {
		return Asset{}, err
	}
	token, err := newToken()
	if err != nil {
		return Asset{}, err
	}
	var a Asset
	err = s.pool.QueryRow(ctx,
		`INSERT INTO protected_assets
		   (tenant_id, domain, origin_host, origin_port, status, verify_token, created_at, verified_at)
		 VALUES ($1,$2,$3,$4,'pending',$5,$6,0)
		 RETURNING id, tenant_id, domain, origin_host, origin_port, status, verify_token, created_at, verified_at`,
		tenantID, d, oh, op, token, time.Now().Unix()).
		Scan(&a.ID, &a.TenantID, &a.Domain, &a.OriginHost, &a.OriginPort,
			&a.Status, &a.VerifyToken, &a.CreatedAt, &a.VerifiedAt)
	if err != nil {
		if isUniqueViolation(err) {
			return Asset{}, ErrDomainTaken
		}
		return Asset{}, fmt.Errorf("create asset: %w", err)
	}
	return a, nil
}

// CountByTenant returns how many protected domains the tenant currently holds,
// counting every status (pending and verified alike). It backs the per-plan
// domain cap enforced by the control plane.
func (s *Store) CountByTenant(ctx context.Context, tenantID string) (int64, error) {
	var n int64
	if err := s.pool.QueryRow(ctx,
		`SELECT COUNT(*) FROM protected_assets WHERE tenant_id = $1`, tenantID).Scan(&n); err != nil {
		return 0, err
	}
	return n, nil
}

// List returns the tenant's assets, newest first.
func (s *Store) List(ctx context.Context, tenantID string) ([]Asset, error) {
	rows, err := s.pool.Query(ctx,
		`SELECT id, tenant_id, domain, origin_host, origin_port, status, verify_token, created_at, verified_at
		 FROM protected_assets WHERE tenant_id = $1 ORDER BY created_at DESC, id DESC`, tenantID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()
	out := []Asset{}
	for rows.Next() {
		var a Asset
		if err := rows.Scan(&a.ID, &a.TenantID, &a.Domain, &a.OriginHost, &a.OriginPort,
			&a.Status, &a.VerifyToken, &a.CreatedAt, &a.VerifiedAt); err != nil {
			return nil, err
		}
		out = append(out, a)
	}
	return out, rows.Err()
}

// Get returns the tenant's asset by id, or ErrNotFound (also for another
// tenant's id — its existence is never disclosed).
func (s *Store) Get(ctx context.Context, tenantID string, id int64) (Asset, error) {
	var a Asset
	err := s.pool.QueryRow(ctx,
		`SELECT id, tenant_id, domain, origin_host, origin_port, status, verify_token, created_at, verified_at
		 FROM protected_assets WHERE id = $1 AND tenant_id = $2`, id, tenantID).
		Scan(&a.ID, &a.TenantID, &a.Domain, &a.OriginHost, &a.OriginPort,
			&a.Status, &a.VerifyToken, &a.CreatedAt, &a.VerifiedAt)
	if err != nil {
		if errors.Is(err, pgx.ErrNoRows) {
			return Asset{}, ErrNotFound
		}
		return Asset{}, err
	}
	return a, nil
}

// MarkVerified flips a pending asset to verified. A second call (already
// verified, or another tenant's id) is ErrNotFound.
func (s *Store) MarkVerified(ctx context.Context, tenantID string, id int64) error {
	ct, err := s.pool.Exec(ctx,
		`UPDATE protected_assets SET status='verified', verified_at=$3
		 WHERE id=$1 AND tenant_id=$2 AND status='pending'`,
		id, tenantID, time.Now().Unix())
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

// Delete removes the tenant's asset. A missing / foreign id is ErrNotFound.
func (s *Store) Delete(ctx context.Context, tenantID string, id int64) error {
	ct, err := s.pool.Exec(ctx,
		`DELETE FROM protected_assets WHERE id=$1 AND tenant_id=$2`, id, tenantID)
	if err != nil {
		return err
	}
	if ct.RowsAffected() == 0 {
		return ErrNotFound
	}
	return nil
}

func isUniqueViolation(err error) bool {
	var pgErr *pgconn.PgError
	return errors.As(err, &pgErr) && pgErr.Code == "23505"
}
