package asset

import (
	"context"
	"errors"
	"os"
	"testing"

	"github.com/ahkurdev/garudashield/internal/db"
)

// TestAssetStoreTenantIsolationPG locks the tenant-scoping contract of the
// PostgreSQL store: a tenant can never read, verify, or delete another tenant's
// asset, and a repeated MarkVerified is a no-op (idempotent) rather than a
// second flip. Runs only when GS_DATABASE_URL points at a reachable Postgres.
func TestAssetStoreTenantIsolationPG(t *testing.T) {
	dsn := os.Getenv("GS_DATABASE_URL")
	if dsn == "" {
		t.Skip("GS_DATABASE_URL not set")
	}
	pool, err := db.Connect()
	if err != nil {
		t.Skipf("postgres unavailable: %v", err)
	}
	defer pool.Close()
	ctx := context.Background()
	if err := db.Migrate(ctx, pool); err != nil {
		t.Fatal(err)
	}

	const owner = "asset-itest-owner"
	const intruder = "asset-itest-intruder"
	cleanup := func() {
		_, _ = pool.Exec(ctx, `DELETE FROM protected_assets WHERE tenant_id IN ($1,$2)`, owner, intruder)
		_, _ = pool.Exec(ctx, `DELETE FROM tenants WHERE id IN ($1,$2)`, owner, intruder)
	}
	cleanup()
	defer cleanup()
	for _, id := range []string{owner, intruder} {
		if _, err := pool.Exec(ctx, `INSERT INTO tenants (id,name,plan) VALUES ($1,$1,'free')`, id); err != nil {
			t.Fatal(err)
		}
	}

	s := New(pool)
	a, err := s.Create(ctx, owner, "asset-itest.example.com", "", 0)
	if err != nil {
		t.Fatalf("create: %v", err)
	}
	if a.Domain != "asset-itest.example.com" || a.Status != StatusPending || a.VerifyToken == "" {
		t.Fatalf("unexpected asset: %+v", a)
	}

	// (9) Another tenant must not see/act on it — ErrNotFound, never a
	// different-tenant success.
	if _, err := s.Get(ctx, intruder, a.ID); !errors.Is(err, ErrNotFound) {
		t.Errorf("intruder Get: got %v, want ErrNotFound", err)
	}
	if err := s.MarkVerified(ctx, intruder, a.ID); !errors.Is(err, ErrNotFound) {
		t.Errorf("intruder MarkVerified: got %v, want ErrNotFound", err)
	}
	if err := s.Delete(ctx, intruder, a.ID); !errors.Is(err, ErrNotFound) {
		t.Errorf("intruder Delete: got %v, want ErrNotFound", err)
	}

	// (10) The owner verifies once; a second verify must not double-flip.
	if err := s.MarkVerified(ctx, owner, a.ID); err != nil {
		t.Fatalf("owner MarkVerified: %v", err)
	}
	got, err := s.Get(ctx, owner, a.ID)
	if err != nil {
		t.Fatal(err)
	}
	if got.Status != StatusVerified {
		t.Fatalf("status = %q, want verified", got.Status)
	}
	if err := s.MarkVerified(ctx, owner, a.ID); !errors.Is(err, ErrNotFound) {
		t.Errorf("second MarkVerified: got %v, want ErrNotFound (already verified)", err)
	}
}
