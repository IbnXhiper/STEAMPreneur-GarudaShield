package asset

import (
	"context"
	"errors"
	"net"
	"testing"
)

func TestBlockedIP(t *testing.T) {
	blocked := []string{
		"127.0.0.1", "10.1.2.3", "172.16.0.1", "192.168.1.1",
		"169.254.169.254", // cloud metadata
		"100.64.0.1",      // CGNAT
		"0.0.0.0", "255.255.255.255",
		"192.0.2.1", "198.51.100.1", "203.0.113.1", "198.18.0.1",
		"224.0.0.1", "240.0.0.1",
		"::1", "fe80::1", "fc00::1", "ff02::1", "2001:db8::1",
		"::ffff:127.0.0.1", // v4-mapped loopback
	}
	for _, s := range blocked {
		ip := net.ParseIP(s)
		if ip == nil {
			t.Fatalf("bad test ip %q", s)
		}
		if !BlockedIP(ip) {
			t.Errorf("expected %s to be blocked", s)
		}
	}
	if !BlockedIP(nil) {
		t.Error("nil IP must be blocked (fail-closed)")
	}

	allowed := []string{"8.8.8.8", "1.1.1.1", "93.184.216.34", "2606:4700:4700::1111", "2606:2800:220:1:248:1893:25c8:1946"}
	for _, s := range allowed {
		if BlockedIP(net.ParseIP(s)) {
			t.Errorf("expected %s to be allowed", s)
		}
	}
}

type fakeIPResolver struct {
	m   map[string][]string
	err error
}

func (f fakeIPResolver) LookupIPAddr(_ context.Context, host string) ([]net.IPAddr, error) {
	if f.err != nil {
		return nil, f.err
	}
	ips, ok := f.m[host]
	if !ok {
		return nil, errors.New("no such host")
	}
	out := make([]net.IPAddr, 0, len(ips))
	for _, s := range ips {
		out = append(out, net.IPAddr{IP: net.ParseIP(s)})
	}
	return out, nil
}

func TestCheckHost(t *testing.T) {
	ctx := context.Background()
	r := fakeIPResolver{m: map[string][]string{
		"public.example.com":   {"93.184.216.34"},
		"internal.example.com": {"10.0.0.5"},
		"mixed.example.com":    {"93.184.216.34", "127.0.0.1"},
		"meta.example.com":     {"169.254.169.254"},
	}}
	if err := CheckHost(ctx, r, "public.example.com"); err != nil {
		t.Fatalf("public host rejected: %v", err)
	}
	for _, h := range []string{"internal.example.com", "mixed.example.com", "meta.example.com"} {
		if err := CheckHost(ctx, r, h); !errors.Is(err, ErrBlockedTarget) {
			t.Errorf("expected %s blocked, got %v", h, err)
		}
	}
	if err := CheckHost(ctx, r, "missing.example.com"); err == nil {
		t.Error("expected resolution error for unknown host")
	}
}

func TestGuardDialerControl(t *testing.T) {
	d := GuardDialer(nil)
	if d.Control == nil {
		t.Fatal("Control callback not installed")
	}
	if err := d.Control("tcp", "93.184.216.34:443", nil); err != nil {
		t.Errorf("public target rejected: %v", err)
	}
	for _, addr := range []string{"127.0.0.1:80", "10.0.0.1:80", "169.254.169.254:80", "[::1]:80"} {
		if err := d.Control("tcp", addr, nil); !errors.Is(err, ErrBlockedTarget) {
			t.Errorf("expected %s blocked at dial, got %v", addr, err)
		}
	}
}
