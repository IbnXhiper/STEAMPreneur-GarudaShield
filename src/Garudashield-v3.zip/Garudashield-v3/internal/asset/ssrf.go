// SSRF guard for tenant-supplied network targets (OWASP A10 / API7 SSRF).
//
// GarudaShield never fetches a URL a customer submits. Protection is restricted
// to assets the account has proven it owns (DNS TXT challenge, see asset.go),
// and any host a tenant may point at is screened here: hostnames only (no URL,
// scheme, path, or port smuggling), no IP literal embedded in a domain, and no
// address that resolves into private, loopback, link-local, multicast, CGNAT,
// documentation, or cloud-metadata space (e.g. 169.254.169.254).
//
// The screens are pure and unit-tested: they never open a connection. GuardDialer
// is provided for the (future) case of proxying to a tenant-owned origin: the
// Control callback re-checks the *resolved* IP at connect time, which defeats
// DNS-rebinding (TOCTOU) tricks.
package asset

import (
	"context"
	"errors"
	"fmt"
	"net"
	"syscall"
)

// ErrBlockedTarget is returned when a target address is not publicly routable.
var ErrBlockedTarget = errors.New("target address is not publicly routable")

// ErrNoAddr is returned when a hostname resolves to zero addresses.
var ErrNoAddr = errors.New("host did not resolve to any address")

// blockedCIDRs are the non-public ranges that must never be reachable through a
// tenant-supplied target. net.IP.IsPrivate/IsLoopback cover the common ones;
// this list adds CGNAT, benchmark, documentation, and reserved space.
var blockedCIDRs = func() []*net.IPNet {
	raw := []string{
		"0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8",
		"169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24",
		"192.88.99.0/24", "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24",
		"203.0.113.0/24", "224.0.0.0/4", "240.0.0.0/4", "255.255.255.255/32",
		"::/128", "::1/128", "fc00::/7", "fe80::/10", "ff00::/8",
		"2001:db8::/32", "64:ff9b::/96", "2002::/16",
	}
	out := make([]*net.IPNet, 0, len(raw))
	for _, c := range raw {
		if _, n, err := net.ParseCIDR(c); err == nil {
			out = append(out, n)
		}
	}
	return out
}()

// BlockedIP reports whether an address is unsafe to reach. A nil IP is blocked
// (fail-closed). IPv4-mapped IPv6 addresses are normalised to IPv4 first so the
// v4 ranges apply.
func BlockedIP(ip net.IP) bool {
	if ip == nil {
		return true
	}
	if v4 := ip.To4(); v4 != nil {
		ip = v4
	}
	if ip.IsLoopback() || ip.IsPrivate() || ip.IsUnspecified() ||
		ip.IsLinkLocalUnicast() || ip.IsLinkLocalMulticast() ||
		ip.IsInterfaceLocalMulticast() || ip.IsMulticast() {
		return true
	}
	for _, n := range blockedCIDRs {
		if n.Contains(ip) {
			return true
		}
	}
	return false
}

// IPResolver is the subset of net.Resolver used to screen a hostname. It is an
// interface so tests can inject a fake resolver.
type IPResolver interface {
	LookupIPAddr(ctx context.Context, host string) ([]net.IPAddr, error)
}

// CheckHost resolves host and fails if it is empty or resolves to any blocked
// address. It performs DNS resolution only — it never connects — so it cannot
// be turned into an SSRF sink.
func CheckHost(ctx context.Context, r IPResolver, host string) error {
	if r == nil {
		r = net.DefaultResolver
	}
	addrs, err := r.LookupIPAddr(ctx, host)
	if err != nil {
		return err
	}
	if len(addrs) == 0 {
		return ErrNoAddr
	}
	for _, a := range addrs {
		if BlockedIP(a.IP) {
			return ErrBlockedTarget
		}
	}
	return nil
}

// GuardDialer returns a copy of base (or a fresh dialer) whose Control callback
// rejects any connection whose destination IP is blocked. Because Control runs
// after DNS resolution, an attacker cannot pass a benign name at validation and
// then rebind it to 127.0.0.1 before the dial.
func GuardDialer(base *net.Dialer) *net.Dialer {
	if base == nil {
		base = &net.Dialer{}
	}
	base.Control = func(network, address string, _ syscall.RawConn) error {
		host, _, err := net.SplitHostPort(address)
		if err != nil {
			return err
		}
		ip := net.ParseIP(host)
		if ip == nil {
			return fmt.Errorf("ssrf: unresolved address %q", address)
		}
		if BlockedIP(ip) {
			return fmt.Errorf("%w: %s", ErrBlockedTarget, address)
		}
		return nil
	}
	return base
}
