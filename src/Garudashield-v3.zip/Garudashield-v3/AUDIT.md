# AUDIT — GarudaShield v3 (2026-08-27)

Audit statis + dinamis seluruh codebase v3 (Go engine + Rust WAF + Next.js dashboard).
Tujuan: ukur kesehatan kode, paritas v2, dan daftar kekurangan/risiko sebelum produksi.

## Metode
- `go build ./...`, `go vet ./...` — bersih.
- `go test ./internal/... ./cmd/... -count=1` — 21/21 package lolos.
- Inventarisasi package, endpoint, marker TODO/FIXME, scan keamanan (secret/crypto/eval),
  cek paritas modul v2, cek coverage test, baca config + edge server + docker-compose.

## Kesehatan kode (HIJAU)
- Build & vet bersih; 21/21 test package hijau.
- Ukuran: ~10.7k LoC Go, 81 LoC Rust (wafmatcher cdylib), ~3.5k LoC TS dashboard.
- Tidak ada TODO/FIXME/HACK menggantung (hanya `os.Exit(1)` legitim di boot).
- Paritas modul engine v2→v3 LENGKAP: layer4, layer7, waf, fingerprint, challenge,
  anomaly, reputation, analyzer, access (captcha/token/hold), admin REST+SSE,
  cluster PeerSync, statestore hybrid L1/L2, alerts (telegram/discord/slack/smtp).
- Endpoint admin: 46 route v2-compatible + baru `/api/geo`, `/api/whoami`.
- `rust/wafmatcher/target` sudah di-.gitignore (tidak bloat repo).

## Temuan & Kekurangan

### [CRITICAL] TLS terminasi tidak diimplementasikan
- `cmd/garudashield/main.go` hanya `srv.ListenAndServe()` (HTTP plaintext).
- `config.Fingerprint.UseTLS` / `https` ada tapi TIDAK dipakai di server.
- Dampak: admin key (`x-gs-key`) & manajemen traffic melintasi plaintext →
  key bisa di-intercept di jaringan. Perlu `ListenAndServeTLS` + sertifikat,
  ATAU dokumentasikan secara eksplisit bahwa TLS di-terminasi di front (nginx/anycast).

### [HIGH] Admin API tidak punya brute-force protection
- `admin.auth` cek `x-gs-key`/`Authorization: Bearer` via `subtle.ConstantTimeCompare`
  (timing-safe — bagus) TAPI tidak ada rate-limit/lockout per-IP setelah N gagal.
- Dampak: key bisa di-brute-force. Perlu middleware throttling (pakai `ratelimit`
  internal) di `auth()` sebelum bandingkan secret.

### [MEDIUM] Default secret insecure
- `internal/access/access.go:41` fallback `garudashield-insecure-default` bila
  `AccessSecret` kosong. Boot harus WARN (atau fail) bila secret kosong di mode produksi.

### [MEDIUM] eBPF / XDP L4 offload tidak ada
- V3 hanya L4 userspace (SYN-half-open / port-scan / bogon / UDP-amp).
- DDoS L4 volumetric besar butuh eBPF/XDP di kernel. Desain sebut "menyusul" —
  belum ada stub sama sekali. Rekomendasi: minimal stub + dokumentasi batas userspace.

### [MEDIUM] Attack-suite release gate belum ditulis
- `log.md` nyatakan 7 kategori attack-suite + self-test harian "belum". Ini gate
  rilis ke produksi (v2→v3 cutover). Tanpa itu, regresi paritas tidak terkunci.

### [LOW] Test coverage bolong di paket kritis
- `internal/geo` (0 test — butuh fixture MMDB), `internal/config` (0 test —
  parsing/merge/default), `internal/reqview` (0 test).
- 22 test file / 51 source file. `shield_test.go` ada tapi belum cover semua mode
  (aggressive / emergency / flood fast-path).

### [LOW] GeoIP belum di-doc ke CUTOVER + MMDB tidak di-repo
- `/api/geo` & `/api/whoami` baru, belum masuk `docs/CUTOVER.md` § admin API.
- Database MMDB harus di-fetch manual (`tools/fetch-geodb.ps1`); tidak ada di repo.

### [LOW] Whitelist / reputation belum pindah ke statestore L2
- Blocklist sudah hybrid L1/L2; whitelist & reputation masih ephemeral (L1).
- Cluster PeerSync baru cover blocklist, belum whitelist/reputation lintas node.

### [LOW] Docker Redis tidak auto-wire
- `docker compose --profile redis up` jalan, tapi engine config
  `cluster.redis.enabled` tetap false → butuh edit config manual.
  Bisa di-auto-enable bila env `GS_REDIS=on` terdeteksi.

### [LOW] Dashboard BFF key pass-through
- `GS_API_KEY` (dashboard env) dilewatkan ke engine. Aman asal env tidak bocor.
  `.env.example` `GS_API_KEY=` kosong → di dev admin API loopback-only (sesuai desain).

## Prioritas perbaikan (jika lanjut ke produksi)
1. TLS: implement `ListenAndServeTLS` ATAU dokumentasikan terminasi di front (CRITICAL).
2. Admin API brute-force throttle (HIGH).
3. Boot-fail / warn bila secret kosong di produksi (MEDIUM).
4. Tulis attack-suite gate + self-test harian (MEDIUM, gate rilis).
5. eBPF/XDP stub + batas userspace (MEDIUM).
6. Test untuk geo/config/reqview + mode-shield (LOW).
7. Doc geo/whoami di CUTOVER; auto-wire Redis di docker (LOW).

## Yang SUDAH BAIK (pertahankan)
- fail-closed budget 50ms; paritas quirk v2 disengaja dipertahankan.
- trustProxy hardening (hanya percaya XFF bila dari trusted proxy).
- graceful shutdown + anti-slowloris timeouts + request queue backpressure.
- statestore fallback lokal otomatis bila Redis mati.
- GeoIP resolver nil-safe, offline, tidak pernah gagal verdict.
